# 导入DiffusionPipeline类，这是Diffusers库的核心组件，用于创建和管理扩散模型管道
# 就像一个厨房里的食物处理器，它能将原料（提示词）加工成成品（图像）
from diffusers import DiffusionPipeline
# 导入PyTorch库，这是一个用于深度学习的开源机器学习库
# 类似于乐高积木，它提供了构建神经网络所需的基础组件
import torch

# 设置预训练模型的ID，这里使用的是Stability AI的SDXL基础模型1.0版本
# 就像指定要使用的食谱的名称，告诉系统我们想用哪个模型
pipe_id = "stabilityai/stable-diffusion-xl-base-1.0"
# 从预训练模型创建扩散管道，设置为float16精度以节省显存，并将模型移至CUDA设备（GPU）上运行
# 相当于按照食谱准备好所有工具和材料，并放在厨房台面（GPU）上准备开始工作
pipe = DiffusionPipeline.from_pretrained(pipe_id, torch_dtype=torch.float16).to("cuda")

# 设置生成图像的提示词，描述要生成的是一个戴兜帽的黑客的玩具脸，像素艺术风格
# 就像告诉厨师你想要什么样的菜肴
prompt = "toy_face of a hacker with a hoodie, pixel art"
# 使用提示词生成图像，设置推理步骤为30，注意力缩放为1.0，并设置随机种子为0以确保结果可复现
# 这就像按下食物处理器的启动按钮，开始制作食物，并指定特定的处理时间和方式
image = pipe(
    prompt, num_inference_steps=30, cross_attention_kwargs={"scale": 1.0}, generator=torch.manual_seed(0)
).images[0]
# 这行代码被注释掉了，原本是用来显示生成的图像
#print(image)

# 为模型设置LoRA适配器，名为"toy"，这会改变模型的行为以适应特定风格
# 类似于在食物处理器上安装一个特殊的附件，使其能够以特定方式处理食物
pipe.set_adapters("toy")

# 更新提示词，移除了"pixel art"部分
# 相当于稍微修改了我们的食谱要求
prompt = "toy_face of a hacker with a hoodie"
# 设置LoRA的缩放系数为0.9，控制LoRA适配器对原始模型的影响程度
# 就像调整特殊附件的强度，决定它对最终结果的影响有多大
lora_scale = 0.9
# 使用新的提示词和LoRA设置生成图像
# 再次启动食物处理器，但这次使用了特殊附件和稍微不同的配方
image = pipe(
    prompt, num_inference_steps=30, cross_attention_kwargs={"scale": lora_scale}, generator=torch.manual_seed(0)
).images[0]
# 显示生成的图像
image

# 禁用LoRA适配器，恢复到原始模型状态
# 相当于移除食物处理器上的特殊附件，回到基本配置
pipe.disable_lora()
# 保持与之前相同的提示词
# 使用相同的食谱
prompt = "toy_face of a hacker with a hoodie"
# 使用原始模型（没有LoRA）生成图像
# 用标准配置的食物处理器制作食物
image = pipe(prompt, num_inference_steps=30, generator=torch.manual_seed(0)).images[0]
# 显示生成的图像
image
