# 导入DiffusionPipeline类，这是一个用于运行扩散模型的高级API
# 扩散模型就像一个数字艺术家，可以从随机噪声中逐步创造出清晰的图像
from diffusers import DiffusionPipeline
# 导入PyTorch库，这是深度学习的基础框架，提供了张量计算和GPU加速功能
# 就像是AI世界的"电力系统"，为各种模型提供计算能力
import torch

# 设置预训练模型的ID，指向Stability AI发布的Stable Diffusion XL基础模型
# 这就像选择一位特定的数字艺术家来为我们创作
pipe_id = "stabilityai/stable-diffusion-xl-base-1.0"
# 从预训练模型创建扩散管道实例，设置为半精度浮点数(float16)以节省内存，并移至GPU加速计算
# 这相当于请这位艺术家坐到配备了高性能画笔(GPU)的工作台前，准备开始创作
pipe = DiffusionPipeline.from_pretrained(pipe_id, torch_dtype=torch.float16).to("cuda")

# 设置文本提示，描述我们想要生成的图像：戴着连帽衫的黑客的玩具脸
# 这就像告诉艺术家："请画一个戴着连帽衫的黑客，但要用玩具风格的脸"
prompt = "toy_face of a hacker with a hoodie"

# 设置LoRA缩放因子为0.9，控制LoRA适配器对原始模型的影响程度
# 这就像调整艺术家的创作风格倾向，0.9表示保留90%的特定风格特征
lora_scale = 0.9
# 使用模型生成图像，设置推理步骤为30步，应用LoRA缩放，并固定随机种子为0以确保结果可复现
# 这相当于艺术家开始创作，需要30个步骤完成作品，并且每次都从同一个草图开始(固定种子)
image = pipe(
    prompt, num_inference_steps=30, cross_attention_kwargs={"scale": lora_scale}, generator=torch.manual_seed(0)
).images[0]
#print(image)  # 这行被注释掉了，原本用于显示生成的图像

# 加载像素艺术风格的LoRA权重到模型中
# 这就像给艺术家提供了一套像素艺术的工具和技法指南，让他能够创作像素风格的作品
pipe.load_lora_weights("nerijs/pixel-art-xl", weight_name="pixel-art-xl.safetensors", adapter_name="pixel")
# 激活名为"pixel"的适配器，告诉模型我们想要使用像素艺术风格
# 相当于告诉艺术家："现在请使用像素艺术风格来创作"
pipe.set_adapters("pixel")

# 更新提示文本，明确指定我们想要像素艺术风格的戴连帽衫的黑客图像
# 这是给艺术家的新指令："请画一个戴连帽衫的黑客，使用像素艺术风格"
prompt = "a hacker with a hoodie, pixel art"
# 再次使用模型生成图像，保持相同的参数设置，但使用新的提示和已激活的像素艺术适配器
# 艺术家现在用像素艺术风格，按照相同的创作流程再次创作一幅作品
image = pipe(
    prompt, num_inference_steps=30, cross_attention_kwargs={"scale": lora_scale}, generator=torch.manual_seed(0)
).images[0]
#print(image)  # 这行同样被注释掉了，原本用于显示第二张生成的图像