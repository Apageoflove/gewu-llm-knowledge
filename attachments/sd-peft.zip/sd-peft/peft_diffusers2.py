# 导入PyTorch库，这是一个用于深度学习的开源库，提供了张量计算和GPU加速等功能
# 例如：我们可以用torch.tensor([1, 2, 3])创建一个简单的张量，或使用torch.nn构建神经网络
import torch
# 从diffusers库导入DiffusionPipeline类，这是一个用于运行扩散模型的高级API
# 扩散模型是一种生成模型，可以从噪声中逐步"去噪"生成图像，就像从模糊照片中逐渐显现清晰图像
from diffusers import DiffusionPipeline

# 从预训练模型创建一个扩散管道实例
# 这就像从商店购买一台已经调试好的专业相机，我们直接获取一个训练好的模型
# stabilityai/stable-diffusion-xl-base-1.0是一个强大的图像生成模型
# torch_dtype=torch.float16设置模型使用半精度浮点数，可以节省内存并加快推理速度
# to("cuda")将模型移动到GPU上以加速计算，就像把复杂计算任务交给专用计算机而不是普通计算器
pipeline = DiffusionPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0", torch_dtype=torch.float16
).to("cuda")

# 加载LoRA权重到模型中
# LoRA(Low-Rank Adaptation)是一种微调大型模型的高效方法，只需更新少量参数
# 这就像给相机安装特殊滤镜，使它能够拍摄特定风格的照片
# 这里加载的是一个名为"super-cereal"的风格适配器，可以让生成的图像呈现麦片盒风格
pipeline.load_lora_weights(
    "ostris/super-cereal-sdxl-lora",
    weight_name="cereal_box_sdxl_v1.safetensors",
    adapter_name="cereal"
)
# 激活名为"cereal"的适配器
# 这就像在相机上选择使用哪个滤镜，告诉模型我们想要使用麦片盒风格进行生成
pipeline.set_adapters("cereal")
# 使用模型生成图像，输入是文本提示"寿司卷形状像可爱的猫脸"
# 就像告诉艺术家"我想要一幅看起来像猫脸的寿司画"，模型会根据这个描述生成图像
# images[0]表示获取生成的第一张图像（如果生成了多张）
image = pipeline("sushi rolls shaped like kawaii cat faces").images[0]
# 这行代码被注释掉了，原本用于显示生成的图像
# 如果取消注释，将会显示生成的图像
#print(image)
