# 导入DiffusionPipeline类，这是一个用于运行扩散模型的高级API
# 扩散模型就像一个数字画家，能够从文字描述中创造出图像
from diffusers import DiffusionPipeline
# 导入PyTorch库，这是深度学习的基础框架，提供了张量计算和GPU加速功能
# 就像是AI世界的"发动机"，为各种模型提供计算动力
import torch

# 设置预训练模型的ID，指向Stability AI发布的Stable Diffusion XL基础模型
# 这就像选择一位特定的数字艺术家来为我们创作
pipe_id = "stabilityai/stable-diffusion-xl-base-1.0"
# 从预训练模型创建扩散管道实例，设置为半精度浮点数(float16)以节省内存，并移至GPU加速计算
# 这相当于请这位艺术家坐到配备了高性能画笔(GPU)的工作台前，准备开始创作
pipe = DiffusionPipeline.from_pretrained(pipe_id, torch_dtype=torch.float16).to("cuda")

# 重新启用LoRA适配器功能，之前我们曾经禁用过它
# 这就像重新给艺术家提供特殊的绘画工具，让他能够使用特定的绘画风格
pipe.enable_lora()  # enable lora again, after we disabled it above
# 设置文本提示，描述我们想要生成的图像：戴着连帽衫的黑客的玩具脸，像素艺术风格
# 这就像告诉艺术家："请画一个戴着连帽衫的黑客，使用玩具风格的脸，并采用像素艺术风格"
prompt = "toy_face of a hacker with a hoodie, pixel art"
# 设置适配器权重比例，只在UNet模型的下采样部分应用权重为1的像素风格，其他部分不应用（权重为0）
# 这就像告诉艺术家："在画草图阶段使用100%的像素风格技巧，但在细节和最终修饰阶段不要使用"
adapter_weight_scales = {"unet": {"down": 1, "mid": 0, "up": 0}}
# 激活"pixel"适配器并应用上面定义的权重比例
# 相当于让艺术家拿起像素风格的画笔，但只在特定的创作阶段使用它
pipe.load_lora_weights("nerijs/pixel-art-xl", weight_name="pixel-art-xl.safetensors", adapter_name="pixel")
pipe.set_adapters("pixel", adapter_weight_scales)
# 使用模型生成图像，设置推理步骤为30步，并固定随机种子为0以确保结果可复现
# 这相当于艺术家开始创作，需要30个步骤完成作品，并且每次都从同一个草图开始(固定种子)
image = pipe(prompt, num_inference_steps=30, generator=torch.manual_seed(0)).images[0]
#print(image)  # 这行被注释掉了，原本用于显示生成的图像

# 修改适配器权重比例，这次只在UNet模型的中间部分应用权重为1的像素风格
# 这就像告诉艺术家："在构图和主体结构阶段使用100%的像素风格技巧，但在草图和最终修饰阶段不要使用"
adapter_weight_scales = {"unet": {"down": 0, "mid": 1, "up": 0}}
# 重新设置"pixel"适配器的权重比例
# 相当于让艺术家调整像素风格画笔的使用方式，现在只在创作的中间阶段使用它
pipe.set_adapters("pixel", adapter_weight_scales)
# 再次使用模型生成图像，使用相同的提示和参数，但适配器权重比例不同
# 艺术家再次创作，但这次改变了像素风格的应用方式，会产生不同的艺术效果
image = pipe(prompt, num_inference_steps=30, generator=torch.manual_seed(0)).images[0]
#print(image)  # 这行被注释掉了，原本用于显示生成的图像

# 再次修改适配器权重比例，这次只在UNet模型的上采样部分应用权重为1的像素风格
# 这就像告诉艺术家："在最终细节和修饰阶段使用100%的像素风格技巧，但在前期创作阶段不要使用"
adapter_weight_scales = { "unet": { "down": 0, "mid": 0, "up": 1} }
# 重新设置"pixel"适配器的权重比例
# 相当于让艺术家再次调整像素风格画笔的使用方式，现在只在创作的最后阶段使用它
pipe.set_adapters("pixel", adapter_weight_scales)
# 第三次使用模型生成图像，使用相同的提示和参数，但适配器权重比例又有不同
# 艺术家第三次创作，使用了另一种像素风格的应用方式，会产生与前两次不同的艺术效果
image = pipe(prompt, num_inference_steps=30, generator=torch.manual_seed(0)).images[0]
#print(image)  # 这行被注释掉了，原本用于显示生成的图像

# 为"toy"风格适配器设置一个简单的权重比例0.5
# 这就像告诉艺术家："使用50%的玩具风格元素"，相当于半强度的玩具风格效果
adapter_weight_scales_toy = 0.5
# 为"pixel"风格适配器设置一个复杂的权重比例结构，在不同的模型部分和块中使用不同的权重
# 这就像给艺术家一个详细的指导方案："在草图阶段使用90%的像素风格，在最终修饰的第一部分使用60%的像素风格，
# 在最终修饰的第二部分，对不同的细节分别使用40%、80%和100%的像素风格"
adapter_weight_scales_pixel = {
    "unet": {
        "down": 0.9,  # 在下采样部分的所有Transformer层使用0.9的权重比例
        # "mid"  # 因为在这个例子中没有给出"mid"的值，所以中间部分的所有Transformer层将使用默认的1.0权重比例
        "up": {
            "block_0": 0.6,  # 上采样部分的第0个块中的所有3个Transformer层使用0.6的权重比例
            "block_1": [0.4, 0.8, 1.0],  # 上采样部分的第1个块中的3个Transformer层分别使用0.4、0.8和1.0的权重比例
        }
    }
}
# 同时激活"toy"和"pixel"两种适配器，并分别应用它们的权重比例
# 这就像让艺术家同时使用玩具风格和像素风格的技巧，但按照不同的比例混合这两种风格
pipe.set_adapters(["toy", "pixel"], [adapter_weight_scales_toy, adapter_weight_scales_pixel])
# 使用两种混合风格生成最终图像
# 艺术家现在创作一幅融合了玩具风格和像素风格的作品，根据指定的比例在不同创作阶段应用不同强度的风格元素
image = pipe(prompt, num_inference_steps=30, generator=torch.manual_seed(0)).images[0]
#print(image)  # 这行被注释掉了，原本用于显示最终生成的图像