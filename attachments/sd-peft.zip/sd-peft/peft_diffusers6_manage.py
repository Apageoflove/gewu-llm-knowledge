# 导入DiffusionPipeline类，这是一个用于运行扩散模型的高级API
# 扩散模型就像一个数字画家，能够从文字描述中创造出图像
from diffusers import DiffusionPipeline
# 导入PyTorch库，这是深度学习的基础框架，提供了张量计算和GPU加速功能
# 就像是AI世界的"发动机"，为各种模型提供计算动力
import torch

# 设置预训练模型的ID，指向Stability AI发布的Stable Diffusion XL基础模型
# 这就像选择一位特定的数字艺术家来为我们创作
pipe_id = "stabilityai/stable-diffusion-xl-base-1.0"
# 从预训练模型创建扩散管道实例，设置为半精度浮点数(float16)以节省内存，并移至GPU加速计算
# 这相当于请这位艺术家坐到配备了高性能画笔(GPU)的工作台前，准备开始创作
pipe = DiffusionPipeline.from_pretrained(pipe_id, torch_dtype=torch.float16).to("cuda")
pipe.load_lora_weights("nerijs/pixel-art-xl", weight_name="pixel-art-xl.safetensors", adapter_name="pixel")
#pipe.load_lora_weights("CiroN2022/toy-face", weight_name="toy_face_sdxl.safetensors", adapter_name="toy")
#pipe.set_adapters(["toy", "pixel"])
pipe.set_adapters(["pixel"])
# 获取当前激活的所有适配器（LoRA）
# 这就像查看艺术家当前正在使用哪些特殊绘画工具
# 例如：就像确认画家是否同时使用了水彩和油画技法
active_adapters = pipe.get_active_adapters()
# 显示当前激活的适配器列表
# 结果显示当前有两个激活的适配器："toy"（玩具风格）和"pixel"（像素艺术风格）
print(active_adapters)
["toy", "pixel"]

# 获取模型各组件中加载的所有适配器
# 这就像详细检查艺术家在不同创作阶段使用的所有工具
# 例如：查看在草图、上色和细节处理阶段分别使用了哪些特殊技法
list_adapters_component_wise = pipe.get_list_adapters()
# 显示各组件中的适配器列表
# 结果显示在文本编码器、U-Net模型和第二文本编码器中都加载了"toy"和"pixel"两种适配器
# 这就像艺术家在构思、主体创作和细节处理的所有阶段都准备了玩具风格和像素风格的技法
print(list_adapters_component_wise)
{"text_encoder": ["toy", "pixel"], "unet": ["toy", "pixel"], "text_encoder_2": ["toy", "pixel"]}

# 删除名为"toy"的适配器
# 这就像让艺术家放下玩具风格的绘画工具，不再使用这种风格进行创作
# 例如：告诉画家"不要再使用卡通风格的技法，专注于其他风格"
pipe.delete_adapters("toy")
# 再次获取当前激活的适配器，确认"toy"适配器已被删除
# 结果显示现在只有"pixel"（像素艺术风格）适配器处于激活状态
# 这表明艺术家现在只使用像素风格的技法进行创作
pipe.get_active_adapters()
["pixel"]
