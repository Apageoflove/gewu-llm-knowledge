-- 性能优化相关SQL
-- 为用户表添加索引优化查询性能

-- 1. 为用户名添加索引（用于登录和用户名搜索）
ALTER TABLE sys_user ADD INDEX idx_user_name (user_name);

-- 2. 为手机号添加索引（用于手机号搜索和唯一性检查）
ALTER TABLE sys_user ADD INDEX idx_phonenumber (phonenumber);

-- 3. 为邮箱添加索引（用于邮箱搜索和唯一性检查）
ALTER TABLE sys_user ADD INDEX idx_email (email);

-- 4. 为部门ID添加索引（用于部门用户查询）
ALTER TABLE sys_user ADD INDEX idx_dept_id (dept_id);

-- 5. 为状态字段添加索引（用于状态过滤）
ALTER TABLE sys_user ADD INDEX idx_status (status);

-- 6. 为创建时间添加索引（用于时间范围查询）
ALTER TABLE sys_user ADD INDEX idx_create_time (create_time);

-- 7. 为删除标志添加索引（用于过滤已删除数据）
ALTER TABLE sys_user ADD INDEX idx_del_flag (del_flag);

-- 8. 组合索引优化常用查询
ALTER TABLE sys_user ADD INDEX idx_dept_status_del (dept_id, status, del_flag);

-- 9. 为角色用户关联表添加索引
ALTER TABLE sys_user_role ADD INDEX idx_user_id (user_id);
ALTER TABLE sys_user_role ADD INDEX idx_role_id (role_id);

-- 10. 为用户岗位关联表添加索引
ALTER TABLE sys_user_post ADD INDEX idx_user_id (user_id);
ALTER TABLE sys_user_post ADD INDEX idx_post_id (post_id);

-- 11. 为部门表添加索引
ALTER TABLE sys_dept ADD INDEX idx_parent_id (parent_id);
ALTER TABLE sys_dept ADD INDEX idx_status (status);

-- 12. 为角色表添加索引
ALTER TABLE sys_role ADD INDEX idx_role_key (role_key);
ALTER TABLE sys_role ADD INDEX idx_status (status);

-- 优化建议:
-- 1. 定期分析表统计信息: ANALYZE TABLE table_name;
-- 2. 定期优化表结构: OPTIMIZE TABLE table_name;
-- 3. 监控慢查询日志，优化慢SQL