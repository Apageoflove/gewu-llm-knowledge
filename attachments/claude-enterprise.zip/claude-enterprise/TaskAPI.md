# 任务管理模块 API 接口文档

## 概述

任务管理模块提供完整的任务CRUD操作，支持任务分配、完成、状态管理等功能。

## 数据库表结构

需要先执行 `RuoYi-Vue/sql/sys_task.sql` 创建任务表和初始数据。

## API 接口列表

### 1. 查询任务列表

**接口地址：** `GET /system/task/list`

**权限：** `system:task:list`

**请求参数：**
- `title` (可选): 任务标题
- `status` (可选): 任务状态 (0待办 1进行中 2已完成 3已取消)
- `priority` (可选): 优先级 (1高 2中 3低)
- `assigneeId` (可选): 分配给的用户ID
- `creatorId` (可选): 创建者用户ID

**响应示例：**
```json
{
  "code": 200,
  "msg": "查询成功",
  "rows": [...],
  "total": 3
}
```

### 2. 查询任务详情

**接口地址：** `GET /system/task/{taskId}`

**权限：** `system:task:query`

**响应示例：**
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "taskId": 1,
    "title": "系统优化任务",
    "description": "对系统性能进行全面优化",
    "priority": "1",
    "status": "1",
    "assigneeId": 2,
    "creatorId": 1,
    "assigneeName": "张三",
    "creatorName": "admin"
  }
}
```

### 3. 新增任务

**接口地址：** `POST /system/task`

**权限：** `system:task:add`

**请求体：**
```json
{
  "title": "新任务标题",
  "description": "任务描述",
  "priority": "2",
  "assigneeId": 3,
  "dueDate": "2024-12-31 23:59:59",
  "remark": "备注信息"
}
```

### 4. 修改任务

**接口地址：** `PUT /system/task`

**权限：** `system:task:edit`

**请求体：**
```json
{
  "taskId": 1,
  "title": "更新后的任务标题",
  "description": "更新后的描述",
  "priority": "1"
}
```

### 5. 删除任务

**接口地址：** `DELETE /system/task/{taskIds}`

**权限：** `system:task:remove`

**说明：** 支持批量删除，taskIds 可以是单个ID或多个ID（逗号分隔）

### 6. 完成任务

**接口地址：** `PUT /system/task/complete/{taskId}`

**权限：** `system:task:edit`

**功能：** 将任务状态设置为已完成，并记录完成时间

### 7. 分配任务

**接口地址：** `PUT /system/task/assign/{taskId}/{assigneeId}`

**权限：** `system:task:edit`

**功能：** 将任务分配给指定用户，并设置状态为进行中

### 8. 查询我的任务

**接口地址：** `GET /system/task/my`

**权限：** `system:task:list`

**功能：** 查询当前登录用户被分配的任务

### 9. 查询我创建的任务

**接口地址：** `GET /system/task/created`

**权限：** `system:task:list`

**功能：** 查询当前登录用户创建的任务

### 10. 按状态查询任务

**接口地址：** `GET /system/task/status/{status}`

**权限：** `system:task:list`

**状态参数：**
- `0`: 待办
- `1`: 进行中  
- `2`: 已完成
- `3`: 已取消

### 11. 统计用户任务数量

**接口地址：** `GET /system/task/count/{assigneeId}`

**权限：** `system:task:list`

**响应示例：**
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": 5
}
```

## 任务状态说明

- `0`: 待办 - 任务已创建但尚未开始
- `1`: 进行中 - 任务正在执行
- `2`: 已完成 - 任务已完成
- `3`: 已取消 - 任务被取消

## 优先级说明

- `1`: 高优先级
- `2`: 中优先级（默认）
- `3`: 低优先级

## 权限配置

需要在系统菜单管理中添加以下权限：
- `system:task:list` - 查询任务
- `system:task:query` - 任务详情
- `system:task:add` - 新增任务
- `system:task:edit` - 修改任务
- `system:task:remove` - 删除任务

## 测试步骤

1. 先执行数据库脚本创建任务表
2. 启动RuoYi应用
3. 登录系统获取认证token
4. 使用Postman或其他工具测试API接口
5. 验证权限控制是否正常工作

## 功能特点

- ✅ 完整的CRUD操作
- ✅ 权限控制和操作日志
- ✅ 分页查询支持
- ✅ 任务分配和状态管理
- ✅ 用户关联显示（assigneeName, creatorName）
- ✅ 逻辑删除支持
- ✅ 参数验证和XSS防护