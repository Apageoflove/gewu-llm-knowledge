# 用户管理系统 Product Specs

## 1. 功能概述
### 1.1 核心功能
- 用户注册/登录
- 权限管理
- 个人信息维护

## 2. 技术架构
### 2.1 前端技术栈
- React 18 + TypeScript
- 状态管理：Redux Toolkit

### 2.2 后端技术栈
- Node.js + Express
- 数据库：PostgreSQL

## 3. API设计
### 3.1 用户认证
POST /api/auth/login
{
  "username": "string",
  "password": "string"
}

## 4. 数据模型
...