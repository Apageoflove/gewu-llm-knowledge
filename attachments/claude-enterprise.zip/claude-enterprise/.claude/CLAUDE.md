# 项目开发规范

## 语言规范
- 所有对话和文档都使用中文
- 注释使用中文
- 错误提示使用中文
- 文档使用中文Markdown格式

## 代码规范
- 使用ESLint + Prettier
- 函数采用小驼峰命名
- 组件采用大驼峰命名
- 常量使用全大写下划线分隔

## Git规范
- 使用conventional commits
- feat: 新功能
- fix: 修复bug
- docs: 文档更新
- refactor: 代码重构

## 开发原则
- 单一职责原则
- 每个PR只解决一个问题
- 代码必须有单元测试
- 注释用中文，代码用英文

## 个人偏好
- 优先使用函数式组件
- 状态管理使用Zustand
- 样式使用CSS Modules
- 避免使用any类型