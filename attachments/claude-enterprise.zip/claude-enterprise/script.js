document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');
    const nav = document.querySelector('.nav');
    const backToTop = document.getElementById('backToTop');
    const heroSlides = document.querySelectorAll('.hero-slide');
    const heroDots = document.querySelectorAll('.dot');
    const contactForm = document.querySelector('.contact-form');
    
    let currentSlide = 0;
    let slideInterval;

    function initMobileMenu() {
        navToggle.addEventListener('click', function() {
            navList.classList.toggle('active');
            nav.classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            if (!nav.contains(e.target)) {
                navList.classList.remove('active');
                nav.classList.remove('active');
            }
        });

        const navLinks = document.querySelectorAll('.nav-list a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navList.classList.remove('active');
                nav.classList.remove('active');
            });
        });
    }

    function initHeroSlider() {
        let isTransitioning = false;

        function setSlideBackground(slide, index) {
            const backgrounds = [
                'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                'linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%)',
                'linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%)'
            ];
            slide.style.background = backgrounds[index] || backgrounds[0];
            
            // 同时设置百叶窗背景
            const blinds = slide.querySelectorAll('.blind');
            blinds.forEach(blind => {
                blind.style.background = backgrounds[index] || backgrounds[0];
            });
        }

        function showSlideWithBlinds(index) {
            if (isTransitioning) return;
            isTransitioning = true;

            const currentActiveSlide = document.querySelector('.hero-slide.active');
            const nextSlide = heroSlides[index];
            
            // 设置新幻灯片的背景
            setSlideBackground(nextSlide, index);
            
            // 如果有当前活跃的幻灯片，先关闭百叶窗
            if (currentActiveSlide && currentActiveSlide !== nextSlide) {
                currentActiveSlide.classList.add('blinds-closing');
                
                setTimeout(() => {
                    // 移除当前活跃状态
                    currentActiveSlide.classList.remove('active', 'blinds-closing', 'blinds-opening');
                    
                    // 激活新幻灯片并开始开启百叶窗动画
                    nextSlide.classList.add('active');
                    
                    // 强制重绘
                    nextSlide.offsetHeight;
                    
                    nextSlide.classList.add('blinds-opening');
                    
                    setTimeout(() => {
                        nextSlide.classList.remove('blinds-opening');
                        isTransitioning = false;
                    }, 1500);
                    
                }, 800);
            } else {
                // 首次加载或同一张幻灯片
                nextSlide.classList.add('active', 'blinds-opening');
                setTimeout(() => {
                    nextSlide.classList.remove('blinds-opening');
                    isTransitioning = false;
                }, 1500);
            }

            // 更新指示点
            heroDots.forEach((dot, i) => {
                dot.classList.remove('active');
            });
            heroDots[index].classList.add('active');
        }

        function nextSlide() {
            if (isTransitioning) return;
            currentSlide = (currentSlide + 1) % heroSlides.length;
            showSlideWithBlinds(currentSlide);
        }

        function startSlideShow() {
            slideInterval = setInterval(nextSlide, 6000);
        }

        function stopSlideShow() {
            clearInterval(slideInterval);
        }

        // 初始化第一张幻灯片
        setSlideBackground(heroSlides[0], 0);
        heroSlides[0].classList.add('blinds-opening');
        setTimeout(() => {
            heroSlides[0].classList.remove('blinds-opening');
        }, 1500);

        heroDots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                if (isTransitioning) return;
                currentSlide = index;
                showSlideWithBlinds(currentSlide);
                stopSlideShow();
                startSlideShow();
            });
        });

        const heroSection = document.querySelector('.hero');
        heroSection.addEventListener('mouseenter', stopSlideShow);
        heroSection.addEventListener('mouseleave', startSlideShow);

        startSlideShow();
    }

    function initBackToTop() {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });

        backToTop.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    function initFormValidation() {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();
            
            let isValid = true;
            let errorMessages = [];

            if (!name) {
                isValid = false;
                errorMessages.push('请输入您的姓名');
            }

            if (!email) {
                isValid = false;
                errorMessages.push('请输入您的邮箱');
            } else if (!isValidEmail(email)) {
                isValid = false;
                errorMessages.push('请输入有效的邮箱地址');
            }

            if (!message) {
                isValid = false;
                errorMessages.push('请输入留言内容');
            }

            removeErrorMessages();

            if (!isValid) {
                showErrorMessages(errorMessages);
                return;
            }

            showSuccessMessage('留言提交成功！我们会尽快与您联系。');
            contactForm.reset();
        });
    }

    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function showErrorMessages(messages) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-messages';
        errorDiv.style.cssText = `
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
        `;
        
        const ul = document.createElement('ul');
        ul.style.cssText = 'margin: 0; padding-left: 20px;';
        
        messages.forEach(message => {
            const li = document.createElement('li');
            li.textContent = message;
            ul.appendChild(li);
        });
        
        errorDiv.appendChild(ul);
        contactForm.insertBefore(errorDiv, contactForm.firstChild);
    }

    function showSuccessMessage(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.style.cssText = `
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        `;
        successDiv.textContent = message;
        
        contactForm.insertBefore(successDiv, contactForm.firstChild);
        
        setTimeout(() => {
            successDiv.remove();
        }, 5000);
    }

    function removeErrorMessages() {
        const errorDiv = contactForm.querySelector('.error-messages');
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    function initSmoothScrolling() {
        const navLinks = document.querySelectorAll('a[href^="#"]');
        
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    const headerHeight = document.querySelector('.header').offsetHeight;
                    const targetPosition = targetElement.offsetTop - headerHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    function initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        const animateElements = document.querySelectorAll('.about-item, .product-item, .news-item');
        
        animateElements.forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(element);
        });
    }

    function initHeaderScroll() {
        let lastScrollTop = 0;
        const header = document.querySelector('.header');

        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > 100) {
                header.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
                header.style.backdropFilter = 'blur(10px)';
            } else {
                header.style.backgroundColor = '#fff';
                header.style.backdropFilter = 'none';
            }

            lastScrollTop = scrollTop;
        });
    }

    function initProductHover() {
        const productItems = document.querySelectorAll('.product-item');
        
        productItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px) scale(1.02)';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    }

    initMobileMenu();
    initHeroSlider();
    initBackToTop();
    initFormValidation();
    initSmoothScrolling();
    initScrollAnimations();
    initHeaderScroll();
    initProductHover();

    console.log('企业官网加载完成');
});