#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
坦克大战游戏测试脚本
用于验证游戏核心功能是否正常工作
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """测试所有模块是否能正常导入"""
    print("🔍 测试模块导入...")
    
    try:
        import pygame
        print("✅ Pygame 导入成功")
    except ImportError as e:
        print(f"❌ Pygame 导入失败: {e}")
        return False
    
    try:
        from config import *
        print("✅ Config 模块导入成功")
    except ImportError as e:
        print(f"❌ Config 模块导入失败: {e}")
        return False
    
    try:
        from utils import *
        print("✅ Utils 模块导入成功")
    except ImportError as e:
        print(f"❌ Utils 模块导入失败: {e}")
        return False
    
    try:
        from src.tank import Tank, PlayerTank, EnemyTank
        print("✅ Tank 模块导入成功")
    except ImportError as e:
        print(f"❌ Tank 模块导入失败: {e}")
        return False
    
    try:
        from src.bullet import Bullet, BulletManager
        print("✅ Bullet 模块导入成功")
    except ImportError as e:
        print(f"❌ Bullet 模块导入失败: {e}")
        return False
    
    try:
        from src.map import GameMap, LevelManager
        print("✅ Map 模块导入成功")
    except ImportError as e:
        print(f"❌ Map 模块导入失败: {e}")
        return False
    
    try:
        from src.ui import UIManager
        print("✅ UI 模块导入成功")
    except ImportError as e:
        print(f"❌ UI 模块导入失败: {e}")
        return False
    
    try:
        from src.game import Game
        print("✅ Game 模块导入成功")
    except ImportError as e:
        print(f"❌ Game 模块导入失败: {e}")
        return False
    
    return True

def test_pygame_init():
    """测试Pygame初始化"""
    print("\n🎮 测试Pygame初始化...")
    
    try:
        import pygame
        pygame.init()
        screen = pygame.display.set_mode((100, 100))
        pygame.display.set_caption("测试")
        print("✅ Pygame 初始化成功")
        pygame.quit()
        return True
    except Exception as e:
        print(f"❌ Pygame 初始化失败: {e}")
        return False

def test_tank_creation():
    """测试坦克创建"""
    print("\n🚗 测试坦克创建...")
    
    try:
        from src.tank import PlayerTank, EnemyTank
        from config import TANK_TYPES
        
        # 创建玩家坦克
        player = PlayerTank(100, 100)
        print("✅ 玩家坦克创建成功")
        
        # 创建敌方坦克
        enemy = EnemyTank(200, 200, TANK_TYPES['BASIC_ENEMY'])
        print("✅ 敌方坦克创建成功")
        
        return True
    except Exception as e:
        print(f"❌ 坦克创建失败: {e}")
        return False

def test_map_generation():
    """测试地图生成"""
    print("\n🗺️ 测试地图生成...")
    
    try:
        from src.map import GameMap
        
        game_map = GameMap()
        print("✅ 地图创建成功")
        
        # 测试生成位置
        spawn_positions = game_map.get_spawn_positions()
        print(f"✅ 生成位置获取成功: {len(spawn_positions)} 个位置")
        
        player_pos = game_map.get_player_spawn_position()
        print(f"✅ 玩家生成位置: {player_pos}")
        
        return True
    except Exception as e:
        print(f"❌ 地图生成失败: {e}")
        return False

def test_bullet_system():
    """测试子弹系统"""
    print("\n💥 测试子弹系统...")
    
    try:
        from src.bullet import Bullet, BulletManager
        from src.tank import PlayerTank
        from config import DIRECTIONS
        
        # 创建玩家坦克
        player = PlayerTank(100, 100)
        
        # 创建子弹
        bullet = Bullet(120, 120, DIRECTIONS['UP'], player)
        print("✅ 子弹创建成功")
        
        # 创建子弹管理器
        bullet_manager = BulletManager()
        bullet_manager.add_bullet(bullet)
        print("✅ 子弹管理器创建成功")
        
        return True
    except Exception as e:
        print(f"❌ 子弹系统测试失败: {e}")
        return False

def run_all_tests():
    """运行所有测试"""
    print("🚀 开始游戏功能测试")
    print("=" * 50)
    
    tests = [
        test_imports,
        test_pygame_init,
        test_tank_creation,
        test_map_generation,
        test_bullet_system
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ 测试异常: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有测试通过！游戏应该可以正常运行。")
        return True
    else:
        print("⚠️ 部分测试失败，请检查错误信息。")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    
    if success:
        print("\n🎮 现在可以运行游戏了:")
        print("python main.py")
    else:
        print("\n🔧 请修复上述错误后再试。")

