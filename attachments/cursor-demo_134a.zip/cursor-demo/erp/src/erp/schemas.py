"""
Pydantic数据模型和验证
"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field


# 用户相关模型
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: str = Field(..., min_length=1, max_length=100)
    employee_id: str = Field(..., min_length=1, max_length=20)
    department: Optional[str] = Field(None, max_length=50)
    position: Optional[str] = Field(None, max_length=50)


class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=50)


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, min_length=1, max_length=100)
    department: Optional[str] = Field(None, max_length=50)
    position: Optional[str] = Field(None, max_length=50)
    is_active: Optional[bool] = None


class User(UserBase):
    id: int
    is_active: bool
    is_admin: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# 登录相关模型
class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


class UserLogin(BaseModel):
    username: str
    password: str


# 打卡相关模型
class AttendanceRecordBase(BaseModel):
    date: str = Field(..., pattern=r'^\d{4}-\d{2}-\d{2}$')
    clock_in_location: Optional[str] = Field(None, max_length=200)
    clock_out_location: Optional[str] = Field(None, max_length=200)
    notes: Optional[str] = None


class AttendanceRecordCreate(AttendanceRecordBase):
    pass


class AttendanceRecordUpdate(BaseModel):
    clock_out_location: Optional[str] = Field(None, max_length=200)
    notes: Optional[str] = None


class AttendanceRecord(AttendanceRecordBase):
    id: int
    user_id: int
    clock_in: Optional[datetime] = None
    clock_out: Optional[datetime] = None
    work_hours: float = 0.0
    status: str = "normal"
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class AttendanceRecordWithUser(AttendanceRecord):
    user: User


# 打卡操作模型
class ClockInRequest(BaseModel):
    location: Optional[str] = Field(None, max_length=200)


class ClockOutRequest(BaseModel):
    location: Optional[str] = Field(None, max_length=200)


# 统一响应模型
class Response(BaseModel):
    success: bool = True
    message: str = "操作成功"
    data: Optional[dict] = None


class ListResponse(BaseModel):
    success: bool = True
    message: str = "查询成功"
    data: list
    total: int = 0
    page: int = 1
    page_size: int = 20


# 部门模型
class DepartmentBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=20)
    description: Optional[str] = None
    manager_id: Optional[int] = None


class DepartmentCreate(DepartmentBase):
    pass


class Department(DepartmentBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
