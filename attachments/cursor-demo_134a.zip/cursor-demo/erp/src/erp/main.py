"""
FastAPI主应用程序
"""
import os
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from .database import create_tables, get_db
from .api import auth, users, attendance
from .schemas import Response

# 创建FastAPI应用
app = FastAPI(
    title=os.getenv("APP_NAME", "ERP Demo System"),
    description="基于Python的企业资源规划系统演示版本",
    version=os.getenv("APP_VERSION", "0.1.0"),
    docs_url="/docs",
    redoc_url="/redoc"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该限制具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载静态文件
static_dir = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# 注册API路由
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(attendance.router, prefix="/api/v1")


@app.get("/", summary="主页面")
async def root():
    """
    返回主页面
    """
    static_dir = os.path.join(os.path.dirname(__file__), "static")
    index_file = os.path.join(static_dir, "index.html")
    return FileResponse(index_file)


@app.get("/api", response_model=Response, summary="系统信息")
async def api_info():
    """
    获取系统基本信息
    """
    return Response(
        message="ERP系统运行正常",
        data={
            "name": os.getenv("APP_NAME", "ERP Demo System"),
            "version": os.getenv("APP_VERSION", "0.1.0"),
            "status": "running"
        }
    )


@app.get("/health", response_model=Response, summary="健康检查")
async def health_check(db: Session = Depends(get_db)):
    """
    系统健康检查
    """
    try:
        # 测试数据库连接
        from sqlalchemy import text
        db.execute(text("SELECT 1"))
        return Response(
            message="系统健康",
            data={"database": "connected", "status": "healthy"}
        )
    except Exception as e:
        return Response(
            success=False,
            message="系统异常",
            data={"error": str(e), "status": "unhealthy"}
        )


# 应用启动事件
@app.on_event("startup")
async def startup_event():
    """
    应用启动时执行的操作
    """
    # 创建数据库表
    create_tables()
    print("数据库表创建完成")
    
    # 可以在这里添加初始化数据的逻辑
    print("ERP系统启动成功！")


# 应用关闭事件
@app.on_event("shutdown")
async def shutdown_event():
    """
    应用关闭时执行的操作
    """
    print("ERP系统正在关闭...")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
