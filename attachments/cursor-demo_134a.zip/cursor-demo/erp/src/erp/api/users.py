"""
用户管理API路由
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import User, UserCreate, UserUpdate, Response, ListResponse
from ..auth import get_current_active_user, get_current_admin_user, get_user_by_username, get_user_by_email, get_user_by_employee_id
from ..crud import create_user, get_user, get_users, update_user, delete_user

router = APIRouter(prefix="/users", tags=["用户管理"])


@router.post("/", response_model=User, summary="创建用户")
async def create_new_user(
    user: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """
    创建新用户（需要管理员权限）
    """
    # 检查用户名是否已存在
    if get_user_by_username(db, user.username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用户名已存在"
        )
    
    # 检查邮箱是否已存在
    if get_user_by_email(db, user.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="邮箱已存在"
        )
    
    # 检查工号是否已存在
    if get_user_by_employee_id(db, user.employee_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="工号已存在"
        )
    
    return create_user(db=db, user=user)


@router.get("/", response_model=ListResponse, summary="获取用户列表")
async def read_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """
    获取用户列表（需要管理员权限）
    """
    users = get_users(db, skip=skip, limit=limit)
    return ListResponse(
        data=[User.from_orm(user) for user in users],
        total=len(users),
        page=skip // limit + 1,
        page_size=limit
    )


@router.get("/{user_id}", response_model=User, summary="获取用户详情")
async def read_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    获取用户详情（只能查看自己的信息，管理员可以查看所有用户）
    """
    # 普通用户只能查看自己的信息
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="权限不足"
        )
    
    db_user = get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )
    return db_user


@router.put("/{user_id}", response_model=User, summary="更新用户信息")
async def update_user_info(
    user_id: int,
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    更新用户信息（只能更新自己的信息，管理员可以更新所有用户）
    """
    # 普通用户只能更新自己的信息
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="权限不足"
        )
    
    db_user = update_user(db, user_id=user_id, user_update=user_update)
    if db_user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )
    return db_user


@router.delete("/{user_id}", response_model=Response, summary="删除用户")
async def delete_user_info(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """
    删除用户（需要管理员权限）
    """
    if delete_user(db, user_id=user_id):
        return Response(message="用户删除成功")
    else:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )
