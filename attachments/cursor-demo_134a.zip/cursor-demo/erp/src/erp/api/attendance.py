"""
考勤打卡API路由
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import (
    AttendanceRecord, AttendanceRecordWithUser, ClockInRequest, ClockOutRequest, 
    Response, ListResponse, User
)
from ..auth import get_current_active_user, get_current_admin_user
from ..crud import (
    clock_in, clock_out, get_user_attendance_records, 
    get_all_attendance_records, get_attendance_record_by_date
)

router = APIRouter(prefix="/attendance", tags=["考勤打卡"])


@router.post("/clock-in", response_model=AttendanceRecord, summary="上班打卡")
async def clock_in_endpoint(
    request: ClockInRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    员工上班打卡
    """
    try:
        record = clock_in(db, user_id=current_user.id, location=request.location)
        return record
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/clock-out", response_model=AttendanceRecord, summary="下班打卡")
async def clock_out_endpoint(
    request: ClockOutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    员工下班打卡
    """
    try:
        record = clock_out(db, user_id=current_user.id, location=request.location)
        return record
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/my-records", response_model=ListResponse, summary="查看我的考勤记录")
async def get_my_attendance_records(
    start_date: Optional[str] = Query(None, description="开始日期 (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="结束日期 (YYYY-MM-DD)"),
    skip: int = Query(0, ge=0, description="跳过的记录数"),
    limit: int = Query(20, ge=1, le=100, description="返回的记录数"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    查看当前用户的考勤记录
    """
    records = get_user_attendance_records(
        db, 
        user_id=current_user.id, 
        start_date=start_date, 
        end_date=end_date,
        skip=skip,
        limit=limit
    )
    
    return ListResponse(
        data=[AttendanceRecord.from_orm(record) for record in records],
        total=len(records),
        page=skip // limit + 1,
        page_size=limit
    )


@router.get("/today", response_model=Optional[AttendanceRecord], summary="查看今天的打卡记录")
async def get_today_attendance(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    查看今天的打卡记录
    """
    from datetime import date
    today = date.today().strftime('%Y-%m-%d')
    record = get_attendance_record_by_date(db, current_user.id, today)
    return record


@router.get("/records", response_model=ListResponse, summary="查看所有考勤记录")
async def get_all_attendance(
    start_date: Optional[str] = Query(None, description="开始日期 (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="结束日期 (YYYY-MM-DD)"),
    skip: int = Query(0, ge=0, description="跳过的记录数"),
    limit: int = Query(20, ge=1, le=100, description="返回的记录数"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """
    查看所有用户的考勤记录（需要管理员权限）
    """
    records = get_all_attendance_records(
        db, 
        start_date=start_date, 
        end_date=end_date,
        skip=skip,
        limit=limit
    )
    
    # 包含用户信息的记录
    records_with_user = []
    for record in records:
        record_dict = AttendanceRecord.from_orm(record).dict()
        record_dict["user"] = User.from_orm(record.user)
        records_with_user.append(record_dict)
    
    return ListResponse(
        data=records_with_user,
        total=len(records),
        page=skip // limit + 1,
        page_size=limit
    )


@router.get("/user/{user_id}/records", response_model=ListResponse, summary="查看指定用户考勤记录")
async def get_user_attendance(
    user_id: int,
    start_date: Optional[str] = Query(None, description="开始日期 (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="结束日期 (YYYY-MM-DD)"),
    skip: int = Query(0, ge=0, description="跳过的记录数"),
    limit: int = Query(20, ge=1, le=100, description="返回的记录数"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """
    查看指定用户的考勤记录（需要管理员权限）
    """
    records = get_user_attendance_records(
        db, 
        user_id=user_id, 
        start_date=start_date, 
        end_date=end_date,
        skip=skip,
        limit=limit
    )
    
    return ListResponse(
        data=[AttendanceRecord.from_orm(record) for record in records],
        total=len(records),
        page=skip // limit + 1,
        page_size=limit
    )
