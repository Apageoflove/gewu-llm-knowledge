"""
初始化演示数据
"""
from sqlalchemy.orm import Session
from .database import SessionLocal, create_tables
from .models import User, Department
from .auth import get_password_hash


def init_demo_data():
    """初始化演示数据"""
    # 创建数据库表
    create_tables()
    
    db = SessionLocal()
    try:
        # 检查是否已经有用户数据
        if db.query(User).first():
            print("数据已存在，跳过初始化")
            return
        
        # 创建部门
        departments = [
            Department(name="技术部", code="TECH", description="负责系统开发和维护"),
            Department(name="人事部", code="HR", description="负责人力资源管理"),
            Department(name="财务部", code="FIN", description="负责财务管理"),
            Department(name="销售部", code="SALES", description="负责销售业务"),
        ]
        
        for dept in departments:
            db.add(dept)
        
        # 创建用户
        users = [
            User(
                username="admin",
                email="admin@company.com",
                full_name="系统管理员",
                employee_id="EMP001",
                department="技术部",
                position="系统管理员",
                hashed_password=get_password_hash("admin123"),
                is_admin=True,
            ),
            User(
                username="zhangsan",
                email="zhangsan@company.com",
                full_name="张三",
                employee_id="EMP002",
                department="技术部",
                position="软件工程师",
                hashed_password=get_password_hash("123456"),
            ),
            User(
                username="lisi",
                email="lisi@company.com",
                full_name="李四",
                employee_id="EMP003",
                department="销售部",
                position="销售代表",
                hashed_password=get_password_hash("123456"),
            ),
            User(
                username="wangwu",
                email="wangwu@company.com",
                full_name="王五",
                employee_id="EMP004",
                department="人事部",
                position="人事专员",
                hashed_password=get_password_hash("123456"),
            ),
        ]
        
        for user in users:
            db.add(user)
        
        db.commit()
        print("演示数据初始化完成！")
        print("\n默认用户账号:")
        print("管理员: admin / admin123")
        print("普通用户: zhangsan / 123456")
        print("普通用户: lisi / 123456")
        print("普通用户: wangwu / 123456")
        
    except Exception as e:
        print(f"初始化数据失败: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    init_demo_data()
