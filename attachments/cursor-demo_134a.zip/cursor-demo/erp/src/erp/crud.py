"""
数据库CRUD操作
"""
from datetime import datetime, date
from typing import List, Optional

from sqlalchemy.orm import Session
from sqlalchemy import func, and_

from .models import User, AttendanceRecord, Department
from .schemas import UserCreate, UserUpdate, AttendanceRecordCreate, AttendanceRecordUpdate
from .auth import get_password_hash


# 用户相关CRUD操作
def create_user(db: Session, user: UserCreate) -> User:
    """创建用户"""
    hashed_password = get_password_hash(user.password)
    db_user = User(
        username=user.username,
        email=user.email,
        full_name=user.full_name,
        employee_id=user.employee_id,
        department=user.department,
        position=user.position,
        hashed_password=hashed_password,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_user(db: Session, user_id: int) -> Optional[User]:
    """获取用户"""
    return db.query(User).filter(User.id == user_id).first()


def get_users(db: Session, skip: int = 0, limit: int = 100) -> List[User]:
    """获取用户列表"""
    return db.query(User).offset(skip).limit(limit).all()


def update_user(db: Session, user_id: int, user_update: UserUpdate) -> Optional[User]:
    """更新用户"""
    db_user = db.query(User).filter(User.id == user_id).first()
    if db_user:
        update_data = user_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_user, field, value)
        db_user.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(db_user)
    return db_user


def delete_user(db: Session, user_id: int) -> bool:
    """删除用户"""
    db_user = db.query(User).filter(User.id == user_id).first()
    if db_user:
        db.delete(db_user)
        db.commit()
        return True
    return False


# 考勤相关CRUD操作
def get_attendance_record_by_date(db: Session, user_id: int, date_str: str) -> Optional[AttendanceRecord]:
    """根据日期获取考勤记录"""
    return db.query(AttendanceRecord).filter(
        and_(AttendanceRecord.user_id == user_id, AttendanceRecord.date == date_str)
    ).first()


def create_attendance_record(db: Session, user_id: int, record: AttendanceRecordCreate) -> AttendanceRecord:
    """创建考勤记录"""
    db_record = AttendanceRecord(
        user_id=user_id,
        date=record.date,
        clock_in_location=record.clock_in_location,
        notes=record.notes,
    )
    db.add(db_record)
    db.commit()
    db.refresh(db_record)
    return db_record


def update_attendance_record(db: Session, record_id: int, record_update: AttendanceRecordUpdate) -> Optional[AttendanceRecord]:
    """更新考勤记录"""
    db_record = db.query(AttendanceRecord).filter(AttendanceRecord.id == record_id).first()
    if db_record:
        update_data = record_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_record, field, value)
        db_record.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(db_record)
    return db_record


def clock_in(db: Session, user_id: int, location: Optional[str] = None) -> AttendanceRecord:
    """上班打卡"""
    today = date.today().strftime('%Y-%m-%d')
    now = datetime.now()
    
    # 检查今天是否已经有记录
    existing_record = get_attendance_record_by_date(db, user_id, today)
    
    if existing_record:
        if existing_record.clock_in:
            raise ValueError("今天已经打过上班卡了")
        # 更新现有记录
        existing_record.clock_in = now
        existing_record.clock_in_location = location
        existing_record.updated_at = now
        db.commit()
        db.refresh(existing_record)
        return existing_record
    else:
        # 创建新记录
        db_record = AttendanceRecord(
            user_id=user_id,
            date=today,
            clock_in=now,
            clock_in_location=location,
        )
        db.add(db_record)
        db.commit()
        db.refresh(db_record)
        return db_record


def clock_out(db: Session, user_id: int, location: Optional[str] = None) -> AttendanceRecord:
    """下班打卡"""
    today = date.today().strftime('%Y-%m-%d')
    now = datetime.now()
    
    # 获取今天的记录
    record = get_attendance_record_by_date(db, user_id, today)
    
    if not record:
        raise ValueError("今天还没有上班打卡记录")
    
    if not record.clock_in:
        raise ValueError("今天还没有上班打卡")
        
    if record.clock_out:
        raise ValueError("今天已经打过下班卡了")
    
    # 更新下班打卡信息
    record.clock_out = now
    record.clock_out_location = location
    
    # 计算工作时长（小时）
    work_duration = now - record.clock_in
    record.work_hours = round(work_duration.total_seconds() / 3600, 2)
    
    # 判断状态（简单规则）
    clock_in_time = record.clock_in.time()
    clock_out_time = now.time()
    
    if clock_in_time > datetime.strptime("09:30", "%H:%M").time():
        record.status = "late"  # 迟到
    elif clock_out_time < datetime.strptime("17:30", "%H:%M").time() and record.work_hours < 8:
        record.status = "early_leave"  # 早退
    else:
        record.status = "normal"  # 正常
    
    record.updated_at = now
    db.commit()
    db.refresh(record)
    return record


def get_user_attendance_records(
    db: Session, 
    user_id: int, 
    start_date: Optional[str] = None, 
    end_date: Optional[str] = None,
    skip: int = 0, 
    limit: int = 100
) -> List[AttendanceRecord]:
    """获取用户考勤记录"""
    query = db.query(AttendanceRecord).filter(AttendanceRecord.user_id == user_id)
    
    if start_date:
        query = query.filter(AttendanceRecord.date >= start_date)
    if end_date:
        query = query.filter(AttendanceRecord.date <= end_date)
    
    return query.order_by(AttendanceRecord.date.desc()).offset(skip).limit(limit).all()


def get_all_attendance_records(
    db: Session,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    skip: int = 0,
    limit: int = 100
) -> List[AttendanceRecord]:
    """获取所有考勤记录"""
    query = db.query(AttendanceRecord).join(User)
    
    if start_date:
        query = query.filter(AttendanceRecord.date >= start_date)
    if end_date:
        query = query.filter(AttendanceRecord.date <= end_date)
    
    return query.order_by(AttendanceRecord.date.desc()).offset(skip).limit(limit).all()
