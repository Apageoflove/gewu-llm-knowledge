"""
数据库模型定义
"""
from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Integer, String, ForeignKey, Text, Float
from sqlalchemy.orm import relationship
from .database import Base


class User(Base):
    """用户模型"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    full_name = Column(String(100), nullable=False)
    employee_id = Column(String(20), unique=True, index=True, nullable=False)
    department = Column(String(50), nullable=True)
    position = Column(String(50), nullable=True)
    hashed_password = Column(String(100), nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关联打卡记录
    attendance_records = relationship("AttendanceRecord", back_populates="user")


class AttendanceRecord(Base):
    """考勤打卡记录模型"""
    __tablename__ = "attendance_records"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    date = Column(String(10), nullable=False)  # 格式: YYYY-MM-DD
    clock_in = Column(DateTime, nullable=True)  # 上班打卡时间
    clock_out = Column(DateTime, nullable=True)  # 下班打卡时间
    clock_in_location = Column(String(200), nullable=True)  # 上班打卡地点
    clock_out_location = Column(String(200), nullable=True)  # 下班打卡地点
    work_hours = Column(Float, default=0.0)  # 工作时长（小时）
    status = Column(String(20), default="normal")  # 状态: normal, late, early_leave, absent
    notes = Column(Text, nullable=True)  # 备注
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关联用户
    user = relationship("User", back_populates="attendance_records")


class Department(Base):
    """部门模型"""
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    manager_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
