#!/usr/bin/env python3
"""
API接口测试脚本
"""
import requests
import json
from datetime import datetime

# 服务器地址
BASE_URL = "http://localhost:8000/api/v1"

def test_login():
    """测试登录"""
    print("🔐 测试用户登录...")
    
    # 登录数据
    login_data = {
        "username": "admin",
        "password": "admin123"
    }
    
    response = requests.post(
        f"{BASE_URL}/auth/login",
        data=login_data
    )
    
    if response.status_code == 200:
        token_data = response.json()
        print(f"✅ 登录成功，获取到token: {token_data['access_token'][:20]}...")
        return token_data["access_token"]
    else:
        print(f"❌ 登录失败: {response.text}")
        return None

def test_get_user_info(token):
    """测试获取用户信息"""
    print("👤 测试获取用户信息...")
    
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/auth/me", headers=headers)
    
    if response.status_code == 200:
        user_data = response.json()
        print(f"✅ 用户信息: {user_data['full_name']} ({user_data['employee_id']})")
        return user_data
    else:
        print(f"❌ 获取用户信息失败: {response.text}")
        return None

def test_clock_in(token):
    """测试上班打卡"""
    print("⏰ 测试上班打卡...")
    
    headers = {"Authorization": f"Bearer {token}"}
    clock_data = {
        "location": "公司前台"
    }
    
    response = requests.post(
        f"{BASE_URL}/attendance/clock-in",
        headers=headers,
        json=clock_data
    )
    
    if response.status_code == 200:
        record = response.json()
        print(f"✅ 上班打卡成功: {record['clock_in']}")
        return record
    else:
        print(f"❌ 上班打卡失败: {response.text}")
        return None

def test_clock_out(token):
    """测试下班打卡"""
    print("🏃 测试下班打卡...")
    
    headers = {"Authorization": f"Bearer {token}"}
    clock_data = {
        "location": "公司后门"
    }
    
    response = requests.post(
        f"{BASE_URL}/attendance/clock-out",
        headers=headers,
        json=clock_data
    )
    
    if response.status_code == 200:
        record = response.json()
        print(f"✅ 下班打卡成功: {record['clock_out']}")
        print(f"📊 工作时长: {record['work_hours']} 小时")
        print(f"📋 状态: {record['status']}")
        return record
    else:
        print(f"❌ 下班打卡失败: {response.text}")
        return None

def test_get_today_attendance(token):
    """测试查看今天的考勤"""
    print("📅 测试查看今天的考勤记录...")
    
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/attendance/today", headers=headers)
    
    if response.status_code == 200:
        record = response.json()
        if record:
            print(f"✅ 今天的考勤记录:")
            print(f"   上班时间: {record.get('clock_in', '未打卡')}")
            print(f"   下班时间: {record.get('clock_out', '未打卡')}")
            print(f"   工作时长: {record.get('work_hours', 0)} 小时")
            print(f"   状态: {record.get('status', '未知')}")
        else:
            print("📭 今天还没有考勤记录")
        return record
    else:
        print(f"❌ 查看今天考勤失败: {response.text}")
        return None

def test_get_my_records(token):
    """测试查看我的考勤记录"""
    print("📊 测试查看我的考勤记录...")
    
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/attendance/my-records", headers=headers)
    
    if response.status_code == 200:
        result = response.json()
        records = result.get("data", [])
        print(f"✅ 找到 {len(records)} 条考勤记录")
        for record in records[:3]:  # 只显示前3条
            print(f"   日期: {record['date']}, 工作时长: {record['work_hours']}h, 状态: {record['status']}")
        return records
    else:
        print(f"❌ 查看考勤记录失败: {response.text}")
        return None

def main():
    """主测试函数"""
    print("=" * 60)
    print("🧪 ERP系统API接口测试")
    print("=" * 60)
    
    try:
        # 测试系统状态
        response = requests.get("http://localhost:8000/health")
        if response.status_code != 200:
            print("❌ 系统未运行，请先启动服务器: python run.py")
            return
        
        print("✅ 系统运行正常")
        
        # 1. 测试登录
        token = test_login()
        if not token:
            return
        
        print()
        
        # 2. 测试获取用户信息
        user_info = test_get_user_info(token)
        if not user_info:
            return
        
        print()
        
        # 3. 测试查看今天的考勤
        test_get_today_attendance(token)
        print()
        
        # 4. 测试上班打卡
        test_clock_in(token)
        print()
        
        # 5. 测试下班打卡
        test_clock_out(token)
        print()
        
        # 6. 测试查看考勤记录
        test_get_my_records(token)
        
        print("\n" + "=" * 60)
        print("🎉 所有测试完成！")
        print("💡 可以访问 http://localhost:8000/docs 查看完整API文档")
        print("=" * 60)
        
    except requests.exceptions.ConnectionError:
        print("❌ 无法连接到服务器，请确保系统正在运行")
        print("💡 运行命令: python run.py")
    except Exception as e:
        print(f"❌ 测试过程中出现错误: {e}")

if __name__ == "__main__":
    main()
