#!/usr/bin/env python3
"""
ERP系统启动脚本
"""
import os
import sys
import subprocess

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def install_dependencies():
    """安装依赖包"""
    print("安装依赖包...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ 依赖包安装完成")
    except subprocess.CalledProcessError as e:
        print(f"❌ 依赖包安装失败: {e}")
        return False
    return True

def init_database():
    """初始化数据库"""
    print("初始化数据库...")
    try:
        from src.erp.init_data import init_demo_data
        init_demo_data()
        print("✅ 数据库初始化完成")
    except Exception as e:
        print(f"❌ 数据库初始化失败: {e}")
        return False
    return True

def start_server():
    """启动服务器"""
    print("启动ERP系统...")
    try:
        import uvicorn
        uvicorn.run(
            "src.erp.main:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
    except Exception as e:
        print(f"❌ 服务器启动失败: {e}")
        return False
    return True

def main():
    """主函数"""
    print("=" * 50)
    print("🚀 ERP系统启动程序")
    print("=" * 50)
    
    # 检查Python版本
    if sys.version_info < (3, 8):
        print("❌ 需要Python 3.8或更高版本")
        return
    
    print(f"✅ Python版本: {sys.version}")
    
    # 安装依赖
    if not install_dependencies():
        return
    
    # 初始化数据库
    if not init_database():
        return
    
    print("\n" + "=" * 50)
    print("🎉 ERP系统准备就绪！")
    print("📊 API文档: http://localhost:8000/docs")
    print("📋 接口文档: http://localhost:8000/redoc")
    print("💡 默认管理员账号: admin / admin123")
    print("=" * 50)
    
    # 启动服务器
    start_server()

if __name__ == "__main__":
    main()
