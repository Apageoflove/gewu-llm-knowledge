#!/usr/bin/env python3
"""
检查数据库内容
"""
import sqlite3
import os

def check_database():
    db_file = "erp.db"
    if not os.path.exists(db_file):
        print("❌ 数据库文件不存在")
        return
    
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        print("📋 数据库表:")
        for table in tables:
            print(f"  - {table[0]}")
        
        # 检查用户数据
        try:
            cursor.execute("SELECT username, email, full_name, is_admin FROM users")
            users = cursor.fetchall()
            print(f"\n👥 用户数据 ({len(users)} 个用户):")
            for user in users:
                print(f"  - {user[0]} ({user[2]}) - 管理员: {bool(user[3])}")
        except Exception as e:
            print(f"❌ 查询用户数据失败: {e}")
        
        # 检查考勤数据
        try:
            cursor.execute("SELECT COUNT(*) FROM attendance_records")
            count = cursor.fetchone()[0]
            print(f"\n📊 考勤记录: {count} 条")
        except Exception as e:
            print(f"❌ 查询考勤数据失败: {e}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ 数据库连接失败: {e}")

if __name__ == "__main__":
    check_database()
