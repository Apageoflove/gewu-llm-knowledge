#!/usr/bin/env python3
"""
Web界面演示脚本
"""
import webbrowser
import time
import requests

def check_server():
    """检查服务器是否运行"""
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        return response.status_code == 200
    except:
        return False

def main():
    print("=" * 60)
    print("🌐 ERP系统Web界面演示")
    print("=" * 60)
    
    # 检查服务器状态
    if not check_server():
        print("❌ 服务器未运行！")
        print("💡 请先运行: python run.py 或 uvicorn src.erp.main:app --reload")
        return
    
    print("✅ 服务器运行正常")
    print()
    
    print("🎯 Web界面功能:")
    print("  📱 现代化响应式设计")
    print("  🔐 用户登录认证")
    print("  ⏰ 员工上下班打卡")
    print("  📊 实时考勤状态显示")
    print("  📋 考勤记录查看")
    print("  🕒 实时时间显示")
    print()
    
    print("👤 测试账号:")
    print("  管理员: admin / admin123")
    print("  员工: zhangsan / 123456")
    print("  员工: lisi / 123456")
    print("  员工: wangwu / 123456")
    print()
    
    print("🌐 访问地址:")
    print("  主页面: http://localhost:8000")
    print("  API文档: http://localhost:8000/docs")
    print("  系统健康: http://localhost:8000/health")
    print()
    
    # 自动打开浏览器
    try:
        print("🚀 正在打开浏览器...")
        webbrowser.open("http://localhost:8000")
        print("✅ 浏览器已打开!")
        print()
        print("💡 提示:")
        print("  1. 使用上述测试账号登录")
        print("  2. 体验员工打卡功能")
        print("  3. 查看考勤记录和状态")
        print("  4. 测试不同用户的权限")
        print()
        print("🎉 享受您的ERP系统体验!")
        
    except Exception as e:
        print(f"❌ 无法自动打开浏览器: {e}")
        print("💡 请手动访问: http://localhost:8000")

if __name__ == "__main__":
    main()
