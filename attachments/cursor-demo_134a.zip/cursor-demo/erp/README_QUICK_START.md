# ERP系统快速启动指南

## 🚀 快速开始

### 1. 环境要求
- Python 3.8+
- pip（Python包管理器）

### 2. 一键启动
```bash
# 克隆或下载项目后，进入项目目录
cd erp-demo

# 运行启动脚本（会自动安装依赖、初始化数据库、启动服务）
python run.py
```

### 3. 访问系统
启动成功后，可以通过以下地址访问：

- **API文档（Swagger）**: http://localhost:8000/docs
- **API文档（ReDoc）**: http://localhost:8000/redoc
- **系统健康检查**: http://localhost:8000/health

### 4. 默认账号
系统会自动创建以下测试账号：

| 用户名 | 密码 | 角色 | 姓名 | 工号 |
|--------|------|------|------|------|
| admin | admin123 | 管理员 | 系统管理员 | EMP001 |
| zhangsan | 123456 | 普通用户 | 张三 | EMP002 |
| lisi | 123456 | 普通用户 | 李四 | EMP003 |
| wangwu | 123456 | 普通用户 | 王五 | EMP004 |

## 📱 员工打卡功能测试

### 方法1：运行测试脚本
```bash
# 在新的终端窗口运行
python test_api.py
```

### 方法2：使用API文档界面
1. 访问 http://localhost:8000/docs
2. 点击 **认证** 分组下的 `/auth/login` 接口
3. 点击 "Try it out" 按钮
4. 输入用户名和密码，点击 "Execute"
5. 复制返回的 `access_token`
6. 点击页面右上角的 "Authorize" 按钮
7. 输入：`Bearer {你的token}`
8. 现在可以测试打卡相关接口了

### 方法3：使用curl命令

#### 登录获取token
```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin123"
```

#### 上班打卡
```bash
curl -X POST "http://localhost:8000/api/v1/attendance/clock-in" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"location": "公司前台"}'
```

#### 下班打卡
```bash
curl -X POST "http://localhost:8000/api/v1/attendance/clock-out" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"location": "公司后门"}'
```

#### 查看今天的考勤
```bash
curl -X GET "http://localhost:8000/api/v1/attendance/today" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## 🔥 核心功能

### 员工打卡系统
- ✅ **上班打卡**：记录上班时间和地点
- ✅ **下班打卡**：记录下班时间和地点，自动计算工作时长
- ✅ **状态判断**：自动判断正常、迟到、早退状态
- ✅ **考勤查询**：查看个人和全体员工考勤记录
- ✅ **数据统计**：工作时长统计和考勤分析

### 用户管理系统
- ✅ **用户认证**：JWT令牌认证
- ✅ **权限控制**：管理员和普通用户权限分离
- ✅ **用户管理**：增删改查用户信息
- ✅ **安全保护**：密码加密存储

## 📁 项目结构

```
erp-demo/
├── src/erp/                    # 核心代码
│   ├── api/                    # API路由
│   │   ├── auth.py            # 认证接口
│   │   ├── users.py           # 用户管理接口
│   │   └── attendance.py      # 考勤打卡接口
│   ├── models.py              # 数据库模型
│   ├── schemas.py             # 数据验证模型
│   ├── database.py            # 数据库连接
│   ├── auth.py                # 认证逻辑
│   ├── crud.py                # 数据库操作
│   ├── main.py                # FastAPI主应用
│   └── init_data.py           # 初始化数据
├── run.py                     # 启动脚本
├── test_api.py                # API测试脚本
├── requirements.txt           # 依赖包列表
├── README.md                  # 项目说明
├── plan.md                    # 开发计划
└── erp.db                     # SQLite数据库文件（运行后生成）
```

## 🛠️ 开发说明

### 手动安装依赖
```bash
pip install -r requirements.txt
```

### 手动启动
```bash
# 初始化数据库
python -c "from src.erp.init_data import init_demo_data; init_demo_data()"

# 启动服务
uvicorn src.erp.main:app --reload --host 0.0.0.0 --port 8000
```

### 数据库文件
- 使用SQLite数据库，文件保存为 `erp.db`
- 支持切换到PostgreSQL（修改环境变量即可）

## 🚧 后续扩展

按照 `plan.md` 开发计划，后续将逐步实现：
- 采购管理模块
- 销售管理模块
- 库存管理模块
- 生产管理模块
- 财务管理模块
- 报表分析模块

## ❗ 注意事项

1. 这是演示版本，生产环境请修改默认密钥和密码
2. 当前使用SQLite数据库，大规模使用建议切换到PostgreSQL
3. 考勤状态判断基于简单规则（9:30上班，17:30下班），可根据需要调整
4. API接口支持跨域访问，生产环境请限制允许的域名

## 🆘 常见问题

**Q: 端口8000被占用怎么办？**
A: 修改 `run.py` 中的端口号，或者关闭占用8000端口的程序

**Q: 如何重置数据库？**
A: 删除 `erp.db` 文件，重新运行 `python run.py`

**Q: 如何添加新用户？**
A: 使用管理员账号登录，调用用户创建接口，或修改 `init_data.py` 添加

**Q: 如何修改考勤规则？**
A: 修改 `src/erp/crud.py` 中的 `clock_out` 函数中的状态判断逻辑
