# 工具函数
import pygame
import math
from config import GRID_SIZE

def load_image(path, size=None):
    """加载图片资源"""
    try:
        image = pygame.image.load(path)
        if size:
            image = pygame.transform.scale(image, size)
        return image
    except pygame.error:
        # 如果图片不存在，创建简单的彩色方块
        surface = pygame.Surface(size if size else (32, 32))
        surface.fill((255, 0, 255))  # 紫色表示缺失资源
        return surface

def create_simple_tank(color, size=(32, 32)):
    """创建简单的坦克图形"""
    surface = pygame.Surface(size)
    surface.fill(color)
    # 添加坦克的炮管
    pygame.draw.rect(surface, (0, 0, 0), (size[0]//2-2, 0, 4, size[1]//3))
    return surface

def create_simple_bullet(color=(255, 255, 0), size=(4, 4)):
    """创建简单的子弹图形"""
    surface = pygame.Surface(size)
    surface.fill(color)
    return surface

def create_terrain_tile(terrain_type, size=(16, 16)):
    """创建地形图块"""
    from config import COLORS, TERRAIN_TYPES
    
    surface = pygame.Surface(size)
    
    if terrain_type == TERRAIN_TYPES['BRICK_WALL']:
        surface.fill(COLORS['BROWN'])
        # 添加砖块纹理
        for i in range(0, size[0], 4):
            for j in range(0, size[1], 4):
                pygame.draw.rect(surface, COLORS['BLACK'], (i, j, 2, 2))
    
    elif terrain_type == TERRAIN_TYPES['STEEL_WALL']:
        surface.fill(COLORS['GRAY'])
        # 添加金属纹理
        pygame.draw.rect(surface, COLORS['WHITE'], (0, 0, size[0], 2))
        pygame.draw.rect(surface, COLORS['WHITE'], (0, 0, 2, size[1]))
    
    elif terrain_type == TERRAIN_TYPES['WATER']:
        surface.fill(COLORS['BLUE'])
        # 添加水波纹理
        for i in range(0, size[0], 3):
            pygame.draw.line(surface, COLORS['WHITE'], (i, 0), (i, size[1]))
    
    elif terrain_type == TERRAIN_TYPES['GRASS']:
        surface.fill(COLORS['GREEN'])
        # 添加草地纹理
        for i in range(0, size[0], 2):
            for j in range(0, size[1], 2):
                if (i + j) % 4 == 0:
                    pygame.draw.rect(surface, (0, 200, 0), (i, j, 1, 1))
    
    elif terrain_type == TERRAIN_TYPES['BASE']:
        surface.fill(COLORS['YELLOW'])
        pygame.draw.rect(surface, COLORS['RED'], (2, 2, size[0]-4, size[1]-4))
    
    else:  # EMPTY
        surface.fill(COLORS['DARK_GRAY'])
    
    return surface

def grid_to_pixel(grid_x, grid_y):
    """网格坐标转换为像素坐标"""
    return grid_x * GRID_SIZE, grid_y * GRID_SIZE

def pixel_to_grid(pixel_x, pixel_y):
    """像素坐标转换为网格坐标"""
    return pixel_x // GRID_SIZE, pixel_y // GRID_SIZE

def check_collision(rect1, rect2):
    """检查两个矩形是否碰撞"""
    return rect1.colliderect(rect2)

def distance(pos1, pos2):
    """计算两点之间的距离"""
    return math.sqrt((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)

def normalize_direction(direction):
    """标准化方向向量"""
    length = math.sqrt(direction[0]**2 + direction[1]**2)
    if length == 0:
        return (0, 0)
    return (direction[0] / length, direction[1] / length)

def rotate_surface(surface, angle):
    """旋转表面"""
    return pygame.transform.rotate(surface, angle)

def clamp(value, min_val, max_val):
    """限制值在指定范围内"""
    return max(min_val, min(value, max_val))

def get_angle_from_direction(direction):
    """从方向获取角度"""
    if direction == (0, -1):  # UP
        return 0
    elif direction == (1, 0):  # RIGHT
        return 270
    elif direction == (0, 1):  # DOWN
        return 180
    elif direction == (-1, 0):  # LEFT
        return 90
    return 0

