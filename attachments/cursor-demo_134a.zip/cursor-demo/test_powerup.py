#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
道具系统测试脚本
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_powerup_system():
    """测试道具系统"""
    print("🧪 测试道具系统...")
    
    try:
        # 导入所需模块
        from src.powerup import PowerUp, PowerUpManager
        from src.tank import PlayerTank
        from config import POWERUP_TYPES
        
        print("✅ 道具模块导入成功")
        
        # 测试道具创建
        invisibility_powerup = PowerUp(100, 100, POWERUP_TYPES['INVISIBILITY'])
        print("✅ 隐身道具创建成功")
        
        # 测试玩家坦克
        player = PlayerTank(200, 200)
        print("✅ 玩家坦克创建成功")
        
        # 测试道具效果应用
        effect_message = invisibility_powerup.apply_effect(player)
        print(f"✅ 道具效果应用成功: {effect_message}")
        
        # 检查隐身状态
        if hasattr(player, 'invisibility_active') and player.invisibility_active:
            print("✅ 隐身状态激活成功")
        else:
            print("❌ 隐身状态激活失败")
        
        # 测试道具管理器
        powerup_manager = PowerUpManager()
        print("✅ 道具管理器创建成功")
        
        return True
        
    except Exception as e:
        print(f"❌ 道具系统测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_invisibility_collision():
    """测试隐身状态下的碰撞"""
    print("\n🛡️ 测试隐身碰撞...")
    
    try:
        from src.tank import PlayerTank, EnemyTank
        from src.bullet import Bullet
        from config import DIRECTIONS, TANK_TYPES
        
        # 创建玩家和敌方坦克
        player = PlayerTank(100, 100)
        enemy = EnemyTank(200, 200, TANK_TYPES['BASIC_ENEMY'])
        
        # 激活隐身
        player.activate_invisibility(5000)
        print("✅ 玩家隐身激活")
        
        # 创建敌方子弹
        bullet = Bullet(150, 150, DIRECTIONS['LEFT'], enemy)
        print("✅ 敌方子弹创建")
        
        # 测试碰撞（应该不受伤害）
        collision_result = bullet.check_collision_with_tank(player)
        
        if collision_result and player.health == player.max_health:
            print("✅ 隐身状态下成功避免伤害")
        else:
            print("❌ 隐身状态碰撞测试失败")
        
        return True
        
    except Exception as e:
        print(f"❌ 隐身碰撞测试失败: {e}")
        return False

def run_powerup_tests():
    """运行所有道具测试"""
    print("🚀 开始道具系统测试")
    print("=" * 50)
    
    tests = [
        test_powerup_system,
        test_invisibility_collision
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ 测试异常: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 道具测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有道具测试通过！")
        return True
    else:
        print("⚠️ 部分道具测试失败")
        return False

if __name__ == "__main__":
    success = run_powerup_tests()
    
    print("\n🎮 道具系统功能说明:")
    print("- 隐身道具每15秒随机生成")
    print("- 玩家触碰道具即可激活隐身状态")
    print("- 隐身持续10秒，期间敌方子弹无法造成伤害")
    print("- 隐身时坦克呈现半透明效果，带有蓝色边框")
    print("- UI界面会显示'隐身激活'状态")
    
    if success:
        print("\n✅ 现在可以运行游戏体验隐身道具:")
        print("python main.py")

