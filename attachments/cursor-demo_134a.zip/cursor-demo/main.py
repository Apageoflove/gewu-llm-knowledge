#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
坦克大战游戏主入口
基于Python和Pygame开发的经典坦克大战游戏
"""

import os
import sys

# 添加项目根目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# 检查Pygame是否安装
try:
    import pygame
    print("Pygame 检查通过")
except ImportError:
    print("错误: 未安装Pygame")
    print("请运行: pip install pygame")
    sys.exit(1)

# 导入游戏模块
try:
    from src.game import Game
except ImportError as e:
    print(f"导入游戏模块失败: {e}")
    sys.exit(1)


def check_dependencies():
    """检查依赖项"""
    print("检查游戏依赖...")
    
    # 检查Pygame版本
    pygame_version = pygame.version.ver
    print(f"Pygame 版本: {pygame_version}")
    
    # 检查音频支持
    if pygame.mixer.get_init():
        print("音频支持: 正常")
    else:
        print("音频支持: 未初始化")
    
    print("依赖检查完成")


def main():
    """主函数"""
    print("=" * 50)
    print("🎮 坦克大战游戏")
    print("基于Python + Pygame开发")
    print("=" * 50)
    
    # 检查依赖
    check_dependencies()
    
    print("\n游戏控制说明:")
    print("🎯 方向键：移动坦克")
    print("🔫 空格键：射击")
    print("⏸️  ESC键：暂停/继续游戏")
    print("🔄 R键：重新开始")
    print("❌ Alt+F4：退出游戏")
    print("\n正在启动游戏...")
    
    try:
        # 创建并运行游戏
        game = Game()
        game.run()
        
    except KeyboardInterrupt:
        print("\n游戏被用户中断")
    except Exception as e:
        print(f"\n游戏运行错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("游戏已退出")
        pygame.quit()


if __name__ == "__main__":
    main()

