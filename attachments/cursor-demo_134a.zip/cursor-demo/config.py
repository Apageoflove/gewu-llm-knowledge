# 游戏配置文件
import pygame

# 游戏窗口设置
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# 网格设置
GRID_SIZE = 16  # 每个网格的像素大小
GRID_COLS = SCREEN_WIDTH // GRID_SIZE
GRID_ROWS = SCREEN_HEIGHT // GRID_SIZE

# 坦克设置
TANK_SIZE = 32
TANK_SPEED = 2  # 像素/帧
BULLET_SPEED = 4
BULLET_SIZE = 4

# 颜色定义
COLORS = {
    'BLACK': (0, 0, 0),
    'WHITE': (255, 255, 255),
    'GREEN': (0, 255, 0),
    'RED': (255, 0, 0),
    'BLUE': (0, 0, 255),
    'BROWN': (139, 69, 19),
    'GRAY': (128, 128, 128),
    'DARK_GRAY': (47, 47, 47),
    'YELLOW': (255, 255, 0),
}

# 方向定义
DIRECTIONS = {
    'UP': (0, -1),
    'DOWN': (0, 1),
    'LEFT': (-1, 0),
    'RIGHT': (1, 0)
}

# 地形类型
TERRAIN_TYPES = {
    'EMPTY': 0,
    'BRICK_WALL': 1,
    'STEEL_WALL': 2,
    'WATER': 3,
    'GRASS': 4,
    'BASE': 5
}

# 坦克类型
TANK_TYPES = {
    'PLAYER': 0,
    'BASIC_ENEMY': 1,
    'ARMOR_ENEMY': 2,
    'FAST_ENEMY': 3,
    'HEAVY_ENEMY': 4
}

# 游戏状态
GAME_STATES = {
    'MENU': 0,
    'PLAYING': 1,
    'PAUSED': 2,
    'GAME_OVER': 3
}

# 道具类型
POWERUP_TYPES = {
    'INVISIBILITY': 0,
    'WEAPON_UPGRADE': 1,
    'EXTRA_LIFE': 2,
    'FREEZE': 3,
    'BIG_BULLET': 4,
    'NUKE': 5
}

# 道具设置
POWERUP_SIZE = 24
POWERUP_SPAWN_CHANCE = 0.05  # 5% 概率生成道具
INVISIBILITY_DURATION = 10000  # 隐身持续时间（毫秒）
BIG_BULLET_DURATION = 15000  # 大子弹持续时间（毫秒）
BIG_BULLET_SIZE = 12  # 大子弹尺寸

# 按键映射
PLAYER_KEYS = {
    pygame.K_UP: 'UP',
    pygame.K_DOWN: 'DOWN',
    pygame.K_LEFT: 'LEFT',
    pygame.K_RIGHT: 'RIGHT',
    pygame.K_SPACE: 'FIRE'
}
