#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新道具功能测试脚本
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_big_bullet_powerup():
    """测试大子弹道具"""
    print("🚀 测试大子弹道具...")
    
    try:
        from src.powerup import PowerUp
        from src.tank import PlayerTank
        from config import POWERUP_TYPES, BIG_BULLET_SIZE
        
        # 创建大子弹道具
        big_bullet_powerup = PowerUp(100, 100, POWERUP_TYPES['BIG_BULLET'])
        print("✅ 大子弹道具创建成功")
        
        # 创建玩家坦克
        player = PlayerTank(200, 200)
        print("✅ 玩家坦克创建成功")
        
        # 应用道具效果
        effect_message = big_bullet_powerup.apply_effect(player)
        print(f"✅ 道具效果: {effect_message}")
        
        # 检查大子弹状态
        if hasattr(player, 'big_bullet_active') and player.big_bullet_active:
            print("✅ 大子弹状态激活成功")
        else:
            print("❌ 大子弹状态激活失败")
        
        # 测试射击大子弹
        bullet = player.shoot()
        if bullet and hasattr(bullet, 'is_big_bullet') and bullet.is_big_bullet:
            print("✅ 大子弹射击成功")
            print(f"✅ 大子弹伤害: {bullet.damage}")
        else:
            print("❌ 大子弹射击失败")
        
        return True
        
    except Exception as e:
        print(f"❌ 大子弹道具测试失败: {e}")
        return False

def test_nuke_powerup():
    """测试核弹道具"""
    print("\n💥 测试核弹道具...")
    
    try:
        from src.powerup import PowerUp
        from src.tank import PlayerTank, EnemyTank
        from config import POWERUP_TYPES, TANK_TYPES
        
        # 创建核弹道具
        nuke_powerup = PowerUp(100, 100, POWERUP_TYPES['NUKE'])
        print("✅ 核弹道具创建成功")
        
        # 创建玩家坦克
        player = PlayerTank(200, 200)
        print("✅ 玩家坦克创建成功")
        
        # 应用道具效果
        effect_message = nuke_powerup.apply_effect(player)
        print(f"✅ 道具效果: {effect_message}")
        
        if effect_message == "核弹爆炸！":
            print("✅ 核弹效果识别成功")
        else:
            print("❌ 核弹效果识别失败")
        
        return True
        
    except Exception as e:
        print(f"❌ 核弹道具测试失败: {e}")
        return False

def test_freeze_powerup():
    """测试冰冻道具"""
    print("\n❄️ 测试冰冻道具...")
    
    try:
        from src.powerup import PowerUp
        from src.tank import PlayerTank, EnemyTank
        from config import POWERUP_TYPES, TANK_TYPES
        
        # 创建冰冻道具
        freeze_powerup = PowerUp(100, 100, POWERUP_TYPES['FREEZE'])
        print("✅ 冰冻道具创建成功")
        
        # 创建玩家坦克
        player = PlayerTank(200, 200)
        print("✅ 玩家坦克创建成功")
        
        # 创建敌方坦克
        enemy = EnemyTank(300, 300, TANK_TYPES['BASIC_ENEMY'])
        print("✅ 敌方坦克创建成功")
        
        # 应用道具效果
        effect_message = freeze_powerup.apply_effect(player)
        print(f"✅ 道具效果: {effect_message}")
        
        if effect_message == "敌人冰冻！":
            print("✅ 冰冻效果识别成功")
        else:
            print("❌ 冰冻效果识别失败")
        
        return True
        
    except Exception as e:
        print(f"❌ 冰冻道具测试失败: {e}")
        return False

def test_powerup_generation():
    """测试道具生成系统"""
    print("\n🎲 测试道具生成系统...")
    
    try:
        from src.powerup import PowerUpManager
        from src.map import GameMap
        from src.tank import PlayerTank
        
        # 创建道具管理器
        powerup_manager = PowerUpManager()
        print("✅ 道具管理器创建成功")
        
        # 创建地图
        game_map = GameMap()
        print("✅ 游戏地图创建成功")
        
        # 创建玩家
        player = PlayerTank(100, 100)
        print("✅ 玩家坦克创建成功")
        
        # 强制生成道具
        powerup_manager._spawn_random_powerup(game_map)
        print("✅ 道具生成成功")
        
        # 检查道具数量
        if powerup_manager.get_powerup_count() > 0:
            print(f"✅ 当前道具数量: {powerup_manager.get_powerup_count()}")
        else:
            print("❌ 没有道具生成")
        
        return True
        
    except Exception as e:
        print(f"❌ 道具生成测试失败: {e}")
        return False

def test_powerup_visuals():
    """测试道具视觉效果"""
    print("\n🎨 测试道具视觉效果...")
    
    try:
        from src.powerup import PowerUp
        from config import POWERUP_TYPES
        import pygame
        
        pygame.init()
        
        # 测试所有道具类型的图形创建
        powerup_types = [
            POWERUP_TYPES['INVISIBILITY'],
            POWERUP_TYPES['BIG_BULLET'],
            POWERUP_TYPES['NUKE'],
            POWERUP_TYPES['FREEZE']
        ]
        
        type_names = ['隐身', '大子弹', '核弹', '冰冻']
        
        for i, powerup_type in enumerate(powerup_types):
            powerup = PowerUp(100, 100, powerup_type)
            if powerup.image:
                print(f"✅ {type_names[i]}道具图形创建成功")
            else:
                print(f"❌ {type_names[i]}道具图形创建失败")
        
        pygame.quit()
        return True
        
    except Exception as e:
        print(f"❌ 道具视觉测试失败: {e}")
        return False

def run_new_powerup_tests():
    """运行所有新道具测试"""
    print("🚀 开始新道具系统测试")
    print("=" * 60)
    
    tests = [
        test_big_bullet_powerup,
        test_nuke_powerup,
        test_freeze_powerup,
        test_powerup_generation,
        test_powerup_visuals
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ 测试异常: {e}")
    
    print("\n" + "=" * 60)
    print(f"📊 新道具测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有新道具测试通过！")
        return True
    else:
        print("⚠️ 部分新道具测试失败")
        return False

if __name__ == "__main__":
    success = run_new_powerup_tests()
    
    print("\n🎮 新道具功能说明:")
    print("=" * 50)
    print("🚀 大威力子弹道具 (橙色炮弹)")
    print("   - 子弹尺寸变大 (4→12像素)")
    print("   - 伤害提升3倍")
    print("   - 持续15秒")
    print("   - 橙色光效")
    
    print("\n💥 核弹道具 (红色爆炸)")
    print("   - 瞬间消灭所有敌方坦克")
    print("   - 获得所有击杀分数")
    print("   - 屏幕白色闪烁效果")
    print("   - 极其稀有")
    
    print("\n❄️ 冰冻道具 (雪花图案)")
    print("   - 冰冻所有敌方坦克5秒")
    print("   - 敌人无法移动和射击")
    print("   - 蓝色冰晶视觉效果")
    print("   - 战术型道具")
    
    print("\n🛡️ 隐身道具 (淡蓝色)")
    print("   - 免疫敌方子弹伤害")
    print("   - 持续10秒")
    print("   - 半透明效果")
    print("   - 防御型道具")
    
    if success:
        print(f"\n✅ 现在可以运行游戏体验所有新道具:")
        print("python main.py")
        print("\n🎯 道具获取提示:")
        print("- 道具每15秒随机生成")
        print("- 最多同时存在3个道具")
        print("- 用坦克触碰道具即可获得")
        print("- 注意观察UI界面的状态提示")




