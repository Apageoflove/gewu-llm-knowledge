from typing import List, TypeVar, Callable, Optional

T = TypeVar("T")

def quick_sort(items: List[T], *, key: Optional[Callable[[T], object]] = None, reverse: bool = False) -> List[T]:
    """
    快速排序算法实现
    
    Args:
        items: 待排序的列表
        key: 提取比较键的函数（类似内置 sorted 的 key 参数）
        reverse: True 为降序，False 为升序
    
    Returns:
        排序后的新列表（不修改原列表）
    
    时间复杂度: 平均 O(n log n)，最坏 O(n²)
    空间复杂度: O(log n) 递归栈空间
    """
    arr = items[:]  # 创建副本，避免修改原列表
    key_fn = key if key is not None else (lambda x: x)  # 默认比较函数
    
    def _quicksort(low: int, high: int) -> None:
        """递归快速排序核心函数"""
        if low < high:  # 确保子数组有效（至少2个元素）
            # 分区操作：返回基准元素的最终位置
            pi = _partition(low, high)
            # 递归排序基准左侧部分（小于基准的元素）
            _quicksort(low, pi - 1)
            # 递归排序基准右侧部分（大于基准的元素）
            _quicksort(pi + 1, high)
    
    def _partition(low: int, high: int) -> int:
        """
        分区函数：将数组分为小于基准和大于基准两部分
        采用 Lomuto 分区方案（选择最后一个元素作为基准）
        """
        # 选择最后一个元素作为基准值
        pivot = key_fn(arr[high])
        # i 指向"小于基准区域"的最后一个位置
        i = low - 1  
        
        # 遍历 [low, high-1] 区间的所有元素
        for j in range(low, high):
            current = key_fn(arr[j])
            # 根据 reverse 参数决定比较逻辑
            # 升序: current <= pivot 时放到左侧
            # 降序: current >= pivot 时放到左侧
            should_swap = (not reverse and current <= pivot) or (reverse and current >= pivot)
            if should_swap:
                i += 1  # 扩展小于基准的区域
                arr[i], arr[j] = arr[j], arr[i]  # 交换到正确位置
        
        # 将基准元素放到正确位置（小于区域的下一位）
        arr[i + 1], arr[high] = arr[high], arr[i + 1]
        return i + 1  # 返回基准元素的最终位置
    
    # 只有超过1个元素才需要排序
    if len(arr) > 1:
        _quicksort(0, len(arr) - 1)
    return arr


if __name__ == "__main__":
    # 测试基本升序排序
    print(quick_sort([5, 1, 4, 2, 8]))                 # [1, 2, 4, 5, 8]
    
    # 测试降序排序
    print(quick_sort([5, 1, 4, 2, 8], reverse=True))   # [8, 5, 4, 2, 1]
    
    # 测试自定义 key 函数排序（按字典的 "n" 键排序）
    data = [{"n": 2}, {"n": 1}, {"n": 3}]
    print(quick_sort(data, key=lambda d: d["n"]))      # [{'n': 1}, {'n': 2}, {'n': 3}]