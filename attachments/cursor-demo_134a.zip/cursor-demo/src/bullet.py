# 子弹类模块
import pygame
from config import *
from utils import create_simple_bullet

class Bullet:
    """子弹类"""
    
    def __init__(self, x, y, direction, owner):
        self.x = float(x)
        self.y = float(y)
        self.direction = direction
        self.owner = owner  # 发射子弹的坦克
        self.speed = BULLET_SPEED
        self.damage = 1
        self.active = True
        self.is_big_bullet = False
        
        # 根据发射者设置子弹属性
        if hasattr(owner, 'power_level'):
            self.damage = owner.power_level
            self.speed = BULLET_SPEED + owner.power_level
        
        # 创建子弹图形（初始为普通子弹）
        self.bullet_size = BULLET_SIZE
        self.image = create_simple_bullet(COLORS['YELLOW'], (BULLET_SIZE, BULLET_SIZE))
        self.rect = pygame.Rect(x, y, BULLET_SIZE, BULLET_SIZE)
        
        # 更新子弹外观（如果是大子弹）
        self._update_bullet_appearance()
        
    def update(self, dt):
        """更新子弹位置"""
        if not self.active:
            return
            
        # 移动子弹
        self.x += self.direction[0] * self.speed
        self.y += self.direction[1] * self.speed
        
        # 更新碰撞矩形
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        
        # 检查是否超出屏幕边界
        if (self.x < 0 or self.x >= SCREEN_WIDTH or 
            self.y < 0 or self.y >= SCREEN_HEIGHT):
            self.active = False
    
    def check_collision_with_terrain(self, game_map):
        """检查与地形的碰撞"""
        if not self.active or not game_map:
            return False
            
        # 获取子弹所在的网格位置
        grid_x = int(self.x // GRID_SIZE)
        grid_y = int(self.y // GRID_SIZE)
        
        # 检查周围的地形块
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                check_x = grid_x + dx
                check_y = grid_y + dy
                
                if (0 <= check_x < GRID_COLS and 0 <= check_y < GRID_ROWS):
                    terrain = game_map.get_terrain(check_x, check_y)
                    
                    if terrain == TERRAIN_TYPES['BRICK_WALL']:
                        # 砖墙可以被摧毁
                        terrain_rect = pygame.Rect(check_x * GRID_SIZE, check_y * GRID_SIZE, 
                                                 GRID_SIZE, GRID_SIZE)
                        if self.rect.colliderect(terrain_rect):
                            game_map.destroy_terrain(check_x, check_y)
                            self.active = False
                            return True
                    
                    elif terrain == TERRAIN_TYPES['STEEL_WALL']:
                        # 钢墙不可摧毁
                        terrain_rect = pygame.Rect(check_x * GRID_SIZE, check_y * GRID_SIZE, 
                                                 GRID_SIZE, GRID_SIZE)
                        if self.rect.colliderect(terrain_rect):
                            self.active = False
                            return True
        
        return False
    
    def check_collision_with_tank(self, tank):
        """检查与坦克的碰撞"""
        if (not self.active or not tank.alive or 
            tank == self.owner or not hasattr(tank, 'get_rect')):
            return False
            
        tank_rect = tank.get_rect()
        if self.rect.colliderect(tank_rect):
            # 检查是否是队友火力（简单的队友判断）
            if (hasattr(self.owner, 'tank_type') and hasattr(tank, 'tank_type')):
                owner_is_player = self.owner.tank_type == TANK_TYPES['PLAYER']
                target_is_player = tank.tank_type == TANK_TYPES['PLAYER']
                
                # 玩家子弹不能伤害玩家，敌方子弹不能伤害敌方
                if owner_is_player == target_is_player:
                    return False
            
            # 检查护盾
            if hasattr(tank, 'shield_active') and tank.shield_active:
                self.active = False
                return True
            
            # 检查隐身状态（仅对敌方子弹有效）
            if (hasattr(tank, 'invisibility_active') and tank.invisibility_active and
                hasattr(self.owner, 'tank_type') and hasattr(tank, 'tank_type') and
                self.owner.tank_type != TANK_TYPES['PLAYER'] and tank.tank_type == TANK_TYPES['PLAYER']):
                self.active = False
                return True
            
            # 造成伤害
            tank.take_damage(self.damage)
            self.active = False
            
            # 给玩家加分
            if (hasattr(self.owner, 'tank_type') and 
                self.owner.tank_type == TANK_TYPES['PLAYER'] and
                hasattr(self.owner, 'add_score')):
                
                # 根据敌方坦克类型给分
                score_map = {
                    TANK_TYPES['BASIC_ENEMY']: 100,
                    TANK_TYPES['ARMOR_ENEMY']: 200,
                    TANK_TYPES['FAST_ENEMY']: 150,
                    TANK_TYPES['HEAVY_ENEMY']: 300
                }
                score = score_map.get(tank.tank_type, 100)
                self.owner.add_score(score)
            
            return True
        
        return False
    
    def check_collision_with_bullet(self, other_bullet):
        """检查与其他子弹的碰撞"""
        if (not self.active or not other_bullet.active or 
            other_bullet == self or 
            other_bullet.owner == self.owner):
            return False
            
        if self.rect.colliderect(other_bullet.rect):
            # 两颗子弹相撞，都消失
            self.active = False
            other_bullet.active = False
            return True
        
        return False
    
    def _update_bullet_appearance(self):
        """更新子弹外观"""
        if self.is_big_bullet:
            self.bullet_size = BIG_BULLET_SIZE
            # 创建大子弹图形 - 橙色，更大，带光效
            surface = pygame.Surface((BIG_BULLET_SIZE, BIG_BULLET_SIZE))
            surface.set_colorkey((0, 0, 0))
            
            center = BIG_BULLET_SIZE // 2
            # 外层光晕
            pygame.draw.circle(surface, (255, 140, 0), (center, center), center)
            # 内层核心
            pygame.draw.circle(surface, (255, 165, 0), (center, center), center - 2)
            # 中心亮点
            pygame.draw.circle(surface, (255, 255, 0), (center, center), center - 4)
            
            self.image = surface
            # 更新碰撞矩形大小
            old_center = self.rect.center
            self.rect = pygame.Rect(0, 0, BIG_BULLET_SIZE, BIG_BULLET_SIZE)
            self.rect.center = old_center
        else:
            self.bullet_size = BULLET_SIZE
            self.image = create_simple_bullet(COLORS['YELLOW'], (BULLET_SIZE, BULLET_SIZE))
    
    def draw(self, screen):
        """绘制子弹"""
        if self.active:
            screen.blit(self.image, (int(self.x), int(self.y)))


class BulletManager:
    """子弹管理器"""
    
    def __init__(self):
        self.bullets = []
    
    def add_bullet(self, bullet):
        """添加子弹"""
        if bullet:
            self.bullets.append(bullet)
    
    def update(self, dt, game_map, tanks):
        """更新所有子弹"""
        active_bullets = []
        
        for bullet in self.bullets:
            if bullet.active:
                bullet.update(dt)
                
                # 检查地形碰撞
                bullet.check_collision_with_terrain(game_map)
                
                # 检查坦克碰撞
                for tank in tanks:
                    bullet.check_collision_with_tank(tank)
                
                # 检查子弹间碰撞
                for other_bullet in self.bullets:
                    if other_bullet != bullet:
                        bullet.check_collision_with_bullet(other_bullet)
                
                if bullet.active:
                    active_bullets.append(bullet)
        
        self.bullets = active_bullets
    
    def draw(self, screen):
        """绘制所有子弹"""
        for bullet in self.bullets:
            bullet.draw(screen)
    
    def clear(self):
        """清除所有子弹"""
        self.bullets.clear()
    
    def get_bullet_count(self):
        """获取活跃子弹数量"""
        return len(self.bullets)
