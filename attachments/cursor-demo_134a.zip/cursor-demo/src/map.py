# 地图系统模块
import pygame
import random
from config import *
from utils import create_terrain_tile, pixel_to_grid

class GameMap:
    """游戏地图类"""
    
    def __init__(self):
        self.width = GRID_COLS
        self.height = GRID_ROWS
        self.terrain = [[TERRAIN_TYPES['EMPTY'] for _ in range(self.width)] 
                       for _ in range(self.height)]
        
        # 创建地形图块缓存
        self.terrain_images = {}
        for terrain_type in TERRAIN_TYPES.values():
            self.terrain_images[terrain_type] = create_terrain_tile(terrain_type)
        
        # 生成默认地图
        self.generate_level_1()
    
    def generate_level_1(self):
        """生成第一关地图"""
        # 清空地图
        for y in range(self.height):
            for x in range(self.width):
                self.terrain[y][x] = TERRAIN_TYPES['EMPTY']
        
        # 添加边界墙
        self._add_border_walls()
        
        # 添加一些随机障碍
        self._add_random_obstacles()
        
        # 添加玩家基地
        base_x, base_y = self.width // 2, self.height - 3
        self.terrain[base_y][base_x] = TERRAIN_TYPES['BASE']
        
        # 在基地周围添加保护墙
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                x, y = base_x + dx, base_y + dy
                if 0 <= x < self.width and 0 <= y < self.height:
                    if self.terrain[y][x] == TERRAIN_TYPES['EMPTY']:
                        self.terrain[y][x] = TERRAIN_TYPES['BRICK_WALL']
    
    def _add_border_walls(self):
        """添加边界墙"""
        # 顶部和底部
        for x in range(self.width):
            self.terrain[0][x] = TERRAIN_TYPES['STEEL_WALL']
            self.terrain[self.height - 1][x] = TERRAIN_TYPES['STEEL_WALL']
        
        # 左侧和右侧
        for y in range(self.height):
            self.terrain[y][0] = TERRAIN_TYPES['STEEL_WALL']
            self.terrain[y][self.width - 1] = TERRAIN_TYPES['STEEL_WALL']
    
    def _add_random_obstacles(self):
        """添加随机障碍"""
        # 添加砖墙群
        for _ in range(8):
            x = random.randint(2, self.width - 4)
            y = random.randint(2, self.height - 6)
            self._add_wall_cluster(x, y, TERRAIN_TYPES['BRICK_WALL'], 3)
        
        # 添加钢墙
        for _ in range(3):
            x = random.randint(2, self.width - 4)
            y = random.randint(2, self.height - 6)
            self._add_wall_cluster(x, y, TERRAIN_TYPES['STEEL_WALL'], 2)
        
        # 添加水域
        for _ in range(2):
            x = random.randint(3, self.width - 5)
            y = random.randint(3, self.height - 8)
            self._add_wall_cluster(x, y, TERRAIN_TYPES['WATER'], 4)
        
        # 添加草地
        for _ in range(5):
            x = random.randint(2, self.width - 3)
            y = random.randint(2, self.height - 6)
            self.terrain[y][x] = TERRAIN_TYPES['GRASS']
    
    def _add_wall_cluster(self, center_x, center_y, terrain_type, size):
        """添加墙体群"""
        for dx in range(-size//2, size//2 + 1):
            for dy in range(-size//2, size//2 + 1):
                x, y = center_x + dx, center_y + dy
                if (0 < x < self.width - 1 and 0 < y < self.height - 1 and
                    random.random() < 0.7):  # 70% 概率放置
                    self.terrain[y][x] = terrain_type
    
    def get_terrain(self, grid_x, grid_y):
        """获取指定网格的地形类型"""
        if 0 <= grid_x < self.width and 0 <= grid_y < self.height:
            return self.terrain[grid_y][grid_x]
        return TERRAIN_TYPES['STEEL_WALL']  # 边界外视为钢墙
    
    def set_terrain(self, grid_x, grid_y, terrain_type):
        """设置指定网格的地形类型"""
        if 0 <= grid_x < self.width and 0 <= grid_y < self.height:
            self.terrain[grid_y][grid_x] = terrain_type
    
    def destroy_terrain(self, grid_x, grid_y):
        """摧毁地形（仅砖墙可摧毁）"""
        if (0 <= grid_x < self.width and 0 <= grid_y < self.height and
            self.terrain[grid_y][grid_x] == TERRAIN_TYPES['BRICK_WALL']):
            self.terrain[grid_y][grid_x] = TERRAIN_TYPES['EMPTY']
            return True
        return False
    
    def is_passable(self, grid_x, grid_y):
        """检查指定网格是否可通行"""
        terrain = self.get_terrain(grid_x, grid_y)
        return terrain in [TERRAIN_TYPES['EMPTY'], TERRAIN_TYPES['GRASS']]
    
    def check_tank_collision(self, pixel_x, pixel_y, tank_size):
        """检查坦克在指定像素位置是否与地形碰撞"""
        # 检查坦克四个角对应的网格
        corners = [
            (pixel_x, pixel_y),  # 左上
            (pixel_x + tank_size - 1, pixel_y),  # 右上
            (pixel_x, pixel_y + tank_size - 1),  # 左下
            (pixel_x + tank_size - 1, pixel_y + tank_size - 1)  # 右下
        ]
        
        for corner_x, corner_y in corners:
            grid_x, grid_y = pixel_to_grid(corner_x, corner_y)
            terrain = self.get_terrain(grid_x, grid_y)
            
            # 不可通行的地形
            if terrain in [TERRAIN_TYPES['BRICK_WALL'], 
                          TERRAIN_TYPES['STEEL_WALL'], 
                          TERRAIN_TYPES['WATER'],
                          TERRAIN_TYPES['BASE']]:
                return True
        
        return False
    
    def get_spawn_positions(self):
        """获取敌方坦克生成位置"""
        spawn_positions = []
        
        # 在地图上方寻找合适的生成点
        for x in range(2, self.width - 2, 3):
            y = 1
            if self.is_valid_spawn_position(x, y):
                spawn_positions.append((x * GRID_SIZE, y * GRID_SIZE))
        
        # 如果没有足够的生成点，添加更多
        if len(spawn_positions) < 3:
            for x in range(1, self.width - 1, 4):
                for y in range(1, 4):
                    if self.is_valid_spawn_position(x, y):
                        pos = (x * GRID_SIZE, y * GRID_SIZE)
                        if pos not in spawn_positions:
                            spawn_positions.append(pos)
                            if len(spawn_positions) >= 6:
                                break
                if len(spawn_positions) >= 6:
                    break
        
        return spawn_positions
    
    def is_valid_spawn_position(self, grid_x, grid_y):
        """检查是否是有效的生成位置"""
        # 检查3x3区域是否都可通行
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                x, y = grid_x + dx, grid_y + dy
                if not self.is_passable(x, y):
                    return False
        return True
    
    def get_player_spawn_position(self):
        """获取玩家生成位置"""
        # 在地图底部中央生成
        center_x = self.width // 2
        center_y = self.height - 5
        
        # 确保位置可用
        for dy in range(3):
            for dx in range(-1, 2):
                x, y = center_x + dx, center_y - dy
                if self.is_valid_spawn_position(x, y):
                    return (x * GRID_SIZE, y * GRID_SIZE)
        
        # 如果中央不可用，寻找其他位置
        for y in range(self.height - 6, self.height - 2):
            for x in range(2, self.width - 2):
                if self.is_valid_spawn_position(x, y):
                    return (x * GRID_SIZE, y * GRID_SIZE)
        
        # 默认位置
        return (GRID_SIZE * 2, (self.height - 3) * GRID_SIZE)
    
    def draw(self, screen):
        """绘制地图"""
        for y in range(self.height):
            for x in range(self.width):
                terrain_type = self.terrain[y][x]
                if terrain_type != TERRAIN_TYPES['EMPTY']:
                    image = self.terrain_images[terrain_type]
                    screen.blit(image, (x * GRID_SIZE, y * GRID_SIZE))


class LevelManager:
    """关卡管理器"""
    
    def __init__(self):
        self.current_level = 1
        self.max_level = 5
        
    def load_level(self, level_number):
        """加载指定关卡"""
        game_map = GameMap()
        
        if level_number == 1:
            game_map.generate_level_1()
        else:
            # 生成更复杂的关卡
            game_map.generate_random_level(level_number)
        
        return game_map
    
    def next_level(self):
        """进入下一关"""
        if self.current_level < self.max_level:
            self.current_level += 1
            return self.load_level(self.current_level)
        return None
    
    def reset(self):
        """重置关卡"""
        self.current_level = 1


# 为GameMap类添加方法扩展
def generate_random_level(self, level_number):
    """生成随机关卡"""
    # 清空地图
    for y in range(self.height):
        for x in range(self.width):
            self.terrain[y][x] = TERRAIN_TYPES['EMPTY']
    
    # 添加边界
    self._add_border_walls()
    
    # 根据关卡难度调整障碍密度
    obstacle_density = min(0.2 + level_number * 0.05, 0.4)
    
    # 添加随机障碍
    total_cells = (self.width - 4) * (self.height - 8)  # 排除边界和基地区域
    obstacle_count = int(total_cells * obstacle_density)
    
    for _ in range(obstacle_count):
        x = random.randint(2, self.width - 3)
        y = random.randint(2, self.height - 6)
        
        # 随机选择地形类型
        terrain_types = [
            TERRAIN_TYPES['BRICK_WALL'],
            TERRAIN_TYPES['STEEL_WALL'],
            TERRAIN_TYPES['WATER']
        ]
        weights = [0.6, 0.3, 0.1]  # 砖墙最多，钢墙次之，水最少
        
        terrain_type = random.choices(terrain_types, weights=weights)[0]
        self.terrain[y][x] = terrain_type
    
    # 添加基地
    base_x, base_y = self.width // 2, self.height - 3
    self.terrain[base_y][base_x] = TERRAIN_TYPES['BASE']
    
    # 保护基地
    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            if dx == 0 and dy == 0:
                continue
            x, y = base_x + dx, base_y + dy
            if 0 <= x < self.width and 0 <= y < self.height:
                self.terrain[y][x] = TERRAIN_TYPES['BRICK_WALL']

# 将方法添加到GameMap类
GameMap.generate_random_level = generate_random_level
