# 用户界面模块
import pygame
from config import *

class UIManager:
    """用户界面管理器"""
    
    def __init__(self):
        # 字体
        self.font_large = pygame.font.Font(None, 48)
        self.font_medium = pygame.font.Font(None, 36)
        self.font_small = pygame.font.Font(None, 24)
        
        # UI元素
        self.hud_elements = {}
        
    def draw_hud(self, screen, player_tank, level, enemies_left):
        """绘制游戏界面"""
        if not player_tank:
            return
        
        # 生命值显示
        self._draw_health_bar(screen, player_tank)
        
        # 分数显示
        score_text = self.font_medium.render(f"分数: {player_tank.score}", True, COLORS['WHITE'])
        screen.blit(score_text, (10, 50))
        
        # 关卡显示
        level_text = self.font_medium.render(f"关卡: {level}", True, COLORS['WHITE'])
        screen.blit(level_text, (SCREEN_WIDTH - 150, 10))
        
        # 敌人数量
        enemy_text = self.font_medium.render(f"敌人: {enemies_left}", True, COLORS['WHITE'])
        screen.blit(enemy_text, (SCREEN_WIDTH - 150, 50))
        
        # 武器等级（如果有）
        if hasattr(player_tank, 'power_level'):
            power_text = self.font_small.render(f"武器等级: {player_tank.power_level}", True, COLORS['YELLOW'])
            screen.blit(power_text, (10, 90))
        
        # 护盾状态
        if hasattr(player_tank, 'shield_active') and player_tank.shield_active:
            shield_text = self.font_small.render("护盾激活", True, COLORS['BLUE'])
            screen.blit(shield_text, (10, 115))
        
        # 隐身状态
        if hasattr(player_tank, 'invisibility_active') and player_tank.invisibility_active:
            invisibility_text = self.font_small.render("隐身激活", True, (200, 200, 255))
            screen.blit(invisibility_text, (10, 140))
        
        # 大子弹状态
        if hasattr(player_tank, 'big_bullet_active') and player_tank.big_bullet_active:
            big_bullet_text = self.font_small.render("大威力子弹", True, (255, 165, 0))
            screen.blit(big_bullet_text, (10, 165))
    
    def _draw_health_bar(self, screen, player_tank):
        """绘制生命值条"""
        bar_width = 200
        bar_height = 20
        bar_x = 10
        bar_y = 10
        
        # 背景条
        pygame.draw.rect(screen, COLORS['RED'], (bar_x, bar_y, bar_width, bar_height))
        
        # 生命值条
        if player_tank.max_health > 0:
            health_ratio = player_tank.health / player_tank.max_health
            health_width = int(bar_width * health_ratio)
            pygame.draw.rect(screen, COLORS['GREEN'], (bar_x, bar_y, health_width, bar_height))
        
        # 边框
        pygame.draw.rect(screen, COLORS['WHITE'], (bar_x, bar_y, bar_width, bar_height), 2)
        
        # 生命值文字
        health_text = self.font_small.render(f"{player_tank.health}/{player_tank.max_health}", True, COLORS['WHITE'])
        text_x = bar_x + bar_width // 2 - health_text.get_width() // 2
        text_y = bar_y + bar_height // 2 - health_text.get_height() // 2
        screen.blit(health_text, (text_x, text_y))
    
    def draw_menu(self, screen, title, options, selected_index=0):
        """绘制菜单"""
        screen.fill(COLORS['BLACK'])
        
        # 标题
        title_surface = self.font_large.render(title, True, COLORS['WHITE'])
        title_rect = title_surface.get_rect(center=(SCREEN_WIDTH//2, 150))
        screen.blit(title_surface, title_rect)
        
        # 选项
        for i, option in enumerate(options):
            color = COLORS['YELLOW'] if i == selected_index else COLORS['WHITE']
            option_surface = self.font_medium.render(option, True, color)
            option_rect = option_surface.get_rect(center=(SCREEN_WIDTH//2, 250 + i * 50))
            screen.blit(option_surface, option_rect)
    
    def draw_pause_overlay(self, screen):
        """绘制暂停覆盖层"""
        # 半透明背景
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(128)
        overlay.fill(COLORS['BLACK'])
        screen.blit(overlay, (0, 0))
        
        # 暂停文字
        pause_text = self.font_large.render("游戏暂停", True, COLORS['WHITE'])
        pause_rect = pause_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        screen.blit(pause_text, pause_rect)
        
        # 提示
        hint_text = self.font_medium.render("按 ESC 继续", True, COLORS['WHITE'])
        hint_rect = hint_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 60))
        screen.blit(hint_text, hint_rect)
    
    def draw_game_over(self, screen, final_score, is_victory=False):
        """绘制游戏结束界面"""
        screen.fill(COLORS['BLACK'])
        
        # 结果标题
        if is_victory:
            title = "胜利！"
            title_color = COLORS['GREEN']
        else:
            title = "游戏结束"
            title_color = COLORS['RED']
        
        title_surface = self.font_large.render(title, True, title_color)
        title_rect = title_surface.get_rect(center=(SCREEN_WIDTH//2, 200))
        screen.blit(title_surface, title_rect)
        
        # 最终分数
        score_text = self.font_medium.render(f"最终分数: {final_score}", True, COLORS['WHITE'])
        score_rect = score_text.get_rect(center=(SCREEN_WIDTH//2, 280))
        screen.blit(score_text, score_rect)
        
        # 重新开始提示
        restart_text = self.font_medium.render("按 R 重新开始", True, COLORS['WHITE'])
        restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH//2, 350))
        screen.blit(restart_text, restart_rect)
        
        # 退出提示
        quit_text = self.font_medium.render("按 ESC 退出", True, COLORS['WHITE'])
        quit_rect = quit_text.get_rect(center=(SCREEN_WIDTH//2, 400))
        screen.blit(quit_text, quit_rect)
    
    def draw_level_transition(self, screen, level_number):
        """绘制关卡过渡界面"""
        screen.fill(COLORS['BLACK'])
        
        # 关卡信息
        level_text = self.font_large.render(f"第 {level_number} 关", True, COLORS['WHITE'])
        level_rect = level_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        screen.blit(level_text, level_rect)
        
        # 准备文字
        ready_text = self.font_medium.render("准备开始", True, COLORS['YELLOW'])
        ready_rect = ready_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 60))
        screen.blit(ready_text, ready_rect)
    
    def draw_minimap(self, screen, game_map, player_tank, enemy_tanks):
        """绘制小地图"""
        minimap_size = 120
        minimap_x = SCREEN_WIDTH - minimap_size - 10
        minimap_y = SCREEN_HEIGHT - minimap_size - 10
        
        # 小地图背景
        pygame.draw.rect(screen, COLORS['DARK_GRAY'], 
                        (minimap_x, minimap_y, minimap_size, minimap_size))
        pygame.draw.rect(screen, COLORS['WHITE'], 
                        (minimap_x, minimap_y, minimap_size, minimap_size), 2)
        
        # 缩放比例
        scale_x = minimap_size / SCREEN_WIDTH
        scale_y = minimap_size / SCREEN_HEIGHT
        
        # 绘制地形（简化）
        for y in range(0, game_map.height, 2):
            for x in range(0, game_map.width, 2):
                terrain = game_map.get_terrain(x, y)
                if terrain != TERRAIN_TYPES['EMPTY']:
                    pixel_x = minimap_x + int(x * GRID_SIZE * scale_x)
                    pixel_y = minimap_y + int(y * GRID_SIZE * scale_y)
                    
                    if terrain == TERRAIN_TYPES['BRICK_WALL']:
                        color = COLORS['BROWN']
                    elif terrain == TERRAIN_TYPES['STEEL_WALL']:
                        color = COLORS['GRAY']
                    elif terrain == TERRAIN_TYPES['WATER']:
                        color = COLORS['BLUE']
                    elif terrain == TERRAIN_TYPES['BASE']:
                        color = COLORS['YELLOW']
                    else:
                        color = COLORS['GREEN']
                    
                    pygame.draw.rect(screen, color, (pixel_x, pixel_y, 2, 2))
        
        # 绘制玩家坦克
        if player_tank and player_tank.alive:
            player_x = minimap_x + int(player_tank.x * scale_x)
            player_y = minimap_y + int(player_tank.y * scale_y)
            pygame.draw.circle(screen, COLORS['GREEN'], (player_x, player_y), 3)
        
        # 绘制敌方坦克
        for enemy in enemy_tanks:
            if enemy.alive:
                enemy_x = minimap_x + int(enemy.x * scale_x)
                enemy_y = minimap_y + int(enemy.y * scale_y)
                pygame.draw.circle(screen, COLORS['RED'], (enemy_x, enemy_y), 2)
    
    def draw_controls_help(self, screen):
        """绘制控制说明"""
        help_lines = [
            "控制说明:",
            "方向键 - 移动坦克",
            "空格键 - 射击",
            "ESC键 - 暂停/继续",
            "R键 - 重新开始",
            "M键 - 静音切换"
        ]
        
        y_offset = 20
        for line in help_lines:
            text = self.font_small.render(line, True, COLORS['WHITE'])
            screen.blit(text, (SCREEN_WIDTH - 200, y_offset))
            y_offset += 25
