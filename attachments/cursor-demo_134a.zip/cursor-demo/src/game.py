# 游戏主类模块
import pygame
import random
import sys
from config import *
from src.tank import PlayerTank, EnemyTank
from src.bullet import BulletManager
from src.map import GameMap, LevelManager
from src.ui import UIManager
from src.powerup import PowerUpManager

class Game:
    """游戏主类"""
    
    def __init__(self):
        # 初始化Pygame
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("坦克大战")
        self.clock = pygame.time.Clock()
        self.running = True
        
        # 游戏状态
        self.state = GAME_STATES['PLAYING']
        self.paused = False
        
        # 游戏对象
        self.level_manager = LevelManager()
        self.game_map = self.level_manager.load_level(1)
        self.bullet_manager = BulletManager()
        self.ui_manager = UIManager()
        self.powerup_manager = PowerUpManager()
        
        # 坦克
        self.player_tank = None
        self.enemy_tanks = []
        self.max_enemies = 6
        self.enemies_spawned = 0
        self.enemies_per_level = 20
        
        # 生成系统
        self.spawn_positions = self.game_map.get_spawn_positions()
        self.last_spawn_time = 0
        self.spawn_interval = 3000  # 3秒生成一个敌人
        
        # 游戏统计
        self.level_start_time = pygame.time.get_ticks()
        
        # 特效计时
        self.nuke_flash_time = 0
        
        # 初始化游戏
        self._init_game()
    
    def _init_game(self):
        """初始化游戏"""
        # 创建玩家坦克
        player_pos = self.game_map.get_player_spawn_position()
        self.player_tank = PlayerTank(player_pos[0], player_pos[1])
        
        # 重置敌人计数
        self.enemy_tanks.clear()
        self.enemies_spawned = 0
        
        # 清除子弹和道具
        self.bullet_manager.clear()
        self.powerup_manager.clear()
        
        # 生成初始敌人
        self._spawn_initial_enemies()
        
        print(f"游戏初始化完成 - 关卡 {self.level_manager.current_level}")
    
    def _spawn_initial_enemies(self):
        """生成初始敌人"""
        initial_enemies = min(3, len(self.spawn_positions))
        for i in range(initial_enemies):
            if i < len(self.spawn_positions):
                self._spawn_enemy(self.spawn_positions[i])
    
    def _spawn_enemy(self, position=None):
        """生成敌人坦克"""
        if (len(self.enemy_tanks) >= self.max_enemies or 
            self.enemies_spawned >= self.enemies_per_level):
            return
        
        # 选择生成位置
        if position is None:
            available_positions = []
            for pos in self.spawn_positions:
                # 检查位置是否被占用
                occupied = False
                for tank in self.enemy_tanks:
                    if abs(tank.x - pos[0]) < TANK_SIZE and abs(tank.y - pos[1]) < TANK_SIZE:
                        occupied = True
                        break
                if not occupied:
                    available_positions.append(pos)
            
            if not available_positions:
                return
            
            position = random.choice(available_positions)
        
        # 选择坦克类型（根据关卡调整概率）
        level = self.level_manager.current_level
        tank_types = [
            (TANK_TYPES['BASIC_ENEMY'], 0.4),
            (TANK_TYPES['ARMOR_ENEMY'], 0.3),
            (TANK_TYPES['FAST_ENEMY'], 0.2),
            (TANK_TYPES['HEAVY_ENEMY'], 0.1 * level)  # 高级关卡更多重型坦克
        ]
        
        rand = random.random()
        cumulative = 0
        selected_type = TANK_TYPES['BASIC_ENEMY']
        
        for tank_type, probability in tank_types:
            cumulative += probability
            if rand <= cumulative:
                selected_type = tank_type
                break
        
        # 创建敌方坦克
        enemy_tank = EnemyTank(position[0], position[1], selected_type)
        self.enemy_tanks.append(enemy_tank)
        self.enemies_spawned += 1
        
        print(f"生成敌方坦克: {selected_type} 在位置 {position}")
    
    def handle_events(self):
        """处理事件"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.paused = not self.paused
                elif event.key == pygame.K_r:
                    self._restart_game()
                elif event.key == pygame.K_n and not self.enemy_tanks:
                    # 调试：N键进入下一关
                    self._next_level()
    
    def update(self, dt):
        """更新游戏状态"""
        if self.paused or self.state != GAME_STATES['PLAYING']:
            return
        
        current_time = pygame.time.get_ticks()
        
        # 更新玩家坦克
        if self.player_tank and self.player_tank.alive:
            keys = pygame.key.get_pressed()
            bullet = self.player_tank.handle_input(keys, self.game_map)
            if bullet:
                self.bullet_manager.add_bullet(bullet)
            self.player_tank.update(dt)
        
        # 更新敌方坦克
        active_enemies = []
        all_tanks = [self.player_tank] + self.enemy_tanks
        
        for enemy in self.enemy_tanks:
            if enemy.alive:
                bullet = enemy.update(dt, self.game_map, self.player_tank, all_tanks)
                if bullet:
                    self.bullet_manager.add_bullet(bullet)
                active_enemies.append(enemy)
        
        self.enemy_tanks = active_enemies
        
        # 生成新敌人
        if (current_time - self.last_spawn_time >= self.spawn_interval and
            len(self.enemy_tanks) < self.max_enemies and
            self.enemies_spawned < self.enemies_per_level):
            self._spawn_enemy()
            self.last_spawn_time = current_time
        
        # 更新子弹
        self.bullet_manager.update(dt, self.game_map, all_tanks)
        
        # 更新道具
        powerup_message = self.powerup_manager.update(dt, self.game_map, self.player_tank)
        if powerup_message:
            # 处理特殊道具效果
            if powerup_message == "核弹爆炸！":
                self._handle_nuke_effect()
            elif powerup_message == "敌人冰冻！":
                self._handle_freeze_effect()
            # 可以在这里显示道具获得消息
            pass
        
        # 检查游戏结束条件
        self._check_game_conditions()
    
    def _check_game_conditions(self):
        """检查游戏结束条件"""
        # 玩家死亡
        if not self.player_tank or not self.player_tank.alive:
            self.state = GAME_STATES['GAME_OVER']
            print("游戏结束 - 玩家坦克被摧毁")
            return
        
        # 检查基地是否被摧毁
        if self._is_base_destroyed():
            self.state = GAME_STATES['GAME_OVER']
            print("游戏结束 - 基地被摧毁")
            return
        
        # 关卡完成
        if (len(self.enemy_tanks) == 0 and 
            self.enemies_spawned >= self.enemies_per_level):
            print("关卡完成！")
            self._next_level()
    
    def _is_base_destroyed(self):
        """检查基地是否被摧毁"""
        for y in range(self.game_map.height):
            for x in range(self.game_map.width):
                if self.game_map.get_terrain(x, y) == TERRAIN_TYPES['BASE']:
                    return False
        return True
    
    def _next_level(self):
        """进入下一关"""
        next_map = self.level_manager.next_level()
        if next_map:
            self.game_map = next_map
            self._init_game()
            self.spawn_interval = max(1000, self.spawn_interval - 200)  # 逐渐加快生成速度
            print(f"进入关卡 {self.level_manager.current_level}")
        else:
            print("恭喜！您已完成所有关卡！")
            self.state = GAME_STATES['GAME_OVER']
    
    def _handle_nuke_effect(self):
        """处理核弹效果 - 消灭所有敌人"""
        destroyed_count = 0
        for enemy in self.enemy_tanks:
            if enemy.alive:
                enemy.take_damage(999)  # 巨大伤害，确保死亡
                destroyed_count += 1
                
                # 给玩家加分
                if self.player_tank:
                    score_map = {
                        TANK_TYPES['BASIC_ENEMY']: 100,
                        TANK_TYPES['ARMOR_ENEMY']: 200,
                        TANK_TYPES['FAST_ENEMY']: 150,
                        TANK_TYPES['HEAVY_ENEMY']: 300
                    }
                    score = score_map.get(enemy.tank_type, 100)
                    self.player_tank.add_score(score)
        
        print(f"核弹爆炸！摧毁了 {destroyed_count} 个敌方坦克！")
        
        # 创建爆炸视觉效果（简单的屏幕闪烁）
        self.nuke_flash_time = pygame.time.get_ticks() + 500  # 闪烁0.5秒
    
    def _handle_freeze_effect(self):
        """处理冰冻效果 - 暂停所有敌人移动"""
        for enemy in self.enemy_tanks:
            if enemy.alive:
                # 设置冰冻状态
                enemy.frozen = True
                enemy.freeze_end_time = pygame.time.get_ticks() + 5000  # 冰冻5秒
        
        print("所有敌人被冰冻5秒！")
    
    def _restart_game(self):
        """重新开始游戏"""
        self.level_manager.reset()
        self.game_map = self.level_manager.load_level(1)
        self.state = GAME_STATES['PLAYING']
        self.spawn_interval = 3000
        self._init_game()
        print("游戏重新开始")
    
    def draw(self):
        """绘制游戏"""
        # 清屏
        self.screen.fill(COLORS['BLACK'])
        
        if self.state == GAME_STATES['PLAYING']:
            # 绘制地图
            self.game_map.draw(self.screen)
            
            # 绘制坦克
            if self.player_tank:
                self.player_tank.draw(self.screen)
            
            for enemy in self.enemy_tanks:
                enemy.draw(self.screen)
            
            # 绘制子弹
            self.bullet_manager.draw(self.screen)
            
            # 绘制道具
            self.powerup_manager.draw(self.screen)
            
            # 绘制UI
            self._draw_hud()
            
            # 绘制暂停提示
            if self.paused:
                self._draw_pause_screen()
            
            # 绘制核弹爆炸闪烁效果
            if hasattr(self, 'nuke_flash_time') and pygame.time.get_ticks() < self.nuke_flash_time:
                flash_overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
                flash_overlay.set_alpha(150)
                flash_overlay.fill(COLORS['WHITE'])
                self.screen.blit(flash_overlay, (0, 0))
        
        elif self.state == GAME_STATES['GAME_OVER']:
            self._draw_game_over_screen()
        
        # 更新显示
        pygame.display.flip()
    
    def _draw_hud(self):
        """绘制游戏界面"""
        font = pygame.font.Font(None, 36)
        
        # 玩家信息
        if self.player_tank:
            # 生命值
            health_text = font.render(f"生命: {self.player_tank.health}", True, COLORS['WHITE'])
            self.screen.blit(health_text, (10, 10))
            
            # 分数
            score_text = font.render(f"分数: {self.player_tank.score}", True, COLORS['WHITE'])
            self.screen.blit(score_text, (10, 50))
        
        # 关卡信息
        level_text = font.render(f"关卡: {self.level_manager.current_level}", True, COLORS['WHITE'])
        self.screen.blit(level_text, (SCREEN_WIDTH - 150, 10))
        
        # 敌人信息
        enemies_left = self.enemies_per_level - self.enemies_spawned + len(self.enemy_tanks)
        enemy_text = font.render(f"敌人: {enemies_left}", True, COLORS['WHITE'])
        self.screen.blit(enemy_text, (SCREEN_WIDTH - 150, 50))
        
        # 子弹计数（调试信息）
        bullet_text = font.render(f"子弹: {self.bullet_manager.get_bullet_count()}", True, COLORS['WHITE'])
        self.screen.blit(bullet_text, (10, 90))
    
    def _draw_pause_screen(self):
        """绘制暂停界面"""
        # 半透明覆盖
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(128)
        overlay.fill(COLORS['BLACK'])
        self.screen.blit(overlay, (0, 0))
        
        # 暂停文字
        font = pygame.font.Font(None, 72)
        text = font.render("游戏暂停", True, COLORS['WHITE'])
        text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        self.screen.blit(text, text_rect)
        
        # 提示文字
        font_small = pygame.font.Font(None, 36)
        hint = font_small.render("按 ESC 继续游戏", True, COLORS['WHITE'])
        hint_rect = hint.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 50))
        self.screen.blit(hint, hint_rect)
    
    def _draw_game_over_screen(self):
        """绘制游戏结束界面"""
        self.screen.fill(COLORS['BLACK'])
        
        # 游戏结束文字
        font = pygame.font.Font(None, 72)
        text = font.render("游戏结束", True, COLORS['RED'])
        text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 50))
        self.screen.blit(text, text_rect)
        
        # 最终分数
        if self.player_tank:
            font_score = pygame.font.Font(None, 48)
            score_text = font_score.render(f"最终分数: {self.player_tank.score}", True, COLORS['WHITE'])
            score_rect = score_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
            self.screen.blit(score_text, score_rect)
        
        # 重新开始提示
        font_small = pygame.font.Font(None, 36)
        restart_text = font_small.render("按 R 重新开始", True, COLORS['WHITE'])
        restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 50))
        self.screen.blit(restart_text, restart_rect)
    
    def run(self):
        """游戏主循环"""
        print("坦克大战游戏开始！")
        print("控制说明：")
        print("- 方向键：移动坦克")
        print("- 空格键：射击")
        print("- ESC键：暂停/继续")
        print("- R键：重新开始")
        
        while self.running:
            dt = self.clock.tick(FPS)
            
            self.handle_events()
            self.update(dt)
            self.draw()
        
        pygame.quit()
        sys.exit()


def main():
    """主函数"""
    try:
        game = Game()
        game.run()
    except Exception as e:
        print(f"游戏运行错误: {e}")
        pygame.quit()
        sys.exit(1)


if __name__ == "__main__":
    main()
