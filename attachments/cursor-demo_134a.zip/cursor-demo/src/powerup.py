# 道具系统模块
import pygame
import random
import math
from config import *
from utils import create_terrain_tile

class PowerUp:
    """道具基类"""
    
    def __init__(self, x, y, powerup_type=POWERUP_TYPES['INVISIBILITY']):
        self.x = x
        self.y = y
        self.powerup_type = powerup_type
        self.active = True
        self.collected = False
        
        # 动画效果
        self.animation_time = 0
        self.pulse_scale = 1.0
        
        # 创建道具图形
        self.original_image = self._create_powerup_image()
        self.image = self.original_image
        self.rect = pygame.Rect(x, y, POWERUP_SIZE, POWERUP_SIZE)
        
        # 道具属性
        self._setup_powerup_properties()
        
    def _setup_powerup_properties(self):
        """根据道具类型设置属性"""
        if self.powerup_type == POWERUP_TYPES['INVISIBILITY']:
            self.color = (200, 200, 255)  # 淡蓝色
            self.effect_duration = INVISIBILITY_DURATION
            
        elif self.powerup_type == POWERUP_TYPES['WEAPON_UPGRADE']:
            self.color = COLORS['YELLOW']
            self.effect_duration = 0  # 永久效果
            
        elif self.powerup_type == POWERUP_TYPES['EXTRA_LIFE']:
            self.color = COLORS['GREEN']
            self.effect_duration = 0  # 瞬间效果
            
        elif self.powerup_type == POWERUP_TYPES['FREEZE']:
            self.color = (150, 255, 255)  # 冰蓝色
            self.effect_duration = 5000  # 5秒冰冻
            
        elif self.powerup_type == POWERUP_TYPES['BIG_BULLET']:
            self.color = (255, 165, 0)  # 橙色
            self.effect_duration = BIG_BULLET_DURATION  # 15秒大子弹
            
        elif self.powerup_type == POWERUP_TYPES['NUKE']:
            self.color = (255, 69, 0)  # 红橙色
            self.effect_duration = 0  # 瞬间效果
    
    def _create_powerup_image(self):
        """创建道具图形"""
        surface = pygame.Surface((POWERUP_SIZE, POWERUP_SIZE))
        surface.set_colorkey(COLORS['BLACK'])  # 设置透明色
        
        if self.powerup_type == POWERUP_TYPES['INVISIBILITY']:
            # 隐身道具 - 透明效果的圆圈
            center = POWERUP_SIZE // 2
            pygame.draw.circle(surface, (200, 200, 255), (center, center), center - 2)
            pygame.draw.circle(surface, (150, 150, 200), (center, center), center - 2, 3)
            # 添加闪烁星星效果
            for i in range(4):
                angle = i * math.pi / 2
                x = center + int(math.cos(angle) * (center - 6))
                y = center + int(math.sin(angle) * (center - 6))
                pygame.draw.circle(surface, COLORS['WHITE'], (x, y), 2)
        
        elif self.powerup_type == POWERUP_TYPES['WEAPON_UPGRADE']:
            # 武器升级 - 黄色闪电
            pygame.draw.polygon(surface, COLORS['YELLOW'], [
                (POWERUP_SIZE//2, 2), (POWERUP_SIZE//2 + 4, POWERUP_SIZE//2),
                (POWERUP_SIZE//2 + 2, POWERUP_SIZE//2), (POWERUP_SIZE//2 + 6, POWERUP_SIZE - 2),
                (POWERUP_SIZE//2 - 2, POWERUP_SIZE//2 + 4), (POWERUP_SIZE//2, POWERUP_SIZE//2 + 2),
                (POWERUP_SIZE//2 - 4, 2)
            ])
        
        elif self.powerup_type == POWERUP_TYPES['EXTRA_LIFE']:
            # 额外生命 - 绿色十字
            pygame.draw.rect(surface, COLORS['GREEN'], 
                           (POWERUP_SIZE//2 - 2, 4, 4, POWERUP_SIZE - 8))
            pygame.draw.rect(surface, COLORS['GREEN'], 
                           (4, POWERUP_SIZE//2 - 2, POWERUP_SIZE - 8, 4))
        
        elif self.powerup_type == POWERUP_TYPES['FREEZE']:
            # 冰冻道具 - 雪花图案
            center = POWERUP_SIZE // 2
            # 主十字
            pygame.draw.line(surface, (150, 255, 255), (center, 2), (center, POWERUP_SIZE - 2), 2)
            pygame.draw.line(surface, (150, 255, 255), (2, center), (POWERUP_SIZE - 2, center), 2)
            # 对角线
            pygame.draw.line(surface, (150, 255, 255), (4, 4), (POWERUP_SIZE - 4, POWERUP_SIZE - 4), 2)
            pygame.draw.line(surface, (150, 255, 255), (POWERUP_SIZE - 4, 4), (4, POWERUP_SIZE - 4), 2)
        
        elif self.powerup_type == POWERUP_TYPES['BIG_BULLET']:
            # 大子弹道具 - 橙色炮弹形状
            center = POWERUP_SIZE // 2
            # 炮弹本体
            pygame.draw.ellipse(surface, (255, 165, 0), 
                              (center - 6, 4, 12, POWERUP_SIZE - 8))
            # 炮弹头部
            pygame.draw.circle(surface, (255, 140, 0), (center, 6), 4)
            # 闪光效果
            pygame.draw.circle(surface, COLORS['YELLOW'], (center - 3, 8), 2)
            pygame.draw.circle(surface, COLORS['WHITE'], (center + 2, 10), 1)
        
        elif self.powerup_type == POWERUP_TYPES['NUKE']:
            # 核弹道具 - 红色爆炸图案
            center = POWERUP_SIZE // 2
            # 核心圆圈
            pygame.draw.circle(surface, (255, 69, 0), (center, center), 8)
            pygame.draw.circle(surface, (255, 140, 0), (center, center), 6)
            pygame.draw.circle(surface, COLORS['YELLOW'], (center, center), 4)
            # 爆炸射线
            for i in range(8):
                angle = i * math.pi / 4
                x1 = center + int(math.cos(angle) * 6)
                y1 = center + int(math.sin(angle) * 6)
                x2 = center + int(math.cos(angle) * 10)
                y2 = center + int(math.sin(angle) * 10)
                pygame.draw.line(surface, (255, 69, 0), (x1, y1), (x2, y2), 2)
        
        return surface
    
    def update(self, dt):
        """更新道具状态"""
        if not self.active:
            return
        
        # 更新动画
        self.animation_time += dt
        self.pulse_scale = 1.0 + 0.1 * math.sin(self.animation_time * 0.005)
        
        # 更新图形
        scaled_size = int(POWERUP_SIZE * self.pulse_scale)
        self.image = pygame.transform.scale(self.original_image, (scaled_size, scaled_size))
        
        # 更新碰撞矩形位置（保持中心对齐）
        old_center = self.rect.center
        self.rect = self.image.get_rect()
        self.rect.center = old_center
    
    def check_collision_with_tank(self, tank):
        """检查与坦克的碰撞"""
        if not self.active or self.collected:
            return False
        
        tank_rect = tank.get_rect()
        if self.rect.colliderect(tank_rect):
            self.collected = True
            self.active = False
            return True
        
        return False
    
    def apply_effect(self, tank):
        """应用道具效果到坦克"""
        if self.powerup_type == POWERUP_TYPES['INVISIBILITY']:
            if hasattr(tank, 'activate_invisibility'):
                tank.activate_invisibility(self.effect_duration)
                return "隐身激活！"
        
        elif self.powerup_type == POWERUP_TYPES['WEAPON_UPGRADE']:
            if hasattr(tank, 'upgrade_weapon'):
                tank.upgrade_weapon()
                return "武器升级！"
        
        elif self.powerup_type == POWERUP_TYPES['EXTRA_LIFE']:
            if hasattr(tank, 'heal'):
                tank.heal(1)
                return "生命恢复！"
        
        elif self.powerup_type == POWERUP_TYPES['FREEZE']:
            # 冰冻效果需要在游戏主循环中处理
            return "敌人冰冻！"
        
        elif self.powerup_type == POWERUP_TYPES['BIG_BULLET']:
            if hasattr(tank, 'activate_big_bullet'):
                tank.activate_big_bullet(self.effect_duration)
                return "大威力子弹激活！"
        
        elif self.powerup_type == POWERUP_TYPES['NUKE']:
            # 核弹效果需要在游戏主循环中处理所有敌人
            return "核弹爆炸！"
        
        return "道具生效！"
    
    def draw(self, screen):
        """绘制道具"""
        if self.active and not self.collected:
            screen.blit(self.image, self.rect)


class PowerUpManager:
    """道具管理器"""
    
    def __init__(self):
        self.powerups = []
        self.last_spawn_time = 0
        self.spawn_interval = 15000  # 15秒生成一个道具
        
    def update(self, dt, game_map, player_tank):
        """更新所有道具"""
        current_time = pygame.time.get_ticks()
        
        # 检查是否需要生成新道具
        if (current_time - self.last_spawn_time >= self.spawn_interval and
            len(self.powerups) < 3):  # 最多同时存在3个道具
            self._spawn_random_powerup(game_map)
            self.last_spawn_time = current_time
        
        # 更新现有道具
        active_powerups = []
        effect_message = None
        
        for powerup in self.powerups:
            if powerup.active:
                powerup.update(dt)
                
                # 检查玩家碰撞
                if powerup.check_collision_with_tank(player_tank):
                    effect_message = powerup.apply_effect(player_tank)
                    print(f"玩家获得道具: {effect_message}")
                else:
                    active_powerups.append(powerup)
        
        self.powerups = active_powerups
        return effect_message
    
    def _spawn_random_powerup(self, game_map):
        """随机生成道具"""
        # 寻找合适的生成位置
        attempts = 0
        max_attempts = 50
        
        while attempts < max_attempts:
            x = random.randint(POWERUP_SIZE, SCREEN_WIDTH - POWERUP_SIZE)
            y = random.randint(POWERUP_SIZE, SCREEN_HEIGHT - POWERUP_SIZE)
            
            # 检查位置是否可用（不在墙体内）
            if self._is_valid_spawn_position(x, y, game_map):
                # 随机选择道具类型
                powerup_types = list(POWERUP_TYPES.values())
                powerup_type = random.choice(powerup_types)
                
                powerup = PowerUp(x, y, powerup_type)
                self.powerups.append(powerup)
                print(f"生成道具: 类型 {powerup_type} 在位置 ({x}, {y})")
                break
            
            attempts += 1
    
    def _is_valid_spawn_position(self, x, y, game_map):
        """检查是否是有效的道具生成位置"""
        if not game_map:
            return True
        
        # 检查道具区域是否与地形冲突
        corners = [
            (x, y), (x + POWERUP_SIZE, y),
            (x, y + POWERUP_SIZE), (x + POWERUP_SIZE, y + POWERUP_SIZE)
        ]
        
        for corner_x, corner_y in corners:
            grid_x = corner_x // GRID_SIZE
            grid_y = corner_y // GRID_SIZE
            
            if (0 <= grid_x < GRID_COLS and 0 <= grid_y < GRID_ROWS):
                terrain = game_map.get_terrain(grid_x, grid_y)
                if terrain in [TERRAIN_TYPES['BRICK_WALL'], 
                              TERRAIN_TYPES['STEEL_WALL'], 
                              TERRAIN_TYPES['WATER'],
                              TERRAIN_TYPES['BASE']]:
                    return False
        
        return True
    
    def draw(self, screen):
        """绘制所有道具"""
        for powerup in self.powerups:
            powerup.draw(screen)
    
    def clear(self):
        """清除所有道具"""
        self.powerups.clear()
    
    def get_powerup_count(self):
        """获取当前道具数量"""
        return len(self.powerups)
