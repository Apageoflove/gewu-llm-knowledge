# 坦克类模块
import pygame
import random
from config import *
from utils import create_simple_tank, get_angle_from_direction, rotate_surface

class Tank:
    """坦克基类"""
    
    def __init__(self, x, y, tank_type=TANK_TYPES['PLAYER']):
        self.x = x
        self.y = y
        self.tank_type = tank_type
        self.direction = DIRECTIONS['UP']
        self.speed = TANK_SPEED
        self.health = 1
        self.max_health = 1
        self.alive = True
        self.last_shot_time = 0
        self.shot_cooldown = 500  # 毫秒
        
        # 设置坦克属性
        self._setup_tank_properties()
        
        # 创建坦克图形
        self.original_image = self._create_tank_image()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        # 移动相关
        self.target_x = x
        self.target_y = y
        self.moving = False
        
    def _setup_tank_properties(self):
        """根据坦克类型设置属性"""
        if self.tank_type == TANK_TYPES['PLAYER']:
            self.speed = TANK_SPEED
            self.health = 3
            self.max_health = 3
            self.shot_cooldown = 300
            self.color = COLORS['GREEN']
            
        elif self.tank_type == TANK_TYPES['BASIC_ENEMY']:
            self.speed = TANK_SPEED // 2
            self.health = 1
            self.max_health = 1
            self.shot_cooldown = 800
            self.color = COLORS['RED']
            
        elif self.tank_type == TANK_TYPES['ARMOR_ENEMY']:
            self.speed = TANK_SPEED // 2
            self.health = 3
            self.max_health = 3
            self.shot_cooldown = 600
            self.color = (200, 0, 0)  # 深红色
            
        elif self.tank_type == TANK_TYPES['FAST_ENEMY']:
            self.speed = TANK_SPEED * 2
            self.health = 1
            self.max_health = 1
            self.shot_cooldown = 400
            self.color = (255, 100, 100)  # 浅红色
            
        elif self.tank_type == TANK_TYPES['HEAVY_ENEMY']:
            self.speed = TANK_SPEED // 3
            self.health = 5
            self.max_health = 5
            self.shot_cooldown = 1000
            self.color = (100, 0, 0)  # 暗红色
            
    def _create_tank_image(self):
        """创建坦克图形"""
        return create_simple_tank(self.color, (TANK_SIZE, TANK_SIZE))
    
    def update(self, dt):
        """更新坦克状态"""
        if not self.alive:
            return
            
        # 平滑移动到目标位置
        if self.moving:
            dx = self.target_x - self.x
            dy = self.target_y - self.y
            
            if abs(dx) < self.speed and abs(dy) < self.speed:
                self.x = self.target_x
                self.y = self.target_y
                self.moving = False
            else:
                if dx != 0:
                    self.x += self.speed if dx > 0 else -self.speed
                if dy != 0:
                    self.y += self.speed if dy > 0 else -self.speed
            
            self.rect.x = self.x
            self.rect.y = self.y
    
    def move(self, direction, game_map):
        """移动坦克"""
        if not self.alive or self.moving:
            return False
            
        # 计算新位置
        new_x = self.x + direction[0] * GRID_SIZE
        new_y = self.y + direction[1] * GRID_SIZE
        
        # 检查边界
        if (new_x < 0 or new_x >= SCREEN_WIDTH - TANK_SIZE or 
            new_y < 0 or new_y >= SCREEN_HEIGHT - TANK_SIZE):
            return False
        
        # 检查地形碰撞
        if game_map and game_map.check_tank_collision(new_x, new_y, TANK_SIZE):
            return False
        
        # 更新方向和目标位置
        self.direction = direction
        self.target_x = new_x
        self.target_y = new_y
        self.moving = True
        
        # 旋转坦克图形
        angle = get_angle_from_direction(direction)
        self.image = rotate_surface(self.original_image, angle)
        
        return True
    
    def can_shoot(self):
        """检查是否可以射击"""
        current_time = pygame.time.get_ticks()
        return current_time - self.last_shot_time >= self.shot_cooldown
    
    def shoot(self):
        """射击"""
        if not self.alive or not self.can_shoot():
            return None
            
        self.last_shot_time = pygame.time.get_ticks()
        
        # 计算子弹起始位置（坦克中心）
        if hasattr(self, 'big_bullet_active') and self.big_bullet_active:
            bullet_size = BIG_BULLET_SIZE
        else:
            bullet_size = BULLET_SIZE
            
        bullet_x = self.x + TANK_SIZE // 2 - bullet_size // 2
        bullet_y = self.y + TANK_SIZE // 2 - bullet_size // 2
        
        from src.bullet import Bullet
        bullet = Bullet(bullet_x, bullet_y, self.direction, self)
        
        # 如果是大子弹，设置特殊属性
        if hasattr(self, 'big_bullet_active') and self.big_bullet_active:
            bullet.is_big_bullet = True
            bullet.damage *= 3  # 大子弹伤害是普通子弹的3倍
        
        return bullet
    
    def take_damage(self, damage=1):
        """受到伤害"""
        if not self.alive:
            return
            
        self.health -= damage
        if self.health <= 0:
            self.alive = False
            self.health = 0
    
    def heal(self, amount=1):
        """恢复生命值"""
        if not self.alive:
            return
            
        self.health = min(self.health + amount, self.max_health)
    
    def get_rect(self):
        """获取碰撞矩形"""
        return pygame.Rect(self.x, self.y, TANK_SIZE, TANK_SIZE)
    
    def draw(self, screen):
        """绘制坦克"""
        if self.alive:
            screen.blit(self.image, (self.x, self.y))
            
            # 绘制生命值条（仅非玩家坦克）
            if self.tank_type != TANK_TYPES['PLAYER'] and self.max_health > 1:
                self._draw_health_bar(screen)
            
            # 绘制冰冻效果（敌方坦克）
            if hasattr(self, 'frozen') and self.frozen:
                # 绘制冰冻边框
                pygame.draw.rect(screen, (150, 255, 255), 
                               (self.x, self.y, TANK_SIZE, TANK_SIZE), 3)
                # 绘制冰晶效果
                center_x = self.x + TANK_SIZE // 2
                center_y = self.y + TANK_SIZE // 2
                pygame.draw.line(screen, (200, 255, 255), 
                               (center_x - 8, center_y), (center_x + 8, center_y), 2)
                pygame.draw.line(screen, (200, 255, 255), 
                               (center_x, center_y - 8), (center_x, center_y + 8), 2)
    
    def _draw_health_bar(self, screen):
        """绘制生命值条"""
        bar_width = TANK_SIZE
        bar_height = 4
        bar_x = self.x
        bar_y = self.y - 8
        
        # 背景条
        pygame.draw.rect(screen, COLORS['RED'], 
                        (bar_x, bar_y, bar_width, bar_height))
        
        # 生命值条
        health_width = int(bar_width * (self.health / self.max_health))
        pygame.draw.rect(screen, COLORS['GREEN'], 
                        (bar_x, bar_y, health_width, bar_height))


class PlayerTank(Tank):
    """玩家坦克类"""
    
    def __init__(self, x, y):
        super().__init__(x, y, TANK_TYPES['PLAYER'])
        self.score = 0
        self.power_level = 1
        self.shield_active = False
        self.shield_end_time = 0
        self.invisibility_active = False
        self.invisibility_end_time = 0
        self.big_bullet_active = False
        self.big_bullet_end_time = 0
    
    def handle_input(self, keys, game_map):
        """处理输入"""
        if not self.alive:
            return None
            
        # 移动
        for key, direction_name in PLAYER_KEYS.items():
            if keys[key] and direction_name in DIRECTIONS:
                direction = DIRECTIONS[direction_name]
                self.move(direction, game_map)
                break
        
        # 射击
        if keys[pygame.K_SPACE] and self.can_shoot():
            return self.shoot()
        
        return None
    
    def update(self, dt):
        """更新玩家坦克"""
        super().update(dt)
        
        current_time = pygame.time.get_ticks()
        
        # 更新护盾状态
        if self.shield_active:
            if current_time >= self.shield_end_time:
                self.shield_active = False
        
        # 更新隐身状态
        if self.invisibility_active:
            if current_time >= self.invisibility_end_time:
                self.invisibility_active = False
        
        # 更新大子弹状态
        if self.big_bullet_active:
            if current_time >= self.big_bullet_end_time:
                self.big_bullet_active = False
    
    def activate_shield(self, duration=5000):
        """激活护盾"""
        self.shield_active = True
        self.shield_end_time = pygame.time.get_ticks() + duration
    
    def activate_invisibility(self, duration=10000):
        """激活隐身"""
        self.invisibility_active = True
        self.invisibility_end_time = pygame.time.get_ticks() + duration
    
    def activate_big_bullet(self, duration=15000):
        """激活大子弹"""
        self.big_bullet_active = True
        self.big_bullet_end_time = pygame.time.get_ticks() + duration
    
    def upgrade_weapon(self):
        """升级武器"""
        self.power_level = min(self.power_level + 1, 3)
        self.shot_cooldown = max(100, self.shot_cooldown - 50)
    
    def add_score(self, points):
        """增加分数"""
        self.score += points
    
    def draw(self, screen):
        """绘制玩家坦克"""
        # 如果隐身，绘制半透明效果
        if self.invisibility_active:
            # 创建半透明表面
            temp_surface = pygame.Surface((TANK_SIZE, TANK_SIZE))
            temp_surface.set_alpha(100)  # 设置透明度
            temp_surface.blit(self.image, (0, 0))
            screen.blit(temp_surface, (self.x, self.y))
            
            # 绘制隐身边框效果
            pygame.draw.rect(screen, (200, 200, 255), 
                           (self.x, self.y, TANK_SIZE, TANK_SIZE), 2)
        else:
            super().draw(screen)
        
        # 绘制护盾效果
        if self.shield_active:
            pygame.draw.circle(screen, COLORS['BLUE'], 
                             (self.x + TANK_SIZE//2, self.y + TANK_SIZE//2), 
                             TANK_SIZE//2 + 5, 2)
        
        # 绘制隐身状态指示
        if self.invisibility_active:
            pygame.draw.circle(screen, (200, 200, 255), 
                             (self.x + TANK_SIZE//2, self.y + TANK_SIZE//2), 
                             TANK_SIZE//2 + 8, 1)


class EnemyTank(Tank):
    """敌方坦克类"""
    
    def __init__(self, x, y, tank_type=TANK_TYPES['BASIC_ENEMY']):
        super().__init__(x, y, tank_type)
        self.ai_timer = 0
        self.ai_interval = random.randint(1000, 3000)  # AI思考间隔
        self.target_direction = None
        self.stuck_counter = 0
        self.last_position = (x, y)
        self.frozen = False
        self.freeze_end_time = 0
        
    def update(self, dt, game_map, player_tank, other_tanks):
        """更新敌方坦克AI"""
        super().update(dt)
        
        if not self.alive:
            return None
        
        current_time = pygame.time.get_ticks()
        
        # 检查冰冻状态
        if self.frozen:
            if current_time >= self.freeze_end_time:
                self.frozen = False
            else:
                return None  # 冰冻期间不执行任何AI操作
        
        bullet = None
        
        # AI决策
        if current_time - self.ai_timer >= self.ai_interval:
            self.ai_timer = current_time
            self.ai_interval = random.randint(500, 2000)
            
            # 选择行动
            if random.random() < 0.3 and self.can_shoot():  # 30% 概率射击
                bullet = self.shoot()
            else:
                self._choose_movement_direction(game_map, player_tank, other_tanks)
        
        # 执行移动
        if self.target_direction and not self.moving:
            success = self.move(self.target_direction, game_map)
            if not success:
                self.stuck_counter += 1
                if self.stuck_counter >= 3:
                    # 如果卡住了，随机选择新方向
                    self._choose_random_direction()
                    self.stuck_counter = 0
        
        # 检查是否卡住
        if (self.x, self.y) == self.last_position:
            self.stuck_counter += 1
        else:
            self.stuck_counter = 0
            self.last_position = (self.x, self.y)
        
        return bullet
    
    def _choose_movement_direction(self, game_map, player_tank, other_tanks):
        """选择移动方向"""
        if not player_tank or not player_tank.alive:
            self._choose_random_direction()
            return
        
        # 计算到玩家的距离
        player_distance = ((self.x - player_tank.x)**2 + (self.y - player_tank.y)**2)**0.5
        
        # 如果距离太近，随机移动
        if player_distance < 100:
            self._choose_random_direction()
        else:
            # 朝向玩家移动
            dx = player_tank.x - self.x
            dy = player_tank.y - self.y
            
            if abs(dx) > abs(dy):
                self.target_direction = DIRECTIONS['RIGHT'] if dx > 0 else DIRECTIONS['LEFT']
            else:
                self.target_direction = DIRECTIONS['DOWN'] if dy > 0 else DIRECTIONS['UP']
    
    def _choose_random_direction(self):
        """选择随机方向"""
        directions = list(DIRECTIONS.values())
        self.target_direction = random.choice(directions)
