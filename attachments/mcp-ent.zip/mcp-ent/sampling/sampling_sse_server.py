# 如果想使用MCP Inspector ，就引入这个包
# from mcp.server.fastmcp import FastMCP

# 如果想独立启动fastmcp server，就引入这个包
from fastmcp import FastMCP

mcp = FastMCP("mcp-server")

from fastmcp import Context

# -- 服务器端 --
# 创建一个从客户端请求LLM补全的服务器


@mcp.tool()
async def generate_poem(topic: str, context: Context) -> str:
    """生成关于给定主题的短诗。"""
    # 服务器从客户端LLM请求补全
    response = await context.sample(
        f"请为{topic}写一首短诗",
        system_prompt="你是一位才华横溢的诗人，能够创作简洁而富有感染力的诗歌。"
    )
    return response.text

# 获取文档资源
@mcp.resource("data://get_docs")
def get_docs() -> list[str]:
    """返回可用产品类别列表。"""
    return (
        "MCP 的诞生绝非偶然，而是 AI 发展进程中需求推动的必然结果。随着 GPT-4、Claude 等大模型在推理能力和回答质量上取得显著突破，如何让 AI 与企业自身的数据和系统对接，成为横亘在发展道路上的新挑战。"
        "在 MCP 出现之前，不同 AI 助手接入数据库、文件系统、第三方应用等，通常都需要编写定制的集成代码。例如，开发者可能使用 LangChain 框架编写 Python 脚本，让某个 LLM 能查询自家数据库；"
        "可要是换成另一个 LLM 模型或另一个数据源，就不得不重新适配新的代码。"
        "这种“M×N 集成难题”日益突出：M 种不同的大模型与 N 种不同的数据 / 工具要两两集成，需要开发和维护大量碎片化的连接器。这不仅开发成本高、容易出错，而且难以规模化地扩展 AI 系统的能力")

@mcp.tool()
async def summarize_document(document_uri: str, context: Context) -> str:
    """使用客户端LLM能力总结文档。"""
    # 首先读取文档作为资源
    doc_resource = await context.read_resource(document_uri)
    doc_content = doc_resource[0].content  # 假设为单个文本内容

    # 然后要求客户端LLM对其进行总结
    response = await context.sample(
        f"请总结以下文档内容：\n\n{doc_content}",
        system_prompt="你是一位专业的总结专家，请创建简洁的摘要。"
    )
    return response.text


if __name__ == "__main__":
    mcp.run(transport='sse', host="127.0.0.1", port=3001)
