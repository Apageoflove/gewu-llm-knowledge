
#uv添加python库
uv add "mcp[cli]"
uv add "fastmcp"
uv add "openai"
uv add pydantic_ai

#uv 命令启动MCP Inspector
uv run mcp dev server.py


#mcp命令启动MCP Inspector
mcp dev server.py
mcp dev debug_stdio_server.py


#安装官方mcp库
pip install mcp[cli]

#安装fastmcp库
pip install fastmcp