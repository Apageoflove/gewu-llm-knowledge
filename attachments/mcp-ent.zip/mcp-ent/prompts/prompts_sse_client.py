import asyncio
import json
import logging
import os
from fastmcp import Client
from openai import OpenAI, AsyncOpenAI
from pydantic_ai.models.openai import OpenAIModel
from pydantic_ai.providers.deepseek import DeepSeekProvider
import re


class LLMClient:
    """大语言模型客户端，负责与LLM API进行通信"""

    def __init__(self, model_name: str, url: str, api_key: str) -> None:
        """
        初始化LLM客户端

        Args:
            model_name: 模型名称
            url: API基础URL
            api_key: API密钥
        """
        self.model_name: str = model_name
        self.url: str = url
        self.client = OpenAI(api_key=api_key, base_url=url)

    def get_response(self, messages: list[dict[str, str]]) -> str:
        """
        向LLM发送消息并获取响应

        Args:
            messages: 消息列表，每条消息包含role和content

        Returns:
            LLM的响应文本
        """
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=messages,
            stream=False
        )
        return response.choices[0].message.content


class ChatSession:
    """聊天会话管理器，处理用户输入、LLM响应和资源访问"""

    def __init__(self, llm_client: LLMClient, mcp_client: Client) -> None:
        """
        初始化聊天会话

        Args:
            llm_client: LLM客户端实例
            mcp_client: MCP客户端实例，用于访问资源
        """
        self.mcp_client: Client = mcp_client
        self.llm_client: LLMClient = llm_client

    async def process_llm_response(self, llm_response: str) -> str:
        """
        处理LLM的响应，解析资源URI调用或工具调用并执行

        Args:
            llm_response: LLM返回的响应文本

        Returns:
            处理后的响应文本，包含资源数据或工具执行结果
        """
        try:
            # 检查是否为资源URI调用（以*://开头，例如：db://）
            if re.match(r'^\w+://', llm_response.strip()):
                uri = llm_response.strip()
                try:
                    # 执行资源读取
                    resource_data = await self.mcp_client.read_resource(uri=uri)
                    return f"Resource data: {resource_data}"
                except Exception as e:
                    error_msg = f"Error reading resource: {str(e)}"
                    logging.error(error_msg)
                    return error_msg
            else:
                # 尝试解析为JSON工具调用（保留兼容性）
                if llm_response.startswith('```json'):
                    llm_response = llm_response.strip('```json').strip('```').strip()
                try:
                    tool_call = json.loads(llm_response)
                    # 处理工具调用
                    if "tool" in tool_call and "arguments" in tool_call:
                        # 检查工具是否可用
                        available_tools = await self.mcp_client.list_tools()
                        if any(tool.name == tool_call["tool"] for tool in available_tools):
                            try:
                                # 执行工具调用
                                tool_result = await self.mcp_client.call_tool(
                                    tool_call["tool"], tool_call["arguments"]
                                )
                                return f"Tool execution result: {tool_result}"
                            except Exception as e:
                                error_msg = f"Error executing tool: {str(e)}"
                                logging.error(error_msg)
                                return error_msg
                        return f"Tool not found: {tool_call['tool']}"
                    
                    # 处理提示词调用
                    elif "prompt" in tool_call and "arguments" in tool_call:
                        # 检查提示词是否可用
                        available_prompts = await self.mcp_client.list_prompts()
                        if any(prompt.name == tool_call["prompt"] for prompt in available_prompts):
                            try:
                                # 执行提示词调用
                                prompt_result = await self.mcp_client.get_prompt(
                                    tool_call["prompt"], tool_call["arguments"]
                                )
                                return f"Prompt execution result: {prompt_result}"
                            except Exception as e:
                                error_msg = f"Error executing prompt: {str(e)}"
                                logging.error(error_msg)
                                return error_msg
                        return f"Prompt not found: {tool_call['prompt']}"
                    
                    # 处理资源调用（JSON格式）
                    elif "resource" in tool_call:
                        try:
                            # 执行资源读取
                            resource_data = await self.mcp_client.read_resource(uri=tool_call["resource"])
                            return f"Resource data: {resource_data}"
                        except Exception as e:
                            error_msg = f"Error reading resource: {str(e)}"
                            logging.error(error_msg)
                            return error_msg
                except json.JSONDecodeError:
                    pass
                # 如果不是JSON格式或工具调用，直接返回原始响应
                return llm_response
        except Exception as e:
            error_msg = f"Error processing LLM response: {str(e)}"
            logging.error(error_msg)
            return error_msg

    async def start(self, system_message: str) -> None:
        """
        启动聊天会话的主循环

        Args:
            system_message: 系统提示消息，指导LLM的行为
        """
        messages = [{"role": "system", "content": system_message}]
        while True:
            try:
                # 获取用户输入
                user_input = input("用户: ").strip().lower()
                if user_input in ["quit", "exit", "退出"]:
                    print('AI助手已退出')
                    break
                messages.append({"role": "user", "content": user_input})

                # 获取LLM的初始响应
                llm_response = self.llm_client.get_response(messages)
                print("助手: ", llm_response)

                # 处理可能的资源调用或工具调用
                result = await self.process_llm_response(llm_response)

                # 如果处理结果与原始响应不同，说明执行了资源调用或工具调用，需要进一步处理
                while result != llm_response:
                    messages.append({"role": "assistant", "content": llm_response})
                    messages.append({"role": "system", "content": result})

                    # 将资源数据或工具执行结果发送回LLM获取新响应
                    llm_response = self.llm_client.get_response(messages)
                    result = await self.process_llm_response(llm_response)
                    print("助手: ", llm_response)

                messages.append({"role": "assistant", "content": llm_response})

            except KeyboardInterrupt:
                print('AI助手已退出')
                break


# 获取DeepSeek API密钥
api_key = os.getenv('DEEPSEEK_API_KEY')
base_url = os.getenv('DEEPSEEK_BASE_URL')
model_name = os.getenv('DEEPSEEK_MODEL_NAME')

client = AsyncOpenAI(max_retries=3, base_url=base_url, api_key=api_key)
# 初始化DeepSeek模型
model = OpenAIModel(
    model_name=model_name,
    provider=DeepSeekProvider(openai_client=client),
)



async def main():
    """主函数，初始化客户端并启动聊天会话"""
    async with Client("http://127.0.0.1:3001/sse", timeout=600) as mcp_client:
        # 初始化LLM客户端，使用通义千问模型
        llm_client = LLMClient(
            model_name='gpt-4o',
            api_key=os.getenv('OPENAI_API_KEY'),
            url='https://api.openai.com/v1'
        )

        # 获取可用工具列表并格式化为系统提示的一部分
        tools = await mcp_client.list_tools()
        dict_list = [tool.__dict__ for tool in tools]
        tools_description = json.dumps(dict_list, ensure_ascii=False)

        # 获取可用资源列表并格式化为系统提示的一部分
        try:
            resources = await mcp_client.list_resources()
            resources_description = json.dumps(resources, ensure_ascii=False)
        except Exception as e:
            logging.error(f"Error listing resources: {str(e)}")
            resources_description = "[]"
        # 获取可用提示词列表并格式化为系统提示的一部分
        prompts = await mcp_client.list_prompts()
        prompts_dicts = []
        for resource in prompts:
            data_dict = {}
            for key, value in resource.__dict__.items():
                # 将AnyUrl类型转换为字符串
                if hasattr(value, '__str__'):
                    data_dict[key] = str(value)
                else:
                    data_dict[key] = value
            prompts_dicts.append(data_dict)
        prompts_description = json.dumps(prompts_dicts, ensure_ascii=False)
        # 系统提示，指导LLM如何使用资源模板和返回响应
        system_message = f'''
                       你是一个智能助手，严格遵循以下协议返回响应：

                       可用工具：{tools_description}
                       可用资源：{resources_description}
                       可用提示词模版：{prompts_description}

                       响应规则：
                       1、当需要计算时，返回严格符合以下格式的纯净JSON：
                       {{
                           "tool": "tool-name",
                           "arguments": {{
                               "argument-name": "value"
                           }}
                       }}
                       2、当需要获取资源时，返回严格符合以下格式的纯净JSON：
                       {{
                           "resource": "resource-name"
                       }}
                       3、当需要使用提示词模板时，返回严格符合以下格式的纯净JSON：
                       {{
                           "prompt": "prompt-name",
                           "arguments": {{
                               "argument-name": "value"
                           }}
                       }}
                       4、禁止包含以下内容：
                        - Markdown标记（如```json）
                        - 自然语言解释（如"结果："）
                        - 格式化数值（必须保持原始精度）
                        - 单位符号（如元、kg）

                       校验流程：
                       ✓ 参数数量与工具/资源定义一致
                       ✓ 数值类型为number
                       ✓ JSON格式有效性检查

                       正确示例：
                       用户：单价88.5买235个多少钱？
                       响应：{{"tool":"multiply","arguments":{{"a":88.5,"b":235}}}}
                       用户：获取用户张三的问候
                       响应：{{"resource":"greeting://{{张三}}"}}
                       用户：使用客服回复模板回复客户
                       响应：{{"prompt":"customer-service","arguments":{{"customer_name":"客户名","issue":"问题描述"}}}}

                       错误示例：
                       用户：总金额是多少？
                       错误响应：总价500元 → 含自然语言
                       错误响应：```json{{...}}``` → 含Markdown

                       5、在收到工具、资源或提示词的响应后：
                        - 将原始数据转化为自然、对话式的回应
                        - 保持回复简洁但信息丰富
                        - 聚焦于最相关的信息
                        - 使用用户问题中的适当上下文
                        - 避免简单重复使用原始数据
                       '''
        # 启动聊天会话
        chat_session = ChatSession(llm_client=llm_client, mcp_client=mcp_client)
        await chat_session.start(system_message=system_message)


if __name__ == "__main__":
    asyncio.run(main())
