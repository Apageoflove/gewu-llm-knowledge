# 如果想使用MCP Inspector ，就引入这个包
# from mcp.server.fastmcp import FastMCP

# 如果想独立启动fastmcp server，就引入这个包
from fastmcp import FastMCP
from fastmcp.prompts import Message
from mcp.server.fastmcp.prompts.base import AssistantMessage, UserMessage

mcp = FastMCP("mcp-server")


@mcp.prompt()
def ask_review(code_snippet: str) -> str:
    """生成标准的代码审查请求。"""
    return f"请审查以下代码片段中的潜在错误和风格问题：\n```python\n{code_snippet}\n```"


@mcp.prompt()
def debug_session_start(error_message: str) -> list[Message]:
    """启动调试帮助会话。"""
    return [
        UserMessage(f"我遇到了一个错误：\n{error_message}"), AssistantMessage(
            "好的，我可以帮助你解决这个问题。你能提供完整的错误追踪信息并告诉我你当时在尝试做什么吗？")
    ]


if __name__ == "__main__":
    mcp.run(transport='sse', host="127.0.0.1", port=3001)
