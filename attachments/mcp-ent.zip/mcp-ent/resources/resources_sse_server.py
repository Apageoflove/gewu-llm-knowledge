# 如果想使用MCP Inspector ，就引入这个包
# from mcp.server.fastmcp import FastMCP

# 如果想独立启动fastmcp server，就引入这个包
from fastmcp import FastMCP
from pydantic import BaseModel

mcp = FastMCP("mcp-server")


# 静态资源，返回简单的文本
@mcp.resource("config://app-version")
def get_app_version() -> str:
    """返回应用程序版本。"""
    return "v2.1.0"


# 动态资源模板，期望从URI中获取'user_id'参数
@mcp.resource("db://users/{user_id}/email")
async def get_user_email(user_id: str) -> str:
    """根据给定的用户ID检索邮箱地址。"""
    # 替换为实际的数据库查询
    emails = {"123": "alice@example.com", "456": "bob@example.com"}
    return emails.get(user_id, "not_found@example.com")


# 返回JSON数据的资源
@mcp.resource("data://product-categories")
def get_categories() -> list[str]:
    """返回可用产品类别列表。"""
    return ["Electronics", "Books", "Home Goods"]


if __name__ == "__main__":
    mcp.run(transport='sse', host="127.0.0.1", port=3001)
