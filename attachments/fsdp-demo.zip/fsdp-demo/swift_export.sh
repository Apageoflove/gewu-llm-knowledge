swift export \
    --adapters output/v2-20250517-223753/checkpoint-6 \
    --merge_lora true