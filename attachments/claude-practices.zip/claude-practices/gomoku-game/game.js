// 游戏配置常量
const GAME_CONFIG = {
    BOARD_SIZE: 15,
    CELL_SIZE: 40,
    CANVAS_SIZE: 600,
    WIN_COUNT: 5,
    PLAYER_BLACK: 1,
    PLAYER_WHITE: 2,
    EMPTY_CELL: 0
};

// 五子棋游戏主类
class GomokuGame {
    constructor() {
        // 初始化游戏配置
        this.boardSize = GAME_CONFIG.BOARD_SIZE;
        this.cellSize = GAME_CONFIG.CELL_SIZE;
        this.board = [];
        this.currentPlayer = GAME_CONFIG.PLAYER_BLACK;
        this.gameOver = false;
        this.moveHistory = [];
        
        // 获取DOM元素并检查存在性
        this.canvas = this.getRequiredElement('game-board');
        this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
        this.playerIndicator = this.getRequiredElement('player-indicator');
        this.gameResult = this.getRequiredElement('game-result');
        this.winnerText = this.getRequiredElement('winner-text');
        this.restartBtn = this.getRequiredElement('restart-btn');
        this.undoBtn = this.getRequiredElement('undo-btn');
        this.newGameBtn = this.getRequiredElement('new-game-btn');
        
        // 检查必需元素是否存在
        if (!this.validateRequiredElements()) {
            throw new Error('缺少必需的DOM元素，请检查HTML结构');
        }
        
        // 初始化游戏
        this.initGame();
        this.bindEvents();
    }
    
    // 获取必需元素并返回，如果不存在则返回null
    getRequiredElement(id) {
        const element = document.getElementById(id);
        if (!element) {
            console.error(`找不到ID为 '${id}' 的元素`);
        }
        return element;
    }
    
    // 验证必需元素是否都存在
    validateRequiredElements() {
        const requiredElements = [
            this.canvas, this.ctx, this.playerIndicator, 
            this.gameResult, this.winnerText, this.restartBtn,
            this.undoBtn, this.newGameBtn
        ];
        return requiredElements.every(element => element !== null);
    }
    
    // 初始化游戏状态
    initGame() {
        // 初始化棋盘为空
        this.board = Array(this.boardSize).fill(null).map(() => 
            Array(this.boardSize).fill(GAME_CONFIG.EMPTY_CELL)
        );
        
        this.currentPlayer = GAME_CONFIG.PLAYER_BLACK; // 黑子先手
        this.gameOver = false;
        this.moveHistory = [];
        
        this.drawBoard();
        this.updatePlayerIndicator();
        this.hideGameResult();
    }
    
    // 绑定事件监听器
    bindEvents() {
        // 棋盘点击事件
        if (this.canvas) {
            this.canvas.addEventListener('click', (event) => {
                if (this.gameOver) return;
                
                const rect = this.canvas.getBoundingClientRect();
                const x = event.clientX - rect.left;
                const y = event.clientY - rect.top;
                
                this.handleBoardClick(x, y);
            });
        }
        
        // 重新开始按钮
        if (this.restartBtn) {
            this.restartBtn.addEventListener('click', () => {
                this.initGame();
            });
        }
        
        // 悔棋按钮
        if (this.undoBtn) {
            this.undoBtn.addEventListener('click', () => {
                this.undoMove();
            });
        }
        
        // 新游戏按钮（弹窗中）
        if (this.newGameBtn) {
            this.newGameBtn.addEventListener('click', () => {
                this.initGame();
            });
        }
    }
    
    // 处理棋盘点击事件
    handleBoardClick(x, y) {
        // 使用Math.floor而不Math.round来计算坐标，防止越界
        const col = Math.floor((x + this.cellSize / 2) / this.cellSize);
        const row = Math.floor((y + this.cellSize / 2) / this.cellSize);
        
        // 加强边界检查
        if (!this.isValidPosition(row, col)) {
            return;
        }
        
        // 检查该位置是否已有棋子
        if (this.board[row][col] !== GAME_CONFIG.EMPTY_CELL) {
            return;
        }
        
        // 落子
        this.makeMove(row, col);
    }
    
    // 检查位置是否有效
    isValidPosition(row, col) {
        return row >= 0 && row < this.boardSize && 
               col >= 0 && col < this.boardSize;
    }
    
    // 执行落子操作
    makeMove(row, col) {
        // 记录落子历史
        this.moveHistory.push({
            row,
            col,
            player: this.currentPlayer
        });
        
        // 在棋盘上放置棋子
        this.board[row][col] = this.currentPlayer;
        
        // 重新绘制棋盘
        this.drawBoard();
        
        // 检查是否获胜
        if (this.checkWin(row, col)) {
            this.endGame(this.currentPlayer);
            return;
        }
        
        // 检查是否平局（棋盘已满）
        if (this.isBoardFull()) {
            this.endGame(0); // 0表示平局
            return;
        }
        
        // 切换玩家
        this.currentPlayer = this.currentPlayer === GAME_CONFIG.PLAYER_BLACK ? 
                            GAME_CONFIG.PLAYER_WHITE : GAME_CONFIG.PLAYER_BLACK;
        this.updatePlayerIndicator();
    }
    
    // 检查是否获胜
    checkWin(row, col) {
        const player = this.board[row][col];
        const directions = [
            [0, 1],   // 水平
            [1, 0],   // 垂直
            [1, 1],   // 主对角线
            [1, -1]   // 副对角线
        ];
        
        // 检查四个方向
        for (const [dx, dy] of directions) {
            let count = 1; // 包含当前棋子
            
            // 向正方向计算连子数
            count += this.countConsecutive(row, col, dx, dy, player);
            
            // 向反方向计算连子数
            count += this.countConsecutive(row, col, -dx, -dy, player);
            
            // 如果连续数达到获胜条件，获胜
            if (count >= GAME_CONFIG.WIN_COUNT) {
                return true;
            }
        }
        
        return false;
    }
    
    // 计算指定方向的连续棋子数量
    countConsecutive(row, col, dx, dy, player) {
        let count = 0;
        let newRow = row + dx;
        let newCol = col + dy;
        
        // 沿着指定方向计算连续的同色棋子
        while (this.isValidPosition(newRow, newCol) && 
               this.board[newRow][newCol] === player) {
            count++;
            newRow += dx;
            newCol += dy;
        }
        
        return count;
    }
    
    // 检查棋盘是否已满
    isBoardFull() {
        return this.board.every(row => row.every(cell => cell !== GAME_CONFIG.EMPTY_CELL));
    }
    
    // 悔棋功能
    undoMove() {
        if (this.moveHistory.length === 0 || this.gameOver) return;
        
        // 取出最后一步棋
        const lastMove = this.moveHistory.pop();
        
        // 清除棋盘上的棋子
        this.board[lastMove.row][lastMove.col] = GAME_CONFIG.EMPTY_CELL;
        
        // 切换回上一个玩家
        this.currentPlayer = lastMove.player;
        
        // 重新绘制棋盘和更新界面
        this.drawBoard();
        this.updatePlayerIndicator();
    }
    
    // 结束游戏
    endGame(winner) {
        this.gameOver = true;
        
        let message;
        if (winner === 0) {
            message = '平局！';
        } else {
            const playerName = winner === GAME_CONFIG.PLAYER_BLACK ? '黑子' : '白子';
            message = `${playerName}获胜！`;
        }
        
        this.winnerText.textContent = message;
        this.showGameResult();
    }
    
    // 显示游戏结果弹窗
    showGameResult() {
        this.gameResult.classList.remove('hidden');
    }
    
    // 隐藏游戏结果弹窗
    hideGameResult() {
        this.gameResult.classList.add('hidden');
    }
    
    // 更新当前玩家指示器
    updatePlayerIndicator() {
        const playerName = this.currentPlayer === GAME_CONFIG.PLAYER_BLACK ? '黑子' : '白子';
        const playerColor = this.currentPlayer === GAME_CONFIG.PLAYER_BLACK ? '#333' : '#fff';
        
        this.playerIndicator.textContent = playerName;
        this.playerIndicator.style.color = playerColor;
        this.playerIndicator.style.textShadow = playerColor === '#fff' ? 
            '1px 1px 2px rgba(0,0,0,0.8)' : 'none';
    }
    
    // 绘制棋盘
    drawBoard() {
        const ctx = this.ctx;
        const size = this.cellSize;
        
        // 清空画布
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 设置线条样式
        ctx.strokeStyle = '#8b4513';
        ctx.lineWidth = 2;
        
        // 绘制网格线
        for (let i = 0; i < this.boardSize; i++) {
            // 垂直线
            ctx.beginPath();
            ctx.moveTo(i * size, 0);
            ctx.lineTo(i * size, (this.boardSize - 1) * size);
            ctx.stroke();
            
            // 水平线
            ctx.beginPath();
            ctx.moveTo(0, i * size);
            ctx.lineTo((this.boardSize - 1) * size, i * size);
            ctx.stroke();
        }
        
        // 绘制星位点（天元和四个角的中点）
        ctx.fillStyle = '#8b4513';
        const starPoints = [
            [3, 3], [3, 11], [7, 7], [11, 3], [11, 11]
        ];
        
        starPoints.forEach(([x, y]) => {
            ctx.beginPath();
            ctx.arc(x * size, y * size, 4, 0, Math.PI * 2);
            ctx.fill();
        });
        
        // 绘制棋子
        for (let row = 0; row < this.boardSize; row++) {
            for (let col = 0; col < this.boardSize; col++) {
                if (this.board[row][col] !== GAME_CONFIG.EMPTY_CELL) {
                    this.drawStone(row, col, this.board[row][col]);
                }
            }
        }
    }
    
    // 绘制单个棋子
    drawStone(row, col, player) {
        const ctx = this.ctx;
        const x = col * this.cellSize;
        const y = row * this.cellSize;
        const radius = this.cellSize * 0.4;
        
        // 绘制棋子阴影
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.beginPath();
        ctx.arc(x + 2, y + 2, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        
        // 绘制棋子主体
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        
        if (player === GAME_CONFIG.PLAYER_BLACK) {
            // 黑子：渐变填充
            const gradient = ctx.createRadialGradient(x - 5, y - 5, 0, x, y, radius);
            gradient.addColorStop(0, '#666');
            gradient.addColorStop(1, '#000');
            ctx.fillStyle = gradient;
        } else {
            // 白子：渐变填充
            const gradient = ctx.createRadialGradient(x - 5, y - 5, 0, x, y, radius);
            gradient.addColorStop(0, '#fff');
            gradient.addColorStop(1, '#ddd');
            ctx.fillStyle = gradient;
        }
        
        ctx.fill();
        
        // 绘制棋子边框
        ctx.strokeStyle = player === GAME_CONFIG.PLAYER_BLACK ? '#333' : '#999';
        ctx.lineWidth = 1;
        ctx.stroke();
    }
}

// 页面加载完成后初始化游戏
document.addEventListener('DOMContentLoaded', () => {
    // 创建游戏实例
    const game = new GomokuGame();
});