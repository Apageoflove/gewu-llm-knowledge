# 五子棋游戏 (Gomoku Game)

一个基于HTML5 Canvas的五子棋游戏，支持双人本地对战模式。

## 🎮 游戏特色

- **精美界面**：基于HTML5 Canvas绘制的棋盘和棋子
- **双人对战**：支持两位玩家轮流下棋
- **游戏规则**：标准五子棋规则，先连成五子者获胜
- **悔棋功能**：支持撤销上一步操作
- **响应式设计**：适配不同屏幕尺寸

## 🚀 快速开始

### 在线体验

直接打开 `index.html` 文件即可在浏览器中游戏。

### 本地开发

1. 克隆项目
```bash
git clone https://github.com/lifejolly/gomoku-game.git
cd gomoku-game
```

2. 安装依赖
```bash
npm install
```

3. 启动开发服务器
```bash
npm run dev
```

4. 打开浏览器访问 `http://localhost:3000`

## 🎯 游戏规则

1. 棋盘为15x15格
2. 黑棋先行，白棋后手
3. 在棋盘交叉点放置棋子
4. 先在横、竖、斜任意方向连成5子者获胜
5. 支持悔棋和重新开始功能

## 🛠 技术栈

- **前端**：HTML5, CSS3, JavaScript (ES6+)
- **图形**：Canvas API
- **开发工具**：Live Server, HTTP Server
- **包管理**：npm

## 📁 项目结构

```
gomoku-game/
├── index.html          # 主页面
├── styles.css          # 样式文件
├── game.js            # 游戏逻辑
├── package.json       # 项目配置
├── .gitignore        # Git忽略文件
└── README.md         # 项目说明
```

## 🎮 游戏操作

- **下棋**：点击棋盘交叉点放置棋子
- **重新开始**：点击"重新开始"按钮
- **悔棋**：点击"悔棋"按钮撤销上一步

## 🎯 游戏特点

- **简单易用**：直观的点击操作，易于上手
- **视觉美观**：精心设计的棋盘和棋子样式
- **功能完整**：支持重新开始、悔棋等基础功能

## 🚧 开发计划

- [ ] 实现基础AI算法，支持人机对战
- [ ] 添加游戏统计功能
- [ ] 实现在线对战功能
- [ ] 添加游戏历史记录
- [ ] 添加音效和动画
- [ ] 优化用户交互体验

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🤝 贡献

欢迎提交问题和改进建议！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 👨‍💻 作者

- **Claude Code** - *初始开发* - [Claude](https://claude.ai)

---

⭐ 如果这个项目对你有帮助，请给它一个星标！