package com.example.io.selector;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

/**
 * 多路复用socket
 */
public class MultiplexingSocket {
    static ByteBuffer buffer = ByteBuffer.allocateDirect(4096);

    public static void main(String[] args) throws Exception {
        LinkedList<SocketChannel> clients = new LinkedList<>();
        //1.启动server
        //new socket,开启监听
        ServerSocketChannel socketChannel = ServerSocketChannel.open();
        socketChannel.bind(new InetSocketAddress(9090));
        //设置非阻塞，接受客户端
        socketChannel.configureBlocking(false);
        //多路复用器（JDK包装的代理，select /poll/epoll/kqueue）
        Selector selector = Selector.open(); //java自动代理，默认为epoll
        //Selector selector = PollSelectorProvider.provider().openSelector();//指定为poll
        //将服务端socket 注册到 多路复用器
        socketChannel.register(selector, SelectionKey.OP_ACCEPT);
        //2. 轮训多路复用器
        // 先询问有没有连接,如果有则返回数量以及对应的对象(fd)
        while (selector.select() > 0) {
            System.out.println();
            Set<SelectionKey> selectionKeys = selector.selectedKeys();
            Iterator<SelectionKey> iter = selectionKeys.iterator();
            while (iter.hasNext()) {
                SelectionKey key = iter.next();
                iter.remove();
                //2.1 处理新的连接
                if (key.isAcceptable()) {
                    //接受客户端连接; 非阻塞，无客户端返回null(操作系统返回-1)
                    SocketChannel client = socketChannel.accept();
                    //设置读非阻塞
                    client.configureBlocking(false);
                    //同样，把client也注册到selector
                    client.register(selector, SelectionKey.OP_READ);
                    System.out.println("new client : " + client.getRemoteAddress());
                }
                //2.2 处理读取数据
                else if (key.isReadable()) {
                    readDataFromSocket(key);
                }
            }
        }
    }

    protected static void readDataFromSocket(SelectionKey key) throws Exception {
        SocketChannel socketChannel = (SocketChannel) key.channel();
        // 非阻塞, >0 表示读取到的字节数量, 0或-1表示未读取到或读取异常
        // 请注意：这个例子降低复杂度，不考虑报文大于buffer size的情况
        int num = socketChannel.read(buffer);
        if (num > 0) {
            buffer.flip();
            byte[] clientBytes = new byte[buffer.limit()];
            //从缓冲区 读取到内存中
            buffer.get(clientBytes);
            System.out.println(socketChannel.socket().getPort() + ":" + new String(clientBytes));
            //清空缓冲区
            buffer.clear();
        }
    }
}
