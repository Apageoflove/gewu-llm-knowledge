# 快速开始 - 模型量化演示
# 导入safetensors中的torch模块，用于安全地加载和保存张量
import torch
# 导入AutoModelForCausalLM类，这是一个自动选择合适模型架构的类，用于因果语言建模
from transformers import AutoModelForCausalLM, AutoTokenizer
import os
import tempfile

# 设置模型ID，这里使用的是Meta AI的OPT-350M模型，一个有3.5亿参数的语言模型
# 类似于选择一个大小适中的预训练"大脑"作为我们的起点
model_id = "facebook/opt-350m"

# 首先加载原始模型，用于比较
original_model = AutoModelForCausalLM.from_pretrained(model_id)
# 计算原始模型参数数量
original_params = sum(p.numel() for p in original_model.parameters())
print(f"原始模型参数数量: {original_params}")
print(f"原始模型内存占用: {original_model.get_memory_footprint() / 1024 / 1024:.2f} MB")

#打印模型结构，查看量化后的层
print("\n原始模型结构:")
print(original_model)

# 保存原始模型并获取文件大小
original_save_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "original_model")
os.makedirs(original_save_path, exist_ok=True)
original_model.save_pretrained(original_save_path)
original_size = sum(os.path.getsize(os.path.join(original_save_path, f)) for f in os.listdir(original_save_path) if os.path.isfile(os.path.join(original_save_path, f)))
print(f"原始模型文件大小: {original_size / 1024 / 1024:.2f} MB")


# 加载模型并启用4比特量化，大大减少内存占用（约减少75%）
# 就像把一个大文件压缩成小文件，但保留大部分功能
# device_map="auto"让模型自动选择合适的设备（CPU/GPU）加载
model = AutoModelForCausalLM.from_pretrained(model_id, load_in_4bit=True, device_map="auto")
# 计算量化后模型参数数量
quantized_params = sum(p.numel() for p in model.parameters())
print(f"4比特量化模型参数数量: {quantized_params}")
print(f"4比特量化模型内存占用: {model.get_memory_footprint() / 1024 / 1024:.2f} MB")
print(f"内存减少比例: {(1 - model.get_memory_footprint() / original_model.get_memory_footprint()) * 100:.2f}%")

# 保存量化模型并获取文件大小
quantized_save_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quantized_model")
os.makedirs(quantized_save_path, exist_ok=True)
model.save_pretrained(quantized_save_path)
quantized_size = sum(os.path.getsize(os.path.join(quantized_save_path, f)) for f in os.listdir(quantized_save_path) if os.path.isfile(os.path.join(quantized_save_path, f)))
print(f"4比特量化模型文件大小: {quantized_size / 1024 / 1024:.2f} MB")
print(f"文件大小减少比例: {(1 - quantized_size / original_size) * 100:.2f}%")

#打印模型结构，查看量化后的层
print("\n量化后的模型结构:")
print(model)

# 高级用法 - 使用更复杂的量化配置
# 导入BitsAndBytesConfig类，用于详细配置量化参数
from transformers import BitsAndBytesConfig

# 创建一个综合的4比特量化配置
# 这就像是为模型压缩设置更精细的参数，类似于设置ZIP压缩的高级选项
nf4_config = BitsAndBytesConfig(
    load_in_4bit=True,                         # 启用4比特量化
    bnb_4bit_quant_type="nf4",                 # 使用NF4（Normal Float 4）量化类型，对语言模型更友好
    #bnb_4bit_use_double_quant=True,            # 启用嵌套量化，进一步节省内存（量化两次）
    bnb_4bit_compute_dtype=torch.bfloat16      # 使用bfloat16作为计算数据类型，平衡精度和速度
)

# 使用上面定义的高级配置加载模型
# 这样加载的模型在保持性能的同时，能够更有效地利用内存
model_nf4 = AutoModelForCausalLM.from_pretrained(model_id, quantization_config=nf4_config)
print(f"NF4量化模型内存占用: {model_nf4.get_memory_footprint() / 1024 / 1024:.2f} MB")

# 保存NF4量化模型并获取文件大小
nf4_save_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nf4_model")
os.makedirs(nf4_save_path, exist_ok=True)
model_nf4.save_pretrained(nf4_save_path)
nf4_size = sum(os.path.getsize(os.path.join(nf4_save_path, f)) for f in os.listdir(nf4_save_path) if os.path.isfile(os.path.join(nf4_save_path, f)))
print(f"NF4量化模型文件大小: {nf4_size / 1024 / 1024:.2f} MB")
print(f"文件大小减少比例: {(1 - nf4_size / original_size) * 100:.2f}%")

# 更改计算数据类型 - 专注于调整计算精度
# 重新导入torch和BitsAndBytesConfig，确保可用性
import torch
from transformers import BitsAndBytesConfig

# 创建一个专注于计算数据类型的配置
# 这就像告诉模型"思考"时使用什么精度，类似于选择计算器的精度
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,                         # 启用4比特量化
    bnb_4bit_compute_dtype=torch.bfloat16      # 使用bfloat16进行计算，这是一种介于float32和float16之间的格式
                                               # 比如，原本需要32位存储的3.14159265359，现在用16位近似表示
)

# 嵌套量化 - 专注于进一步压缩模型大小
# 再次导入BitsAndBytesConfig
from transformers import BitsAndBytesConfig

# 创建一个专注于嵌套量化的配置
# 嵌套量化就像是"压缩的压缩"，先把模型压缩为4比特，然后对这些4比特的权重再次压缩
double_quant_config = BitsAndBytesConfig(
    load_in_4bit=True,                         # 启用4比特量化
    bnb_4bit_use_double_quant=True,            # 启用嵌套量化，可以额外节省约25%的内存
)

# 使用嵌套量化配置加载模型
# 这种方法特别适合在内存受限的环境中运行大型模型
model_double_quant = AutoModelForCausalLM.from_pretrained(model_id, quantization_config=double_quant_config)
print(f"嵌套量化模型内存占用: {model_double_quant.get_memory_footprint() / 1024 / 1024:.2f} MB")

# 保存嵌套量化模型并获取文件大小
double_quant_save_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "double_quant_model")
os.makedirs(double_quant_save_path, exist_ok=True)
model_double_quant.save_pretrained(double_quant_save_path)
double_quant_size = sum(os.path.getsize(os.path.join(double_quant_save_path, f)) for f in os.listdir(double_quant_save_path) if os.path.isfile(os.path.join(double_quant_save_path, f)))
print(f"嵌套量化模型文件大小: {double_quant_size / 1024 / 1024:.2f} MB")
print(f"文件大小减少比例: {(1 - double_quant_size / original_size) * 100:.2f}%")

# 简单测试模型性能
tokenizer = AutoTokenizer.from_pretrained(model_id)
test_text = "Hello, my name is"
inputs = tokenizer(test_text, return_tensors="pt").to(model.device)

print("\n测试原始模型输出:")
with torch.no_grad():
    outputs = model.generate(**inputs, max_new_tokens=20)
    print(tokenizer.decode(outputs[0], skip_special_tokens=True))

print("\n测试NF4量化模型输出:")
with torch.no_grad():
    outputs = model_nf4.generate(**inputs, max_new_tokens=20)
    print(tokenizer.decode(outputs[0], skip_special_tokens=True))