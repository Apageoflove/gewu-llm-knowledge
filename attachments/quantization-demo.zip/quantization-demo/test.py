from transformers import BertModel
# 导入torch库，主要用于深度学习中的张量操作和神经网络构建
import torch
# 设置设备为GPU（如果可用）或CPU，用于模型的计算
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(DEVICE)