# 从datasets库中导入load_dataset函数，用于加载数据集
from datasets import load_dataset

# 加载food101数据集，这是一个包含101种食物图片的数据集
# 例如：披萨、汉堡、寿司等常见食物
ds = load_dataset("food101")

# 获取训练集中的所有标签名称
# 例如：labels可能包含["apple_pie", "baklava", "pizza"...]等101种食物名称
labels = ds["train"].features["label"].names
# 创建两个字典用于标签和ID之间的相互转换
# label2id: 将食物名称映射到数字ID，如{"apple_pie": 0, "baklava": 1, ...}
# id2label: 将数字ID映射到食物名称，如{0: "apple_pie", 1: "baklava", ...}
label2id, id2label = dict(), dict()
for i, label in enumerate(labels):
    label2id[label] = i
    id2label[i] = label

# 测试id2label字典，获取ID为2的食物名称
id2label[2]
# 输出结果是"baklava"（一种中东甜点）

# 从transformers库导入AutoImageProcessor，用于图像预处理
from transformers import AutoImageProcessor

# 加载预训练的图像处理器，用于处理输入图像以适应ViT模型
# ViT是Vision Transformer的缩写，是一种用于图像分类的Transformer模型
image_processor = AutoImageProcessor.from_pretrained("google/vit-base-patch16-224-in21k")

# 从torchvision.transforms导入各种图像变换函数
# 这些函数用于数据增强和图像预处理
from torchvision.transforms import (
    CenterCrop,  # 中心裁剪
    Compose,     # 组合多个变换
    Normalize,   # 标准化图像
    RandomHorizontalFlip,  # 随机水平翻转
    RandomResizedCrop,     # 随机裁剪并调整大小
    Resize,      # 调整图像大小
    ToTensor,    # 将PIL图像转换为张量
)

# 创建标准化变换，使用图像处理器提供的均值和标准差
# 标准化可以使模型训练更稳定，例如将像素值从[0,255]转换到均值为0、标准差为1的分布
normalize = Normalize(mean=image_processor.image_mean, std=image_processor.image_std)

# 创建训练数据的变换管道
# 包括：随机裁剪和调整大小、随机水平翻转（数据增强）、转换为张量、标准化
train_transforms = Compose(
    [
        RandomResizedCrop(image_processor.size["height"]),
        RandomHorizontalFlip(),
        ToTensor(),
        normalize,
    ]
)

# 创建验证数据的变换管道
# 验证集不需要数据增强，只需调整大小、中心裁剪、转换为张量和标准化
val_transforms = Compose(
    [
        Resize(image_processor.size["height"]),
        CenterCrop(image_processor.size["height"]),
        ToTensor(),
        normalize,
    ]
)


# 定义训练数据预处理函数
# 将每个样本中的图像转换为RGB格式并应用训练变换
def preprocess_train(example_batch):
    example_batch["pixel_values"] = [train_transforms(image.convert("RGB")) for image in example_batch["image"]]
    return example_batch


# 定义验证数据预处理函数
# 将每个样本中的图像转换为RGB格式并应用验证变换
def preprocess_val(example_batch):
    example_batch["pixel_values"] = [val_transforms(image.convert("RGB")) for image in example_batch["image"]]
    return example_batch


# 为了快速测试，只选择训练集和验证集的前10个样本
# 实际训练时应使用完整数据集
train_ds = ds["train"].select(range(10))
val_ds = ds["validation"].select(range(10))

# 设置数据集的转换函数，使数据在加载时自动应用预处理
train_ds.set_transform(preprocess_train)
val_ds.set_transform(preprocess_val)

# 导入PyTorch库
import torch


# 定义数据整理函数，用于将一批样本组合成一个批次
# 例如：将多张图片和它们的标签组合成一个批次，以便模型训练
def collate_fn(examples):
    # 将所有样本的像素值堆叠成一个批次张量
    pixel_values = torch.stack([example["pixel_values"] for example in examples])
    # 将所有样本的标签组合成一个张量
    labels = torch.tensor([example["label"] for example in examples])
    # 返回包含像素值和标签的字典
    return {"pixel_values": pixel_values, "labels": labels}


# 导入用于图像分类的模型和训练工具
from transformers import AutoModelForImageClassification, TrainingArguments, Trainer

# 加载预训练的ViT模型并配置为我们的分类任务
# ignore_mismatched_sizes=True允许模型适应不同大小的输入
model = AutoModelForImageClassification.from_pretrained(
    "google/vit-base-patch16-224-in21k",
    label2id=label2id,
    id2label=id2label,
    ignore_mismatched_sizes=True,
)

# 导入PEFT（Parameter-Efficient Fine-Tuning）相关工具
# PEFT允许我们只微调模型的一小部分参数，节省计算资源
from peft import LoraConfig, get_peft_model

# 配置LoRA（Low-Rank Adaptation）参数
# LoRA是一种参数高效的微调方法，只更新少量参数
config = LoraConfig(
    r=16,  # LoRA的秩，较高的值提供更多的模型容量但需要更多参数
    lora_alpha=16,  # LoRA的缩放因子
    target_modules=["query", "value"],  # 要应用LoRA的模块，这里是Transformer的query和value矩阵
    lora_dropout=0.1,  # LoRA的dropout率，用于防止过拟合
    bias="none",  # 不更新偏置参数
    modules_to_save=["classifier"],  # 完全微调的模块，这里是分类器头部
)
# 将模型转换为PEFT模型
model = get_peft_model(model, config)
# 打印可训练参数的信息
model.print_trainable_parameters()
# 输出显示：可训练参数占总参数的0.77%，大大减少了计算需求
"trainable params: 667,493 || all params: 86,543,818 || trainable%: 0.7712775047664294"

# 设置Hugging Face账户名
account = "VergilDante"
# 构建模型ID
peft_model_id = f"{account}/vit-base-patch16-224-in21k"

# 设置批量大小
batch_size = 128

# 配置训练参数
args = TrainingArguments(
    peft_model_id,  # 输出目录
    remove_unused_columns=False,  # 保留所有列，因为我们的collate_fn需要它们
    eval_strategy="epoch",  # 每个epoch评估一次
    save_strategy="epoch",  # 每个epoch保存一次
    learning_rate=5e-3,  # 学习率
    per_device_train_batch_size=batch_size,  # 每个设备的训练批量大小
    gradient_accumulation_steps=4,  # 梯度累积步数，用于模拟更大的批量
    per_device_eval_batch_size=batch_size,  # 每个设备的评估批量大小
    fp16=True,  # 使用混合精度训练，加速训练过程
    num_train_epochs=5,  # 训练5个epoch
    logging_steps=10,  # 每10步记录一次日志
    load_best_model_at_end=True,  # 训练结束时加载最佳模型
    label_names=["labels"],  # 标签的名称
)

# 创建Trainer实例
trainer = Trainer(
    model,  # 模型
    args,  # 训练参数
    train_dataset=train_ds,  # 训练数据集
    eval_dataset=val_ds,  # 评估数据集
    tokenizer=image_processor,  # 图像处理器
    data_collator=collate_fn,  # 数据整理函数
)
# 开始训练
trainer.train()

# 将微调后的模型上传到Hugging Face模型中心
model.push_to_hub(peft_model_id)

# 导入用于加载PEFT模型的工具和其他必要库
from peft import PeftConfig, PeftModel
from transformers import AutoModelForImageClassification
from PIL import Image
import requests

# 加载PEFT配置
config = PeftConfig.from_pretrained("stevhliu/vit-base-patch16-224-in21k-lora")
# 加载基础模型
model = AutoModelForImageClassification.from_pretrained(
    config.base_model_name_or_path,
    label2id=label2id,
    id2label=id2label,
    ignore_mismatched_sizes=True,
)
# 加载PEFT权重，将它们应用到基础模型上
model = PeftModel.from_pretrained(model, "stevhliu/vit-base-patch16-224-in21k-lora")

# 从网络加载一张测试图片（这里是beignets，一种法国甜点）
url = "https://hugging-face.cn/datasets/sayakpaul/sample-datasets/resolve/main/beignets.jpeg"
image = Image.open(requests.get(url, stream=True).raw)
# 使用图像处理器处理图像
encoding = image_processor(image.convert("RGB"), return_tensors="pt")
# 使用模型进行推理
with torch.no_grad():
    outputs = model(**encoding)
    logits = outputs.logits

# 获取预测的类别索引（概率最高的类别）
predicted_class_idx = logits.argmax(-1).item()
# 打印预测结果
print("Predicted class:", model.config.id2label[predicted_class_idx])
# 输出结果是"beignets"，说明模型正确识别了图片中的食物
"Predicted class: beignets"
