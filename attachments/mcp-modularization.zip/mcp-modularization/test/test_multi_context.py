import pytest
import asyncio
from src.multi_context_server import MultiContextServer
from src.multi_context_client import MultiContextClient

@pytest.fixture
async def server():
    server = MultiContextServer(host="localhost", port=8888)
    await server.start()
    yield server
    await server.stop()

@pytest.fixture
async def client():
    client = MultiContextClient(host="localhost", port=8888)
    await client.connect()
    yield client
    await client.disconnect()

@pytest.mark.asyncio
async def test_create_context(client):
    # 测试创建上下文
    response = await client.create_context("test_context")
    assert response["success"] is True
    assert "test_context created successfully" in response["message"]

@pytest.mark.asyncio
async def test_duplicate_context(client):
    # 测试创建重复的上下文
    await client.create_context("test_context")
    response = await client.create_context("test_context")
    assert response["success"] is False
    assert "already exists" in response["message"]

@pytest.mark.asyncio
async def test_set_and_get_data(client):
    # 测试设置和获取数据
    await client.create_context("test_context")
    
    # 设置数据
    set_response = await client.set_data("test_context", "test_key", "test_value")
    assert set_response["success"] is True
    
    # 获取数据
    get_response = await client.get_data("test_context", "test_key")
    assert get_response["success"] is True
    assert get_response["data"]["value"] == "test_value"

@pytest.mark.asyncio
async def test_list_contexts(client):
    # 测试列出所有上下文
    await client.create_context("context1")
    await client.create_context("context2")
    
    response = await client.list_contexts()
    assert response["success"] is True
    assert "context1" in response["data"]["contexts"]
    assert "context2" in response["data"]["contexts"]

@pytest.mark.asyncio
async def test_get_data_from_nonexistent_context(client):
    # 测试从不存在的上下文获取数据
    response = await client.get_data("nonexistent_context", "test_key")
    assert response["success"] is False
    assert "not found" in response["message"]

@pytest.mark.asyncio
async def test_multiple_contexts_isolation(client):
    # 测试多个上下文之间的数据隔离
    await client.create_context("context1")
    await client.create_context("context2")
    
    # 在context1中设置数据
    await client.set_data("context1", "name", "Alice")
    # 在context2中设置数据
    await client.set_data("context2", "name", "Bob")
    
    # 验证数据隔离
    response1 = await client.get_data("context1", "name")
    response2 = await client.get_data("context2", "name")
    
    assert response1["data"]["value"] == "Alice"
    assert response2["data"]["value"] == "Bob"
