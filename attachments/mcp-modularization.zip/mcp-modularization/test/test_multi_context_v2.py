import pytest
import asyncio
from fastmcp import Client
from fastmcp.client.transports import FastMCPTransport
from src.multi_context_server_v2 import mcp

@pytest.fixture
async def client():
    """创建测试客户端"""
    transport = FastMCPTransport(mcp=mcp)
    async with Client(transport=transport) as client:
        yield client

@pytest.mark.asyncio
async def test_create_context(client):
    """测试创建上下文功能"""
    response = await client.tools.call("create_context", context_id="test_context")
    assert "created successfully" in response

@pytest.mark.asyncio
async def test_duplicate_context(client):
    """测试创建重复上下文的处理"""
    await client.tools.call("create_context", context_id="test_context")
    response = await client.tools.call("create_context", context_id="test_context")
    assert "already exists" in response

@pytest.mark.asyncio
async def test_set_and_get_data(client):
    """测试数据的设置和获取"""
    # 创建上下文
    await client.tools.call("create_context", context_id="test_context")
    
    # 设置数据
    set_response = await client.tools.call("set_data", 
        context_id="test_context",
        key="test_key",
        value="test_value"
    )
    assert "successfully" in set_response
    
    # 获取数据
    get_response = await client.tools.call("get_data",
        context_id="test_context",
        key="test_key"
    )
    assert "test_value" in get_response

@pytest.mark.asyncio
async def test_list_contexts(client):
    """测试列出所有上下文功能"""
    # 创建多个上下文
    await client.tools.call("create_context", context_id="context1")
    await client.tools.call("create_context", context_id="context2")
    
    # 获取上下文列表
    response = await client.tools.call("list_contexts")
    assert "context1" in response
    assert "context2" in response

@pytest.mark.asyncio
async def test_get_data_from_nonexistent_context(client):
    """测试从不存在的上下文获取数据"""
    response = await client.tools.call("get_data",
        context_id="nonexistent_context",
        key="test_key"
    )
    assert "not found" in response

@pytest.mark.asyncio
async def test_multiple_contexts_isolation(client):
    """测试多个上下文之间的数据隔离"""
    # 创建两个上下文
    await client.tools.call("create_context", context_id="context1")
    await client.tools.call("create_context", context_id="context2")
    
    # 在不同上下文中设置数据
    await client.tools.call("set_data",
        context_id="context1",
        key="name",
        value="Alice"
    )
    await client.tools.call("set_data",
        context_id="context2",
        key="name",
        value="Bob"
    )
    
    # 验证数据隔离
    response1 = await client.tools.call("get_data",
        context_id="context1",
        key="name"
    )
    response2 = await client.tools.call("get_data",
        context_id="context2",
        key="name"
    )
    
    assert "Alice" in response1
    assert "Bob" in response2

@pytest.mark.asyncio
async def test_get_nonexistent_key(client):
    """测试获取不存在的键"""
    await client.tools.call("create_context", context_id="test_context")
    response = await client.tools.call("get_data",
        context_id="test_context",
        key="nonexistent_key"
    )
    assert "not found" in response