from mcp import ClientSession  # 从mcp模块导入ClientSession类
from mcp.client.stdio import StdioServerParameters, stdio_client  # 导入StdioServerParameters和stdio_client用于标准输入输出通信
import asyncio  # 导入asyncio用于异步编程
import logging  # 导入logging用于日志记录
import sys  # 导入sys模块用于获取Python解释器路径

# 配置日志
logging.basicConfig(level=logging.INFO)  # 设置日志级别为INFO
logger = logging.getLogger(__name__)  # 获取当前模块的日志记录器

class MultiContextClient:  # 定义多上下文客户端类
    def __init__(self, server_script_path: str):  # 初始化方法，接收服务器脚本路径
        """初始化MCP客户端
        
        Args:
            server_script_path: MCP服务器脚本路径
        """
        self.server_script_path = server_script_path  # 保存服务器脚本路径
        self.session = None  # 初始化会话为None
        
    async def connect(self):  # 异步方法，连接到MCP服务器
        """连接到MCP服务器"""
        logger.info("正在连接到MCP服务器...")  # 记录连接日志
        
        # 配置服务器参数
        server_params = StdioServerParameters(  # 创建StdioServerParameters对象
            command=sys.executable,  # Python解释器路径
            args=[self.server_script_path]  # 服务器脚本路径
        )
        
        try:
            # 建立连接
            async with stdio_client(server_params) as (read, write):  # 使用stdio_client建立与服务器的连接
                self.session = ClientSession(read, write)  # 创建客户端会话对象
                
                # 初始化会话
                await self.session.initialize()  # 初始化会话
                logger.info("成功连接到MCP服务器！")  # 记录成功日志
                
                # 运行测试
                await self.run_tests()  # 调用测试方法
                
        except Exception as e:  # 捕获异常
            logger.error(f"连接失败: {e}")  # 记录错误日志
            raise  # 抛出异常
        
    async def run_tests(self):  # 异步方法，运行测试
        """运行测试"""
        try:
            # 创建上下文
            result = await self.session.call_tool("create_context", {"context_id": "context1"})  # 创建context1
            logger.info(f"创建上下文1结果: {result}")  # 记录结果
            
            result = await self.session.call_tool("create_context", {"context_id": "context2"})  # 创建context2
            logger.info(f"创建上下文2结果: {result}")  # 记录结果
            
            # 在不同上下文中设置数据
            result = await self.session.call_tool("set_data", {  # 在context1中设置数据
                "context_id": "context1",
                "key": "name",
                "value": "Alice"
            })
            logger.info(f"设置上下文1数据结果: {result}")  # 记录结果
            
            result = await self.session.call_tool("set_data", {  # 在context2中设置数据
                "context_id": "context2",
                "key": "name",
                "value": "Bob"
            })
            logger.info(f"设置上下文2数据结果: {result}")  # 记录结果
            
            # 获取数据
            result = await self.session.call_tool("get_data", {  # 获取context1中的数据
                "context_id": "context1",
                "key": "name"
            })
            logger.info(f"获取上下文1数据结果: {result}")  # 记录结果
            
            result = await self.session.call_tool("get_data", {  # 获取context2中的数据
                "context_id": "context2",
                "key": "name"
            })
            logger.info(f"获取上下文2数据结果: {result}")  # 记录结果
            
            # 列出所有上下文
            result = await self.session.call_tool("list_contexts", {})  # 列出所有上下文
            logger.info(f"列出所有上下文结果: {result}")  # 记录结果
            
        except Exception as e:  # 捕获异常
            logger.error(f"测试过程中出现错误: {e}")  # 记录错误日志
            raise  # 抛出异常

async def main():  # 定义主异步函数
    """主函数"""
    logger.info("启动MCP客户端测试程序")  # 记录启动日志
    
    # 创建客户端并连接
    client = MultiContextClient("src/multi_context_server_v2.py")  # 创建MultiContextClient实例
    await client.connect()  # 连接到服务器

if __name__ == "__main__":  # 判断是否为主程序入口
    asyncio.run(main())  # 运行主异步函数