# 导入标准MCP库中的FastMCP类，用于创建MCP服务
from mcp.server.fastmcp import FastMCP

# 创建FastMCP服务器实例作为全局变量
mcp = FastMCP(
    name="SimpleMCPServer", 
    instructions="这是一个基于MCP实现的简单MCP服务，提供服务信息查询接口。"
)

# 使用装饰器定义服务信息工具
@mcp.tool()
def server_info() -> dict:
    """返回MCP服务的基本信息"""
    # 构造服务信息字典
    info = {
        "server_name": "SimpleMCPServer",
        "version": "1.0.0",
        "description": "这是一个基于fastmcp实现的简单MCP服务，提供服务信息查询接口。"
    }
    return info

# 主程序入口
if __name__ == "__main__":
    # 启动服务，监听0.0.0.0:8000
    mcp.run()