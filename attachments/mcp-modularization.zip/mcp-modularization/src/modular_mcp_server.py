"""
模块化MCP架构实现
"""
import asyncio
import json
import abc
from typing import Dict, Any, List, Optional, Callable, Type
from dataclasses import dataclass
import importlib
import logging
from pathlib import Path

# =================== 核心接口定义 ===================

class MCPModule(abc.ABC):
    """MCP模块基类"""
    
    @property
    @abc.abstractmethod
    def module_name(self) -> str:
        """模块名称"""
        pass
    
    @property
    @abc.abstractmethod
    def version(self) -> str:
        """模块版本"""
        pass
    
    @abc.abstractmethod
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """初始化模块"""
        pass
    
    @abc.abstractmethod
    async def cleanup(self):
        """清理模块资源"""
        pass
    
    @abc.abstractmethod
    async def health_check(self) -> bool:
        """健康检查"""
        pass

class TransportModule(MCPModule):
    """传输模块接口"""
    
    @abc.abstractmethod
    async def send_message(self, message: Dict[str, Any]) -> bool:
        """发送消息"""
        pass
    
    @abc.abstractmethod
    async def receive_message(self) -> Optional[Dict[str, Any]]:
        """接收消息"""
        pass
    
    @abc.abstractmethod
    async def connect(self) -> bool:
        """建立连接"""
        pass
    
    @abc.abstractmethod
    async def disconnect(self):
        """断开连接"""
        pass

class ProtocolModule(MCPModule):
    """协议模块接口"""
    
    @abc.abstractmethod
    async def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """处理请求"""
        pass
    
    @abc.abstractmethod
    async def validate_message(self, message: Dict[str, Any]) -> bool:
        """验证消息格式"""
        pass

class BusinessModule(MCPModule):
    """业务模块接口"""
    
    @abc.abstractmethod
    async def handle_resource_request(self, resource_uri: str) -> Any:
        """处理资源请求"""
        pass
    
    @abc.abstractmethod
    async def handle_tool_call(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """处理工具调用"""
        pass

# =================== 具体模块实现 ===================

class StdioTransportModule(TransportModule):
    """STDIO传输模块"""
    
    def __init__(self):
        self.connected = False
        self.process = None
        
    @property
    def module_name(self) -> str:
        return "stdio_transport"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """初始化STDIO传输"""
        self.command = config.get("command", [])
        logging.info(f"初始化STDIO传输: {self.command}")
        return True
    
    async def connect(self) -> bool:
        """建立STDIO连接"""
        try:
            # 这里应该启动子进程
            self.connected = True
            logging.info("STDIO连接已建立")
            return True
        except Exception as e:
            logging.error(f"STDIO连接失败: {e}")
            return False
    
    async def send_message(self, message: Dict[str, Any]) -> bool:
        """发送消息到STDIO"""
        if not self.connected:
            return False
        
        try:
            message_json = json.dumps(message)
            logging.debug(f"发送STDIO消息: {message_json}")
            return True
        except Exception as e:
            logging.error(f"发送STDIO消息失败: {e}")
            return False
    
    async def receive_message(self) -> Optional[Dict[str, Any]]:
        """从STDIO接收消息"""
        if not self.connected:
            return None
        
        # 模拟接收消息
        return {"jsonrpc": "2.0", "method": "ping", "id": 1}
    
    async def disconnect(self):
        """断开STDIO连接"""
        self.connected = False
        logging.info("STDIO连接已断开")
    
    async def cleanup(self):
        """清理资源"""
        await self.disconnect()
    
    async def health_check(self) -> bool:
        """健康检查"""
        return self.connected

class JsonRpcProtocolModule(ProtocolModule):
    """JSON-RPC协议模块"""
    
    def __init__(self):
        self.request_id = 0
        
    @property
    def module_name(self) -> str:
        return "jsonrpc_protocol"
    
    @property
    def version(self) -> str:
        return "2.0.0"
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """初始化协议模块"""
        self.timeout = config.get("timeout", 30)
        logging.info("JSON-RPC协议模块已初始化")
        return True
    
    async def validate_message(self, message: Dict[str, Any]) -> bool:
        """验证JSON-RPC消息格式"""
        required_fields = ["jsonrpc"]
        
        for field in required_fields:
            if field not in message:
                return False
        
        if message["jsonrpc"] != "2.0":
            return False
            
        # 检查是否是请求或响应
        is_request = "method" in message
        is_response = "result" in message or "error" in message
        
        return is_request or is_response
    
    async def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """处理JSON-RPC请求"""
        if not await self.validate_message(request):
            return self._create_error_response(
                request.get("id"), -32600, "Invalid Request"
            )
        
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")
        
        logging.info(f"处理JSON-RPC请求: {method}")
        
        # 这里应该路由到具体的处理器
        result = {"status": "success", "method": method}
        
        return {
            "jsonrpc": "2.0",
            "result": result,
            "id": request_id
        }
    
    def _create_error_response(self, request_id: Any, code: int, message: str) -> Dict[str, Any]:
        """创建错误响应"""
        return {
            "jsonrpc": "2.0",
            "error": {"code": code, "message": message},
            "id": request_id
        }
    
    async def cleanup(self):
        """清理资源"""
        pass
    
    async def health_check(self) -> bool:
        """健康检查"""
        return True

class FileSystemBusinessModule(BusinessModule):
    """文件系统业务模块"""
    
    def __init__(self):
        self.base_path = None
        
    @property
    def module_name(self) -> str:
        return "filesystem_business"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """初始化文件系统模块"""
        self.base_path = Path(config.get("base_path", "."))
        self.allowed_extensions = config.get("allowed_extensions", [".txt", ".json", ".py"])
        logging.info(f"文件系统模块初始化: {self.base_path}")
        return True
    
    async def handle_resource_request(self, resource_uri: str) -> Any:
        """处理文件资源请求"""
        try:
            if resource_uri.startswith("file://"):
                file_path = Path(resource_uri[7:])  # 移除 file:// 前缀
                
                # 安全检查
                if not self._is_safe_path(file_path):
                    raise ValueError("不安全的文件路径")
                
                full_path = self.base_path / file_path
                
                if full_path.exists() and full_path.is_file():
                    content = full_path.read_text(encoding="utf-8")
                    return {
                        "uri": resource_uri,
                        "content": content,
                        "mimeType": "text/plain"
                    }
                else:
                    raise FileNotFoundError(f"文件不存在: {full_path}")
                    
        except Exception as e:
            logging.error(f"处理资源请求失败: {e}")
            raise
    
    async def handle_tool_call(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """处理工具调用"""
        if tool_name == "list_files":
            return await self._list_files(arguments.get("directory", "."))
        elif tool_name == "read_file":
            return await self._read_file(arguments.get("path"))
        elif tool_name == "write_file":
            return await self._write_file(arguments.get("path"), arguments.get("content"))
        else:
            raise ValueError(f"未知工具: {tool_name}")
    
    async def _list_files(self, directory: str) -> List[Dict[str, Any]]:
        """列出文件"""
        dir_path = self.base_path / directory
        
        if not self._is_safe_path(Path(directory)):
            raise ValueError("不安全的目录路径")
        
        files = []
        for item in dir_path.iterdir():
            if item.is_file() and item.suffix in self.allowed_extensions:
                files.append({
                    "name": item.name,
                    "path": str(item.relative_to(self.base_path)),
                    "size": item.stat().st_size,
                    "type": "file"
                })
            elif item.is_dir():
                files.append({
                    "name": item.name,
                    "path": str(item.relative_to(self.base_path)),
                    "type": "directory"
                })
        
        return files
    
    async def _read_file(self, path: str) -> str:
        """读取文件"""
        file_path = Path(path)
        
        if not self._is_safe_path(file_path):
            raise ValueError("不安全的文件路径")
        
        full_path = self.base_path / file_path
        return full_path.read_text(encoding="utf-8")
    
    async def _write_file(self, path: str, content: str) -> bool:
        """写入文件"""
        file_path = Path(path)
        
        if not self._is_safe_path(file_path):
            raise ValueError("不安全的文件路径")
        
        full_path = self.base_path / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        return True
    
    def _is_safe_path(self, path: Path) -> bool:
        """检查路径安全性"""
        # 防止目录遍历攻击
        try:
            resolved_path = (self.base_path / path).resolve()
            return str(resolved_path).startswith(str(self.base_path.resolve()))
        except:
            return False
    
    async def cleanup(self):
        """清理资源"""
        pass
    
    async def health_check(self) -> bool:
        """健康检查"""
        return self.base_path.exists() if self.base_path else False

# =================== 模块管理器 ===================

@dataclass
class ModuleConfig:
    module_class: Type[MCPModule]
    config: Dict[str, Any]
    enabled: bool = True
    dependencies: List[str] = None

class ModularMCPServer:
    """模块化MCP服务器"""
    
    def __init__(self):
        self.modules: Dict[str, MCPModule] = {}
        self.module_configs: Dict[str, ModuleConfig] = {}
        self.initialized = False
        
    def register_module(self, name: str, module_config: ModuleConfig):
        """注册模块"""
        self.module_configs[name] = module_config
        logging.info(f"注册模块: {name}")
    
    async def initialize_all(self):
        """初始化所有模块"""
        # 按依赖顺序初始化
        initialized_modules = set()
        
        # 计算需要初始化的模块数量
        enabled_configs = {name: config for name, config in self.module_configs.items() if config.enabled}
        
        while len(initialized_modules) < len(enabled_configs):
            progress_made = False
            
            for name, config in enabled_configs.items():
                if name in initialized_modules:
                    continue
                
                # 检查依赖是否已初始化
                dependencies = config.dependencies or []
                if all(dep in initialized_modules for dep in dependencies):
                    # 初始化模块
                    module_instance = config.module_class()
                    success = await module_instance.initialize(config.config)
                    
                    if success:
                        self.modules[name] = module_instance
                        initialized_modules.add(name)
                        progress_made = True
                        logging.info(f"模块初始化成功: {name}")
                    else:
                        logging.error(f"模块初始化失败: {name}")
                        
            if not progress_made and len(enabled_configs) > 0:
                raise Exception("模块依赖循环或初始化失败")
        
        self.initialized = True
        logging.info("所有模块初始化完成")
    
    async def get_module(self, name: str, module_type: Type = None) -> Optional[MCPModule]:
        """获取模块实例"""
        module = self.modules.get(name)
        
        if module and module_type:
            if isinstance(module, module_type):
                return module
            else:
                return None
        
        return module
    
    async def health_check_all(self) -> Dict[str, bool]:
        """检查所有模块健康状态"""
        results = {}
        
        for name, module in self.modules.items():
            try:
                results[name] = await module.health_check()
            except Exception as e:
                logging.error(f"模块健康检查失败 {name}: {e}")
                results[name] = False
        
        return results
    
    async def cleanup_all(self):
        """清理所有模块"""
        for name, module in self.modules.items():
            try:
                await module.cleanup()
                logging.info(f"模块清理完成: {name}")
            except Exception as e:
                logging.error(f"模块清理失败 {name}: {e}")
        
        self.modules.clear()
        self.initialized = False

# =================== 配置和启动 ===================

async def setup_modular_mcp_server():
    """设置模块化MCP服务器"""
    server = ModularMCPServer()
    
    # 注册传输模块
    server.register_module("stdio_transport", ModuleConfig(
        module_class=StdioTransportModule,
        config={"command": ["python", "mcp_server.py"]},
        dependencies=[]
    ))
    
    # 注册协议模块
    server.register_module("jsonrpc_protocol", ModuleConfig(
        module_class=JsonRpcProtocolModule,
        config={"timeout": 30},
        dependencies=[]
    ))
    
    # 注册业务模块
    server.register_module("filesystem_business", ModuleConfig(
        module_class=FileSystemBusinessModule,
        config={
            "base_path": ".",
            "allowed_extensions": [".txt", ".json", ".py", ".md"]
        },
        dependencies=[]
    ))
    
    return server

async def demo_modular_mcp():
    """演示模块化MCP"""
    print("=== 模块化MCP服务器演示 ===\n")
    
    # 设置日志
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # 创建服务器
    server = await setup_modular_mcp_server()
    
    try:
        # 初始化所有模块
        print("初始化模块...")
        await server.initialize_all()
        
        # 健康检查
        print("\n健康检查结果:")
        health_status = await server.health_check_all()
        for module_name, status in health_status.items():
            print(f"  {module_name}: {'✓' if status else '✗'}")
        
        # 测试传输模块
        print("\n测试传输模块:")
        transport = await server.get_module("stdio_transport", StdioTransportModule)
        if transport:
            await transport.connect()
            await transport.send_message({"test": "message"})
        
        # 测试协议模块
        print("\n测试协议模块:")
        protocol = await server.get_module("jsonrpc_protocol", JsonRpcProtocolModule)
        if protocol:
            request = {"jsonrpc": "2.0", "method": "test", "id": 1}
            response = await protocol.process_request(request)
            print(f"协议响应: {response}")
        
        # 测试业务模块
        print("\n测试业务模块:")
        business = await server.get_module("filesystem_business", FileSystemBusinessModule)
        if business:
            files = await business.handle_tool_call("list_files", {"directory": "."})
            print(f"文件列表: {len(files)} 个文件")
        
    except Exception as e:
        print(f"演示过程中出现错误: {e}")
    finally:
        # 清理资源
        print("\n清理资源...")
        await server.cleanup_all()
        print("演示完成")

if __name__ == "__main__":
    asyncio.run(demo_modular_mcp())