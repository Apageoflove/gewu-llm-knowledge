#!/usr/bin/env python3
"""
简化的stdio MCP客户端测试版本
"""
import asyncio
import logging
import sys
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_client():
    """测试客户端"""
    logger.info("启动测试客户端...")
    
    # 服务器参数
    server_params = StdioServerParameters(
        command=sys.executable,
        args=["src/test_stdio_server.py"]
    )
    
    try:
        # 连接到服务器
        async with stdio_client(server_params) as (read, write):
            logger.info("连接到服务器成功")
            
            # 创建客户端会话
            session = ClientSession(read, write)
            
            # 初始化会话
            logger.info("初始化会话...")
            await session.initialize()
            logger.info("会话初始化成功")
            
            # 列出工具
            logger.info("列出可用工具...")
            tools = await session.list_tools()
            logger.info(f"可用工具: {tools}")
            
            # 调用工具
            logger.info("调用hello工具...")
            result = await session.call_tool("hello", {"name": "Alice"})
            logger.info(f"工具调用结果: {result}")
            
    except Exception as e:
        logger.error(f"测试失败: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(test_client())
