from fastmcp import MCPServer, Context, Request, Response
import asyncio
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CustomContext(Context):
    def __init__(self, context_id: str):
        super().__init__(context_id)
        self.data = {}  # 用于存储上下文相关的数据
        
    def set_data(self, key: str, value: any):
        self.data[key] = value
        
    def get_data(self, key: str) -> any:
        return self.data.get(key)

class MultiContextServer:
    def __init__(self, host: str = "localhost", port: int = 8080):
        self.server = MCPServer(host=host, port=port)
        self.contexts = {}  # 存储多个上下文
        
        # 注册处理函数
        self.server.register_handler("create_context", self.handle_create_context)
        self.server.register_handler("set_data", self.handle_set_data)
        self.server.register_handler("get_data", self.handle_get_data)
        self.server.register_handler("list_contexts", self.handle_list_contexts)
        
    async def handle_create_context(self, request: Request) -> Response:
        context_id = request.data.get("context_id")
        if not context_id:
            return Response(success=False, message="Context ID is required")
            
        if context_id in self.contexts:
            return Response(success=False, message=f"Context {context_id} already exists")
            
        self.contexts[context_id] = CustomContext(context_id)
        logger.info(f"Created new context: {context_id}")
        return Response(success=True, message=f"Context {context_id} created successfully")
        
    async def handle_set_data(self, request: Request) -> Response:
        context_id = request.data.get("context_id")
        key = request.data.get("key")
        value = request.data.get("value")
        
        if not all([context_id, key, value]):
            return Response(success=False, message="Missing required parameters")
            
        if context_id not in self.contexts:
            return Response(success=False, message=f"Context {context_id} not found")
            
        context = self.contexts[context_id]
        context.set_data(key, value)
        logger.info(f"Set data in context {context_id}: {key}={value}")
        return Response(success=True, message=f"Data set successfully in context {context_id}")
        
    async def handle_get_data(self, request: Request) -> Response:
        context_id = request.data.get("context_id")
        key = request.data.get("key")
        
        if not all([context_id, key]):
            return Response(success=False, message="Missing required parameters")
            
        if context_id not in self.contexts:
            return Response(success=False, message=f"Context {context_id} not found")
            
        context = self.contexts[context_id]
        value = context.get_data(key)
        return Response(success=True, data={"value": value})
        
    async def handle_list_contexts(self, request: Request) -> Response:
        context_list = list(self.contexts.keys())
        return Response(success=True, data={"contexts": context_list})
        
    async def start(self):
        await self.server.start()
        logger.info(f"Server started on {self.server.host}:{self.server.port}")
        
    async def stop(self):
        await self.server.stop()
        logger.info("Server stopped")

async def main():
    server = MultiContextServer()
    try:
        await server.start()
        # 保持服务器运行
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        await server.stop()

if __name__ == "__main__":
    asyncio.run(main())
