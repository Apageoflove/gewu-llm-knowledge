#!/usr/bin/env python3
"""
简化的stdio MCP服务器测试版本
"""
import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
)

# 配置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# 创建服务器
server = Server("TestServer")

@server.list_tools()
async def list_tools() -> list[Tool]:
    """列出工具"""
    logger.info("列出工具被调用")
    return [
        Tool(
            name="hello",
            description="打招呼",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "名字"
                    }
                },
                "required": ["name"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """处理工具调用"""
    logger.info(f"工具调用: {name} with {arguments}")
    
    if name == "hello":
        name_arg = arguments.get("name", "World")
        return [TextContent(type="text", text=f"Hello, {name_arg}!")]
    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]

async def main():
    logger.info("启动测试服务器...")
    async with stdio_server() as (read_stream, write_stream):
        logger.info("Stdio streams created, running server...")
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())
