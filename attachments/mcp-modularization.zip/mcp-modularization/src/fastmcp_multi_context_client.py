from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from typing import Dict, Any, Optional
import asyncio
import logging
import sys

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FastMCPMultiContextClient:
    """FastMCP多上下文客户端"""
    
    def __init__(self, server_script_path: str = "src/stdio_multi_context_server.py"):
        """初始化FastMCP客户端
        
        Args:
            server_script_path: 服务器脚本路径
        """
        self.server_script_path = server_script_path
        self.session = None
        
    async def connect(self):
        """连接到MCP服务器"""
        logger.info("正在连接到MCP服务器...")
        
        # 配置服务器参数
        server_params = StdioServerParameters(
            command=sys.executable,  # Python解释器路径
            args=[self.server_script_path]  # 服务器脚本路径
        )
        
        try:
            # 建立连接
            async with stdio_client(server_params) as (read, write):
                self.session = ClientSession(read, write)
                
                # 初始化会话
                await self.session.initialize()
                logger.info("成功连接到MCP服务器！")
                
                # 运行测试
                await self.run_tests()
                
        except Exception as e:
            logger.error(f"连接失败: {e}")
            raise
            
    async def initialize(self):
        """初始化客户端"""
        logger.info("初始化FastMCP多上下文客户端...")
        # 这里可以添加客户端初始化逻辑
        logger.info("FastMCP多上下文客户端初始化完成")
        
    async def create_context(self, context_id: str) -> str:
        """创建新的上下文
        
        Args:
            context_id: 上下文ID
            
        Returns:
            创建结果信息
        """
        if not self.session:
            return "客户端未连接到服务器"
            
        logger.info(f"创建上下文: {context_id}")
        try:
            result = await self.session.call_tool("create_context", {"context_id": context_id})
            logger.info(f"创建上下文 {context_id} 结果: {result}")
            return str(result)
        except Exception as e:
            logger.error(f"创建上下文 {context_id} 失败: {e}")
            return f"创建上下文失败: {str(e)}"
            
    async def set_data(self, context_id: str, key: str, value: any) -> str:
        """在指定上下文中设置数据
        
        Args:
            context_id: 上下文ID
            key: 数据键
            value: 数据值
            
        Returns:
            设置结果信息
        """
        if not self.session:
            return "客户端未连接到服务器"
            
        logger.info(f"在上下文 {context_id} 中设置数据: {key}={value}")
        try:
            result = await self.session.call_tool("set_data", {
                "context_id": context_id,
                "key": key,
                "value": value
            })
            logger.info(f"设置数据结果: {result}")
            return str(result)
        except Exception as e:
            logger.error(f"设置数据失败: {e}")
            return f"设置数据失败: {str(e)}"
            
    async def get_data(self, context_id: str, key: str) -> str:
        """从指定上下文中获取数据
        
        Args:
            context_id: 上下文ID
            key: 数据键
            
        Returns:
            获取的数据值或错误信息
        """
        if not self.session:
            return "客户端未连接到服务器"
            
        logger.info(f"从上下文 {context_id} 中获取数据: {key}")
        try:
            result = await self.session.call_tool("get_data", {
                "context_id": context_id,
                "key": key
            })
            logger.info(f"获取数据结果: {result}")
            return str(result)
        except Exception as e:
            logger.error(f"获取数据失败: {e}")
            return f"获取数据失败: {str(e)}"
            
    async def list_contexts(self) -> str:
        """列出所有上下文
        
        Returns:
            上下文列表
        """
        if not self.session:
            return "客户端未连接到服务器"
            
        logger.info("列出所有上下文")
        try:
            result = await self.session.call_tool("list_contexts", {})
            logger.info(f"上下文列表: {result}")
            return str(result)
        except Exception as e:
            logger.error(f"获取上下文列表失败: {e}")
            return f"获取上下文列表失败: {str(e)}"
            
    async def run_interactive_mode(self):
        """运行交互模式"""
        logger.info("进入交互模式")
        print("FastMCP多上下文客户端 - 交互模式")
        print("支持的命令:")
        print("  create_context <context_id>     - 创建上下文")
        print("  set_data <context_id> <key> <value> - 设置数据")
        print("  get_data <context_id> <key>     - 获取数据")
        print("  list_contexts                   - 列出所有上下文")
        print("  quit                            - 退出")
        print("-" * 40)
        
        try:
            # 连接到服务器
            server_params = StdioServerParameters(
                command=sys.executable,
                args=[self.server_script_path]
            )
            
            async with stdio_client(server_params) as (read, write):
                self.session = ClientSession(read, write)
                await self.session.initialize()
                logger.info("成功连接到MCP服务器！")
                
                print("✅ 已连接到服务器")
                
                while True:
                    try:
                        user_input = await asyncio.get_event_loop().run_in_executor(
                            None, input, "请输入命令: "
                        )
                        
                        if user_input.lower() in ['quit', 'exit', 'q']:
                            print("退出客户端")
                            break
                            
                        parts = user_input.strip().split()
                        if not parts:
                            continue
                            
                        command = parts[0]
                        
                        if command == "create_context" and len(parts) == 2:
                            result = await self.create_context(parts[1])
                            print(f"结果: {result}")
                            
                        elif command == "set_data" and len(parts) >= 4:
                            context_id = parts[1]
                            key = parts[2]
                            value = " ".join(parts[3:])  # 支持包含空格的值
                            result = await self.set_data(context_id, key, value)
                            print(f"结果: {result}")
                            
                        elif command == "get_data" and len(parts) == 3:
                            context_id = parts[1]
                            key = parts[2]
                            result = await self.get_data(context_id, key)
                            print(f"结果: {result}")
                            
                        elif command == "list_contexts" and len(parts) == 1:
                            result = await self.list_contexts()
                            print(f"结果: {result}")
                            
                        else:
                            print("无效命令或参数错误")
                            
                    except KeyboardInterrupt:
                        print("\n收到中断信号，退出客户端")
                        break
                    except Exception as e:
                        logger.error(f"处理命令时出错: {e}")
                        print(f"错误: {e}")
                        
        except Exception as e:
            logger.error(f"连接服务器失败: {e}")
            print(f"连接服务器失败: {e}")
                    
        async def run_tests(self):
            """运行测试"""
            try:
                # 创建上下文
                result = await self.session.call_tool("create_context", {"context_id": "user_context"})
                logger.info(f"创建上下文结果: {result}")
                    
                result = await self.session.call_tool("create_context", {"context_id": "system_context"})
                logger.info(f"创建上下文结果: {result}")
                    
                # 在不同上下文中设置数据
                result = await self.session.call_tool("set_data", {
                    "context_id": "user_context",
                    "key": "username",
                    "value": "Alice"
                })
                logger.info(f"设置用户名结果: {result}")
                    
                result = await self.session.call_tool("set_data", {
                    "context_id": "user_context",
                    "key": "email",
                    "value": "alice@example.com"
                })
                logger.info(f"设置邮箱结果: {result}")
                    
                result = await self.session.call_tool("set_data", {
                    "context_id": "system_context",
                    "key": "version",
                    "value": "1.0.0"
                })
                logger.info(f"设置版本结果: {result}")
                    
                result = await self.session.call_tool("set_data", {
                    "context_id": "system_context",
                    "key": "status",
                    "value": "active"
                })
                logger.info(f"设置状态结果: {result}")
                    
                # 获取数据
                result = await self.session.call_tool("get_data", {
                    "context_id": "user_context",
                    "key": "username"
                })
                logger.info(f"获取用户名结果: {result}")
                    
                result = await self.session.call_tool("get_data", {
                    "context_id": "system_context",
                    "key": "version"
                })
                logger.info(f"获取版本结果: {result}")
                    
                # 列出所有上下文
                result = await self.session.call_tool("list_contexts", {})
                logger.info(f"上下文列表: {result}")
                    
            except Exception as e:
                logger.error(f"测试过程中出现错误: {e}")
                raise


async def demo():
    """演示函数"""
    logger.info("启动FastMCP多上下文客户端演示")
    
    # 创建客户端实例
    client = FastMCPMultiContextClient()
    
    # 连接并运行测试
    await client.connect()


async def main():
    """主函数"""
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        # 运行演示
        await demo()
    else:
        # 创建客户端并运行交互模式
        client = FastMCPMultiContextClient()
        await client.run_interactive_mode()


if __name__ == "__main__":
    asyncio.run(main())