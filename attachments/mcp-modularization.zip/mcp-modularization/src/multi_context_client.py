from fastmcp import MCPClient
import asyncio
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MultiContextClient:
    def __init__(self, host: str = "localhost", port: int = 8080):
        self.client = MCPClient(host=host, port=port)
        
    async def connect(self):
        await self.client.connect()
        logger.info("Connected to server")
        
    async def disconnect(self):
        await self.client.disconnect()
        logger.info("Disconnected from server")
        
    async def create_context(self, context_id: str) -> dict:
        response = await self.client.request("create_context", {"context_id": context_id})
        logger.info(f"Create context response: {response}")
        return response
        
    async def set_data(self, context_id: str, key: str, value: any) -> dict:
        response = await self.client.request("set_data", {
            "context_id": context_id,
            "key": key,
            "value": value
        })
        logger.info(f"Set data response: {response}")
        return response
        
    async def get_data(self, context_id: str, key: str) -> dict:
        response = await self.client.request("get_data", {
            "context_id": context_id,
            "key": key
        })
        logger.info(f"Get data response: {response}")
        return response
        
    async def list_contexts(self) -> dict:
        response = await self.client.request("list_contexts", {})
        logger.info(f"List contexts response: {response}")
        return response

async def main():
    client = MultiContextClient()
    try:
        # 连接到服务器
        await client.connect()
        
        # 创建上下文
        await client.create_context("context1")
        await client.create_context("context2")
        
        # 在不同上下文中设置数据
        await client.set_data("context1", "name", "Alice")
        await client.set_data("context2", "name", "Bob")
        
        # 获取数据
        result1 = await client.get_data("context1", "name")
        result2 = await client.get_data("context2", "name")
        
        # 列出所有上下文
        contexts = await client.list_contexts()
        
        # 打印结果
        logger.info(f"Context1 name: {result1.get('data', {}).get('value')}")
        logger.info(f"Context2 name: {result2.get('data', {}).get('value')}")
        logger.info(f"All contexts: {contexts.get('data', {}).get('contexts')}")
        
    except Exception as e:
        logger.error(f"Error occurred: {e}")
    finally:
        await client.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
