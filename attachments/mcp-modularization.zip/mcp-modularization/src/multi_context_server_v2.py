# 导入 FastMCP 框架
from fastmcp import FastMCP
# 导入类型注解
from typing import Dict, Any
# 导入日志模块
import logging

# 配置日志级别为INFO
logging.basicConfig(level=logging.INFO)
# 获取当前模块的日志记录器
logger = logging.getLogger(__name__)

# 创建 FastMCP 实例，命名为 MultiContextServer
mcp = FastMCP("MultiContextServer")

# 定义一个用于存储多个上下文的字典，键为上下文ID，值为该上下文的数据字典
contexts: Dict[str, Dict[str, Any]] = {}

# 注册 create_context 工具方法
@mcp.tool()
def create_context(context_id: str) -> str:
    """创建新的上下文"""
    # 如果上下文已存在，记录警告日志并返回提示
    if context_id in contexts:
        logger.warning(f"Context {context_id} already exists")
        return f"Context {context_id} already exists"
    # 新建一个空的上下文数据字典
    contexts[context_id] = {}
    # 记录创建成功的日志
    logger.info(f"Created new context: {context_id}")
    # 返回创建成功的信息
    return f"Context {context_id} created successfully"

# 注册 set_data 工具方法
@mcp.tool()
def set_data(context_id: str, key: str, value: Any) -> str:
    """在指定上下文中设置数据"""
    # 如果指定的上下文不存在，记录警告日志并返回提示
    if context_id not in contexts:
        logger.warning(f"Context {context_id} not found")
        return f"Context {context_id} not found"
    # 在指定上下文中设置键值对
    contexts[context_id][key] = value
    # 记录设置数据的日志
    logger.info(f"Set data in context {context_id}: {key}={value}")
    # 返回设置成功的信息
    return f"Data set successfully in context {context_id}"

# 注册 get_data 工具方法
@mcp.tool()
def get_data(context_id: str, key: str) -> str:
    """从指定上下文中获取数据"""
    # 如果指定的上下文不存在，记录警告日志并返回提示
    if context_id not in contexts:
        logger.warning(f"Context {context_id} not found")
        return f"Context {context_id} not found"
    # 如果指定的键不存在于该上下文，记录警告日志并返回提示
    if key not in contexts[context_id]:
        logger.warning(f"Key {key} not found in context {context_id}")
        return f"Key {key} not found in context {context_id}"
    # 获取指定键的值
    value = contexts[context_id][key]
    # 记录获取数据的日志
    logger.info(f"Get data from context {context_id}: {key}={value}")
    # 返回获取到的值（转为字符串）
    return str(value)

# 注册 list_contexts 工具方法
@mcp.tool()
def list_contexts() -> str:
    """列出所有上下文"""
    # 获取所有上下文ID的列表
    context_list = list(contexts.keys())
    # 记录列出上下文的日志
    logger.info(f"Listing contexts: {context_list}")
    # 返回上下文ID列表的字符串表示
    return str(context_list)

# 判断是否为主程序入口
if __name__ == "__main__":
    # 启动服务器并记录日志
    logger.info("Starting MCP server...")
    mcp.run()