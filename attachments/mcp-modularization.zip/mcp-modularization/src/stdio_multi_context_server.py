#!/usr/bin/env python3
"""
标准MCP多上下文服务器
使用stdio协议与客户端通信
"""
import asyncio
import logging
from typing import Dict, Any

# 导入MCP标准库
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolRequest,
    CallToolResult,
)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 创建MCP服务器实例
server = Server("MultiContextServer")

# 存储多个上下文的字典
contexts: Dict[str, Dict[str, Any]] = {}


@server.list_tools()
async def list_tools() -> list[Tool]:
    """列出服务器支持的工具"""
    return [
        Tool(
            name="create_context",
            description="创建一个新的上下文",
            inputSchema={
                "type": "object",
                "properties": {
                    "context_id": {
                        "type": "string",
                        "description": "上下文ID"
                    }
                },
                "required": ["context_id"]
            }
        ),
        Tool(
            name="set_data",
            description="在指定上下文中设置数据",
            inputSchema={
                "type": "object",
                "properties": {
                    "context_id": {
                        "type": "string",
                        "description": "上下文ID"
                    },
                    "key": {
                        "type": "string",
                        "description": "数据键"
                    },
                    "value": {
                        "description": "数据值（任意类型）"
                    }
                },
                "required": ["context_id", "key", "value"]
            }
        ),
        Tool(
            name="get_data",
            description="从指定上下文中获取数据",
            inputSchema={
                "type": "object",
                "properties": {
                    "context_id": {
                        "type": "string",
                        "description": "上下文ID"
                    },
                    "key": {
                        "type": "string",
                        "description": "数据键"
                    }
                },
                "required": ["context_id", "key"]
            }
        ),
        Tool(
            name="list_contexts",
            description="列出所有上下文",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """处理工具调用"""
    try:
        if name == "create_context":
            context_id = arguments.get("context_id")
            if not context_id:
                return [TextContent(type="text", text="错误：缺少context_id参数")]
            
            if context_id in contexts:
                logger.warning(f"Context {context_id} already exists")
                return [TextContent(type="text", text=f"Context {context_id} already exists")]
            
            contexts[context_id] = {}
            logger.info(f"Created new context: {context_id}")
            return [TextContent(type="text", text=f"Context {context_id} created successfully")]
        
        elif name == "set_data":
            context_id = arguments.get("context_id")
            key = arguments.get("key")
            value = arguments.get("value")
            
            if not all([context_id, key is not None, value is not None]):
                return [TextContent(type="text", text="错误：缺少必要参数")]
            
            if context_id not in contexts:
                logger.warning(f"Context {context_id} not found")
                return [TextContent(type="text", text=f"Context {context_id} not found")]
            
            contexts[context_id][key] = value
            logger.info(f"Set data in context {context_id}: {key}={value}")
            return [TextContent(type="text", text=f"Data set successfully in context {context_id}")]
        
        elif name == "get_data":
            context_id = arguments.get("context_id")
            key = arguments.get("key")
            
            if not all([context_id, key]):
                return [TextContent(type="text", text="错误：缺少必要参数")]
            
            if context_id not in contexts:
                logger.warning(f"Context {context_id} not found")
                return [TextContent(type="text", text=f"Context {context_id} not found")]
            
            if key not in contexts[context_id]:
                logger.warning(f"Key {key} not found in context {context_id}")
                return [TextContent(type="text", text=f"Key {key} not found in context {context_id}")]
            
            value = contexts[context_id][key]
            logger.info(f"Get data from context {context_id}: {key}={value}")
            return [TextContent(type="text", text=str(value))]
        
        elif name == "list_contexts":
            context_list = list(contexts.keys())
            logger.info(f"Listing contexts: {context_list}")
            return [TextContent(type="text", text=str(context_list))]
        
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    
    except Exception as e:
        logger.error(f"Error in tool {name}: {e}")
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def main():
    """主函数 - 启动stdio服务器"""
    logger.info("启动标准MCP多上下文服务器...")
    
    # 使用stdio服务器运行
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    # 启动服务器
    asyncio.run(main())
