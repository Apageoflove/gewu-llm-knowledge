# MCP客户端测试代码
import asyncio
import json
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
import subprocess
import sys

class MCPClient:
    """MCP客户端类，用于连接和测试MCP服务器"""
    
    def __init__(self, server_script_path: str):
        """初始化MCP客户端
        
        Args:
            server_script_path: MCP服务器脚本路径
        """
        self.server_script_path = server_script_path
        self.session = None
    
    async def connect(self):
        """连接到MCP服务器"""
        print("🔗 正在连接到MCP服务器...")
        
        # 配置服务器参数
        server_params = StdioServerParameters(
            command=sys.executable,  # Python解释器路径
            args=[self.server_script_path]  # 服务器脚本路径
        )
        
        try:
            # 建立连接
            async with stdio_client(server_params) as (read, write):
                self.session = ClientSession(read, write)
                
                # 初始化会话
                await self.session.initialize()
                print("✅ 成功连接到MCP服务器！")
                
                # 运行测试
                await self.run_tests()
                
        except Exception as e:
            print(f"❌ 连接失败: {e}")
    
    async def run_tests(self):
        """运行各种测试"""
        print("\n📋 开始运行测试...")
        
        try:
            # 测试1: 获取服务器信息
            print("\n🔍 测试1: 获取可用工具列表")
            tools_result = await self.session.list_tools()
            print(f"可用工具数量: {len(tools_result.tools)}")
            
            for tool in tools_result.tools:
                print(f"  - 工具名称: {tool.name}")
                print(f"    描述: {tool.description}")
            
            # 测试2: 调用server_info工具
            print("\n🛠️ 测试2: 调用server_info工具")
            if tools_result.tools:
                # 找到server_info工具
                server_info_tool = None
                for tool in tools_result.tools:
                    if tool.name == "server_info":
                        server_info_tool = tool
                        break
                
                if server_info_tool:
                    result = await self.session.call_tool(
                        name="server_info",
                        arguments={}
                    )
                    
                    print("📊 服务器信息:")
                    print(f"  状态: {result.isError}")
                    if result.content:
                        # 解析返回内容
                        for content in result.content:
                            if hasattr(content, 'text'):
                                try:
                                    info = json.loads(content.text)
                                    print(f"  - 服务名称: {info.get('server_name', 'N/A')}")
                                    print(f"  - 版本: {info.get('version', 'N/A')}")
                                    print(f"  - 描述: {info.get('description', 'N/A')}")
                                except json.JSONDecodeError:
                                    print(f"  - 内容: {content.text}")
                            else:
                                print(f"  - 内容: {content}")
                else:
                    print("⚠️ 未找到server_info工具")
            
            print("\n✅ 测试完成！")
            
        except Exception as e:
            print(f"❌ 测试过程中出现错误: {e}")

async def main():
    """主函数"""
    print("🚀 启动MCP客户端测试程序")
    print("=" * 50)
    
    # 创建客户端并连接
    client = MCPClient("src/simple_mcp_server.py")
    await client.connect()

if __name__ == "__main__":
    # 运行客户端
    asyncio.run(main())
