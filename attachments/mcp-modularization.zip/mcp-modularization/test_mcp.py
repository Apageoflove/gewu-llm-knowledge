#!/usr/bin/env python3
"""
MCP服务器测试脚本
提供简单的命令行界面来启动和测试MCP服务器
"""

import subprocess
import sys
import time
import asyncio
import signal
import os
from pathlib import Path

def print_banner():
    """打印横幅"""
    print("=" * 60)
    print("🚀 MCP模块化开发最佳实践 - 测试工具")
    print("=" * 60)
    print()

def print_menu():
    """打印菜单选项"""
    print("📋 请选择操作:")
    print("  1. 启动MCP服务器 (HTTP模式)")
    print("  2. 测试MCP服务器 (STDIO模式)")
    print("  3. 同时启动服务器和客户端测试")
    print("  4. 退出")
    print()

def start_mcp_server():
    """启动MCP服务器"""
    print("🌐 启动MCP服务器...")
    print("服务器将在 http://localhost:8000 运行")
    print("按 Ctrl+C 停止服务器")
    print("-" * 40)
    
    try:
        # 启动服务器进程
        process = subprocess.run([
            sys.executable, 
            "src/simple_mcp_server.py"
        ], cwd=os.getcwd())
        
    except KeyboardInterrupt:
        print("\n✅ 服务器已停止")
    except Exception as e:
        print(f"❌ 启动服务器失败: {e}")

async def test_mcp_client():
    """测试MCP客户端"""
    print("🧪 启动MCP客户端测试...")
    print("-" * 40)
    
    try:
        # 导入并运行客户端
        from src.mcp_client import main
        await main()
        
    except Exception as e:
        print(f"❌ 客户端测试失败: {e}")
        print(f"错误详情: {type(e).__name__}: {str(e)}")

def start_server_and_test():
    """启动服务器并运行测试"""
    print("🔄 启动服务器并运行客户端测试...")
    print("这将在STDIO模式下运行服务器和客户端")
    print("-" * 40)
    
    try:
        # 直接运行客户端测试（客户端会自动启动服务器）
        asyncio.run(test_mcp_client())
        
    except KeyboardInterrupt:
        print("\n✅ 测试已停止")
    except Exception as e:
        print(f"❌ 测试失败: {e}")

def check_dependencies():
    """检查依赖是否安装"""
    print("🔍 检查依赖...")
    
    required_packages = ['mcp', 'fastmcp']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package} 已安装")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package} 未安装")
    
    if missing_packages:
        print(f"\n⚠️ 请先安装缺失的包:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    print("✅ 所有依赖都已安装")
    return True

def main():
    """主函数"""
    print_banner()
    
    # 检查依赖
    if not check_dependencies():
        return
    
    print()
    
    while True:
        print_menu()
        
        try:
            choice = input("请输入选项 (1-4): ").strip()
            
            if choice == '1':
                print()
                start_mcp_server()
                
            elif choice == '2':
                print()
                asyncio.run(test_mcp_client())
                
            elif choice == '3':
                print()
                start_server_and_test()
                
            elif choice == '4':
                print("👋 再见!")
                break
                
            else:
                print("❌ 无效选项，请重新选择")
            
            print("\n" + "-" * 40)
            input("按 Enter 键继续...")
            print()
            
        except KeyboardInterrupt:
            print("\n👋 再见!")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")
            print("\n" + "-" * 40)
            input("按 Enter 键继续...")

if __name__ == "__main__":
    main()
