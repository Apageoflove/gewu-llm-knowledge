#!/usr/bin/env python3
"""
简单的MCP测试客户端 - 直接进行JSON-RPC通信
"""

import subprocess
import sys
import json
import time
import os

class SimpleMCPClient:
    """简单的MCP客户端，使用直接的JSON-RPC通信"""
    
    def __init__(self, server_script):
        self.server_script = server_script
        self.process = None
        self.request_id = 1
    
    def start_server(self):
        """启动MCP服务器"""
        print("🚀 启动MCP服务器...")
        
        # 设置环境变量确保UTF-8编码
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        
        self.process = subprocess.Popen(
            [sys.executable, self.server_script],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            env=env
        )
        
        print("✅ 服务器进程已启动")
    
    def send_message(self, method, params=None):
        """发送JSON-RPC消息到服务器"""
        message = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method
        }
        if params:
            message["params"] = params
        
        json_message = json.dumps(message) + "\n"
        print(f"📤 发送消息: {method}")
        print(f"   内容: {json_message.strip()}")
        
        try:
            self.process.stdin.write(json_message)
            self.process.stdin.flush()
            self.request_id += 1
            return True
        except Exception as e:
            print(f"❌ 发送消息失败: {e}")
            return False
    
    def read_response(self, timeout=5):
        """读取服务器响应"""
        print("📥 等待服务器响应...")
        
        try:
            # 简化读取逻辑，使用readline直接读取一行
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                if self.process.poll() is not None:
                    print("⚠️ 服务器进程已退出")
                    stdout, stderr = self.process.communicate()
                    print(f"标准输出: {stdout}")
                    print(f"错误输出: {stderr}")
                    break
                
                try:
                    # 使用readline读取完整一行
                    response_line = self.process.stdout.readline()
                    if response_line:
                        response_line = response_line.strip()
                        print(f"✅ 收到完整响应")
                        print(f"   长度: {len(response_line)} 字符")
                        print(f"   内容: {response_line}")
                        
                        try:
                            response = json.loads(response_line)
                            return response
                        except json.JSONDecodeError as e:
                            print(f"❌ JSON解析失败: {e}")
                            print(f"   原始内容: {repr(response_line)}")
                            return None
                    else:
                        time.sleep(0.1)
                        continue
                        
                except Exception as read_error:
                    print(f"❌ 读取时出错: {read_error}")
                    time.sleep(0.1)
                    continue
            
            print("⏱️ 读取超时")
            return None
                
        except Exception as e:
            print(f"❌ 读取响应失败: {e}")
            return None
    
    def test_full_flow(self):
        """测试完整的MCP通信流程"""
        print("🧪 开始MCP通信测试")
        print("=" * 50)
        
        try:
            # 1. 启动服务器
            self.start_server()
            time.sleep(1)  # 给服务器一点启动时间
            
            # 2. 发送初始化请求
            print("\n🔄 步骤1: 发送初始化请求")
            if self.send_message("initialize", {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {
                    "name": "simple-test-client",
                    "version": "1.0.0"
                }
            }):
                response = self.read_response()
                if response:
                    print(f"✅ 初始化成功!")
                    print(f"   服务器: {response.get('result', {}).get('serverInfo', {})}")
                else:
                    print("❌ 初始化失败")
                    return
            
            # 3. 发送initialized通知
            print("\n🔄 步骤2: 发送initialized通知")
            initialized_msg = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized"
            }
            json_msg = json.dumps(initialized_msg) + "\n"
            self.process.stdin.write(json_msg)
            self.process.stdin.flush()
            print("✅ initialized通知已发送")
            
            # 等待一点时间让服务器处理initialized通知
            time.sleep(0.5)
            
            # 4. 获取工具列表
            print("\n🔄 步骤3: 获取工具列表")
            if self.send_message("tools/list"):
                response = self.read_response()
                if response:
                    tools = response.get('result', {}).get('tools', [])
                    print(f"✅ 找到 {len(tools)} 个工具:")
                    for tool in tools:
                        print(f"   - {tool.get('name')}: {tool.get('description')}")
                    
                    # 5. 调用server_info工具
                    if any(tool.get('name') == 'server_info' for tool in tools):
                        print("\n🔄 步骤4: 调用server_info工具")
                        if self.send_message("tools/call", {
                            "name": "server_info",
                            "arguments": {}
                        }):
                            response = self.read_response()
                            if response:
                                result = response.get('result', {})
                                content = result.get('content', [])
                                print(f"✅ 工具调用成功!")
                                print(f"   原始结果: {result}")
                                
                                # 尝试解析内容
                                if content:
                                    for item in content:
                                        if isinstance(item, dict) and 'text' in item:
                                            try:
                                                text_content = json.loads(item['text'])
                                                print("📊 服务器信息:")
                                                print(f"   - 服务名称: {text_content.get('server_name', 'N/A')}")
                                                print(f"   - 版本: {text_content.get('version', 'N/A')}")
                                                print(f"   - 描述: {text_content.get('description', 'N/A')}")
                                            except:
                                                print(f"   - 内容: {item.get('text', item)}")
                                        else:
                                            print(f"   - 内容: {item}")
                            else:
                                print("❌ 工具调用失败")
                    else:
                        print("⚠️ 未找到server_info工具")
                else:
                    print("❌ 获取工具列表失败")
            
            print("\n🎉 测试完成!")
            
        except Exception as e:
            print(f"❌ 测试过程中出错: {e}")
        
        finally:
            # 清理
            if self.process and self.process.poll() is None:
                print("\n🧹 清理: 终止服务器进程")
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except:
                    self.process.kill()

if __name__ == "__main__":
    client = SimpleMCPClient("src/simple_mcp_server.py")
    client.test_full_flow()
