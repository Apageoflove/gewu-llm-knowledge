# MCP 模块化开发最佳实践

这是一个基于 **FastMCP** 框架的 MCP（Model Context Protocol）服务器开发示例项目，展示了如何构建、测试和部署 MCP 服务器。

## 📖 项目概述

本项目包含：
- 🖥️ **简单的 MCP 服务器** (`src/simple_mcp_server.py`)
- 🔧 **MCP 客户端测试工具** (`src/mcp_client.py`) 
- 🚀 **一键测试脚本** (`test_mcp.py`)

## 🛠️ 环境设置

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 验证安装

```bash
python test_mcp.py
```

## 🚀 快速开始

### 方法一：使用测试脚本（推荐）

运行交互式测试工具：

```bash
python test_mcp.py
```

选择选项：
- **选项 1**: 启动 HTTP 模式 MCP 服务器
- **选项 2**: 运行 STDIO 模式客户端测试
- **选项 3**: 同时启动服务器和客户端测试

### 方法二：手动启动

#### 启动 MCP 服务器

```bash
python src/simple_mcp_server.py
```

服务器将在 `http://localhost:8000` 运行

#### 运行客户端测试

在新的终端窗口中：

```bash
python src/mcp_client.py
```

## 📋 服务器功能

当前 MCP 服务器提供以下工具：

### `server_info`
- **描述**: 返回 MCP 服务的基本信息
- **参数**: 无
- **返回**: 包含服务器名称、版本和描述的 JSON 对象

示例响应：
```json
{
  "server_name": "SimpleMCPServer",
  "version": "1.0.0", 
  "description": "这是一个基于fastmcp实现的简单MCP服务，提供服务信息查询接口。"
}
```

## 🧪 测试结果示例

运行客户端测试时，你应该看到类似的输出：

```
🚀 启动MCP客户端测试程序
==================================================
🔗 正在连接到MCP服务器...
✅ 成功连接到MCP服务器！

📋 开始运行测试...

🔍 测试1: 获取可用工具列表
可用工具数量: 1
  - 工具名称: server_info
    描述: 返回MCP服务的基本信息

🛠️ 测试2: 调用server_info工具
📊 服务器信息:
  状态: False
  - 服务名称: SimpleMCPServer
  - 版本: 1.0.0
  - 描述: 这是一个基于fastmcp实现的简单MCP服务，提供服务信息查询接口。

✅ 测试完成！
```

## 📁 项目结构

```
mcp-modularization/
├── README.md                 # 项目文档
├── requirements.txt          # Python依赖
├── test_mcp.py              # 一键测试脚本
├── src/
│   ├── simple_mcp_server.py # MCP服务器实现
│   └── mcp_client.py        # MCP客户端测试工具
└── test/                    # 测试目录（待扩展）
```

## 🔧 技术栈

- **MCP框架**: FastMCP 2.0+
- **Python版本**: 3.8+
- **核心依赖**:
  - `mcp`: MCP协议核心库
  - `fastmcp`: 快速MCP服务器框架
  - `uvicorn`: ASGI服务器
  - `pydantic`: 数据验证

## 🌟 扩展开发

### 添加新工具

1. 在 `simple_mcp_server.py` 中创建新的工具类：

```python
class MyNewTool(Tool):
    name = "my_tool"
    description = "我的新工具"
    
    def run(self, **kwargs) -> ToolResponse:
        # 实现工具逻辑
        return ToolResponse(content={"result": "success"})
```

2. 将工具添加到服务器：

```python
server = MCPServer(
    tools=[ServerInfoTool(), MyNewTool()],  # 添加新工具
    title="简单MCP服务",
    description="基于fastmcp的简单MCP服务"
)
```

### 添加资源支持

可以扩展服务器以支持 MCP 资源：

```python
from fastmcp.resources import Resource

class MyResource(Resource):
    uri = "myapp://resource1"
    name = "My Resource"
    description = "示例资源"
    
    def read(self) -> str:
        return "资源内容"
```

## 🐛 故障排除

### 常见问题

1. **ImportError: No module named 'mcp'**
   ```bash
   pip install -r requirements.txt
   ```

2. **端口 8000 被占用**
   - 修改 `simple_mcp_server.py` 中的端口号
   - 或者停止占用端口的进程

3. **客户端连接失败**
   - 确保服务器已启动
   - 检查防火墙设置
   - 使用 STDIO 模式测试（选项2）

## 📚 学习资源

- [MCP 官方文档](https://modelcontextprotocol.io/)
- [FastMCP 文档](https://github.com/jlowin/fastmcp)
- [MCP 协议规范](https://spec.modelcontextprotocol.io/)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 来改进这个项目！

## 📄 许可证

本项目采用 MIT 许可证。
