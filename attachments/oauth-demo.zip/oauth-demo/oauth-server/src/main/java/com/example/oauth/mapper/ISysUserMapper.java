package com.example.oauth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.oauth.domain.entity.SysUser;
import org.apache.ibatis.annotations.Mapper;


/**
 * 用户Mapper接口
 */
@Mapper
public interface ISysUserMapper extends BaseMapper<SysUser> {

}
