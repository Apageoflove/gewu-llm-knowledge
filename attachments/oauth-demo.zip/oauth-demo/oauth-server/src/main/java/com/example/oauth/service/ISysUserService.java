package com.example.oauth.service;

import org.springframework.security.core.userdetails.UserDetailsService;


/**
 * 用户Service接口
 */
public interface ISysUserService extends UserDetailsService {
}
