package com.example.oauth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.oauth.domain.entity.SysRole;
import org.apache.ibatis.annotations.Mapper;


/**
 * 【请填写功能名称】Mapper接口
 */
@Mapper
public interface ISysRoleMapper extends BaseMapper<SysRole> {

}
