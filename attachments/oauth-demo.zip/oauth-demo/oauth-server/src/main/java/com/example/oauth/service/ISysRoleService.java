package com.example.oauth.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.oauth.domain.entity.SysRole;
import org.apache.ibatis.annotations.Mapper;


/**
 * 【请填写功能名称】Mapper接口
 */
@Mapper
public interface ISysRoleService extends IService<SysRole> {

}
