# 导入load_dataset函数，用于从Hugging Face数据集库加载数据集
from datasets import load_dataset

# 加载Twitter投诉数据集，这个数据集包含了用户在Twitter上的投诉信息
# 例如："@某公司 我的订单还没到"这样的推文，以及它们是否包含投诉的标签
ds = load_dataset("ought/raft", "twitter_complaints")

# 将标签ID转换为可读的文本标签，把下划线替换为空格
# 例如：将"no_complaint"转换为"no complaint"
classes = [k.replace("_", " ") for k in ds["train"].features["Label"].names]
# 为数据集添加一个新列"text_label"，将数字标签转换为文本标签
# 例如：如果一条推文的Label是2，对应的text_label可能是"no complaint"
ds = ds.map(
    lambda x: {"text_label": [classes[label] for label in x["Label"]]},
    batched=True,  # 批处理模式，一次处理多个样本
    num_proc=1,    # 使用1个进程进行处理
)
# 查看训练集的第一个样本，了解数据结构
print(ds["train"][0])
# 输出示例：包含推文文本、ID、数字标签和文本标签
{"Tweet text": "@HMRCcustomers No this is my first job", "ID": 0, "Label": 2, "text_label": "no complaint"}

# 导入AutoTokenizer，用于将文本转换为模型可以理解的数字序列
from transformers import AutoTokenizer

# 加载预训练模型的分词器，这里使用的是bloomz-560m模型的分词器
tokenizer = AutoTokenizer.from_pretrained("bigscience/bloomz-560m")
# 如果分词器没有定义填充标记，则使用结束标记作为填充标记
if tokenizer.pad_token_id is None:
    tokenizer.pad_token_id = tokenizer.eos_token_id
# 计算所有类别标签中最长的标签的token长度，用于后续处理
target_max_length = max([len(tokenizer(class_label)["input_ids"]) for class_label in classes])
# 打印最长标签的长度，帮助我们了解需要多少空间来存储标签
print(target_max_length)

# 导入PyTorch库，用于构建和训练神经网络
import torch

# 设置输入序列的最大长度为64个token
max_length = 64


# 定义预处理函数，将文本和标签转换为模型输入格式
def preprocess_function(examples, text_column="Tweet text", label_column="text_label"):
    # 获取批次大小（即当前处理的样本数量）
    batch_size = len(examples[text_column])
    # 构建输入文本，格式为"Tweet text : {推文内容} Label : "
    # 例如："Tweet text : @某公司 我很满意你们的服务 Label : "
    inputs = [f"{text_column} : {x} Label : " for x in examples[text_column]]
    # 将标签转换为字符串
    targets = [str(x) for x in examples[label_column]]
    # 使用分词器将输入文本转换为token ID
    model_inputs = tokenizer(inputs)
    # 使用分词器将标签文本转换为token ID
    labels = tokenizer(targets)
    # 获取所有类别标签（与前面相同，但在函数内部重新计算以确保一致性）
    classes = [k.replace("_", " ") for k in ds["train"].features["Label"].names]
    # 遍历每个样本，进行填充和截断处理
    for i in range(batch_size):
        # 获取当前样本的输入ID和标签ID
        sample_input_ids = model_inputs["input_ids"][i]
        label_input_ids = labels["input_ids"][i]
        # 在输入序列前面填充足够的填充标记，使总长度为max_length
        # 这是左填充，确保实际内容在序列的右侧
        model_inputs["input_ids"][i] = [tokenizer.pad_token_id] * (
                max_length - len(sample_input_ids)
        ) + sample_input_ids
        # 同样为注意力掩码进行填充，填充部分用0表示（不关注），实际内容用1表示（需要关注）
        model_inputs["attention_mask"][i] = [0] * (max_length - len(sample_input_ids)) + model_inputs[
            "attention_mask"
        ][i]
        # 为标签序列填充-100，-100是PyTorch中用于忽略计算损失的特殊值
        labels["input_ids"][i] = [-100] * (max_length - len(label_input_ids)) + label_input_ids
        # 将填充后的序列转换为PyTorch张量，并确保长度不超过max_length
        model_inputs["input_ids"][i] = torch.tensor(model_inputs["input_ids"][i][:max_length])
        model_inputs["attention_mask"][i] = torch.tensor(model_inputs["attention_mask"][i][:max_length])
        labels["input_ids"][i] = torch.tensor(labels["input_ids"][i][:max_length])
    # 将处理好的标签添加到模型输入中
    model_inputs["labels"] = labels["input_ids"]
    # 返回处理好的模型输入
    return model_inputs


# 对整个数据集应用预处理函数
processed_ds = ds.map(
    preprocess_function,
    batched=True,         # 批处理模式
    num_proc=1,           # 使用1个进程
    remove_columns=ds["train"].column_names,  # 移除原始列，只保留处理后的列
    load_from_cache_file=False,  # 不从缓存加载，强制重新处理
    desc="Running tokenizer on dataset",  # 进度条描述
)

# 导入DataLoader用于批量加载数据，导入default_data_collator用于将样本组合成批次
from torch.utils.data import DataLoader
from transformers import default_data_collator

# 为了快速测试，只选择训练集和测试集的前10个样本
# 在实际应用中，应该使用完整数据集
train_ds = processed_ds["train"].select(range(10))
eval_ds = processed_ds["test"].select(range(10))

# 设置批次大小为2，即每次处理2个样本
batch_size = 2

# 创建训练数据加载器，设置为随机打乱数据
train_dataloader = DataLoader(train_ds, shuffle=True, collate_fn=default_data_collator, batch_size=batch_size,
                              pin_memory=True)  # pin_memory=True可以加速GPU训练
# 创建评估数据加载器，不需要打乱数据
eval_dataloader = DataLoader(eval_ds, collate_fn=default_data_collator, batch_size=batch_size, pin_memory=True)

# 导入自回归语言模型类
from transformers import AutoModelForCausalLM

# 加载预训练的bloomz-560m模型
model = AutoModelForCausalLM.from_pretrained("bigscience/bloomz-560m")

# 导入PEFT（参数高效微调）相关函数
from peft import PromptEncoderConfig, get_peft_model

# 配置提示编码器，这是一种参数高效的微调方法
# 只添加少量可训练参数，而不是微调整个模型
peft_config = PromptEncoderConfig(task_type="CAUSAL_LM", num_virtual_tokens=20, encoder_hidden_size=128)
# 将模型转换为PEFT模型
model = get_peft_model(model, peft_config)
# 打印可训练参数的数量和比例
model.print_trainable_parameters()
# 输出示例：只有约0.05%的参数需要训练，大大减少了计算资源需求
"trainable params: 300,288 || all params: 559,514,880 || trainable%: 0.05366935013417338"

# 导入学习率调度器
from transformers import get_linear_schedule_with_warmup

# 设置学习率为0.03
lr = 3e-2
# 设置训练轮数为1
num_epochs = 3

# 创建Adam优化器，设置学习率
optimizer = torch.optim.AdamW(model.parameters(), lr=lr)
# 创建线性学习率调度器，随着训练进行逐渐降低学习率
lr_scheduler = get_linear_schedule_with_warmup(
    optimizer=optimizer,
    num_warmup_steps=0,  # 不使用预热步骤
    num_training_steps=(len(train_dataloader) * num_epochs),  # 总训练步数
)

# 导入tqdm库，用于显示进度条
from tqdm import tqdm

# 设置设备为CUDA（GPU），加速训练
device = "cuda"
# 将模型移动到GPU
model = model.to(device)

# 开始训练循环
for epoch in range(num_epochs):
    # 设置模型为训练模式
    model.train()
    # 初始化总损失为0
    total_loss = 0
    # 遍历训练数据加载器中的每批次个
    for step, batch in enumerate(tqdm(train_dataloader)):
        # 将批次数据移动到GPU
        batch = {k: v.to(device) for k, v in batch.items()}
        # 前向传播，计算模型输出
        outputs = model(**batch)
        # 获取损失值
        loss = outputs.loss
        # 累加损失（转换为float并分离计算图）
        total_loss += loss.detach().float()
        # 反向传播，计算梯度
        loss.backward()
        # 更新模型参数
        optimizer.step()
        # 更新学习率
        lr_scheduler.step()
        # 清零梯度，准备下一次迭代
        optimizer.zero_grad()

    # 训练完一个epoch后，进行评估
    # 设置模型为评估模式
    model.eval()
    # 初始化评估损失和预测结果列表
    eval_loss = 0
    eval_preds = []
    # 遍历评估数据加载器中的每个批次
    for step, batch in enumerate(tqdm(eval_dataloader)):
        # 将批次数据移动到GPU
        batch = {k: v.to(device) for k, v in batch.items()}
        # 使用torch.no_grad()避免计算梯度，节省内存
        with torch.no_grad():
            # 前向传播，计算模型输出
            outputs = model(**batch)
        # 获取损失值
        loss = outputs.loss
        # 累加评估损失
        eval_loss += loss.detach().float()
        # 获取预测结果：找到每个位置概率最高的token，转换为CPU张量，然后解码为文本
        eval_preds.extend(
            tokenizer.batch_decode(torch.argmax(outputs.logits, -1).detach().cpu().numpy(), skip_special_tokens=True)
        )

    # 计算平均评估损失和困惑度（perplexity，语言模型常用的评估指标）
    eval_epoch_loss = eval_loss / len(eval_dataloader)
    eval_ppl = torch.exp(eval_epoch_loss)
    # 计算平均训练损失和困惑度
    train_epoch_loss = total_loss / len(train_dataloader)
    train_ppl = torch.exp(train_epoch_loss)
    # 打印训练和评估结果
    print(f"{epoch=}: {train_ppl=} {train_epoch_loss=} {eval_ppl=} {eval_epoch_loss=}")

# 设置Hugging Face账户名
account = "VergilDante"
# 构建模型ID
peft_model_id = f"{account}/bloomz-560-m-peft-method"
# 将微调后的模型上传到Hugging Face模型中心
model.push_to_hub(peft_model_id)
