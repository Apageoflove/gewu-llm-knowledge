# c:\\users\用户名\.cache\huggingface\ ，修改环境变量 setx HF_HOME "D:\software\huggingface"


python qlora.py --model_name_or_path facebook/opt-350m

#创建python环境
conda create --name qlora  python=3.9
conda activate qlora

pip install transformers peft datasets evaluate accelerate torch bitsandbytes