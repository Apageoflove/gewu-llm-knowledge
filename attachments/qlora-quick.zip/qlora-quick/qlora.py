# 导入必要的库和模块
from collections import defaultdict  # 导入defaultdict，一种当键不存在时提供默认值的字典
import copy  # 导入copy模块，用于创建对象的浅拷贝和深拷贝
import json  # 导入json模块，用于JSON数据的编码和解码
import os  # 导入os模块，提供与操作系统交互的功能
from os.path import exists, join, isdir  # 从os.path导入文件路径相关函数
from dataclasses import dataclass, field  # 导入dataclass装饰器和field函数，用于创建数据类
import sys  # 导入sys模块，提供对Python解释器的访问
from typing import Optional, Dict, Sequence  # 导入类型提示相关的类
import numpy as np  # 导入numpy库，用于科学计算
from tqdm import tqdm  # 导入tqdm，用于显示进度条
import logging  # 导入logging模块，用于日志记录
import bitsandbytes as bnb  # 导入bitsandbytes库，用于模型量化
import pandas as pd  # 导入pandas库，用于数据处理
import importlib  # 导入importlib模块，用于动态导入模块
from packaging import version  # 导入version模块，用于版本比较
from packaging.version import parse  # 从packaging.version导入parse函数

import torch  # 导入PyTorch库，用于深度学习
import transformers  # 导入transformers库，用于使用预训练模型
from torch.nn.utils.rnn import pad_sequence  # 从torch.nn.utils.rnn导入pad_sequence函数，用于序列填充
import argparse  # 导入argparse模块，用于命令行参数解析
from transformers import (  # 从transformers导入各种类和函数
    AutoTokenizer,  # 自动加载tokenizer
    AutoModelForCausalLM,  # 自动加载因果语言模型
    set_seed,  # 设置随机种子函数
    Seq2SeqTrainer,  # 序列到序列训练器
    BitsAndBytesConfig,  # 量化配置
    LlamaTokenizer  # Llama模型的tokenizer
)
from datasets import load_dataset, Dataset  # 从datasets导入加载数据集和Dataset类
import evaluate  # 导入evaluate模块，用于模型评估

from peft import (  # 从peft导入参数高效微调相关的类和函数
    prepare_model_for_kbit_training,  # 为k-bit训练准备模型
    LoraConfig,  # LoRA配置类
    get_peft_model,  # 获取PEFT模型函数
    PeftModel  # PEFT模型类
)
from peft.tuners.lora import LoraLayer  # 从peft.tuners.lora导入LoraLayer类
from transformers.trainer_utils import PREFIX_CHECKPOINT_DIR  # 从transformers.trainer_utils导入检查点目录前缀常量


# 检查Intel扩展PyTorch是否可用的函数
def is_ipex_available():
    # 从版本字符串中提取主要和次要版本号
    def get_major_and_minor_from_version(full_version):
        return str(version.parse(full_version).major) + "." + str(version.parse(full_version).minor)

    # 获取PyTorch版本
    _torch_version = importlib.metadata.version("torch")
    # 检查intel_extension_for_pytorch模块是否存在
    if importlib.util.find_spec("intel_extension_for_pytorch") is None:
        return False
    _ipex_version = "N/A"
    try:
        # 尝试获取intel_extension_for_pytorch版本
        _ipex_version = importlib.metadata.version("intel_extension_for_pytorch")
    except importlib.metadata.PackageNotFoundError:
        return False
    # 获取PyTorch和IPEX的主要和次要版本号
    torch_major_and_minor = get_major_and_minor_from_version(_torch_version)
    ipex_major_and_minor = get_major_and_minor_from_version(_ipex_version)
    # 检查版本是否匹配
    if torch_major_and_minor != ipex_major_and_minor:
        warnings.warn(
            f"Intel Extension for PyTorch {ipex_major_and_minor} 需要与PyTorch {ipex_major_and_minor}.*一起工作，"
            f"但找到的是PyTorch {_torch_version}。请切换到匹配的版本并重新运行。"
        )
        return False
    return True
    

# 如果CUDA可用，允许使用TF32精度
if torch.cuda.is_available():   
    torch.backends.cuda.matmul.allow_tf32 = True

# 设置日志记录器
logger = logging.getLogger(__name__)

# 定义常量
IGNORE_INDEX = -100  # 忽略索引，用于标记不计算损失的位置
DEFAULT_PAD_TOKEN = "[PAD]"  # 默认填充标记

# 定义模型参数数据类
@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(
        default="EleutherAI/pythia-12b"  # 默认模型路径
    )
    trust_remote_code: Optional[bool] = field(
        default=False,
        metadata={"help": "启用在AutoModelForCausalLM#from_pretrained中解压任意代码。"}
    )
    use_auth_token: Optional[bool] = field(
        default=False,
        metadata={"help": "启用使用来自Git凭证的Huggingface认证令牌。"}
    )

# 定义数据参数数据类
@dataclass
class DataArguments:
    eval_dataset_size: int = field(
        default=1024, metadata={"help": "验证数据集的大小。"}
    )
    max_train_samples: Optional[int] = field(
        default=None,
        metadata={
            "help": "用于调试或更快训练，如果设置，将训练样本数量截断为此值。"
        },
    )
    max_eval_samples: Optional[int] = field(
        default=None,
        metadata={
            "help": "用于调试或更快训练，如果设置，将评估样本数量截断为此值。"
        },
    )
    source_max_len: int = field(
        default=1024,
        metadata={"help": "最大源序列长度。序列将被右填充（可能被截断）。"},
    )
    target_max_len: int = field(
        default=256,
        metadata={"help": "最大目标序列长度。序列将被右填充（可能被截断）。"},
    )
    dataset: str = field(
        default='alpaca',
        metadata={"help": "要微调的数据集。查看datamodule获取选项。"}
    )
    dataset_format: Optional[str] = field(
        default=None,
        metadata={"help": "使用的数据集格式。[alpaca|chip2|self-instruct|hh-rlhf]"}
    )

# 定义训练参数数据类，继承自transformers.Seq2SeqTrainingArguments
@dataclass
class TrainingArguments(transformers.Seq2SeqTrainingArguments):
    cache_dir: Optional[str] = field(
        default=None  # 缓存目录
    )
    train_on_source: Optional[bool] = field(
        default=False,
        metadata={"help": "是否在输入文本上进行训练，而不仅仅是目标文本。"}
    )
    mmlu_split: Optional[str] = field(
        default='eval',
        metadata={"help": "要运行的MMLU分割"}
    )
    mmlu_dataset: Optional[str] = field(
        default='mmlu-fs',
        metadata={"help": "要使用的MMLU数据集：选项有`mmlu-zs`（零样本）或`mmlu-fs`（少样本）。"}
    )
    do_mmlu_eval: Optional[bool] = field(
        default=False,
        metadata={"help": "是否运行MMLU评估。"}
    )
    max_mmlu_samples: Optional[int] = field(
        default=None,
        metadata={"help": "如果设置，仅在MMMLU数据集的`max_mmlu_samples`上评估。"}
    )
    mmlu_source_max_len: int = field(
        default=2048,
        metadata={"help": "MMLU的最大源序列长度。"}
    )
    full_finetune: bool = field(
        default=False,
        metadata={"help": "微调整个模型，不使用适配器。"}
    )
    adam8bit: bool = field(
        default=False,
        metadata={"help": "使用8位Adam优化器。"}
    )
    double_quant: bool = field(
        default=True,
        metadata={"help": "通过双重量化压缩量化统计信息。"}
    )
    quant_type: str = field(
        default="nf4",
        metadata={"help": "要使用的量化数据类型。应该是`fp4`或`nf4`之一。"}
    )
    bits: int = field(
        default=4,
        metadata={"help": "使用多少位。"}
    )
    lora_r: int = field(
        default=64,
        metadata={"help": "Lora R维度。"}
    )
    lora_alpha: float = field(
        default=16,
        metadata={"help": "Lora alpha值。"}
    )
    lora_dropout: float = field(
        default=0.0,
        metadata={"help":"Lora dropout率。"}
    )
    max_memory_MB: int = field(
        default=80000,
        metadata={"help": "每个GPU的可用内存（MB）。"}
    )
    report_to: str = field(
        default='none',
        metadata={"help": "使用wandb或其他工具进行报告。"}
    )
    output_dir: str = field(default='./output', metadata={"help": '日志和检查点的输出目录'})
    optim: str = field(default='paged_adamw_32bit', metadata={"help": '要使用的优化器'})
    per_device_train_batch_size: int = field(default=10, metadata={"help": '每个GPU的训练批次大小。增加以提高速度。'})
    gradient_accumulation_steps: int = field(default=16, metadata={"help": '在执行优化器步骤之前累积多少个梯度'})
    max_steps: int = field(default=20, metadata={"help": '要执行的优化器更新步骤数'})
    weight_decay: float = field(default=0.0, metadata={"help": 'AdamW的L2权重衰减率'}) # 如果需要正则化，使用lora dropout
    learning_rate: float = field(default=0.0002, metadata={"help": '学习率'})
    remove_unused_columns: bool = field(default=False, metadata={"help": '移除未使用的列。使此代码库工作所需。'})
    max_grad_norm: float = field(default=0.3, metadata={"help": '梯度裁剪最大范数。这是经过调整的，适用于所有测试的模型。'})
    gradient_checkpointing: bool = field(default=True, metadata={"help": '使用梯度检查点。你会想要使用这个。'})
    do_train: bool = field(default=True, metadata={"help": '是否训练，这是个问题？'})
    lr_scheduler_type: str = field(default='constant', metadata={"help": '学习率调度。常数比余弦稍好，并且对分析有优势'})
    warmup_ratio: float = field(default=0.03, metadata={"help": '用于预热的步骤比例'})
    logging_steps: int = field(default=10, metadata={"help": '记录损失的更新步骤频率'})
    group_by_length: bool = field(default=True, metadata={"help": '将相同长度的序列分组到批次中。节省内存并显著加快训练。'})
    save_strategy: str = field(default='steps', metadata={"help": '何时保存检查点'})
    save_steps: int = field(default=250, metadata={"help": '多久保存一次模型'})
    save_total_limit: int = field(default=40, metadata={"help": '在最旧的被覆盖之前保存多少个检查点'})

# 定义生成参数数据类
@dataclass
class GenerationArguments:
    # 更多超参数请查看：
    # https://huggingface.co/docs/transformers/main_classes/text_generation#transformers.GenerationConfig
    # 长度参数
    max_new_tokens: Optional[int] = field(
        default=256,
        metadata={"help": "如果设置了predict_with_generate，在评估或预测循环中生成的最大新标记数。"}
    )
    min_new_tokens : Optional[int] = field(
        default=None,
        metadata={"help": "生成的最小新标记数。"}
    )

    # 生成策略
    do_sample: Optional[bool] = field(default=False)  # 是否使用采样
    num_beams: Optional[int] = field(default=1)  # 束搜索的束数
    num_beam_groups: Optional[int] = field(default=1)  # 束组数
    penalty_alpha: Optional[float] = field(default=None)  # 惩罚系数
    use_cache: Optional[bool] = field(default=True)  # 是否使用缓存

    # 用于logit操作的超参数
    temperature: Optional[float] = field(default=1.0)  # 温度参数
    top_k: Optional[int] = field(default=50)  # Top-k采样
    top_p: Optional[float] = field(default=1.0)  # Top-p采样
    typical_p: Optional[float] = field(default=1.0)  # Typical-p采样
    diversity_penalty: Optional[float] = field(default=0.0)  # 多样性惩罚
    repetition_penalty: Optional[float] = field(default=1.0)  # 重复惩罚
    length_penalty: Optional[float] = field(default=1.0)  # 长度惩罚
    no_repeat_ngram_size: Optional[int] = field(default=0)  # 不重复的n-gram大小

# 查找所有线性层名称的函数
def find_all_linear_names(args, model):
    # 根据量化位数选择适当的线性层类
    cls = bnb.nn.Linear4bit if args.bits == 4 else (bnb.nn.Linear8bitLt if args.bits == 8 else torch.nn.Linear)
    lora_module_names = set()
    # 遍历模型的所有命名模块
    for name, module in model.named_modules():
        if isinstance(module, cls):
            names = name.split('.')
            lora_module_names.add(names[0] if len(names) == 1 else names[-1])

    # 如果存在'lm_head'，从LoRA模块名称中移除（16位需要）
    if 'lm_head' in lora_module_names:
        lora_module_names.remove('lm_head')
    return list(lora_module_names)


# 保存PEFT模型的回调类
class SavePeftModelCallback(transformers.TrainerCallback):
    # 保存模型方法
    def save_model(self, args, state, kwargs):
        print('保存PEFT检查点...')
        if state.best_model_checkpoint is not None:
            checkpoint_folder = os.path.join(state.best_model_checkpoint, "adapter_model")
        else:
            checkpoint_folder = os.path.join(args.output_dir, f"{PREFIX_CHECKPOINT_DIR}-{state.global_step}")

        peft_model_path = os.path.join(checkpoint_folder, "adapter_model")
        kwargs["model"].save_pretrained(peft_model_path)

        # 删除pytorch_model.bin文件（如果存在）
        pytorch_model_path = os.path.join(checkpoint_folder, "pytorch_model.bin")
        if os.path.exists(pytorch_model_path):
            os.remove(pytorch_model_path)

    # 保存时的回调方法
    def on_save(self, args, state, control, **kwargs):
        self.save_model(args, state, kwargs)
        return control

    # 训练结束时的回调方法
    def on_train_end(self, args, state, control, **kwargs):
        # 创建空文件的辅助函数
        def touch(fname, times=None):
            with open(fname, 'a'):
                os.utime(fname, times)

        # 创建completed文件标记训练完成
        touch(join(args.output_dir, 'completed'))
        self.save_model(args, state, kwargs)

# 获取加速模型的函数
def get_accelerate_model(args, checkpoint_dir):
    # 检测可用的GPU数量
    if torch.cuda.is_available():
        n_gpus = torch.cuda.device_count()
    if is_ipex_available() and torch.xpu.is_available():
        n_gpus = torch.xpu.device_count()
        
    # 设置每个GPU的最大内存
    max_memory = f'{args.max_memory_MB}MB'
    max_memory = {i: max_memory for i in range(n_gpus)}
    device_map = "auto"

    # 如果在分布式设置中，需要设置设备映射和每个设备的最大内存
    if os.environ.get('LOCAL_RANK') is not None:
        local_rank = int(os.environ.get('LOCAL_RANK', '0'))
        device_map = {'': local_rank}
        max_memory = {'': max_memory[local_rank]}

    # 如果进行完全微调，确保位数为16或32
    if args.full_finetune: assert args.bits in [16, 32]

    print(f'加载基础模型 {args.model_name_or_path}...')
    # 确定计算数据类型
    compute_dtype = (torch.float16 if args.fp16 else (torch.bfloat16 if args.bf16 else torch.float32))
    # 从预训练加载因果语言模型
    model = AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path,
        cache_dir=args.cache_dir,
        load_in_4bit=args.bits == 4,
        load_in_8bit=args.bits == 8,
        device_map=device_map,
        max_memory=max_memory,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=args.bits == 4,
            load_in_8bit=args.bits == 8,
            llm_int8_threshold=6.0,
            llm_int8_has_fp16_weight=False,
            bnb_4bit_compute_dtype=compute_dtype,
            bnb_4bit_use_double_quant=args.double_quant,
            bnb_4bit_quant_type=args.quant_type,
        ),
        torch_dtype=(torch.float32 if args.fp16 else (torch.bfloat16 if args.bf16 else torch.float32)),
        trust_remote_code=args.trust_remote_code,
        use_auth_token=args.use_auth_token
    )
    # 如果使用float16且位数为4，检查是否支持bfloat16
    if compute_dtype == torch.float16 and args.bits == 4:
        if torch.cuda.is_bf16_supported():
            print('='*80)
            print('您的GPU支持bfloat16，您可以使用--bf16参数加速训练')
            print('='*80)
            
    # 如果使用float16且在Intel XPU上，切换到bfloat16
    if compute_dtype == torch.float16 and (is_ipex_available() and torch.xpu.is_available()):
        compute_dtype = torch.bfloat16
        print('Intel XPU尚不支持float16，因此切换到bfloat16')

    # 设置模型并行和可并行化属性
    setattr(model, 'model_parallel', True)
    setattr(model, 'is_parallelizable', True)

    # 设置模型配置的torch_dtype
    model.config.torch_dtype=(torch.float32 if args.fp16 else (torch.bfloat16 if args.bf16 else torch.float32))

    # 加载Tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name_or_path,
        cache_dir=args.cache_dir,
        padding_side="right",
        use_fast=False, # 快速tokenizer存在问题
        tokenizer_type='llama' if 'llama' in args.model_name_or_path else None, # 需要HF名称更改
        trust_remote_code=args.trust_remote_code,
        use_auth_token=args.use_auth_token,
    )
    # 如果tokenizer没有pad_token，添加默认pad_token
    if tokenizer._pad_token is None:
        smart_tokenizer_and_embedding_resize(
            special_tokens_dict=dict(pad_token=DEFAULT_PAD_TOKEN),
            tokenizer=tokenizer,
            model=model,
        )
    # 如果是LLaMA模型或LlamaTokenizer，添加特殊标记
    if 'llama' in args.model_name_or_path or isinstance(tokenizer, LlamaTokenizer):
        # LLaMA tokenizer可能没有设置正确的特殊标记
        # 检查并添加缺失的标记，以防止它们被解析为不同的标记
        # 注意这些标记在词汇表中存在
        # 还要注意`model.config.pad_token_id`是0，对应于`<unk>`标记
        print('添加特殊标记。')
        tokenizer.add_special_tokens({
                "eos_token": tokenizer.convert_ids_to_tokens(model.config.eos_token_id),
                "bos_token": tokenizer.convert_ids_to_tokens(model.config.bos_token_id),
                "unk_token": tokenizer.convert_ids_to_tokens(
                    model.config.pad_token_id if model.config.pad_token_id != -1 else tokenizer.pad_token_id
                ),
        })
    
    # 如果不是完全微调，准备模型进行kbit训练
    if not args.full_finetune:
        model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=args.gradient_checkpointing)

    # 如果不是完全微调，加载适配器或添加LoRA模块
    if not args.full_finetune:
        if checkpoint_dir is not None:
            print("从检查点加载适配器。")
            model = PeftModel.from_pretrained(model, join(checkpoint_dir, 'adapter_model'), is_trainable=True)
        else:
            print(f'添加LoRA模块...')
            modules = find_all_linear_names(args, model)
            config = LoraConfig(
                r=args.lora_r,
                lora_alpha=args.lora_alpha,
                target_modules=modules,
                lora_dropout=args.lora_dropout,
                bias="none",
                task_type="CAUSAL_LM",
            )
            model = get_peft_model(model, config)

    # 设置模块的数据类型
    for name, module in model.named_modules():
        if isinstance(module, LoraLayer):
            if args.bf16:
                module = module.to(torch.bfloat16)
        if 'norm' in name:
            module = module.to(torch.float32)
        if 'lm_head' in name or 'embed_tokens' in name:
            if hasattr(module, 'weight'):
                if args.bf16 and module.weight.dtype == torch.float32:
                    module = module.to(torch.bfloat16)
    return model, tokenizer

# 打印可训练参数的函数
def print_trainable_parameters(args, model):
    """
    打印模型中可训练参数的数量。
    """
    trainable_params = 0
    all_param = 0
    for _, param in model.named_parameters():
        all_param += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()
    if args.bits == 4: trainable_params /= 2
    print(
        f"可训练参数: {trainable_params} || "
        f"所有参数: {all_param} || "
        f"可训练比例: {100 * trainable_params / all_param}"
    )

# 智能调整tokenizer和嵌入大小的函数
def smart_tokenizer_and_embedding_resize(
    special_tokens_dict: Dict,
    tokenizer: transformers.PreTrainedTokenizer,
    model: transformers.PreTrainedModel,
):
    """调整tokenizer和嵌入大小。

    注意：这是未优化的版本，可能会使您的嵌入大小不能被64整除。
    """
    # 添加特殊标记并获取新标记数量
    num_new_tokens = tokenizer.add_special_tokens(special_tokens_dict)
    # 调整模型的token嵌入大小
    model.resize_token_embeddings(len(tokenizer))
    
    # 如果有新标记，初始化它们的嵌入
    if num_new_tokens > 0:
        input_embeddings_data = model.get_input_embeddings().weight.data
        output_embeddings_data = model.get_output_embeddings().weight.data

        # 计算现有嵌入的平均值
        input_embeddings_avg = input_embeddings_data[:-num_new_tokens].mean(dim=0, keepdim=True)
        output_embeddings_avg = output_embeddings_data[:-num_new_tokens].mean(dim=0, keepdim=True)

        # 用平均值初始化新标记的嵌入
        input_embeddings_data[-num_new_tokens:] = input_embeddings_avg
        output_embeddings_data[-num_new_tokens:] = output_embeddings_avg

# 因果语言模型的数据整理器
@dataclass
class DataCollatorForCausalLM(object):
    tokenizer: transformers.PreTrainedTokenizer  # tokenizer
    source_max_len: int  # 源序列最大长度
    target_max_len: int  # 目标序列最大长度
    train_on_source: bool  # 是否在源上训练
    predict_with_generate: bool  # 是否使用生成进行预测

    def __call__(self, instances: Sequence[Dict]) -> Dict[str, torch.Tensor]:
        # 提取元素
        sources = [f"{self.tokenizer.bos_token}{example['input']}" for example in instances]
        targets = [f"{example['output']}{self.tokenizer.eos_token}" for example in instances]
        # 对源和目标进行tokenize
        tokenized_sources_with_prompt = self.tokenizer(
            sources,
            max_length=self.source_max_len,
            truncation=True,
            add_special_tokens=False,
        )
        tokenized_targets = self.tokenizer(
            targets,
            max_length=self.target_max_len,
            truncation=True,
            add_special_tokens=False,
        )
        # 为因果语言模型构建输入和标签
        input_ids = []
        labels = []
        for tokenized_source, tokenized_target in zip(
            tokenized_sources_with_prompt['input_ids'],
            tokenized_targets['input_ids']
        ):
            if not self.predict_with_generate:
                # 将源和目标连接起来作为输入
                input_ids.append(torch.tensor(tokenized_source + tokenized_target))
                if not self.train_on_source:
                    # 如果不在源上训练，源部分的标签设为IGNORE_INDEX
                    labels.append(
                        torch.tensor([IGNORE_INDEX for _ in range(len(tokenized_source))] + copy.deepcopy(tokenized_target))
                    )
                # 如果在源上训练，则源和目标部分的标签都设为实际token ID
                else:
                    # 深拷贝tokenized_source和tokenized_target并连接它们作为标签
                    # 例如：如果源是"你好"，目标是"世界"，则标签为"你好世界"
                    labels.append(torch.tensor(copy.deepcopy(tokenized_source + tokenized_target)))
            # 如果是使用生成进行预测的情况
            else:
                # 只将源部分作为输入，不包括目标部分
                # 例如：在推理阶段，我们只提供问题，让模型生成答案
                input_ids.append(torch.tensor(tokenized_source))
        # 对序列进行填充处理
        # 将不同长度的序列填充到相同长度，以便批处理
        # 例如：将["你好", "你好世界"]填充为["你好##", "你好世界"]，其中#表示填充标记
        input_ids = pad_sequence(input_ids, batch_first=True, padding_value=self.tokenizer.pad_token_id)
        # 如果不是使用生成进行预测，则对标签也进行填充；否则标签为None
        # 填充值为IGNORE_INDEX，确保填充部分不参与损失计算
        labels = pad_sequence(labels, batch_first=True, padding_value=IGNORE_INDEX) if not self.predict_with_generate else None
        # 创建返回的数据字典
        data_dict = {
            'input_ids': input_ids,  # 输入ID序列
            'attention_mask': input_ids.ne(self.tokenizer.pad_token_id),  # 注意力掩码，用于区分实际内容和填充部分
        }
        # 如果有标签，则将其添加到数据字典中
        if labels is not None:
            data_dict['labels'] = labels
        # 返回处理好的数据字典，供模型训练或推理使用
        return data_dict

# 从非自然指令数据集中提取数据的函数
def extract_unnatural_instructions_data(examples, extract_reformulations=False):
    # 初始化输出字典，包含输入和输出两个列表
    out = {
        'input': [],  # 存储指令和输入
        'output': [],  # 存储期望输出
    }
    # 遍历所有示例的实例
    for example_instances in examples['instances']:
        for instance in example_instances:
            # 将每个实例的指令和输入添加到输入列表
            out['input'].append(instance['instruction_with_input'])
            # 将每个实例的输出添加到输出列表
            out['output'].append(instance['output'])
    # 如果需要提取重新表述的内容
    if extract_reformulations:
        # 遍历所有示例的重新表述
        for example_reformulations in examples['reformulations']:
            # 如果重新表述不为空
            if example_reformulations is not None:
                # 遍历每个重新表述的实例
                for instance in example_reformulations:
                    # 将重新表述的指令和输入添加到输入列表
                    out['input'].append(instance['instruction_with_input'])
                    # 将重新表述的输出添加到输出列表
                    out['output'].append(instance['output'])
    # 返回提取的数据
    return out

# Alpaca数据集的提示模板字典
ALPACA_PROMPT_DICT = {
    # 带输入的提示模板
    "prompt_input": (
        "以下是描述一个任务的指令，以及提供进一步上下文的输入。"
        "请写一个适当完成请求的回复。\n\n"
        "### 指令:\n{instruction}\n\n### 输入:\n{input}\n\n### 回复: "
    ),
    # 不带输入的提示模板
    "prompt_no_input": (
        "以下是描述一个任务的指令。"
        "请写一个适当完成请求的回复。\n\n"
        "### 指令:\n{instruction}\n\n### 回复: "
    ),
}

# 提取Alpaca数据集的函数
def extract_alpaca_dataset(example):
    # 根据是否有输入选择不同的提示模板
    if example.get("input", "") != "":
        # 如果有输入，使用带输入的提示模板
        prompt_format = ALPACA_PROMPT_DICT["prompt_input"]
    else:
        # 如果没有输入，使用不带输入的提示模板
        prompt_format = ALPACA_PROMPT_DICT["prompt_no_input"]
    # 使用选定的模板格式化示例，并返回格式化后的输入
    # 例如：将{instruction: "翻译", input: "Hello"}格式化为"以下是描述一个任务的指令...### 指令:翻译\n\n### 输入:Hello\n\n### 回复: "
    return {'input': prompt_format.format(**example)}

# 加载本地数据集的函数
def local_dataset(dataset_name):
    # 根据文件扩展名选择不同的加载方式
    if dataset_name.endswith('.json') or dataset_name.endswith('.jsonl'):
        # 如果是JSON或JSONL文件，使用from_json方法加载
        full_dataset = Dataset.from_json(path_or_paths=dataset_name)
    elif dataset_name.endswith('.csv'):
        # 如果是CSV文件，先用pandas读取，再转换为Dataset
        full_dataset = Dataset.from_pandas(pd.read_csv(dataset_name))
    elif dataset_name.endswith('.tsv'):
        # 如果是TSV文件，用pandas读取并指定分隔符为制表符，再转换为Dataset
        full_dataset = Dataset.from_pandas(pd.read_csv(dataset_name, delimiter='\t'))
    else:
        # 如果是不支持的文件格式，抛出错误
        raise ValueError(f"不支持的数据集格式: {dataset_name}")

    # 将数据集分割为训练集和测试集，测试集占10%
    split_dataset = full_dataset.train_test_split(test_size=0.1)
    # 返回分割后的数据集
    return split_dataset

# 创建数据模块的函数，用于监督式微调
def make_data_module(tokenizer: transformers.PreTrainedTokenizer, args) -> Dict:
    """
    为监督式微调创建数据集和数据整理器。
    数据集应该包含以下列: { `input`, `output` }

    可通过`dataset`参数选择的可用数据集:
        - alpaca, 52002个示例
        - alpaca cleaned, 51942个示例
        - chip2 (OIG), 210289个示例
        - self-instruct, 82612个示例
        - hh-rlhf (Anthropic), 160800个示例
        - longform, 23.7k个示例
        - oasst1 (OpenAssistant) 仅主消息树, 9,846个示例

    即将推出:
        - unnatural instructions core, 66010个示例
        - unnatural instructions full, 240670个示例
        - alpaca-gpt4, 52002个示例
        - unnatural-instructions-gpt4, 9000个示例
        - supernatural-instructions, 69624个示例 (与论文相同，每个任务100个示例，可以使用更多)
        - flan (FLAN v2), 最多可用20M个示例
        - vicuna

    """
    # 加载数据集的内部函数
    def load_data(dataset_name):
        # 根据数据集名称选择不同的加载方式
        if dataset_name == 'alpaca':
            return load_dataset("tatsu-lab/alpaca")
        elif dataset_name == 'alpaca-clean':
            return load_dataset("yahma/alpaca-cleaned")
        elif dataset_name == 'chip2':
            return load_dataset("laion/OIG", data_files='unified_chip2.jsonl')
        elif dataset_name == 'self-instruct':
            return load_dataset("yizhongw/self_instruct", name='self_instruct')
        elif dataset_name == 'hh-rlhf':
            return load_dataset("Anthropic/hh-rlhf")
        elif dataset_name == 'longform':
            return load_dataset("akoksal/LongForm")
        elif dataset_name == 'oasst1':
            return load_dataset("timdettmers/openassistant-guanaco")
        elif dataset_name == 'vicuna':
            raise NotImplementedError("Vicuna数据尚未发布。")
        else:
            # 如果不是预定义的数据集，尝试从本地路径加载
            if os.path.exists(dataset_name):
                try:
                    # 设置数据集格式，如果未指定则默认为"input-output"
                    args.dataset_format = args.dataset_format if args.dataset_format else "input-output"
                    # 加载本地数据集
                    full_dataset = local_dataset(dataset_name)
                    return full_dataset
                except:
                    # 如果加载失败，抛出错误
                    raise ValueError(f"从{dataset_name}加载数据集时出错")
            else:
                # 如果数据集不存在，抛出错误
                raise NotImplementedError(f"数据集{dataset_name}尚未实现。")

    # 格式化数据集的内部函数
    def format_dataset(dataset, dataset_format):
        # 根据数据集格式选择不同的处理方式
        if (
            dataset_format == 'alpaca' or dataset_format == 'alpaca-clean' or
            (dataset_format is None and args.dataset in ['alpaca', 'alpaca-clean'])
        ):
            # 对Alpaca格式的数据集应用提取函数，并移除instruction列
            dataset = dataset.map(extract_alpaca_dataset, remove_columns=['instruction'])
        elif dataset_format == 'chip2' or (dataset_format is None and args.dataset == 'chip2'):
            # 对chip2格式的数据集进行处理，分离人类和机器人的对话
            dataset = dataset.map(lambda x: {
                'input': x['text'].split('\n<bot>: ')[0].replace('<human>: ', ''),
                'output': x['text'].split('\n<bot>: ')[1],
            })
        elif dataset_format == 'self-instruct' or (dataset_format is None and args.dataset == 'self-instruct'):
            # 对self-instruct格式的数据集重命名列
            for old, new in [["prompt", "input"], ["completion", "output"]]:
                dataset = dataset.rename_column(old, new)
        elif dataset_format == 'hh-rlhf' or (dataset_format is None and args.dataset == 'hh-rlhf'):
            # 对hh-rlhf格式的数据集进行处理，只使用chosen列作为输出
            dataset = dataset.map(lambda x: {
                'input': '',
                'output': x['chosen']
            })
        elif dataset_format == 'oasst1' or (dataset_format is None and args.dataset == 'oasst1'):
            # 对oasst1格式的数据集进行处理，只使用text列作为输出
            dataset = dataset.map(lambda x: {
                'input': '',
                'output': x['text'],
            })
        elif dataset_format == 'input-output':
            # 如果已经是input-output格式，保持不变
            pass
        # 移除未使用的列，只保留input和output列
        dataset = dataset.remove_columns(
            [col for col in dataset.column_names['train'] if col not in ['input', 'output']]
        )
        return dataset

     # 加载数据集
    dataset = load_data(args.dataset)
    # 格式化数据集
    dataset = format_dataset(dataset, args.dataset_format)

    # 分割训练/评估集，减小大小
    if args.do_eval or args.do_predict:
        # 如果数据集中已有eval分割，直接使用
        if 'eval' in dataset:
            eval_dataset = dataset['eval']
        else:
            # 否则，从训练集中分割出一部分作为评估集
            print('根据`eval_dataset_size`将训练数据集分割为训练集和验证集')
            dataset = dataset["train"].train_test_split(
                test_size=args.eval_dataset_size, shuffle=True, seed=42
            )
            eval_dataset = dataset['test']
        # 如果指定了最大评估样本数，并且评估集大小超过该值，则只选择部分样本
        if args.max_eval_samples is not None and len(eval_dataset) > args.max_eval_samples:
            eval_dataset = eval_dataset.select(range(args.max_eval_samples))
        # 如果按长度分组，则计算每个样本的长度
        if args.group_by_length:
            eval_dataset = eval_dataset.map(lambda x: {'length': len(x['input']) + len(x['output'])})
    # 如果需要训练
    if args.do_train:
        # 获取训练集
        train_dataset = dataset['train']
        # 如果指定了最大训练样本数，并且训练集大小超过该值，则只选择部分样本
        if args.max_train_samples is not None and len(train_dataset) > args.max_train_samples:
            train_dataset = train_dataset.select(range(args.max_train_samples))
        # 如果按长度分组，则计算每个样本的长度
        if args.group_by_length:
            train_dataset = train_dataset.map(lambda x: {'length': len(x['input']) + len(x['output'])})

    # 创建数据整理器，用于处理批次数据
    data_collator = DataCollatorForCausalLM(
        tokenizer=tokenizer,  # 分词器
        source_max_len=args.source_max_len,  # 源序列最大长度
        target_max_len=args.target_max_len,  # 目标序列最大长度
        train_on_source=args.train_on_source,  # 是否在源上训练
        predict_with_generate=args.predict_with_generate,  # 是否使用生成进行预测
    )
    # 返回包含训练集、评估集、预测集和数据整理器的字典
    return dict(
        train_dataset=train_dataset if args.do_train else None,
        eval_dataset=eval_dataset if args.do_eval else None,
        predict_dataset=eval_dataset if args.do_predict else None,
        data_collator=data_collator
    )

# 获取最后一个检查点的函数
def get_last_checkpoint(checkpoint_dir):
    # 如果检查点目录存在
    if isdir(checkpoint_dir):
        # 检查是否存在completed文件，表示训练已完成
        is_completed = exists(join(checkpoint_dir, 'completed'))
        if is_completed: return None, True  # 如果已完成，返回None和True
        # 查找最大步数的检查点
        max_step = 0
        for filename in os.listdir(checkpoint_dir):
            # 如果是以checkpoint开头的目录
            if isdir(join(checkpoint_dir, filename)) and filename.startswith('checkpoint'):
                # 提取步数并更新最大步数
                max_step = max(max_step, int(filename.replace('checkpoint-', '')))
        # 如果没有找到检查点，返回None和is_completed
        if max_step == 0: return None, is_completed  # 训练已开始，但没有检查点
        # 构建检查点路径
        checkpoint_dir = join(checkpoint_dir, f'checkpoint-{max_step}')
        print(f"找到之前的检查点: {checkpoint_dir}")
        return checkpoint_dir, is_completed  # 找到检查点！
    return None, False  # 首次训练

# 训练函数
def train():
    # 解析命令行参数
    hfparser = transformers.HfArgumentParser((
        ModelArguments, DataArguments, TrainingArguments, GenerationArguments
    ))
    # 将参数解析为数据类和剩余字符串
    model_args, data_args, training_args, generation_args, extra_args = \
        hfparser.parse_args_into_dataclasses(return_remaining_strings=True)
    # 设置生成配置
    training_args.generation_config = transformers.GenerationConfig(**vars(generation_args))
    # 将所有参数合并到一个命名空间
    args = argparse.Namespace(
        **vars(model_args), **vars(data_args), **vars(training_args)
    )
    print(args)
    
    # 获取最后一个检查点
    checkpoint_dir, completed_training = get_last_checkpoint(args.output_dir)
    if completed_training:
        print('检测到训练已经完成！')

    # 加载模型和分词器
    model, tokenizer = get_accelerate_model(args, checkpoint_dir)

    # 禁用模型缓存以节省内存
    model.config.use_cache = False
    print('已加载模型')
    # 设置随机种子以确保可重现性
    set_seed(args.seed)

    # 创建数据模块
    data_module = make_data_module(tokenizer=tokenizer, args=args)
    
    # 创建Seq2SeqTrainer实例
    trainer = Seq2SeqTrainer(
        model=model,  # 模型
        tokenizer=tokenizer,  # 分词器
        args=training_args,  # 训练参数
        **{k:v for k,v in data_module.items() if k != 'predict_dataset'},  # 数据模块中除predict_dataset外的所有项
    )

    # 添加回调
    # 如果不是全量微调，添加SavePeftModelCallback回调以保存PEFT模型
    if not args.full_finetune:
        trainer.add_callback(SavePeftModelCallback)
    # 如果需要进行MMLU评估
    if args.do_mmlu_eval:
        # 根据MMLU数据集类型加载不同的数据
        if args.mmlu_dataset == 'mmlu-zs':
            # 加载零样本MMLU数据集
            mmlu_dataset = load_dataset("json", data_files={
                'eval': 'data/mmlu/zero_shot_mmlu_val.json',
                'test': 'data/mmlu/zero_shot_mmlu_test.json',
            })
            mmlu_dataset = mmlu_dataset.remove_columns('subject')
        # 加载五样本MMLU数据集（仅用于评估/测试）
        elif args.mmlu_dataset == 'mmlu' or args.mmlu_dataset == 'mmlu-fs':
            mmlu_dataset = load_dataset("json", data_files={
                'eval': 'data/mmlu/five_shot_mmlu_val.json',
                'test': 'data/mmlu/five_shot_mmlu_test.json',
            })
            # mmlu_dataset = mmlu_dataset.remove_columns('subject')
        # 选择指定的分割
        mmlu_dataset = mmlu_dataset[args.mmlu_split]
        # 如果指定了最大MMLU样本数，则只选择部分样本
        if args.max_mmlu_samples is not None:
            mmlu_dataset = mmlu_dataset.select(range(args.max_mmlu_samples))
        # 获取A、B、C、D选项的token ID
        abcd_idx = [
            tokenizer("A", add_special_tokens=False).input_ids[0],
            tokenizer("B", add_special_tokens=False).input_ids[0],
            tokenizer("C", add_special_tokens=False).input_ids[0],
            tokenizer("D", add_special_tokens=False).input_ids[0],
        ]
        # 加载准确率评估指标
        accuracy = evaluate.load("accuracy")
        # 定义MMLU评估回调类
        class MMLUEvalCallback(transformers.TrainerCallback):
            # 在评估时调用的方法
            def on_evaluate(self, args, state, control, model, **kwargs):
                # 获取评估数据加载器
                data_loader = trainer.get_eval_dataloader(mmlu_dataset)
                # 保存原始source_max_len
                source_max_len = trainer.data_collator.source_max_len
                # 设置MMLU专用的source_max_len
                trainer.data_collator.source_max_len = args.mmlu_source_max_len
                # 将模型设置为评估模式
                trainer.model.eval()
                # 初始化预测和参考列表
                preds, refs = [], []
                # 初始化MMLU损失
                loss_mmlu = 0
                # 遍历数据加载器中的所有批次
                for batch in tqdm(data_loader, total=len(data_loader)):
                    # 进行预测步骤，获取损失、logits和标签
                    (loss, logits, labels) = trainer.prediction_step(trainer.model,batch,prediction_loss_only=False,)
                    # 处理每个样本的logits
                    for i, logit in enumerate(logits):
                        # 找到非零标签的位置
                        label_non_zero_id = (batch['labels'][i] != -100).nonzero()[0][0]
                        # 获取A、B、C、D选项的logits
                        logit_abcd = logit[label_non_zero_id-1][abcd_idx]
                        # 将最大logit对应的选项索引添加到预测列表
                        preds.append(torch.argmax(logit_abcd).item())
                    # 处理标签，忽略IGNORE_INDEX
                    labels = labels[labels != IGNORE_INDEX].view(-1, 2)[:,0]
                    # 将标签转换为选项索引并添加到参考列表
                    refs += [abcd_idx.index(label) for label in labels.tolist()]
                    # 累加损失
                    loss_mmlu += loss.item()
                # 提取按主题分类的结果
                results = {'mmlu_loss':loss_mmlu/len(data_loader)}
                # 获取主题列表
                subject = mmlu_dataset['subject']
                # 为每个主题创建字典，存储参考和预测
                subjects = {s:{'refs':[], 'preds':[]} for s in set(subject)}
                # 将预测和参考按主题分组
                for s,p,r in zip(subject, preds, refs):
                    subjects[s]['preds'].append(p)
                    subjects[s]['refs'].append(r)
                # 计算每个主题的得分
                subject_scores = []
                for subject in subjects:
                    # 计算主题准确率
                    subject_score = accuracy.compute(
                        references=subjects[subject]['refs'],
                        predictions=subjects[subject]['preds']
                    )['accuracy']
                    # 将主题准确率添加到结果字典
                    results[f'mmlu_{args.mmlu_split}_accuracy_{subject}'] = subject_score
                    # 将主题得分添加到列表
                    subject_scores.append(subject_score)
                # 计算所有主题的平均准确率
                results[f'mmlu_{args.mmlu_split}_accuracy'] = np.mean(subject_scores)
                # 记录结果
                trainer.log(results)
                # 恢复原始source_max_len
                trainer.data_collator.source_max_len = source_max_len

        # 添加MMLU评估回调
        trainer.add_callback(MMLUEvalCallback)

    # 在训练前验证数据类型和参数数量
    print_trainable_parameters(args, model)
    # 统计不同数据类型的参数数量
    dtypes = {}
    for _, p in model.named_parameters():
        dtype = p.dtype
        if dtype not in dtypes: dtypes[dtype] = 0
        dtypes[dtype] += p.numel()
    # 计算总参数数量
    total = 0
    for k, v in dtypes.items(): total+= v
    # 打印每种数据类型的参数比例
    for k, v in dtypes.items():
        print(k, v, v/total)

    # 初始化指标字典
    all_metrics = {"run_name": args.run_name}
    # 训练
    if args.do_train:
        logger.info("*** 训练 ***")
        # 注意：HF不支持适配器检查点的`resume_from_checkpoint`。
        # 目前适配器检查点按预期重新加载，但优化器/调度器状态不会重新加载。
        train_result = trainer.train()
        # 获取训练指标
        metrics = train_result.metrics
        # 记录训练指标
        trainer.log_metrics("train", metrics)
        # 保存训练指标
        trainer.save_metrics("train", metrics)
        # 保存训练状态
        trainer.save_state()
        # 更新总指标字典
        all_metrics.update(metrics)
    # 评估
    if args.do_eval:
        logger.info("*** 评估 ***")
        # 进行评估
        metrics = trainer.evaluate(metric_key_prefix="eval")
        # 记录评估指标
        trainer.log_metrics("eval", metrics)
        # 保存评估指标
        trainer.save_metrics("eval", metrics)
        # 更新总指标字典
        all_metrics.update(metrics)
    # 预测
    if args.do_predict:
        logger.info("*** 预测 ***")
        # 进行预测
        prediction_output = trainer.predict(test_dataset=data_module['predict_dataset'],metric_key_prefix="predict")
        # 获取预测指标
        prediction_metrics = prediction_output.metrics
        # 获取预测结果
        predictions = prediction_output.predictions
        # 将-100替换为pad_token_id
        predictions = np.where(predictions != -100, predictions, tokenizer.pad_token_id)
        # 将token ID解码为文本
        predictions = tokenizer.batch_decode(
            predictions, skip_special_tokens=True, clean_up_tokenization_spaces=True
        )
        # 将预测结果保存到文件
        with open(os.path.join(args.output_dir, 'predictions.jsonl'), 'w') as fout:
            for i, example in enumerate(data_module['predict_dataset']):
                # 保存包含输入的完整预测
                example['prediction_with_input'] = predictions[i].strip()
                # 保存去除输入后的预测
                example['prediction'] = predictions[i].replace(example['input'], '').strip()
                # 将示例写入文件
                fout.write(json.dumps(example) + '\n')
        # 打印预测指标
        print(prediction_metrics)
        # 记录预测指标
        trainer.log_metrics("predict", prediction_metrics)
        # 保存预测指标
        trainer.save_metrics("predict", prediction_metrics)
        # 更新总指标字典
        all_metrics.update(prediction_metrics)

    # 如果进行了训练、评估或预测，保存所有指标
    if (args.do_train or args.do_eval or args.do_predict):
        # 将所有指标保存到JSON文件
        with open(os.path.join(args.output_dir, "metrics.json"), "w") as fout:
            fout.write(json.dumps(all_metrics))

# 程序入口点
if __name__ == "__main__":
    # 调用训练函数
    train()
