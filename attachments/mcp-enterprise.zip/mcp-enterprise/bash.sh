conda create --name mcp  python=3.12.4
conda activate mcp

#基于docker desktop
docker run --name postgres -e POSTGRES_PASSWORD=123789 -e POSTGRES_USER=sa -p 15432:5432 -d postgres