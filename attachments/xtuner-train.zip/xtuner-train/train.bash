
#安装xtuner
pip install xtuner[all]==0.1.19
pip install xtuner[deepspeed]==0.1.19

#查询配置
xtuner list-cfg

#复制配置
xtuner copy-cfg internlm2_7b_qlora_colorist_e5 .

#配置pretrained_model_name_or_path和data_path

# 启动微调
# 单机单卡
xtuner train ./internlm2_7b_qlora_colorist_e5_copy.py --deepspeed deepspeed_zero2
# 单机多卡
NPROC_PER_NODE=${GPU_NUM} xtuner train ./internlm2_7b_qlora_colorist_e5_copy.py

# 模型转换
# 创建存放 hf 格式参数的目录
mkdir work_dirs/internlm2_7b_qlora_colorist_e5_copy/iter_50_hf

# 转换格式
xtuner convert pth_to_hf internlm2_7b_qlora_colorist_e5_copy.py \
                            work_dirs/internlm2_7b_qlora_colorist_e5_copy/iter_50.pth \
                            work_dirs/internlm2_7b_qlora_colorist_e5_copy/iter_50_hf

# lora合并
# 创建存放合并后的参数的目录
mkdir work_dirs/internlm2_7b_qlora_colorist_e5_copy/merged

# 合并参数
xtuner convert merge .cache/modelscope/hub/Shanghai_AI_Laboratory/internlm2-chat-7b \
                        work_dirs/internlm2_7b_qlora_colorist_e5_copy/iter_50_hf \
                        work_dirs/internlm2_7b_qlora_colorist_e5_copy/merged \
                        --max-shard-size 2GB

#与模型对话
xtuner chat work_dirs/internlm2_7b_qlora_colorist_e5_copy/merged \
                --prompt-template internlm2_chat \
                --system-template colorist

xtuner chat .cache/modelscope/hub/Shanghai_AI_Laboratory/internlm2-chat-7b
                --adapter work_dirs/internlm2_7b_qlora_colorist_e5_copy/iter_50_hf \
                --prompt-template internlm2_chat \
                --system-template colorist

