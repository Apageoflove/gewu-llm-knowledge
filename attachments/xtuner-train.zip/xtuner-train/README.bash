基础环境：ubuntu22.04-cuda12.1.0-py310-torch2.3.0-1.18.0

#监控显卡
nvidia-smi
nvidia-smi -l
watch -n 1 nvidia-smi
nvidia-smi topo -m

pip install nvitop
pip install  nvidia-ml-py -U
nvitop -m auto
nvitop -m compact
nvitop -m full

chmod 777 *
zip -r -o internlm2_7b_qlora_colorist_e5_copy.zip internlm2_7b_qlora_colorist_e5_copy -x "*.safetensors" "*.pt" "*.bin"


#创建python环境
conda create --name xtuner  python=3.10
conda activate xtuner

pip install xtuner[all]==0.1.19

xtuner train ./internlm2_7b_qlora_colorist_e5_copy.py

git clone https://github.com/InternLM/xtuner.git
cd xtuner
pip install -e '.[deepspeed]'

xtuner list-cfg

pip install -U huggingface_hub

#从 HuggingFace 下载
huggingface-cli download internlm/internlm2-chat-7b \
                            --local-dir Shanghai_AI_Laboratory/internlm2-chat-7b \
                            --local-dir-use-symlinks False \
                            --resume-download

#从 ModelScope 下载
pip install -U modelscope

# 拉取模型至当前目录
python -c "from modelscope import snapshot_download; snapshot_download('Shanghai_AI_Laboratory/internlm2-chat-7b', cache_dir='.')"
