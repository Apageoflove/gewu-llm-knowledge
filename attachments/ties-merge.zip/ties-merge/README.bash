# c:\\users\用户名\.cache\huggingface\ ，修改环境变量 setx HF_HOME "D:\software\huggingface"

#创建python环境
conda create --name ties  python=3.9
conda activate ties

pip install transformers peft datasets evaluate accelerate torch bitsandbytes