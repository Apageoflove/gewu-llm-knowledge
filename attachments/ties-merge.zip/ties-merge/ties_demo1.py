# 导入必要的库
# peft库用于参数高效微调（Parameter-Efficient Fine-Tuning）
# 例如：就像给汽车换轮胎而不是整辆车，peft允许我们只调整模型的一小部分参数
from peft import PeftConfig, PeftModel
# transformers库是Hugging Face的核心库，用于加载预训练模型
# 例如：就像从商店购买现成的家具，而不是自己从头制作
from transformers import AutoModelForCausalLM, AutoTokenizer

# 加载预训练模型的配置
# 就像阅读说明书，了解如何使用一个产品
config = PeftConfig.from_pretrained("smangrul/tinyllama_lora_norobots")
# 根据配置加载基础模型，启用4位量化以节省内存，并自动分配到可用设备
# 例如：购买基础车型，然后进行定制化改装
model = AutoModelForCausalLM.from_pretrained(config.base_model_name_or_path, load_in_4bit=True, device_map="auto").eval()
# 加载与模型匹配的分词器，用于将文本转换为模型可理解的格式
# 例如：翻译官，将人类语言转换为机器语言
tokenizer = AutoTokenizer.from_pretrained("smangrul/tinyllama_lora_norobots")

# 设置模型词汇表大小为32005
# 例如：扩展你的词典，使模型能理解更多单词
model.config.vocab_size = 32005
# 调整模型的词嵌入大小以匹配新的词汇表大小
model.resize_token_embeddings(32005)

# 将基础模型转换为PEFT模型，并加载第一个adapter（适配器）
# 例如：给基础车型安装第一个定制配件
model = PeftModel.from_pretrained(model, "smangrul/tinyllama_lora_norobots", adapter_name="norobots")
# 加载第二个adapter，专门用于SQL任务
# 例如：再安装一个专门用于越野的配件
_ = model.load_adapter("smangrul/tinyllama_lora_sql", adapter_name="sql")
# 加载第三个adapter，专门用于广告文案生成
# 例如：再安装一个提升舒适度的配件
_ = model.load_adapter("smangrul/tinyllama_lora_adcopy", adapter_name="adcopy")

# 定义要合并的adapters列表
# 例如：决定要组合使用哪些配件
adapters = ["norobots", "adcopy", "sql"]
# 为每个adapter分配权重，决定其在合并中的重要性
# 例如：决定每个配件的影响程度，norobots的影响是其他两个的两倍
weights = [2.0, 1.0, 1.0]
# 为合并后的adapter命名
adapter_name = "merge"
# 设置稀疏度参数，控制合并后adapter的参数数量
# 例如：决定最终配置使用多少零件，0.2表示只使用20%的参数
density = 0.2
# 使用TIES（Trained Input Element Selection）方法合并adapters
# 例如：智能地组合不同配件的优点，创建一个新的混合配置
model.add_weighted_adapter(adapters, weights, adapter_name, combination_type="ties", density=density)

# 准备用户输入消息
# 例如：准备要问模型的问题
messages = [
    {"role": "user", "content": "Write an essay about Generative AI."},
]
# 将消息格式化为模型可接受的格式
# 例如：按照特定格式整理问题，就像填写标准表格
text = tokenizer.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
# 将文本转换为模型输入的张量格式
# 例如：将文字翻译成数字，因为模型只理解数字
inputs = tokenizer(text, return_tensors="pt")
# 将输入数据移动到GPU上以加速处理
# 例如：将工作材料移到更高效的工作台上
inputs = {k: v.to("cuda") for k, v in inputs.items()}
# 生成模型回答
# 例如：让模型创作回应，设定各种参数控制创作风格
# max_new_tokens=256: 最多生成256个新词元
# do_sample=True: 启用采样，使输出更多样化
# top_p=0.95: 只考虑概率和达到95%的词
# temperature=0.2: 较低的温度使输出更确定、更保守
# repetition_penalty=1.2: 惩罚重复内容，避免循环
outputs = model.generate(**inputs, max_new_tokens=256, do_sample=True, top_p=0.95, temperature=0.2, repetition_penalty=1.2, eos_token_id=tokenizer.eos_token_id)
# 将模型输出的数字转换回人类可读的文本并打印
# 例如：将机器语言翻译回人类语言
print(tokenizer.decode(outputs[0]))

# 演示另一种adapter合并方式（没有使用TIES和density参数）
# 例如：展示另一种组合配件的方法
adapters = ["adapter1", "adapter2", "adapter3"]
# 权重总和为1，表示比例分配
# 例如：adapter1占40%，adapter2和adapter3各占30%
weights = [0.4, 0.3, 0.3]
# 为合并后的adapter命名
adapter_name = "merge"
# 使用默认方法合并adapters（线性组合）
# 例如：简单地按比例混合不同配件的特性
model.add_weighted_adapter(adapters, weights, adapter_name)
model.set_adapter("merge")

outputs = model.generate(**inputs, max_new_tokens=256, do_sample=True, top_p=0.95, temperature=0.2, repetition_penalty=1.2, eos_token_id=tokenizer.eos_token_id)
# 将模型输出的数字转换回人类可读的文本并打印
# 例如：将机器语言翻译回人类语言
print('merge：'+tokenizer.decode(outputs[0]))


# 设置Hugging Face账户名
account = 'VergilDante'
# 设置模型ID，用于上传到Hugging Face Hub
peft_model_id = f"{account}/my_lora_norobots"
# 注释掉的模型上传代码
#model.push_to_hub(peft_model_id)