git clone https://github.com/ggerganov/llama.cpp.git
pip install -r llama.cpp/requirements.txt

# 如果不量化，保留模型的效果
python llama.cpp/convert_hf_to_gguf.py /mnt/workspace/.cache/modelscope/models/LLM-Research/Meta-Llama-3-8B-Instruct  --outtype f16 --verbose --outfile Meta-Llama-3-8B-Instruct_f16.gguf
# 如果需要量化（加速并有损效果），直接执行下面脚本就可以
python llama.cpp/convert_hf_to_gguf.py /mnt/workspace/.cache/modelscope/models/LLM-Research/Meta-Llama-3-8B-Instruct  --outtype q8_0 --verbose --outfile Meta-Llama-3-8B-Instruct_q8_0.gguf

curl -fsSL https://ollama.com/install.sh | sh
nohup ollama serve &
ollama create Meta-Llama-3-8B-Instruct_q8_0 --file ./ModelFile
ollama run Meta-Llama-3-8B-Instruct_q8_0

pip install open-webui
open-webui serve
