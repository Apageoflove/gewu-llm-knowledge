基础环境：ubuntu22.04-cuda12.4.0-py311-torch2.6.0-1.26.0-LLM

#监控显卡
nvidia-smi
nvidia-smi -l
watch -n 1 nvidia-smi
nvidia-smi topo -m

pip install nvitop
pip install  nvidia-ml-py -U
nvitop -m auto
nvitop -m compact
nvitop -m full

chmod 777 *
zip -r -o saves.zip saves -x "*.safetensors" "*.pt" "*.bin" "*.pth" "*tokenizer.json"


#创建python环境
conda create --name xtuner  python=3.10
conda activate xtuner
pip install -U 'xtuner[deepspeed]'

pip install -U 'xtuner[all]'

xtuner train ./internlm2_7b_qlora_colorist_e5_copy.py

git clone https://github.com/InternLM/xtuner.git
cd xtuner
pip install -e '.[deepspeed]'

xtuner list-cfg

pip install -U huggingface_hub

#从 HuggingFace 下载
huggingface-cli download internlm/internlm2-chat-7b \
                            --local-dir Shanghai_AI_Laboratory/internlm2-chat-7b \
                            --local-dir-use-symlinks False \
                            --resume-download

#从 ModelScope 下载
pip install -U modelscope

# 拉取模型至当前目录
python -c "from modelscope import snapshot_download; snapshot_download('Shanghai_AI_Laboratory/internlm2-chat-7b', cache_dir='.')"

