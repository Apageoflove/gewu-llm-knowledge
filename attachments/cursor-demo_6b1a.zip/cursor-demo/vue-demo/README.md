# Vue 3 小示例（零构建、直接可用）

该示例无需任何打包工具，直接在浏览器打开即可使用。包含：

- 计数器（加减）
- 待办列表（添加/删除/标记完成，筛选，localStorage 持久化）
- 双向绑定与计算属性（字符串反转）

## 运行

- 方式 A：直接双击或用浏览器打开 `index.html`
- 方式 B：本地静态服务器（推荐，避免部分浏览器本地文件策略限制）

```powershell
# 在仓库根目录执行
npx --yes serve -l 5174 vue-demo

# 或使用 http-server
npx --yes http-server -p 5174 -c-1 vue-demo
```

然后访问 `http://localhost:5174`。

## 主要文件

- `index.html`：示例页面，使用 Vue 3 CDN 全局构建。

## 升级为工程化（可选）

如果需要 SFC、热更新、TypeScript、ESLint 等：

```powershell
npm create vite@latest my-vue-app -- --template vue
cd my-vue-app
npm install
npm run dev
```
