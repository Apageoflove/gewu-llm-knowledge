def bubble_sort(arr):
    """
    冒泡排序算法实现
    
    原理：
    - 比较相邻的元素，如果第一个比第二个大，就交换它们两个
    - 对每一对相邻元素作同样的工作，从开始第一对到结尾的最后一对
    - 在这个过程中，最大的元素会"冒泡"到数组的末尾
    - 重复以上步骤，直到没有任何一对数字需要比较
    
    时间复杂度：O(n²)
    空间复杂度：O(1)
    
    参数:
        arr (list): 需要排序的数组
    
    返回:
        list: 排序后的数组
    """
    # 获取数组长度
    n = len(arr)
    
    # 外层循环控制排序轮数
    for i in range(n):
        # 设置标志位，用于优化：如果某一轮没有发生交换，说明数组已经有序
        swapped = False
        
        # 内层循环进行相邻元素比较和交换
        # 每一轮后，最大的元素都会"冒泡"到末尾，所以内层循环的范围逐渐减少
        for j in range(0, n - i - 1):
            # 如果前一个元素大于后一个元素，则交换
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        
        # 如果这一轮没有发生交换，说明数组已经有序，可以提前结束
        if not swapped:
            break
    
    return arr


def bubble_sort_with_steps(arr):
    """
    带步骤显示的冒泡排序，用于演示排序过程
    
    参数:
        arr (list): 需要排序的数组
    
    返回:
        list: 排序后的数组
    """
    print(f"原始数组: {arr}")
    print("-" * 40)
    
    n = len(arr)
    
    for i in range(n):
        print(f"第 {i + 1} 轮排序:")
        swapped = False
        
        for j in range(0, n - i - 1):
            print(f"  比较 {arr[j]} 和 {arr[j + 1]}", end="")
            
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
                print(f" -> 交换: {arr}")
            else:
                print(f" -> 不交换: {arr}")
        
        print(f"第 {i + 1} 轮结束: {arr}")
        print()
        
        if not swapped:
            print("数组已经有序，提前结束排序")
            break
    
    return arr


def main():
    """
    主函数：演示冒泡排序的使用
    """
    print("=== 冒泡排序算法演示 ===\n")
    
    # 测试用例1：无序数组
    test_array_1 = [64, 34, 25, 12, 22, 11, 90]
    print("测试用例 1 - 无序数组:")
    print(f"原始数组: {test_array_1}")
    sorted_array_1 = bubble_sort(test_array_1.copy())
    print(f"排序结果: {sorted_array_1}")
    print()
    
    # 测试用例2：已经有序的数组
    test_array_2 = [1, 2, 3, 4, 5]
    print("测试用例 2 - 已排序数组:")
    print(f"原始数组: {test_array_2}")
    sorted_array_2 = bubble_sort(test_array_2.copy())
    print(f"排序结果: {sorted_array_2}")
    print()
    
    # 测试用例3：逆序数组
    test_array_3 = [5, 4, 3, 2, 1]
    print("测试用例 3 - 逆序数组:")
    print(f"原始数组: {test_array_3}")
    sorted_array_3 = bubble_sort(test_array_3.copy())
    print(f"排序结果: {sorted_array_3}")
    print()
    
    # 测试用例4：包含重复元素的数组
    test_array_4 = [3, 7, 3, 1, 7, 2, 1]
    print("测试用例 4 - 包含重复元素:")
    print(f"原始数组: {test_array_4}")
    sorted_array_4 = bubble_sort(test_array_4.copy())
    print(f"排序结果: {sorted_array_4}")
    print()
    
    # 演示排序过程
    print("=== 排序过程演示 ===")
    demo_array = [5, 2, 8, 1, 9]
    bubble_sort_with_steps(demo_array.copy())


if __name__ == "__main__":
    main()
