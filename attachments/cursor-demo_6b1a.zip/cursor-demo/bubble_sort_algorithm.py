#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
冒泡排序算法的Python实现
Author: AI Assistant
Date: 2024
"""


def bubble_sort(arr):
    """
    冒泡排序算法实现
    
    算法原理：
    1. 比较相邻的元素，如果第一个比第二个大，就交换它们
    2. 对每一对相邻元素重复这个过程，从开始到结尾
    3. 最大的元素会"冒泡"到数组的末尾
    4. 重复以上步骤，直到没有需要交换的元素
    
    时间复杂度：O(n²)
    空间复杂度：O(1)
    
    参数:
        arr (list): 需要排序的数组
    
    返回:
        list: 排序后的数组（原地排序）
    """
    n = len(arr)
    
    # 外层循环控制排序的轮数
    for i in range(n):
        # 优化：设置标志位检测是否发生交换
        swapped = False
        
        # 内层循环进行相邻元素比较
        # 每轮排序后，最大元素已到位，减少比较次数
        for j in range(0, n - i - 1):
            # 如果前面的元素大于后面的元素，则交换
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        
        # 如果本轮没有发生交换，说明数组已有序，提前结束
        if not swapped:
            break
    
    return arr


def bubble_sort_descending(arr):
    """
    冒泡排序（降序排列）
    
    参数:
        arr (list): 需要排序的数组
    
    返回:
        list: 降序排序后的数组
    """
    n = len(arr)
    
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            # 降序：前面元素小于后面元素时交换
            if arr[j] < arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        
        if not swapped:
            break
    
    return arr


def bubble_sort_with_animation(arr):
    """
    带动画演示的冒泡排序
    
    参数:
        arr (list): 需要排序的数组
    
    返回:
        list: 排序后的数组
    """
    print(f"原始数组: {arr}")
    print("=" * 50)
    
    n = len(arr)
    
    for i in range(n):
        print(f"\n第 {i + 1} 轮排序:")
        swapped = False
        
        for j in range(0, n - i - 1):
            print(f"  比较 arr[{j}]={arr[j]} 和 arr[{j+1}]={arr[j + 1]}", end="")
            
            if arr[j] > arr[j + 1]:
                # 交换元素
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
                print(f" → 交换！")
                print(f"    当前数组: {arr}")
            else:
                print(f" → 不交换")
        
        print(f"第 {i + 1} 轮结束，数组状态: {arr}")
        
        if not swapped:
            print("数组已有序，提前结束排序！")
            break
    
    print(f"\n最终排序结果: {arr}")
    return arr


def performance_test():
    """
    冒泡排序性能测试
    """
    import time
    import random
    
    print("\n性能测试：")
    print("-" * 30)
    
    # 测试不同大小的数组
    sizes = [100, 500, 1000]
    
    for size in sizes:
        # 生成随机数组
        test_arr = [random.randint(1, 1000) for _ in range(size)]
        
        # 记录排序时间
        start_time = time.time()
        bubble_sort(test_arr.copy())
        end_time = time.time()
        
        print(f"数组大小: {size}, 排序时间: {end_time - start_time:.4f} 秒")


def main():
    """
    主函数：演示冒泡排序的各种用法
    """
    print("冒泡排序算法演示")
    print("=" * 50)
    
    # 测试用例1：基本排序
    print("\n1. 基本冒泡排序：")
    test_arr1 = [64, 34, 25, 12, 22, 11, 90]
    print(f"原始数组: {test_arr1}")
    sorted_arr1 = bubble_sort(test_arr1.copy())
    print(f"排序结果: {sorted_arr1}")
    
    # 测试用例2：已排序数组
    print("\n2. 已排序数组测试：")
    test_arr2 = [1, 2, 3, 4, 5]
    print(f"原始数组: {test_arr2}")
    sorted_arr2 = bubble_sort(test_arr2.copy())
    print(f"排序结果: {sorted_arr2}")
    
    # 测试用例3：逆序数组
    print("\n3. 逆序数组测试：")
    test_arr3 = [9, 8, 7, 6, 5, 4, 3, 2, 1]
    print(f"原始数组: {test_arr3}")
    sorted_arr3 = bubble_sort(test_arr3.copy())
    print(f"排序结果: {sorted_arr3}")
    
    # 测试用例4：降序排序
    print("\n4. 降序排序：")
    test_arr4 = [3, 1, 4, 1, 5, 9, 2, 6]
    print(f"原始数组: {test_arr4}")
    sorted_arr4 = bubble_sort_descending(test_arr4.copy())
    print(f"降序结果: {sorted_arr4}")
    
    # 测试用例5：包含重复元素
    print("\n5. 包含重复元素：")
    test_arr5 = [5, 2, 8, 2, 9, 1, 5, 5]
    print(f"原始数组: {test_arr5}")
    sorted_arr5 = bubble_sort(test_arr5.copy())
    print(f"排序结果: {sorted_arr5}")
    
    # 动画演示（小数组）
    print("\n6. 排序过程动画演示：")
    demo_arr = [5, 2, 8, 1, 9]
    bubble_sort_with_animation(demo_arr.copy())
    
    # 性能测试
    performance_test()
    
    # 算法复杂度说明
    print("\n算法复杂度分析：")
    print("-" * 30)
    print("时间复杂度：")
    print("  - 最好情况：O(n) - 数组已有序")
    print("  - 平均情况：O(n²)")
    print("  - 最坏情况：O(n²) - 数组逆序")
    print("空间复杂度：O(1) - 原地排序")
    print("\n特点：")
    print("  - 稳定排序算法")
    print("  - 原地排序")
    print("  - 简单易理解")
    print("  - 适合小规模数据")


if __name__ == "__main__":
    main()

