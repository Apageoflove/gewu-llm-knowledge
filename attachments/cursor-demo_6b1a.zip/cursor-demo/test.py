def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

# 测试冒泡排序
if __name__ == "__main__":
    test_cases = [
        [],
        [1],
        [5, 2, 9, 1, 5, 6],
        [3, 2, 1, 0, -1],
        [1, 2, 3, 4, 5],
        [5, 4, 3, 2, 1]
    ]
    for idx, case in enumerate(test_cases):
        arr = case.copy()
        bubble_sort(arr)
        print(f"测试用例{idx+1}: 原始: {case} 排序后: {arr}")


