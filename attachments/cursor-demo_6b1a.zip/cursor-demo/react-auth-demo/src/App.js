import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import Dashboard from './components/Dashboard';
import './App.css';

// 认证路由组件
function AuthRouter() {
  const { isAuthenticated, isLoading } = useAuth();
  const [isLoginMode, setIsLoginMode] = useState(true);

  // 如果正在加载认证状态，显示加载器
  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>加载中...</p>
      </div>
    );
  }

  // 如果已认证，显示仪表板
  if (isAuthenticated) {
    return <Dashboard />;
  }

  // 未认证时显示登录或注册表单
  return (
    <div className="auth-container">
      {isLoginMode ? (
        <LoginForm onSwitchToRegister={() => setIsLoginMode(false)} />
      ) : (
        <RegisterForm onSwitchToLogin={() => setIsLoginMode(true)} />
      )}
    </div>
  );
}

// 主应用组件
function App() {
  return (
    <AuthProvider>
      <div className="app">
        <AuthRouter />
      </div>
    </AuthProvider>
  );
}

export default App;

