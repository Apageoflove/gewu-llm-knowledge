import React, { createContext, useContext, useReducer, useEffect } from 'react';

// 认证状态的初始值
const initialState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null
};

// Action Types
const AUTH_ACTIONS = {
  LOGIN_START: 'LOGIN_START',
  LOGIN_SUCCESS: 'LOGIN_SUCCESS',
  LOGIN_FAILURE: 'LOGIN_FAILURE',
  REGISTER_START: 'REGISTER_START',
  REGISTER_SUCCESS: 'REGISTER_SUCCESS',
  REGISTER_FAILURE: 'REGISTER_FAILURE',
  LOGOUT: 'LOGOUT',
  CLEAR_ERROR: 'CLEAR_ERROR'
};

// Reducer函数 - 管理认证状态变化
function authReducer(state, action) {
  switch (action.type) {
    case AUTH_ACTIONS.LOGIN_START:
    case AUTH_ACTIONS.REGISTER_START:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    
    case AUTH_ACTIONS.LOGIN_SUCCESS:
    case AUTH_ACTIONS.REGISTER_SUCCESS:
      return {
        ...state,
        user: action.payload.user,
        isAuthenticated: true,
        isLoading: false,
        error: null
      };
    
    case AUTH_ACTIONS.LOGIN_FAILURE:
    case AUTH_ACTIONS.REGISTER_FAILURE:
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: action.payload.error
      };
    
    case AUTH_ACTIONS.LOGOUT:
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null
      };
    
    case AUTH_ACTIONS.CLEAR_ERROR:
      return {
        ...state,
        error: null
      };
    
    default:
      return state;
  }
}

// 创建Context
const AuthContext = createContext();

// AuthProvider组件
export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // 从localStorage恢复登录状态
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        dispatch({
          type: AUTH_ACTIONS.LOGIN_SUCCESS,
          payload: { user }
        });
      } catch (error) {
        console.error('恢复用户状态失败:', error);
        localStorage.removeItem('user');
      }
    }
  }, []);

  // 模拟API调用的延迟
  const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // 登录函数
  const login = async (email, password) => {
    dispatch({ type: AUTH_ACTIONS.LOGIN_START });
    
    try {
      // 模拟API调用
      await delay(1000);
      
      // 简单的验证逻辑（在实际应用中应该调用真实API）
      const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const user = savedUsers.find(u => u.email === email && u.password === password);
      
      if (user) {
        const userData = { id: user.id, email: user.email, name: user.name };
        localStorage.setItem('user', JSON.stringify(userData));
        
        dispatch({
          type: AUTH_ACTIONS.LOGIN_SUCCESS,
          payload: { user: userData }
        });
        
        return { success: true };
      } else {
        throw new Error('邮箱或密码错误');
      }
    } catch (error) {
      dispatch({
        type: AUTH_ACTIONS.LOGIN_FAILURE,
        payload: { error: error.message }
      });
      return { success: false, error: error.message };
    }
  };

  // 注册函数
  const register = async (name, email, password) => {
    dispatch({ type: AUTH_ACTIONS.REGISTER_START });
    
    try {
      // 模拟API调用
      await delay(1000);
      
      // 检查用户是否已存在
      const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const existingUser = savedUsers.find(u => u.email === email);
      
      if (existingUser) {
        throw new Error('该邮箱已被注册');
      }
      
      // 创建新用户
      const newUser = {
        id: Date.now(),
        name,
        email,
        password // 在实际应用中应该进行加密
      };
      
      savedUsers.push(newUser);
      localStorage.setItem('users', JSON.stringify(savedUsers));
      
      const userData = { id: newUser.id, email: newUser.email, name: newUser.name };
      localStorage.setItem('user', JSON.stringify(userData));
      
      dispatch({
        type: AUTH_ACTIONS.REGISTER_SUCCESS,
        payload: { user: userData }
      });
      
      return { success: true };
    } catch (error) {
      dispatch({
        type: AUTH_ACTIONS.REGISTER_FAILURE,
        payload: { error: error.message }
      });
      return { success: false, error: error.message };
    }
  };

  // 登出函数
  const logout = () => {
    localStorage.removeItem('user');
    dispatch({ type: AUTH_ACTIONS.LOGOUT });
  };

  // 清除错误
  const clearError = () => {
    dispatch({ type: AUTH_ACTIONS.CLEAR_ERROR });
  };

  const value = {
    ...state,
    login,
    register,
    logout,
    clearError
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// 自定义Hook - 使用认证状态
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth必须在AuthProvider内部使用');
  }
  return context;
}

