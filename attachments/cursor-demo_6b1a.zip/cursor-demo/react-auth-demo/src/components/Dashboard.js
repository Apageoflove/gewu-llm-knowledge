import React from 'react';
import { useAuth } from '../context/AuthContext';
import './Dashboard.css';

function Dashboard() {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    if (window.confirm('确认要退出登录吗？')) {
      logout();
    }
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard">
        <header className="dashboard-header">
          <h1 className="dashboard-title">欢迎回来！</h1>
          <button 
            onClick={handleLogout}
            className="logout-btn"
            type="button"
          >
            退出登录
          </button>
        </header>
        
        <div className="user-info-card">
          <div className="user-avatar">
            {user?.name?.charAt(0).toUpperCase() || 'U'}
          </div>
          <div className="user-details">
            <h2 className="user-name">{user?.name}</h2>
            <p className="user-email">{user?.email}</p>
            <p className="user-id">用户ID: {user?.id}</p>
          </div>
        </div>

        <div className="dashboard-content">
          <div className="feature-grid">
            <div className="feature-card">
              <div className="feature-icon">👤</div>
              <h3>个人资料</h3>
              <p>查看和编辑个人信息</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🔒</div>
              <h3>安全设置</h3>
              <p>管理密码和安全选项</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>数据统计</h3>
              <p>查看使用统计信息</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">⚙️</div>
              <h3>系统设置</h3>
              <p>自定义应用偏好设置</p>
            </div>
          </div>
        </div>

        <footer className="dashboard-footer">
          <p>© 2024 React 认证系统演示</p>
        </footer>
      </div>
    </div>
  );
}

export default Dashboard;

