import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import './AuthForm.css';

function RegisterForm({ onSwitchToLogin }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  
  const [formErrors, setFormErrors] = useState({});
  const { register, isLoading, error, clearError } = useAuth();

  // 清除错误当组件挂载时
  useEffect(() => {
    clearError();
  }, [clearError]);

  // 处理输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // 清除对应字段的错误
    if (formErrors[name]) {
      setFormErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  // 验证表单
  const validateForm = () => {
    const errors = {};
    
    if (!formData.name.trim()) {
      errors.name = '请输入用户名';
    } else if (formData.name.trim().length < 2) {
      errors.name = '用户名至少2个字符';
    }
    
    if (!formData.email) {
      errors.email = '请输入邮箱地址';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = '请输入有效的邮箱地址';
    }
    
    if (!formData.password) {
      errors.password = '请输入密码';
    } else if (formData.password.length < 6) {
      errors.password = '密码长度至少6位';
    } else if (!/(?=.*[a-zA-Z])(?=.*\d)/.test(formData.password)) {
      errors.password = '密码必须包含字母和数字';
    }
    
    if (!formData.confirmPassword) {
      errors.confirmPassword = '请确认密码';
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = '两次输入的密码不一致';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // 处理表单提交
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const result = await register(
      formData.name.trim(),
      formData.email,
      formData.password
    );
    
    if (result.success) {
      // 注册成功，AuthContext会自动更新状态
      console.log('注册成功');
    }
  };

  return (
    <div className="auth-form-container">
      <div className="auth-form">
        <h2 className="auth-title">注册</h2>
        
        {error && (
          <div className="error-message" role="alert">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label htmlFor="name" className="form-label">
              用户名
            </label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleInputChange}
              className={`form-input ${formErrors.name ? 'error' : ''}`}
              placeholder="请输入用户名"
              disabled={isLoading}
              autoComplete="name"
            />
            {formErrors.name && (
              <span className="field-error" role="alert">
                {formErrors.name}
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="register-email" className="form-label">
              邮箱地址
            </label>
            <input
              id="register-email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`form-input ${formErrors.email ? 'error' : ''}`}
              placeholder="请输入邮箱地址"
              disabled={isLoading}
              autoComplete="email"
            />
            {formErrors.email && (
              <span className="field-error" role="alert">
                {formErrors.email}
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="register-password" className="form-label">
              密码
            </label>
            <input
              id="register-password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleInputChange}
              className={`form-input ${formErrors.password ? 'error' : ''}`}
              placeholder="请输入密码（至少6位，包含字母和数字）"
              disabled={isLoading}
              autoComplete="new-password"
            />
            {formErrors.password && (
              <span className="field-error" role="alert">
                {formErrors.password}
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword" className="form-label">
              确认密码
            </label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              className={`form-input ${formErrors.confirmPassword ? 'error' : ''}`}
              placeholder="请再次输入密码"
              disabled={isLoading}
              autoComplete="new-password"
            />
            {formErrors.confirmPassword && (
              <span className="field-error" role="alert">
                {formErrors.confirmPassword}
              </span>
            )}
          </div>

          <button
            type="submit"
            className="submit-btn"
            disabled={isLoading}
          >
            {isLoading ? '注册中...' : '注册'}
          </button>
        </form>

        <div className="auth-switch">
          <p>
            已有账户？
            <button
              type="button"
              className="switch-btn"
              onClick={onSwitchToLogin}
              disabled={isLoading}
            >
              立即登录
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

export default RegisterForm;

