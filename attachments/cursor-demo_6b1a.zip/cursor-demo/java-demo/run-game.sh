#!/bin/bash

echo "========================================"
echo "          魂斗罗游戏启动器"
echo "========================================"
echo "正在启动游戏，请稍候..."
echo

cd "$(dirname "$0")"
mvn exec:java -Dexec.mainClass="com.contra.Main"

echo
echo "游戏已结束，按回车键关闭..."
read
