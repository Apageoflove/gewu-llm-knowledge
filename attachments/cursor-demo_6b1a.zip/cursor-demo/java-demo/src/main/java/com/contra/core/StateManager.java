package com.contra.core;

import com.contra.entities.*;
import com.contra.levels.Level;
import com.contra.levels.LevelManager;
import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 游戏状态管理器
 * 负责管理游戏的整体状态、实体对象和游戏逻辑
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class StateManager {
    
    /** 当前游戏状态 */
    private Constants.GameState currentState;
    
    /** 之前的游戏状态 */
    private Constants.GameState previousState;
    
    /** 玩家列表 */
    private List<Player> players;
    
    /** 敌人列表 */
    private List<Enemy> enemies;
    
    /** 子弹列表 */
    private List<Bullet> bullets;
    
    /** 道具列表 */
    private List<PowerUp> powerUps;
    
    /** 关卡管理器 */
    private LevelManager levelManager;
    
    /** 当前关卡 */
    private Level currentLevel;
    
    /** 游戏分数 */
    private int score;
    
    /** 当前关卡编号 */
    private int currentLevelNumber;
    
    /** 游戏时间（毫秒） */
    private long gameTime;
    
    /** 上次更新时间 */
    private long lastUpdateTime;
    
    /** 敌人生成计时器 */
    private long enemySpawnTimer;
    
    /** 是否为双人模式 */
    private boolean twoPlayerMode;
    
    /**
     * 构造函数
     */
    public StateManager() {
        initialize();
    }
    
    /**
     * 初始化状态管理器
     */
    private void initialize() {
        // 初始化状态
        currentState = Constants.GameState.MENU;
        previousState = Constants.GameState.MENU;
        
        // 初始化实体列表（使用线程安全的列表）
        players = new CopyOnWriteArrayList<>();
        enemies = new CopyOnWriteArrayList<>();
        bullets = new CopyOnWriteArrayList<>();
        powerUps = new CopyOnWriteArrayList<>();
        
        // 初始化关卡管理器
        levelManager = new LevelManager();
        
        // 初始化游戏变量
        score = 0;
        currentLevelNumber = 1;
        gameTime = 0;
        lastUpdateTime = System.currentTimeMillis();
        enemySpawnTimer = 0;
        twoPlayerMode = false;
        
        System.out.println("StateManager initialized");
    }
    
    /**
     * 更新游戏状态
     */
    public void update() {
        long currentTime = System.currentTimeMillis();
        long deltaTime = currentTime - lastUpdateTime;
        lastUpdateTime = currentTime;
        
        switch (currentState) {
            case MENU:
                updateMenu(deltaTime);
                break;
            case PLAYING:
                updateGame(deltaTime);
                break;
            case PAUSED:
                updatePause(deltaTime);
                break;
            case GAME_OVER:
                updateGameOver(deltaTime);
                break;
            case LEVEL_COMPLETE:
                updateLevelComplete(deltaTime);
                break;
            case SETTINGS:
                updateSettings(deltaTime);
                break;
        }
    }
    
    /**
     * 更新菜单状态
     * @param deltaTime 时间差
     */
    private void updateMenu(long deltaTime) {
        // 菜单逻辑更新（如果需要的话）
    }
    
    /**
     * 更新游戏状态
     * @param deltaTime 时间差
     */
    private void updateGame(long deltaTime) {
        gameTime += deltaTime;
        
        // 更新玩家
        updatePlayers(deltaTime);
        
        // 更新敌人
        updateEnemies(deltaTime);
        
        // 更新子弹
        updateBullets(deltaTime);
        
        // 更新道具
        updatePowerUps(deltaTime);
        
        // 更新关卡
        updateLevel(deltaTime);
        
        // 检查碰撞
        checkCollisions();
        
        // 生成敌人
        spawnEnemies(deltaTime);
        
        // 清理已死亡的实体
        cleanupEntities();
        
        // 检查游戏结束条件
        checkGameEndConditions();
    }
    
    /**
     * 更新暂停状态
     * @param deltaTime 时间差
     */
    private void updatePause(long deltaTime) {
        // 暂停时不更新游戏逻辑
    }
    
    /**
     * 更新游戏结束状态
     * @param deltaTime 时间差
     */
    private void updateGameOver(long deltaTime) {
        // 游戏结束逻辑
    }
    
    /**
     * 更新关卡完成状态
     * @param deltaTime 时间差
     */
    private void updateLevelComplete(long deltaTime) {
        // 关卡完成逻辑
    }
    
    /**
     * 更新设置状态
     * @param deltaTime 时间差
     */
    private void updateSettings(long deltaTime) {
        // 设置页面逻辑
    }
    
    /**
     * 更新玩家
     * @param deltaTime 时间差
     */
    private void updatePlayers(long deltaTime) {
        for (Player player : players) {
            if (player.isAlive()) {
                player.update(deltaTime);
            }
        }
    }
    
    /**
     * 更新敌人
     * @param deltaTime 时间差
     */
    private void updateEnemies(long deltaTime) {
        for (Enemy enemy : enemies) {
            if (enemy.isAlive()) {
                enemy.update(deltaTime);
            }
        }
    }
    
    /**
     * 更新子弹
     * @param deltaTime 时间差
     */
    private void updateBullets(long deltaTime) {
        for (Bullet bullet : bullets) {
            if (bullet.isAlive()) {
                bullet.update(deltaTime);
            }
        }
    }
    
    /**
     * 更新道具
     * @param deltaTime 时间差
     */
    private void updatePowerUps(long deltaTime) {
        for (PowerUp powerUp : powerUps) {
            if (powerUp.isAlive()) {
                powerUp.update(deltaTime);
            }
        }
    }
    
    /**
     * 更新关卡
     * @param deltaTime 时间差
     */
    private void updateLevel(long deltaTime) {
        if (currentLevel != null) {
            currentLevel.update(deltaTime);
        }
    }
    
    /**
     * 检查碰撞
     */
    private void checkCollisions() {
        // 玩家与敌人碰撞
        checkPlayerEnemyCollisions();
        
        // 子弹与敌人碰撞
        checkBulletEnemyCollisions();
        
        // 玩家与道具碰撞
        checkPlayerPowerUpCollisions();
        
        // 子弹与玩家碰撞（敌人子弹）
        checkBulletPlayerCollisions();
    }
    
    /**
     * 检查玩家与敌人的碰撞
     */
    private void checkPlayerEnemyCollisions() {
        for (Player player : players) {
            if (!player.isAlive()) continue;
            
            for (Enemy enemy : enemies) {
                if (!enemy.isAlive()) continue;
                
                if (player.getBounds().intersects(enemy.getBounds())) {
                    handlePlayerEnemyCollision(player, enemy);
                }
            }
        }
    }
    
    /**
     * 检查子弹与敌人的碰撞
     */
    private void checkBulletEnemyCollisions() {
        for (Bullet bullet : bullets) {
            if (!bullet.isAlive() || bullet.getType() != Constants.EntityType.BULLET_PLAYER) continue;
            
            for (Enemy enemy : enemies) {
                if (!enemy.isAlive()) continue;
                
                if (bullet.getBounds().intersects(enemy.getBounds())) {
                    handleBulletEnemyCollision(bullet, enemy);
                }
            }
        }
    }
    
    /**
     * 检查玩家与道具的碰撞
     */
    private void checkPlayerPowerUpCollisions() {
        for (Player player : players) {
            if (!player.isAlive()) continue;
            
            for (PowerUp powerUp : powerUps) {
                if (!powerUp.isAlive()) continue;
                
                if (player.getBounds().intersects(powerUp.getBounds())) {
                    handlePlayerPowerUpCollision(player, powerUp);
                }
            }
        }
    }
    
    /**
     * 检查子弹与玩家的碰撞
     */
    private void checkBulletPlayerCollisions() {
        for (Bullet bullet : bullets) {
            if (!bullet.isAlive() || bullet.getType() != Constants.EntityType.BULLET_ENEMY) continue;
            
            for (Player player : players) {
                if (!player.isAlive()) continue;
                
                if (bullet.getBounds().intersects(player.getBounds())) {
                    handleBulletPlayerCollision(bullet, player);
                }
            }
        }
    }
    
    /**
     * 处理玩家与敌人的碰撞
     * @param player 玩家
     * @param enemy 敌人
     */
    private void handlePlayerEnemyCollision(Player player, Enemy enemy) {
        player.takeDamage(1);
        enemy.takeDamage(999); // 敌人也死亡
        
        if (Constants.DEBUG_MODE) {
            System.out.println("Player hit by enemy!");
        }
    }
    
    /**
     * 处理子弹与敌人的碰撞
     * @param bullet 子弹
     * @param enemy 敌人
     */
    private void handleBulletEnemyCollision(Bullet bullet, Enemy enemy) {
        enemy.takeDamage(bullet.getDamage());
        bullet.destroy();
        
        if (!enemy.isAlive()) {
            addScore(100); // 击败敌人得分
        }
        
        if (Constants.DEBUG_MODE) {
            System.out.println("Bullet hit enemy!");
        }
    }
    
    /**
     * 处理玩家与道具的碰撞
     * @param player 玩家
     * @param powerUp 道具
     */
    private void handlePlayerPowerUpCollision(Player player, PowerUp powerUp) {
        powerUp.apply(player);
        powerUp.destroy();
        
        addScore(50); // 收集道具得分
        
        if (Constants.DEBUG_MODE) {
            System.out.println("Player collected power-up!");
        }
    }
    
    /**
     * 处理子弹与玩家的碰撞
     * @param bullet 子弹
     * @param player 玩家
     */
    private void handleBulletPlayerCollision(Bullet bullet, Player player) {
        player.takeDamage(bullet.getDamage());
        bullet.destroy();
        
        if (Constants.DEBUG_MODE) {
            System.out.println("Player hit by enemy bullet!");
        }
    }
    
    /**
     * 生成敌人
     * @param deltaTime 时间差
     */
    private void spawnEnemies(long deltaTime) {
        enemySpawnTimer += deltaTime;
        
        if (enemySpawnTimer >= Constants.ENEMY_SPAWN_INTERVAL) {
            spawnEnemy();
            enemySpawnTimer = 0;
        }
    }
    
    /**
     * 生成一个敌人
     */
    private void spawnEnemy() {
        // 在屏幕右侧生成敌人
        Vector2D position = new Vector2D(Constants.GAME_WIDTH + 50, Constants.GROUND_Y - Constants.ENEMY_HEIGHT);
        Enemy enemy = new Enemy(position, Constants.EntityType.ENEMY_SOLDIER);
        enemies.add(enemy);
        
        if (Constants.DEBUG_MODE) {
            System.out.println("Enemy spawned at: " + position);
        }
    }
    
    /**
     * 清理已死亡的实体
     */
    private void cleanupEntities() {
        // 清理死亡的敌人
        enemies.removeIf(enemy -> !enemy.isAlive());
        
        // 清理死亡的子弹
        bullets.removeIf(bullet -> !bullet.isAlive());
        
        // 清理过期的道具
        powerUps.removeIf(powerUp -> !powerUp.isAlive());
    }
    
    /**
     * 检查游戏结束条件
     */
    private void checkGameEndConditions() {
        // 检查所有玩家是否都死亡
        boolean allPlayersDead = true;
        for (Player player : players) {
            if (player.isAlive()) {
                allPlayersDead = false;
                break;
            }
        }
        
        if (allPlayersDead) {
            setGameState(Constants.GameState.GAME_OVER);
        }
        
        // 检查关卡是否完成
        if (currentLevel != null && currentLevel.isCompleted()) {
            setGameState(Constants.GameState.LEVEL_COMPLETE);
        }
    }
    
    /**
     * 开始新游戏
     * @param twoPlayer 是否为双人模式
     */
    public void startNewGame(boolean twoPlayer) {
        this.twoPlayerMode = twoPlayer;
        
        // 清理所有实体
        clearAllEntities();
        
        // 重置游戏变量
        score = 0;
        currentLevelNumber = 1;
        gameTime = 0;
        enemySpawnTimer = 0;
        
        // 创建玩家
        createPlayers();
        
        // 加载第一关
        loadLevel(1);
        
        // 切换到游戏状态
        setGameState(Constants.GameState.PLAYING);
        
        System.out.println("New game started - Two player: " + twoPlayer);
    }
    
    /**
     * 创建玩家
     */
    private void createPlayers() {
        // 创建玩家1
        Vector2D player1Pos = new Vector2D(Constants.PLAYER1_START_X, Constants.PLAYER_START_Y);
        Player player1 = new Player(player1Pos, 1);
        players.add(player1);
        
        // 如果是双人模式，创建玩家2
        if (twoPlayerMode) {
            Vector2D player2Pos = new Vector2D(Constants.PLAYER2_START_X, Constants.PLAYER_START_Y);
            Player player2 = new Player(player2Pos, 2);
            players.add(player2);
        }
        
        System.out.println("Players created: " + players.size());
    }
    
    /**
     * 加载关卡
     * @param levelNumber 关卡编号
     */
    public void loadLevel(int levelNumber) {
        this.currentLevelNumber = levelNumber;
        this.currentLevel = levelManager.loadLevel(levelNumber);
        
        if (currentLevel != null) {
            System.out.println("Level " + levelNumber + " loaded");
        } else {
            System.err.println("Failed to load level " + levelNumber);
        }
    }
    
    /**
     * 清理所有实体
     */
    private void clearAllEntities() {
        players.clear();
        enemies.clear();
        bullets.clear();
        powerUps.clear();
    }
    
    /**
     * 添加子弹
     * @param bullet 子弹
     */
    public void addBullet(Bullet bullet) {
        if (bullets.size() < Constants.MAX_BULLETS) {
            bullets.add(bullet);
        }
    }
    
    /**
     * 添加道具
     * @param powerUp 道具
     */
    public void addPowerUp(PowerUp powerUp) {
        powerUps.add(powerUp);
    }
    
    /**
     * 添加分数
     * @param points 分数
     */
    public void addScore(int points) {
        this.score += points;
    }
    
    /**
     * 设置游戏状态
     * @param newState 新状态
     */
    public void setGameState(Constants.GameState newState) {
        if (newState != currentState) {
            previousState = currentState;
            currentState = newState;
            
            System.out.println("Game state changed: " + previousState + " -> " + currentState);
        }
    }
    
    /**
     * 暂停游戏
     */
    public void pauseGame() {
        if (currentState == Constants.GameState.PLAYING) {
            setGameState(Constants.GameState.PAUSED);
        }
    }
    
    /**
     * 恢复游戏
     */
    public void resumeGame() {
        if (currentState == Constants.GameState.PAUSED) {
            setGameState(Constants.GameState.PLAYING);
        }
    }
    
    /**
     * 重置游戏状态
     */
    public void reset() {
        clearAllEntities();
        currentState = Constants.GameState.MENU;
        previousState = Constants.GameState.MENU;
        score = 0;
        currentLevelNumber = 1;
        gameTime = 0;
        enemySpawnTimer = 0;
        twoPlayerMode = false;
        
        System.out.println("Game state reset");
    }
    
    /**
     * 清理资源
     */
    public void cleanup() {
        clearAllEntities();
        
        if (levelManager != null) {
            levelManager.cleanup();
        }
        
        System.out.println("StateManager cleaned up");
    }
    
    // Getters
    public Constants.GameState getCurrentState() { return currentState; }
    public Constants.GameState getPreviousState() { return previousState; }
    public List<Player> getPlayers() { return new ArrayList<>(players); }
    public List<Enemy> getEnemies() { return new ArrayList<>(enemies); }
    public List<Bullet> getBullets() { return new ArrayList<>(bullets); }
    public List<PowerUp> getPowerUps() { return new ArrayList<>(powerUps); }
    public Level getCurrentLevel() { return currentLevel; }
    public int getScore() { return score; }
    public int getCurrentLevelNumber() { return currentLevelNumber; }
    public long getGameTime() { return gameTime; }
    public boolean isTwoPlayerMode() { return twoPlayerMode; }
}
