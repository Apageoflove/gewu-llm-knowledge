package com.contra.ui;

import com.contra.core.StateManager;
import com.contra.entities.*;
import com.contra.input.InputManager;
import com.contra.levels.Level;
import com.contra.utils.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 游戏面板类
 */
public class GamePanel extends JPanel implements ActionListener {
    
    private StateManager stateManager;
    private InputManager inputManager;
    private Timer gameTimer;
    
    public GamePanel(StateManager stateManager, InputManager inputManager) {
        this.stateManager = stateManager;
        this.inputManager = inputManager;
        
        setPreferredSize(new Dimension(Constants.GAME_WIDTH, Constants.GAME_HEIGHT));
        setBackground(Constants.BACKGROUND_COLOR);
        setFocusable(true);
        
        // 创建游戏更新定时器
        gameTimer = new Timer(Constants.FRAME_TIME_MS, this);
        gameTimer.start();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // 更新输入
        updateInput();
        
        // 重绘
        repaint();
    }
    
    private void updateInput() {
        if (stateManager.getCurrentState() == Constants.GameState.PLAYING) {
            for (Player player : stateManager.getPlayers()) {
                if (!player.isAlive()) continue;
                
                int playerNum = player.getPlayerNumber();
                
                // 处理移动
                int horizontal = (playerNum == 1) ? 
                    inputManager.getPlayer1HorizontalInput() : 
                    inputManager.getPlayer2HorizontalInput();
                    
                if (horizontal < 0) {
                    player.moveLeft();
                } else if (horizontal > 0) {
                    player.moveRight();
                } else {
                    player.stopMoving();
                }
                
                // 处理跳跃
                boolean jumping = (playerNum == 1) ? 
                    inputManager.isPlayer1Jumping() : 
                    inputManager.isPlayer2Jumping();
                    
                if (jumping) {
                    player.jump();
                }
                
                // 处理射击
                boolean firing = (playerNum == 1) ? 
                    inputManager.isPlayer1Firing() : 
                    inputManager.isPlayer2Firing();
                    
                if (firing) {
                    Bullet bullet = player.fire();
                    if (bullet != null) {
                        stateManager.addBullet(bullet);
                    }
                }
            }
        }
        
        inputManager.update();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        // 启用抗锯齿
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        switch (stateManager.getCurrentState()) {
            case MENU:
                renderMenu(g2d);
                break;
            case PLAYING:
                renderGame(g2d);
                break;
            case PAUSED:
                renderGame(g2d);
                renderPauseOverlay(g2d);
                break;
            case GAME_OVER:
                renderGameOver(g2d);
                break;
            case LEVEL_COMPLETE:
                renderLevelComplete(g2d);
                break;
            case SETTINGS:
                renderSettings(g2d);
                break;
        }
    }
    
    private void renderMenu(Graphics2D g) {
        g.setColor(Constants.BACKGROUND_COLOR);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        drawCenteredString(g, "CONTRA", getHeight() / 2 - 100);
        
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        drawCenteredString(g, "Press ENTER for Single Player", getHeight() / 2);
        drawCenteredString(g, "Press 2 for Two Players", getHeight() / 2 + 40);
        drawCenteredString(g, "Press S for Settings", getHeight() / 2 + 80);
        drawCenteredString(g, "Press ESC to Quit", getHeight() / 2 + 120);
    }
    
    private void renderGame(Graphics2D g) {
        // 渲染关卡背景
        Level currentLevel = stateManager.getCurrentLevel();
        if (currentLevel != null) {
            currentLevel.render(g);
        }
        
        // 渲染所有实体
        for (Player player : stateManager.getPlayers()) {
            if (player.isAlive()) {
                player.render(g);
            }
        }
        
        for (Enemy enemy : stateManager.getEnemies()) {
            if (enemy.isAlive()) {
                enemy.render(g);
            }
        }
        
        for (Bullet bullet : stateManager.getBullets()) {
            if (bullet.isAlive()) {
                bullet.render(g);
            }
        }
        
        for (PowerUp powerUp : stateManager.getPowerUps()) {
            if (powerUp.isAlive()) {
                powerUp.render(g);
            }
        }
        
        // 渲染HUD
        renderHUD(g);
    }
    
    private void renderHUD(Graphics2D g) {
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        
        // 分数
        g.drawString("Score: " + stateManager.getScore(), 10, 30);
        
        // 关卡
        g.drawString("Level: " + stateManager.getCurrentLevelNumber(), 10, 50);
        
        // 时间
        long gameTime = stateManager.getGameTime() / 1000;
        g.drawString("Time: " + gameTime + "s", 10, 70);
        
        // 玩家状态
        int y = 30;
        for (Player player : stateManager.getPlayers()) {
            g.drawString("P" + player.getPlayerNumber() + " Lives: " + player.getHealth(), 
                        getWidth() - 120, y);
            y += 20;
        }
        
        // 调试信息
        if (Constants.DEBUG_MODE && Constants.SHOW_FPS) {
            g.setFont(new Font("Arial", Font.PLAIN, 12));
            g.drawString("Entities: " + getTotalEntityCount(), 10, getHeight() - 40);
            g.drawString("Press ESC to pause", 10, getHeight() - 20);
        }
    }
    
    private int getTotalEntityCount() {
        return stateManager.getPlayers().size() + 
               stateManager.getEnemies().size() + 
               stateManager.getBullets().size() + 
               stateManager.getPowerUps().size();
    }
    
    private void renderPauseOverlay(Graphics2D g) {
        // 半透明覆盖
        g.setColor(new Color(0, 0, 0, 128));
        g.fillRect(0, 0, getWidth(), getHeight());
        
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.BOLD, 36));
        drawCenteredString(g, "PAUSED", getHeight() / 2 - 50);
        
        g.setFont(new Font("Arial", Font.PLAIN, 18));
        drawCenteredString(g, "Press ESC to Resume", getHeight() / 2 + 20);
        drawCenteredString(g, "Press R to Restart", getHeight() / 2 + 50);
        drawCenteredString(g, "Press M for Menu", getHeight() / 2 + 80);
    }
    
    private void renderGameOver(Graphics2D g) {
        g.setColor(Constants.BACKGROUND_COLOR);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        drawCenteredString(g, "GAME OVER", getHeight() / 2 - 100);
        
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        drawCenteredString(g, "Final Score: " + stateManager.getScore(), getHeight() / 2 - 20);
        drawCenteredString(g, "Press ENTER to Restart", getHeight() / 2 + 20);
        drawCenteredString(g, "Press M for Menu", getHeight() / 2 + 60);
    }
    
    private void renderLevelComplete(Graphics2D g) {
        g.setColor(Constants.BACKGROUND_COLOR);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        g.setColor(Color.GREEN);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        drawCenteredString(g, "LEVEL COMPLETE!", getHeight() / 2 - 100);
        
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        drawCenteredString(g, "Score: " + stateManager.getScore(), getHeight() / 2 - 20);
        drawCenteredString(g, "Press ENTER for Next Level", getHeight() / 2 + 20);
        drawCenteredString(g, "Press M for Menu", getHeight() / 2 + 60);
    }
    
    private void renderSettings(Graphics2D g) {
        g.setColor(Constants.BACKGROUND_COLOR);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        g.setColor(Constants.UI_TEXT_COLOR);
        g.setFont(new Font("Arial", Font.BOLD, 36));
        drawCenteredString(g, "SETTINGS", getHeight() / 2 - 100);
        
        g.setFont(new Font("Arial", Font.PLAIN, 18));
        drawCenteredString(g, "Game Controls:", getHeight() / 2 - 20);
        drawCenteredString(g, "Player 1: WASD to move, SPACE to fire", getHeight() / 2 + 20);
        drawCenteredString(g, "Player 2: Arrow keys to move, ENTER to fire", getHeight() / 2 + 50);
        drawCenteredString(g, "Press M to return to Menu", getHeight() / 2 + 100);
    }
    
    private void drawCenteredString(Graphics2D g, String text, int y) {
        FontMetrics fm = g.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(text)) / 2;
        g.drawString(text, x, y);
    }
    
    public void cleanup() {
        if (gameTimer != null) {
            gameTimer.stop();
        }
    }
}
