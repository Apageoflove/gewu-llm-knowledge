package com.contra.entities;

import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;

/**
 * 子弹类
 */
public class Bullet extends Entity {
    private int damage;
    private int bulletDirection;
    
    public Bullet(Vector2D position, Constants.EntityType type, int direction) {
        super(position, type);
        this.damage = 1;
        this.bulletDirection = direction;
        this.color = Constants.BULLET_COLOR;
        
        // 设置子弹速度
        velocity.x = bulletDirection * Constants.BULLET_SPEED;
        velocity.y = 0;
    }
    
    @Override
    public void update(long deltaTime) {
        updatePosition(deltaTime);
    }
    
    @Override
    public void render(Graphics2D g) {
        g.setColor(color);
        g.fillRect((int)position.x, (int)position.y, width, height);
    }
    
    @Override
    protected void checkBounds() {
        // 子弹移出屏幕就销毁
        if (position.x < 0 || position.x > Constants.GAME_WIDTH || 
            position.y < 0 || position.y > Constants.GAME_HEIGHT) {
            destroy();
        }
    }
    
    @Override
    protected void applyGravity(long deltaTime) {
        // 子弹不受重力影响
    }
    
    public int getDamage() { return damage; }
    public void setDamage(int damage) { this.damage = damage; }
}
