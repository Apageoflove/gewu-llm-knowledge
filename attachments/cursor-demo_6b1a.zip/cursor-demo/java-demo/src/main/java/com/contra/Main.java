package com.contra;

import com.contra.core.GameEngine;
import javax.swing.SwingUtilities;

/**
 * 魂斗罗游戏主入口类
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class Main {
    
    /**
     * 程序主入口
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        // 设置系统属性以优化性能
        System.setProperty("sun.java2d.opengl", "true");
        System.setProperty("sun.java2d.translaccel", "true");
        System.setProperty("sun.java2d.ddforcevram", "true");
        
        // 在Event Dispatch Thread中启动游戏
        SwingUtilities.invokeLater(() -> {
            try {
                // 创建并启动游戏引擎
                GameEngine gameEngine = new GameEngine();
                gameEngine.start();
                
                System.out.println("=== 魂斗罗游戏启动成功 ===");
                System.out.println("版本: 1.0.0");
                System.out.println("开发者: Contra Game Team");
                System.out.println("========================");
                
            } catch (Exception e) {
                System.err.println("游戏启动失败: " + e.getMessage());
                e.printStackTrace();
                System.exit(1);
            }
        });
    }
}
