package com.contra.core;

import com.contra.ui.GamePanel;
import com.contra.input.InputManager;
import com.contra.utils.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 游戏引擎主类
 * 负责初始化游戏窗口、管理游戏状态和协调各个子系统
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class GameEngine {
    
    /** 游戏主窗口 */
    private JFrame gameWindow;
    
    /** 游戏面板 */
    private GamePanel gamePanel;
    
    /** 游戏循环 */
    private GameLoop gameLoop;
    
    /** 状态管理器 */
    private StateManager stateManager;
    
    /** 输入管理器 */
    private InputManager inputManager;
    
    /** 游戏是否正在运行 */
    private boolean running;
    
    /**
     * 构造函数
     */
    public GameEngine() {
        this.running = false;
        initializeComponents();
    }
    
    /**
     * 初始化游戏组件
     */
    private void initializeComponents() {
        try {
            // 设置系统外观
            // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
        } catch (Exception e) {
            System.err.println("Failed to set system look and feel: " + e.getMessage());
        }
        
        // 初始化各个管理器
        stateManager = new StateManager();
        inputManager = new InputManager();
        
        // 创建游戏面板
        gamePanel = new GamePanel(stateManager, inputManager);
        
        // 创建游戏循环
        gameLoop = new GameLoop(gamePanel, stateManager);
        
        // 设置输入管理器的状态管理器引用
        inputManager.setStateManager(stateManager);
        
        // 创建游戏窗口
        createGameWindow();
    }
    
    /**
     * 创建游戏窗口
     */
    private void createGameWindow() {
        gameWindow = new JFrame(Constants.GAME_TITLE);
        
        // 设置窗口属性
        gameWindow.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        gameWindow.setResizable(false);
        gameWindow.setSize(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        gameWindow.setLocationRelativeTo(null);
        
        // 设置窗口图标（如果有的话）
        try {
            // 这里可以设置游戏图标
            // gameWindow.setIconImage(ImageIO.read(getClass().getResource("/icon.png")));
        } catch (Exception e) {
            // 图标加载失败，使用默认图标
        }
        
        // 添加游戏面板
        gameWindow.add(gamePanel);
        
        // 添加窗口关闭监听器
        gameWindow.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                shutdown();
            }
        });
        
        // 添加键盘监听器
        gameWindow.addKeyListener(inputManager);
        gameWindow.setFocusable(true);
        gameWindow.requestFocus();
        
        System.out.println("Game window created successfully");
    }
    
    /**
     * 启动游戏
     */
    public void start() {
        if (running) {
            System.out.println("Game is already running!");
            return;
        }
        
        System.out.println("Starting Contra Game...");
        
        // 显示游戏窗口
        gameWindow.setVisible(true);
        
        // 确保窗口获得焦点
        gameWindow.requestFocus();
        
        // 设置运行状态
        running = true;
        
        // 启动游戏循环
        gameLoop.start();
        
        System.out.println("Game started successfully!");
    }
    
    /**
     * 停止游戏
     */
    public void stop() {
        if (!running) {
            return;
        }
        
        System.out.println("Stopping game...");
        
        running = false;
        
        // 停止游戏循环
        if (gameLoop != null) {
            gameLoop.stop();
        }
        
        System.out.println("Game stopped.");
    }
    
    /**
     * 关闭游戏
     */
    public void shutdown() {
        System.out.println("Shutting down game...");
        
        // 停止游戏
        stop();
        
        // 释放资源
        cleanup();
        
        // 关闭窗口
        if (gameWindow != null) {
            gameWindow.dispose();
        }
        
        System.out.println("Game shutdown complete.");
        System.exit(0);
    }
    
    /**
     * 清理资源
     */
    private void cleanup() {
        // 清理游戏面板
        if (gamePanel != null) {
            gamePanel.cleanup();
        }
        
        // 清理状态管理器
        if (stateManager != null) {
            stateManager.cleanup();
        }
        
        // 清理输入管理器
        if (inputManager != null) {
            inputManager.cleanup();
        }
        
        System.out.println("Resources cleaned up.");
    }
    
    /**
     * 暂停游戏
     */
    public void pause() {
        if (gameLoop != null) {
            gameLoop.pause();
        }
        stateManager.pauseGame();
        System.out.println("Game paused.");
    }
    
    /**
     * 恢复游戏
     */
    public void resume() {
        if (gameLoop != null) {
            gameLoop.resume();
        }
        stateManager.resumeGame();
        System.out.println("Game resumed.");
    }
    
    /**
     * 重启游戏
     */
    public void restart() {
        System.out.println("Restarting game...");
        
        // 停止当前游戏
        stop();
        
        // 重置状态管理器
        stateManager.reset();
        
        // 重新启动
        start();
        
        System.out.println("Game restarted.");
    }
    
    /**
     * 检查游戏是否正在运行
     * @return true if game is running
     */
    public boolean isRunning() {
        return running;
    }
    
    /**
     * 获取游戏窗口
     * @return 游戏窗口
     */
    public JFrame getGameWindow() {
        return gameWindow;
    }
    
    /**
     * 获取游戏面板
     * @return 游戏面板
     */
    public GamePanel getGamePanel() {
        return gamePanel;
    }
    
    /**
     * 获取状态管理器
     * @return 状态管理器
     */
    public StateManager getStateManager() {
        return stateManager;
    }
    
    /**
     * 获取输入管理器
     * @return 输入管理器
     */
    public InputManager getInputManager() {
        return inputManager;
    }
    
    /**
     * 获取游戏循环
     * @return 游戏循环
     */
    public GameLoop getGameLoop() {
        return gameLoop;
    }
    
    /**
     * 切换全屏模式
     */
    public void toggleFullscreen() {
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        
        if (gd.isFullScreenSupported()) {
            if (gd.getFullScreenWindow() == null) {
                // 进入全屏
                gameWindow.dispose();
                gameWindow.setUndecorated(true);
                gameWindow.setVisible(true);
                gd.setFullScreenWindow(gameWindow);
                System.out.println("Entered fullscreen mode");
            } else {
                // 退出全屏
                gd.setFullScreenWindow(null);
                gameWindow.dispose();
                gameWindow.setUndecorated(false);
                gameWindow.setVisible(true);
                gameWindow.setLocationRelativeTo(null);
                System.out.println("Exited fullscreen mode");
            }
        } else {
            System.out.println("Fullscreen not supported on this system");
        }
    }
    
    /**
     * 设置游戏窗口标题
     * @param title 新标题
     */
    public void setTitle(String title) {
        if (gameWindow != null) {
            gameWindow.setTitle(title);
        }
    }
    
    /**
     * 显示错误对话框
     * @param title 错误标题
     * @param message 错误消息
     */
    public void showError(String title, String message) {
        JOptionPane.showMessageDialog(
            gameWindow,
            message,
            title,
            JOptionPane.ERROR_MESSAGE
        );
    }
    
    /**
     * 显示信息对话框
     * @param title 信息标题
     * @param message 信息消息
     */
    public void showInfo(String title, String message) {
        JOptionPane.showMessageDialog(
            gameWindow,
            message,
            title,
            JOptionPane.INFORMATION_MESSAGE
        );
    }
}
