package com.contra.levels;

import com.contra.utils.Constants;

import java.awt.*;

/**
 * 关卡基类
 */
public class Level {
    protected int levelNumber;
    protected boolean completed;
    protected long startTime;
    protected Color backgroundColor;
    
    public Level(int levelNumber) {
        this.levelNumber = levelNumber;
        this.completed = false;
        this.startTime = System.currentTimeMillis();
        this.backgroundColor = Constants.BACKGROUND_COLOR;
    }
    
    public void update(long deltaTime) {
        // 关卡更新逻辑
    }
    
    public void render(Graphics2D g) {
        // 绘制背景
        g.setColor(backgroundColor);
        g.fillRect(0, 0, Constants.GAME_WIDTH, Constants.GAME_HEIGHT);
        
        // 绘制地面
        g.setColor(Color.DARK_GRAY);
        g.fillRect(0, Constants.GROUND_Y, Constants.GAME_WIDTH, Constants.GAME_HEIGHT - Constants.GROUND_Y);
    }
    
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public int getLevelNumber() { return levelNumber; }
}
