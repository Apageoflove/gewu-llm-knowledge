package com.contra.entities;

import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;

/**
 * 游戏实体基类
 * 所有游戏对象的基础类，包含位置、速度、生命值等基本属性
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public abstract class Entity {
    
    /** 实体位置 */
    protected Vector2D position;
    
    /** 实体速度 */
    protected Vector2D velocity;
    
    /** 实体宽度 */
    protected int width;
    
    /** 实体高度 */
    protected int height;
    
    /** 实体类型 */
    protected Constants.EntityType type;
    
    /** 是否存活 */
    protected boolean alive;
    
    /** 生命值 */
    protected int health;
    
    /** 最大生命值 */
    protected int maxHealth;
    
    /** 是否在地面上 */
    protected boolean onGround;
    
    /** 面向方向（1为右，-1为左） */
    protected int direction;
    
    /** 实体颜色 */
    protected Color color;
    
    /**
     * 构造函数
     * @param position 初始位置
     * @param type 实体类型
     */
    public Entity(Vector2D position, Constants.EntityType type) {
        this.position = new Vector2D(position);
        this.velocity = new Vector2D(0, 0);
        this.type = type;
        this.alive = true;
        this.health = 1;
        this.maxHealth = 1;
        this.onGround = false;
        this.direction = 1;
        this.color = Color.WHITE;
        
        // 根据类型设置默认尺寸
        setDefaultSize();
    }
    
    /**
     * 根据实体类型设置默认尺寸
     */
    protected void setDefaultSize() {
        switch (type) {
            case PLAYER:
                this.width = Constants.PLAYER_WIDTH;
                this.height = Constants.PLAYER_HEIGHT;
                break;
            case ENEMY_SOLDIER:
            case ENEMY_FLYER:
                this.width = Constants.ENEMY_WIDTH;
                this.height = Constants.ENEMY_HEIGHT;
                break;
            case BULLET_PLAYER:
            case BULLET_ENEMY:
                this.width = Constants.BULLET_WIDTH;
                this.height = Constants.BULLET_HEIGHT;
                break;
            case POWERUP_WEAPON:
            case POWERUP_LIFE:
            case POWERUP_SCORE:
                this.width = Constants.POWERUP_WIDTH;
                this.height = Constants.POWERUP_HEIGHT;
                break;
            default:
                this.width = 32;
                this.height = 32;
                break;
        }
    }
    
    /**
     * 更新实体（每帧调用）
     * @param deltaTime 时间差（毫秒）
     */
    public abstract void update(long deltaTime);
    
    /**
     * 渲染实体
     * @param g 图形上下文
     */
    public abstract void render(Graphics2D g);
    
    /**
     * 应用重力
     * @param deltaTime 时间差
     */
    protected void applyGravity(long deltaTime) {
        if (!onGround) {
            velocity.y += Constants.GRAVITY * (deltaTime / 16.0); // 标准化到60FPS
            
            // 限制最大下落速度
            if (velocity.y > Constants.MAX_FALL_SPEED) {
                velocity.y = Constants.MAX_FALL_SPEED;
            }
        }
    }
    
    /**
     * 更新位置
     * @param deltaTime 时间差
     */
    protected void updatePosition(long deltaTime) {
        double factor = deltaTime / 16.0; // 标准化到60FPS
        
        // 更新位置
        position.x += velocity.x * factor;
        position.y += velocity.y * factor;
        
        // 检查地面碰撞
        checkGroundCollision();
        
        // 检查边界
        checkBounds();
    }
    
    /**
     * 检查地面碰撞
     */
    protected void checkGroundCollision() {
        if (position.y + height >= Constants.GROUND_Y) {
            position.y = Constants.GROUND_Y - height;
            velocity.y = 0;
            onGround = true;
        } else {
            onGround = false;
        }
    }
    
    /**
     * 检查边界
     */
    protected void checkBounds() {
        // 左边界
        if (position.x < 0) {
            position.x = 0;
            velocity.x = 0;
        }
        
        // 右边界
        if (position.x + width > Constants.GAME_WIDTH) {
            position.x = Constants.GAME_WIDTH - width;
            velocity.x = 0;
        }
        
        // 上边界
        if (position.y < 0) {
            position.y = 0;
            velocity.y = 0;
        }
        
        // 下边界（掉出屏幕）
        if (position.y > Constants.GAME_HEIGHT) {
            destroy();
        }
    }
    
    /**
     * 受到伤害
     * @param damage 伤害值
     */
    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            health = 0;
            destroy();
        }
    }
    
    /**
     * 治疗
     * @param healAmount 治疗量
     */
    public void heal(int healAmount) {
        health += healAmount;
        if (health > maxHealth) {
            health = maxHealth;
        }
    }
    
    /**
     * 销毁实体
     */
    public void destroy() {
        alive = false;
    }
    
    /**
     * 获取碰撞边界
     * @return 碰撞边界矩形
     */
    public Rectangle getBounds() {
        return new Rectangle((int)position.x, (int)position.y, width, height);
    }
    
    /**
     * 获取中心点
     * @return 中心点坐标
     */
    public Vector2D getCenter() {
        return new Vector2D(position.x + width / 2.0, position.y + height / 2.0);
    }
    
    /**
     * 检查与其他实体的碰撞
     * @param other 其他实体
     * @return true如果发生碰撞
     */
    public boolean intersects(Entity other) {
        return getBounds().intersects(other.getBounds());
    }
    
    /**
     * 计算与其他实体的距离
     * @param other 其他实体
     * @return 距离
     */
    public double distanceTo(Entity other) {
        return getCenter().distance(other.getCenter());
    }
    
    /**
     * 设置位置
     * @param x X坐标
     * @param y Y坐标
     */
    public void setPosition(double x, double y) {
        this.position.set(x, y);
    }
    
    /**
     * 设置位置
     * @param position 位置向量
     */
    public void setPosition(Vector2D position) {
        this.position.set(position);
    }
    
    /**
     * 设置速度
     * @param x X速度
     * @param y Y速度
     */
    public void setVelocity(double x, double y) {
        this.velocity.set(x, y);
    }
    
    /**
     * 设置速度
     * @param velocity 速度向量
     */
    public void setVelocity(Vector2D velocity) {
        this.velocity.set(velocity);
    }
    
    /**
     * 添加速度
     * @param x X速度增量
     * @param y Y速度增量
     */
    public void addVelocity(double x, double y) {
        this.velocity.x += x;
        this.velocity.y += y;
    }
    
    /**
     * 设置生命值
     * @param health 生命值
     */
    public void setHealth(int health) {
        this.health = Math.max(0, Math.min(health, maxHealth));
        if (this.health == 0) {
            destroy();
        }
    }
    
    /**
     * 设置最大生命值
     * @param maxHealth 最大生命值
     */
    public void setMaxHealth(int maxHealth) {
        this.maxHealth = Math.max(1, maxHealth);
        if (this.health > this.maxHealth) {
            this.health = this.maxHealth;
        }
    }
    
    // Getters
    public Vector2D getPosition() { return new Vector2D(position); }
    public Vector2D getVelocity() { return new Vector2D(velocity); }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public Constants.EntityType getType() { return type; }
    public boolean isAlive() { return alive; }
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public boolean isOnGround() { return onGround; }
    public int getDirection() { return direction; }
    public Color getColor() { return color; }
    public double getX() { return position.x; }
    public double getY() { return position.y; }
    public double getVX() { return velocity.x; }
    public double getVY() { return velocity.y; }
    
    // Setters
    public void setWidth(int width) { this.width = Math.max(1, width); }
    public void setHeight(int height) { this.height = Math.max(1, height); }
    public void setDirection(int direction) { this.direction = direction; }
    public void setColor(Color color) { this.color = color; }
    public void setOnGround(boolean onGround) { this.onGround = onGround; }
    
    @Override
    public String toString() {
        return String.format("%s at (%.1f, %.1f), Health: %d/%d, Alive: %s", 
                type, position.x, position.y, health, maxHealth, alive);
    }
}
