package com.contra.entities;

import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;

/**
 * 玩家角色类
 */
public class Player extends Entity {
    private int playerNumber;
    private long lastFireTime;
    private Constants.WeaponType currentWeapon;
    
    public Player(Vector2D position, int playerNumber) {
        super(position, Constants.EntityType.PLAYER);
        this.playerNumber = playerNumber;
        this.health = Constants.PLAYER_INITIAL_LIVES;
        this.maxHealth = Constants.PLAYER_INITIAL_LIVES;
        this.lastFireTime = 0;
        this.currentWeapon = Constants.WeaponType.NORMAL;
        this.color = playerNumber == 1 ? Constants.PLAYER_COLOR : Constants.PLAYER2_COLOR;
    }
    
    @Override
    public void update(long deltaTime) {
        applyGravity(deltaTime);
        updatePosition(deltaTime);
    }
    
    @Override
    public void render(Graphics2D g) {
        g.setColor(color);
        g.fillRect((int)position.x, (int)position.y, width, height);
        
        // 绘制生命值
        g.setColor(Color.WHITE);
        g.drawString("P" + playerNumber + " Lives: " + health, (int)position.x, (int)position.y - 5);
    }
    
    public void moveLeft() {
        velocity.x = -Constants.PLAYER_SPEED;
        direction = -1;
    }
    
    public void moveRight() {
        velocity.x = Constants.PLAYER_SPEED;
        direction = 1;
    }
    
    public void stopMoving() {
        velocity.x = 0;
    }
    
    public void jump() {
        if (onGround) {
            velocity.y = Constants.PLAYER_JUMP_FORCE;
            onGround = false;
        }
    }
    
    public Bullet fire() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFireTime >= Constants.BULLET_FIRE_INTERVAL) {
            lastFireTime = currentTime;
            
            Vector2D bulletPos = new Vector2D(
                position.x + width / 2,
                position.y + height / 2
            );
            
            return new Bullet(bulletPos, Constants.EntityType.BULLET_PLAYER, direction);
        }
        return null;
    }
    
    public int getPlayerNumber() { return playerNumber; }
    public Constants.WeaponType getCurrentWeapon() { return currentWeapon; }
    public void setCurrentWeapon(Constants.WeaponType weapon) { this.currentWeapon = weapon; }
}
