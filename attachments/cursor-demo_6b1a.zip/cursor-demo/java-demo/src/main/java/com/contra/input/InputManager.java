package com.contra.input;

import com.contra.core.StateManager;
import com.contra.utils.Constants;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

/**
 * 输入管理器
 * 负责处理键盘输入和将输入转换为游戏命令
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class InputManager implements KeyListener {
    
    /** 当前按下的键集合 */
    private final Set<Integer> pressedKeys;
    
    /** 刚刚按下的键集合（单次触发） */
    private final Set<Integer> justPressedKeys;
    
    /** 刚刚释放的键集合（单次触发） */
    private final Set<Integer> justReleasedKeys;
    
    /** 状态管理器引用 */
    private StateManager stateManager;
    
    /**
     * 构造函数
     */
    public InputManager() {
        this.pressedKeys = new HashSet<>();
        this.justPressedKeys = new HashSet<>();
        this.justReleasedKeys = new HashSet<>();
    }
    
    /**
     * 设置状态管理器
     * @param stateManager 状态管理器
     */
    public void setStateManager(StateManager stateManager) {
        this.stateManager = stateManager;
    }
    
    /**
     * 更新输入状态（每帧调用）
     */
    public void update() {
        // 清理单次触发的键
        justPressedKeys.clear();
        justReleasedKeys.clear();
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        // 如果这个键之前没有被按下，那么这是一次新的按下
        if (!pressedKeys.contains(keyCode)) {
            pressedKeys.add(keyCode);
            justPressedKeys.add(keyCode);
            
            // 处理按键按下事件
            handleKeyPressed(keyCode);
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        if (pressedKeys.contains(keyCode)) {
            pressedKeys.remove(keyCode);
            justReleasedKeys.add(keyCode);
            
            // 处理按键释放事件
            handleKeyReleased(keyCode);
        }
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        // 不需要处理字符输入
    }
    
    /**
     * 处理按键按下事件
     * @param keyCode 按键代码
     */
    private void handleKeyPressed(int keyCode) {
        if (stateManager == null) return;
        
        Constants.GameState currentState = stateManager.getCurrentState();
        
        switch (currentState) {
            case MENU:
                handleMenuKeyPressed(keyCode);
                break;
            case PLAYING:
                handleGameKeyPressed(keyCode);
                break;
            case PAUSED:
                handlePauseKeyPressed(keyCode);
                break;
            case GAME_OVER:
                handleGameOverKeyPressed(keyCode);
                break;
            case LEVEL_COMPLETE:
                handleLevelCompleteKeyPressed(keyCode);
                break;
            case SETTINGS:
                handleSettingsKeyPressed(keyCode);
                break;
        }
    }
    
    /**
     * 处理按键释放事件
     * @param keyCode 按键代码
     */
    private void handleKeyReleased(int keyCode) {
        // 处理按键释放逻辑
    }
    
    /**
     * 处理菜单状态下的按键
     * @param keyCode 按键代码
     */
    private void handleMenuKeyPressed(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_ENTER:
                // 开始单人游戏
                stateManager.startNewGame(false);
                break;
            case KeyEvent.VK_2:
                // 开始双人游戏
                stateManager.startNewGame(true);
                break;
            case KeyEvent.VK_S:
                // 进入设置
                stateManager.setGameState(Constants.GameState.SETTINGS);
                break;
            case KeyEvent.VK_ESCAPE:
            case Constants.SYSTEM_KEYS.QUIT:
                // 退出游戏
                System.exit(0);
                break;
        }
    }
    
    /**
     * 处理游戏状态下的按键
     * @param keyCode 按键代码
     */
    private void handleGameKeyPressed(int keyCode) {
        switch (keyCode) {
            case Constants.SYSTEM_KEYS.PAUSE:
                // 暂停游戏
                stateManager.pauseGame();
                break;
            case Constants.SYSTEM_KEYS.RESTART:
                // 重启游戏
                stateManager.startNewGame(stateManager.isTwoPlayerMode());
                break;
        }
    }
    
    /**
     * 处理暂停状态下的按键
     * @param keyCode 按键代码
     */
    private void handlePauseKeyPressed(int keyCode) {
        switch (keyCode) {
            case Constants.SYSTEM_KEYS.PAUSE:
            case KeyEvent.VK_ENTER:
                // 恢复游戏
                stateManager.resumeGame();
                break;
            case Constants.SYSTEM_KEYS.RESTART:
                // 重启游戏
                stateManager.startNewGame(stateManager.isTwoPlayerMode());
                break;
            case KeyEvent.VK_M:
                // 返回主菜单
                stateManager.setGameState(Constants.GameState.MENU);
                break;
        }
    }
    
    /**
     * 处理游戏结束状态下的按键
     * @param keyCode 按键代码
     */
    private void handleGameOverKeyPressed(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_ENTER:
            case Constants.SYSTEM_KEYS.RESTART:
                // 重新开始游戏
                stateManager.startNewGame(stateManager.isTwoPlayerMode());
                break;
            case KeyEvent.VK_M:
                // 返回主菜单
                stateManager.setGameState(Constants.GameState.MENU);
                break;
            case Constants.SYSTEM_KEYS.QUIT:
                // 退出游戏
                System.exit(0);
                break;
        }
    }
    
    /**
     * 处理关卡完成状态下的按键
     * @param keyCode 按键代码
     */
    private void handleLevelCompleteKeyPressed(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_ENTER:
                // 继续下一关
                int nextLevel = stateManager.getCurrentLevelNumber() + 1;
                if (nextLevel <= Constants.TOTAL_LEVELS) {
                    stateManager.loadLevel(nextLevel);
                    stateManager.setGameState(Constants.GameState.PLAYING);
                } else {
                    // 游戏通关
                    stateManager.setGameState(Constants.GameState.GAME_OVER);
                }
                break;
            case KeyEvent.VK_M:
                // 返回主菜单
                stateManager.setGameState(Constants.GameState.MENU);
                break;
        }
    }
    
    /**
     * 处理设置状态下的按键
     * @param keyCode 按键代码
     */
    private void handleSettingsKeyPressed(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_ESCAPE:
            case KeyEvent.VK_M:
                // 返回主菜单
                stateManager.setGameState(Constants.GameState.MENU);
                break;
        }
    }
    
    /**
     * 检查键是否被按下
     * @param keyCode 按键代码
     * @return true如果键被按下
     */
    public boolean isKeyPressed(int keyCode) {
        return pressedKeys.contains(keyCode);
    }
    
    /**
     * 检查键是否刚刚被按下（单次触发）
     * @param keyCode 按键代码
     * @return true如果键刚刚被按下
     */
    public boolean isKeyJustPressed(int keyCode) {
        return justPressedKeys.contains(keyCode);
    }
    
    /**
     * 检查键是否刚刚被释放（单次触发）
     * @param keyCode 按键代码
     * @return true如果键刚刚被释放
     */
    public boolean isKeyJustReleased(int keyCode) {
        return justReleasedKeys.contains(keyCode);
    }
    
    /**
     * 检查玩家1的移动输入
     * @return 移动方向向量 (-1, 0, 1)
     */
    public int getPlayer1HorizontalInput() {
        int horizontal = 0;
        if (isKeyPressed(Constants.PLAYER1_KEYS.LEFT)) {
            horizontal -= 1;
        }
        if (isKeyPressed(Constants.PLAYER1_KEYS.RIGHT)) {
            horizontal += 1;
        }
        return horizontal;
    }
    
    /**
     * 检查玩家1的垂直输入
     * @return 垂直方向向量 (-1, 0, 1)
     */
    public int getPlayer1VerticalInput() {
        int vertical = 0;
        if (isKeyPressed(Constants.PLAYER1_KEYS.UP)) {
            vertical -= 1;
        }
        if (isKeyPressed(Constants.PLAYER1_KEYS.DOWN)) {
            vertical += 1;
        }
        return vertical;
    }
    
    /**
     * 检查玩家1是否按下射击键
     * @return true如果按下射击键
     */
    public boolean isPlayer1Firing() {
        return isKeyPressed(Constants.PLAYER1_KEYS.FIRE);
    }
    
    /**
     * 检查玩家1是否刚刚按下跳跃键
     * @return true如果刚刚按下跳跃键
     */
    public boolean isPlayer1Jumping() {
        return isKeyJustPressed(Constants.PLAYER1_KEYS.UP);
    }
    
    /**
     * 检查玩家2的移动输入
     * @return 移动方向向量 (-1, 0, 1)
     */
    public int getPlayer2HorizontalInput() {
        int horizontal = 0;
        if (isKeyPressed(Constants.PLAYER2_KEYS.LEFT)) {
            horizontal -= 1;
        }
        if (isKeyPressed(Constants.PLAYER2_KEYS.RIGHT)) {
            horizontal += 1;
        }
        return horizontal;
    }
    
    /**
     * 检查玩家2的垂直输入
     * @return 垂直方向向量 (-1, 0, 1)
     */
    public int getPlayer2VerticalInput() {
        int vertical = 0;
        if (isKeyPressed(Constants.PLAYER2_KEYS.UP)) {
            vertical -= 1;
        }
        if (isKeyPressed(Constants.PLAYER2_KEYS.DOWN)) {
            vertical += 1;
        }
        return vertical;
    }
    
    /**
     * 检查玩家2是否按下射击键
     * @return true如果按下射击键
     */
    public boolean isPlayer2Firing() {
        return isKeyPressed(Constants.PLAYER2_KEYS.FIRE);
    }
    
    /**
     * 检查玩家2是否刚刚按下跳跃键
     * @return true如果刚刚按下跳跃键
     */
    public boolean isPlayer2Jumping() {
        return isKeyJustPressed(Constants.PLAYER2_KEYS.UP);
    }
    
    /**
     * 获取所有当前按下的键
     * @return 按下的键集合
     */
    public Set<Integer> getPressedKeys() {
        return new HashSet<>(pressedKeys);
    }
    
    /**
     * 清理所有输入状态
     */
    public void cleanup() {
        pressedKeys.clear();
        justPressedKeys.clear();
        justReleasedKeys.clear();
        stateManager = null;
        
        System.out.println("InputManager cleaned up");
    }
    
    /**
     * 获取调试信息
     * @return 调试信息字符串
     */
    public String getDebugInfo() {
        return String.format("Pressed: %d, Just Pressed: %d, Just Released: %d", 
                pressedKeys.size(), justPressedKeys.size(), justReleasedKeys.size());
    }
}
