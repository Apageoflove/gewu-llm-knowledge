package com.contra.utils;

/**
 * 2D向量数学运算类
 * 提供向量的基本数学运算功能
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class Vector2D {
    
    /** X坐标 */
    public double x;
    
    /** Y坐标 */
    public double y;
    
    /**
     * 默认构造函数，创建零向量
     */
    public Vector2D() {
        this(0, 0);
    }
    
    /**
     * 构造函数
     * @param x X坐标
     * @param y Y坐标
     */
    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    /**
     * 复制构造函数
     * @param other 要复制的向量
     */
    public Vector2D(Vector2D other) {
        this.x = other.x;
        this.y = other.y;
    }
    
    /**
     * 设置向量的值
     * @param x X坐标
     * @param y Y坐标
     * @return 当前向量实例
     */
    public Vector2D set(double x, double y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    /**
     * 复制另一个向量的值
     * @param other 要复制的向量
     * @return 当前向量实例
     */
    public Vector2D set(Vector2D other) {
        this.x = other.x;
        this.y = other.y;
        return this;
    }
    
    /**
     * 向量加法
     * @param other 要相加的向量
     * @return 新的向量实例
     */
    public Vector2D add(Vector2D other) {
        return new Vector2D(this.x + other.x, this.y + other.y);
    }
    
    /**
     * 向量加法（修改当前向量）
     * @param other 要相加的向量
     * @return 当前向量实例
     */
    public Vector2D addSelf(Vector2D other) {
        this.x += other.x;
        this.y += other.y;
        return this;
    }
    
    /**
     * 向量减法
     * @param other 要相减的向量
     * @return 新的向量实例
     */
    public Vector2D subtract(Vector2D other) {
        return new Vector2D(this.x - other.x, this.y - other.y);
    }
    
    /**
     * 向量减法（修改当前向量）
     * @param other 要相减的向量
     * @return 当前向量实例
     */
    public Vector2D subtractSelf(Vector2D other) {
        this.x -= other.x;
        this.y -= other.y;
        return this;
    }
    
    /**
     * 向量乘以标量
     * @param scalar 标量值
     * @return 新的向量实例
     */
    public Vector2D multiply(double scalar) {
        return new Vector2D(this.x * scalar, this.y * scalar);
    }
    
    /**
     * 向量乘以标量（修改当前向量）
     * @param scalar 标量值
     * @return 当前向量实例
     */
    public Vector2D multiplySelf(double scalar) {
        this.x *= scalar;
        this.y *= scalar;
        return this;
    }
    
    /**
     * 向量除以标量
     * @param scalar 标量值
     * @return 新的向量实例
     */
    public Vector2D divide(double scalar) {
        if (scalar == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return new Vector2D(this.x / scalar, this.y / scalar);
    }
    
    /**
     * 向量除以标量（修改当前向量）
     * @param scalar 标量值
     * @return 当前向量实例
     */
    public Vector2D divideSelf(double scalar) {
        if (scalar == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        this.x /= scalar;
        this.y /= scalar;
        return this;
    }
    
    /**
     * 计算向量的长度（模）
     * @return 向量长度
     */
    public double length() {
        return Math.sqrt(x * x + y * y);
    }
    
    /**
     * 计算向量长度的平方
     * @return 向量长度的平方
     */
    public double lengthSquared() {
        return x * x + y * y;
    }
    
    /**
     * 向量归一化
     * @return 新的单位向量
     */
    public Vector2D normalize() {
        double len = length();
        if (len == 0) {
            return new Vector2D(0, 0);
        }
        return new Vector2D(x / len, y / len);
    }
    
    /**
     * 向量归一化（修改当前向量）
     * @return 当前向量实例
     */
    public Vector2D normalizeSelf() {
        double len = length();
        if (len != 0) {
            this.x /= len;
            this.y /= len;
        }
        return this;
    }
    
    /**
     * 计算两个向量的点积
     * @param other 另一个向量
     * @return 点积值
     */
    public double dot(Vector2D other) {
        return this.x * other.x + this.y * other.y;
    }
    
    /**
     * 计算两个向量的叉积（2D中返回标量）
     * @param other 另一个向量
     * @return 叉积值
     */
    public double cross(Vector2D other) {
        return this.x * other.y - this.y * other.x;
    }
    
    /**
     * 计算两个向量之间的距离
     * @param other 另一个向量
     * @return 距离值
     */
    public double distance(Vector2D other) {
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * 计算两个向量之间距离的平方
     * @param other 另一个向量
     * @return 距离的平方
     */
    public double distanceSquared(Vector2D other) {
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return dx * dx + dy * dy;
    }
    
    /**
     * 计算向量的角度（弧度）
     * @return 角度值（弧度）
     */
    public double angle() {
        return Math.atan2(y, x);
    }
    
    /**
     * 计算两个向量之间的角度（弧度）
     * @param other 另一个向量
     * @return 角度值（弧度）
     */
    public double angleBetween(Vector2D other) {
        double dot = this.dot(other);
        double len1 = this.length();
        double len2 = other.length();
        
        if (len1 == 0 || len2 == 0) {
            return 0;
        }
        
        return Math.acos(dot / (len1 * len2));
    }
    
    /**
     * 向量旋转
     * @param angle 旋转角度（弧度）
     * @return 新的旋转后的向量
     */
    public Vector2D rotate(double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        return new Vector2D(
            x * cos - y * sin,
            x * sin + y * cos
        );
    }
    
    /**
     * 向量旋转（修改当前向量）
     * @param angle 旋转角度（弧度）
     * @return 当前向量实例
     */
    public Vector2D rotateSelf(double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double newX = x * cos - y * sin;
        double newY = x * sin + y * cos;
        this.x = newX;
        this.y = newY;
        return this;
    }
    
    /**
     * 向量线性插值
     * @param other 目标向量
     * @param t 插值参数（0-1）
     * @return 插值结果向量
     */
    public Vector2D lerp(Vector2D other, double t) {
        return new Vector2D(
            x + (other.x - x) * t,
            y + (other.y - y) * t
        );
    }
    
    /**
     * 限制向量的长度
     * @param maxLength 最大长度
     * @return 新的限制长度后的向量
     */
    public Vector2D limit(double maxLength) {
        double len = length();
        if (len > maxLength) {
            return normalize().multiply(maxLength);
        }
        return new Vector2D(this);
    }
    
    /**
     * 限制向量的长度（修改当前向量）
     * @param maxLength 最大长度
     * @return 当前向量实例
     */
    public Vector2D limitSelf(double maxLength) {
        double len = length();
        if (len > maxLength) {
            normalizeSelf().multiplySelf(maxLength);
        }
        return this;
    }
    
    /**
     * 检查向量是否为零向量
     * @return true如果是零向量
     */
    public boolean isZero() {
        return x == 0 && y == 0;
    }
    
    /**
     * 创建向量的副本
     * @return 新的向量实例
     */
    public Vector2D copy() {
        return new Vector2D(this);
    }
    
    /**
     * 静态方法：从角度创建单位向量
     * @param angle 角度（弧度）
     * @return 单位向量
     */
    public static Vector2D fromAngle(double angle) {
        return new Vector2D(Math.cos(angle), Math.sin(angle));
    }
    
    /**
     * 静态方法：随机单位向量
     * @return 随机方向的单位向量
     */
    public static Vector2D random() {
        double angle = Math.random() * 2 * Math.PI;
        return fromAngle(angle);
    }
    
    /**
     * 静态方法：零向量
     * @return 零向量
     */
    public static Vector2D zero() {
        return new Vector2D(0, 0);
    }
    
    /**
     * 静态方法：单位向量（右）
     * @return 右方向单位向量
     */
    public static Vector2D right() {
        return new Vector2D(1, 0);
    }
    
    /**
     * 静态方法：单位向量（左）
     * @return 左方向单位向量
     */
    public static Vector2D left() {
        return new Vector2D(-1, 0);
    }
    
    /**
     * 静态方法：单位向量（上）
     * @return 上方向单位向量
     */
    public static Vector2D up() {
        return new Vector2D(0, -1);
    }
    
    /**
     * 静态方法：单位向量（下）
     * @return 下方向单位向量
     */
    public static Vector2D down() {
        return new Vector2D(0, 1);
    }
    
    @Override
    public String toString() {
        return String.format("Vector2D(%.2f, %.2f)", x, y);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vector2D vector2D = (Vector2D) obj;
        return Double.compare(vector2D.x, x) == 0 && Double.compare(vector2D.y, y) == 0;
    }
    
    @Override
    public int hashCode() {
        long temp = Double.doubleToLongBits(x);
        int result = (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(y);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
}
