package com.contra.entities;

import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;

/**
 * 道具类
 */
public class PowerUp extends Entity {
    private long creationTime;
    
    public PowerUp(Vector2D position, Constants.EntityType type) {
        super(position, type);
        this.creationTime = System.currentTimeMillis();
        this.color = Color.YELLOW;
    }
    
    @Override
    public void update(long deltaTime) {
        // 检查是否过期
        if (System.currentTimeMillis() - creationTime > Constants.POWERUP_LIFETIME) {
            destroy();
        }
        
        applyGravity(deltaTime);
        updatePosition(deltaTime);
    }
    
    @Override
    public void render(Graphics2D g) {
        g.setColor(color);
        g.fillOval((int)position.x, (int)position.y, width, height);
        
        // 绘制简单的标识
        g.setColor(Color.BLACK);
        g.drawString("P", (int)position.x + 5, (int)position.y + 15);
    }
    
    public void apply(Player player) {
        switch (type) {
            case POWERUP_WEAPON:
                // 武器升级逻辑
                break;
            case POWERUP_LIFE:
                player.heal(1);
                break;
            case POWERUP_SCORE:
                // 分数加成
                break;
        }
    }
}
