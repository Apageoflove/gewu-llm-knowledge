package com.contra.core;

import com.contra.ui.GamePanel;
import com.contra.utils.Constants;

/**
 * 游戏主循环类
 * 负责控制游戏的更新和渲染循环，维持稳定的帧率
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public class GameLoop implements Runnable {
    
    /** 游戏面板 */
    private final GamePanel gamePanel;
    
    /** 状态管理器 */
    private final StateManager stateManager;
    
    /** 游戏循环线程 */
    private Thread gameThread;
    
    /** 循环是否运行 */
    private volatile boolean running;
    
    /** 循环是否暂停 */
    private volatile boolean paused;
    
    /** FPS计数器 */
    private int fps;
    
    /** 更新计数器 */
    private int ups;
    
    /** 上一次FPS更新时间 */
    private long lastFpsTime;
    
    /** FPS计数 */
    private int fpsCount;
    
    /** UPS计数 */
    private int upsCount;
    
    /**
     * 构造函数
     * @param gamePanel 游戏面板
     * @param stateManager 状态管理器
     */
    public GameLoop(GamePanel gamePanel, StateManager stateManager) {
        this.gamePanel = gamePanel;
        this.stateManager = stateManager;
        this.running = false;
        this.paused = false;
        this.fps = 0;
        this.ups = 0;
        this.lastFpsTime = System.currentTimeMillis();
        this.fpsCount = 0;
        this.upsCount = 0;
    }
    
    /**
     * 启动游戏循环
     */
    public void start() {
        if (running) {
            System.out.println("Game loop is already running!");
            return;
        }
        
        running = true;
        gameThread = new Thread(this, "GameLoop");
        gameThread.start();
        
        System.out.println("Game loop started");
    }
    
    /**
     * 停止游戏循环
     */
    public void stop() {
        if (!running) {
            return;
        }
        
        running = false;
        
        try {
            if (gameThread != null) {
                gameThread.join(1000); // 等待最多1秒
            }
        } catch (InterruptedException e) {
            System.err.println("Error stopping game loop: " + e.getMessage());
            Thread.currentThread().interrupt();
        }
        
        System.out.println("Game loop stopped");
    }
    
    /**
     * 暂停游戏循环
     */
    public void pause() {
        paused = true;
        System.out.println("Game loop paused");
    }
    
    /**
     * 恢复游戏循环
     */
    public void resume() {
        paused = false;
        synchronized (this) {
            notifyAll();
        }
        System.out.println("Game loop resumed");
    }
    
    /**
     * 游戏循环主方法
     */
    @Override
    public void run() {
        long lastTime = System.nanoTime();
        long lastFpsUpdateTime = System.currentTimeMillis();
        
        final double TARGET_UPS = 60.0; // 目标更新频率
        final double nsPerUpdate = 1_000_000_000.0 / TARGET_UPS;
        
        double delta = 0;
        
        System.out.println("Game loop running at " + TARGET_UPS + " UPS");
        
        while (running) {
            try {
                // 检查暂停状态
                checkPauseState();
                
                long currentTime = System.nanoTime();
                delta += (currentTime - lastTime) / nsPerUpdate;
                lastTime = currentTime;
                
                // 更新游戏逻辑
                while (delta >= 1) {
                    update();
                    delta--;
                    upsCount++;
                }
                
                // 渲染游戏画面
                render();
                fpsCount++;
                
                // 更新FPS和UPS统计
                updateStats(lastFpsUpdateTime);
                lastFpsUpdateTime = updateFpsStats(lastFpsUpdateTime);
                
                // 短暂休眠以避免CPU过度使用
                Thread.sleep(1);
                
            } catch (InterruptedException e) {
                System.err.println("Game loop interrupted: " + e.getMessage());
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("Error in game loop: " + e.getMessage());
                e.printStackTrace();
                // 继续运行，但记录错误
            }
        }
        
        System.out.println("Game loop ended");
    }
    
    /**
     * 检查暂停状态
     */
    private void checkPauseState() throws InterruptedException {
        while (paused && running) {
            synchronized (this) {
                wait();
            }
        }
    }
    
    /**
     * 更新游戏逻辑
     */
    private void update() {
        if (!paused && stateManager != null) {
            stateManager.update();
        }
    }
    
    /**
     * 渲染游戏画面
     */
    private void render() {
        if (gamePanel != null) {
            gamePanel.repaint();
        }
    }
    
    /**
     * 更新统计信息
     * @param lastFpsUpdateTime 上次FPS更新时间
     */
    private void updateStats(long lastFpsUpdateTime) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFpsUpdateTime >= 1000) {
            // 每秒更新一次统计信息
            updateFpsAndUps();
        }
    }
    
    /**
     * 更新FPS统计
     * @param lastFpsUpdateTime 上次更新时间
     * @return 新的更新时间
     */
    private long updateFpsStats(long lastFpsUpdateTime) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFpsUpdateTime >= 1000) {
            updateFpsAndUps();
            return currentTime;
        }
        return lastFpsUpdateTime;
    }
    
    /**
     * 更新FPS和UPS值
     */
    private void updateFpsAndUps() {
        fps = fpsCount;
        ups = upsCount;
        fpsCount = 0;
        upsCount = 0;
        
        // 在调试模式下输出性能信息
        if (Constants.DEBUG_MODE && Constants.SHOW_FPS) {
            System.out.println("FPS: " + fps + ", UPS: " + ups);
        }
        
        // 如果性能太低，发出警告
        if (fps < Constants.TARGET_FPS * 0.8) {
            System.out.println("Warning: Low FPS detected: " + fps);
        }
    }
    
    /**
     * 获取当前FPS
     * @return 当前FPS
     */
    public int getFps() {
        return fps;
    }
    
    /**
     * 获取当前UPS
     * @return 当前UPS
     */
    public int getUps() {
        return ups;
    }
    
    /**
     * 检查游戏循环是否正在运行
     * @return true if running
     */
    public boolean isRunning() {
        return running;
    }
    
    /**
     * 检查游戏循环是否暂停
     * @return true if paused
     */
    public boolean isPaused() {
        return paused;
    }
    
    /**
     * 获取游戏线程
     * @return 游戏线程
     */
    public Thread getGameThread() {
        return gameThread;
    }
    
    /**
     * 设置目标FPS（用于动态调整性能）
     * @param targetFps 目标FPS
     */
    public void setTargetFps(int targetFps) {
        if (targetFps > 0 && targetFps <= 120) {
            // 这里可以实现动态FPS调整逻辑
            System.out.println("Target FPS set to: " + targetFps);
        }
    }
    
    /**
     * 获取性能信息字符串
     * @return 性能信息
     */
    public String getPerformanceInfo() {
        return String.format("FPS: %d, UPS: %d", fps, ups);
    }
    
    /**
     * 强制进行垃圾回收（仅在必要时使用）
     */
    public void forceGarbageCollection() {
        System.gc();
        System.out.println("Forced garbage collection");
    }
}
