package com.contra.utils;

import java.awt.Color;

/**
 * 游戏常量定义类
 * 包含所有游戏中使用的常量值
 * 
 * @author Contra Game Team
 * @version 1.0.0
 */
public final class Constants {
    
    // 私有构造函数，防止实例化
    private Constants() {}
    
    // ==================== 游戏窗口相关 ====================
    
    /** 游戏窗口标题 */
    public static final String GAME_TITLE = "魂斗罗 - Contra Game";
    
    /** 游戏窗口宽度 */
    public static final int WINDOW_WIDTH = 1024;
    
    /** 游戏窗口高度 */
    public static final int WINDOW_HEIGHT = 768;
    
    /** 游戏面板宽度 */
    public static final int GAME_WIDTH = 1024;
    
    /** 游戏面板高度 */
    public static final int GAME_HEIGHT = 768;
    
    // ==================== 游戏循环相关 ====================
    
    /** 目标FPS */
    public static final int TARGET_FPS = 60;
    
    /** 每帧时间间隔（纳秒） */
    public static final long FRAME_TIME_NS = 1_000_000_000L / TARGET_FPS;
    
    /** 每帧时间间隔（毫秒） */
    public static final int FRAME_TIME_MS = 1000 / TARGET_FPS;
    
    // ==================== 物理相关 ====================
    
    /** 重力加速度 */
    public static final double GRAVITY = 0.5;
    
    /** 最大下落速度 */
    public static final double MAX_FALL_SPEED = 15.0;
    
    /** 地面Y坐标 */
    public static final int GROUND_Y = GAME_HEIGHT - 100;
    
    // ==================== 玩家相关 ====================
    
    /** 玩家移动速度 */
    public static final double PLAYER_SPEED = 5.0;
    
    /** 玩家跳跃力度 */
    public static final double PLAYER_JUMP_FORCE = -12.0;
    
    /** 玩家宽度 */
    public static final int PLAYER_WIDTH = 32;
    
    /** 玩家高度 */
    public static final int PLAYER_HEIGHT = 48;
    
    /** 玩家初始生命值 */
    public static final int PLAYER_INITIAL_LIVES = 3;
    
    /** 玩家1初始X坐标 */
    public static final int PLAYER1_START_X = 100;
    
    /** 玩家2初始X坐标 */
    public static final int PLAYER2_START_X = 150;
    
    /** 玩家初始Y坐标 */
    public static final int PLAYER_START_Y = GROUND_Y - PLAYER_HEIGHT;
    
    // ==================== 敌人相关 ====================
    
    /** 基础敌人宽度 */
    public static final int ENEMY_WIDTH = 24;
    
    /** 基础敌人高度 */
    public static final int ENEMY_HEIGHT = 32;
    
    /** 敌人移动速度 */
    public static final double ENEMY_SPEED = 2.0;
    
    /** 敌人生成间隔（毫秒） */
    public static final int ENEMY_SPAWN_INTERVAL = 3000;
    
    // ==================== 子弹相关 ====================
    
    /** 子弹宽度 */
    public static final int BULLET_WIDTH = 8;
    
    /** 子弹高度 */
    public static final int BULLET_HEIGHT = 4;
    
    /** 子弹速度 */
    public static final double BULLET_SPEED = 10.0;
    
    /** 子弹射击间隔（毫秒） */
    public static final int BULLET_FIRE_INTERVAL = 200;
    
    /** 最大子弹数量 */
    public static final int MAX_BULLETS = 50;
    
    // ==================== 道具相关 ====================
    
    /** 道具宽度 */
    public static final int POWERUP_WIDTH = 24;
    
    /** 道具高度 */
    public static final int POWERUP_HEIGHT = 24;
    
    /** 道具生存时间（毫秒） */
    public static final int POWERUP_LIFETIME = 10000;
    
    // ==================== 颜色定义 ====================
    
    /** 背景颜色 */
    public static final Color BACKGROUND_COLOR = new Color(0x1a1a2e);
    
    /** 玩家颜色 */
    public static final Color PLAYER_COLOR = new Color(0x00ff00);
    
    /** 玩家2颜色 */
    public static final Color PLAYER2_COLOR = new Color(0x0080ff);
    
    /** 敌人颜色 */
    public static final Color ENEMY_COLOR = new Color(0xff4444);
    
    /** 子弹颜色 */
    public static final Color BULLET_COLOR = new Color(0xffff00);
    
    /** UI文字颜色 */
    public static final Color UI_TEXT_COLOR = new Color(0xffffff);
    
    /** UI背景颜色 */
    public static final Color UI_BACKGROUND_COLOR = new Color(0x000000, true);
    
    // ==================== 输入键码 ====================
    
    /** 玩家1移动键 */
    public static final class PLAYER1_KEYS {
        public static final int LEFT = 65;  // A
        public static final int RIGHT = 68; // D
        public static final int UP = 87;    // W
        public static final int DOWN = 83;  // S
        public static final int FIRE = 32;  // Space
    }
    
    /** 玩家2移动键 */
    public static final class PLAYER2_KEYS {
        public static final int LEFT = 37;  // Left Arrow
        public static final int RIGHT = 39; // Right Arrow
        public static final int UP = 38;    // Up Arrow
        public static final int DOWN = 40;  // Down Arrow
        public static final int FIRE = 10;  // Enter
    }
    
    /** 系统控制键 */
    public static final class SYSTEM_KEYS {
        public static final int PAUSE = 27;    // ESC
        public static final int RESTART = 82;  // R
        public static final int QUIT = 81;     // Q
    }
    
    // ==================== 游戏状态 ====================
    
    /** 游戏状态枚举 */
    public enum GameState {
        MENU,       // 主菜单
        PLAYING,    // 游戏进行中
        PAUSED,     // 暂停
        GAME_OVER,  // 游戏结束
        LEVEL_COMPLETE, // 关卡完成
        SETTINGS    // 设置
    }
    
    // ==================== 实体类型 ====================
    
    /** 实体类型枚举 */
    public enum EntityType {
        PLAYER,
        ENEMY_SOLDIER,
        ENEMY_FLYER,
        BOSS,
        BULLET_PLAYER,
        BULLET_ENEMY,
        POWERUP_WEAPON,
        POWERUP_LIFE,
        POWERUP_SCORE
    }
    
    // ==================== 武器类型 ====================
    
    /** 武器类型枚举 */
    public enum WeaponType {
        NORMAL,     // 普通子弹
        SPREAD,     // 散弹
        LASER,      // 激光
        RAPID       // 连发
    }
    
    // ==================== 方向枚举 ====================
    
    /** 方向枚举 */
    public enum Direction {
        LEFT(-1, 0),
        RIGHT(1, 0),
        UP(0, -1),
        DOWN(0, 1),
        UP_LEFT(-1, -1),
        UP_RIGHT(1, -1),
        DOWN_LEFT(-1, 1),
        DOWN_RIGHT(1, 1);
        
        public final int dx;
        public final int dy;
        
        Direction(int dx, int dy) {
            this.dx = dx;
            this.dy = dy;
        }
    }
    
    // ==================== 关卡相关 ====================
    
    /** 关卡宽度 */
    public static final int LEVEL_WIDTH = 3000;
    
    /** 关卡滚动速度 */
    public static final double LEVEL_SCROLL_SPEED = 2.0;
    
    /** 总关卡数 */
    public static final int TOTAL_LEVELS = 3;
    
    // ==================== 音频相关 ====================
    
    /** 默认音量 */
    public static final float DEFAULT_VOLUME = 0.7f;
    
    /** 音效音量 */
    public static final float SFX_VOLUME = 0.8f;
    
    /** 背景音乐音量 */
    public static final float MUSIC_VOLUME = 0.6f;
    
    // ==================== 调试相关 ====================
    
    /** 是否显示调试信息 */
    public static final boolean DEBUG_MODE = true;
    
    /** 是否显示碰撞边界 */
    public static final boolean SHOW_COLLISION_BOUNDS = false;
    
    /** 是否显示FPS */
    public static final boolean SHOW_FPS = true;
}
