package com.contra.levels;

/**
 * 关卡管理器
 */
public class LevelManager {
    
    public Level loadLevel(int levelNumber) {
        return new Level(levelNumber);
    }
    
    public void cleanup() {
        // 清理资源
    }
}
