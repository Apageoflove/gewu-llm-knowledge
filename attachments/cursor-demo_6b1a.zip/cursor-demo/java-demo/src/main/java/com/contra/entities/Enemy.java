package com.contra.entities;

import com.contra.utils.Constants;
import com.contra.utils.Vector2D;

import java.awt.*;

/**
 * 敌人基类
 */
public class Enemy extends Entity {
    protected long lastFireTime;
    protected double moveSpeed;
    
    public Enemy(Vector2D position, Constants.EntityType type) {
        super(position, type);
        this.health = 1;
        this.maxHealth = 1;
        this.lastFireTime = 0;
        this.moveSpeed = Constants.ENEMY_SPEED;
        this.color = Constants.ENEMY_COLOR;
        this.direction = -1; // 敌人默认向左移动
    }
    
    @Override
    public void update(long deltaTime) {
        // 简单AI：向左移动
        velocity.x = direction * moveSpeed;
        
        applyGravity(deltaTime);
        updatePosition(deltaTime);
        
        // 如果移出屏幕左侧，销毁敌人
        if (position.x + width < 0) {
            destroy();
        }
    }
    
    @Override
    public void render(Graphics2D g) {
        g.setColor(color);
        g.fillRect((int)position.x, (int)position.y, width, height);
        
        // 绘制简单的眼睛
        g.setColor(Color.WHITE);
        g.fillOval((int)position.x + 5, (int)position.y + 5, 4, 4);
        g.fillOval((int)position.x + width - 9, (int)position.y + 5, 4, 4);
    }
    
    @Override
    protected void checkBounds() {
        // 敌人不受右边界限制
        if (position.x < -width) {
            destroy();
        }
        
        // 检查地面碰撞
        checkGroundCollision();
    }
}
