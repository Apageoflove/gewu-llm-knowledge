@echo off
title 魂斗罗游戏
echo ========================================
echo          魂斗罗游戏启动器
echo ========================================
echo 正在启动游戏，请稍候...
echo.

cd /d "%~dp0"
mvn exec:java -Dexec.mainClass="com.contra.Main"

echo.
echo 游戏已结束，按任意键关闭窗口...
pause > nul
