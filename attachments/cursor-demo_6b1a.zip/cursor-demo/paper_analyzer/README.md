# 论文分析器 (Paper Analyzer)

一个用于分析在线论文并生成统计报表的Python项目。该项目可以从arXiv等学术数据库获取论文数据，进行深度分析，并生成可视化报表。

## 🚀 项目特性

- **数据获取**: 从arXiv API获取论文元数据
- **深度分析**: 包括统计分析、关键词提取、主题建模、协作分析等
- **可视化报表**: 生成HTML和JSON格式的详细报表
- **缓存机制**: 智能缓存减少API调用
- **多种图表**: 使用Plotly和Matplotlib生成交互式图表
- **词云生成**: 生成关键词词云图
- **模块化设计**: 遵循Python最佳实践的清晰架构

## 📋 项目结构

```
paper_analyzer/
├── README.md
├── requirements.txt
├── pyproject.toml
├── config.env.example
├── src/
│   └── paper_analyzer/
│       ├── __init__.py
│       ├── main.py
│       ├── config.py
│       ├── core/
│       │   ├── data_fetcher.py
│       │   ├── analyzer.py
│       │   └── report_generator.py
│       └── utils/
│           ├── exceptions.py
│           ├── json_formatter.py
│           └── text_processor.py
├── tests/
├── data/
├── output/
└── cache/
```

## 🛠️ 安装指南

### 1. 环境要求

- Python 3.8+
- pip

### 2. 安装依赖

```bash
# 克隆项目
git clone <repository-url>
cd paper_analyzer

# 安装依赖
pip install -r requirements.txt

# 或使用pip安装（开发模式）
pip install -e .
```

### 3. 配置环境

```bash
# 复制配置文件模板
cp config.env.example config.env

# 编辑配置文件（可选）
vim config.env
```

## 🚀 快速开始

### 命令行使用

```bash
# 基础搜索和分析
python -m paper_analyzer.main --query "machine learning" --max-results 100

# 快速分析（仅基础统计）
python -m paper_analyzer.main --query "deep learning" --quick --max-results 50

# 生成JSON格式报告
python -m paper_analyzer.main --query "artificial intelligence" --format json

# 自定义报告标题和输出目录
python -m paper_analyzer.main \
    --query "computer vision" \
    --title "计算机视觉研究分析" \
    --output-dir ./my_reports
```

### Python代码使用

```python
from paper_analyzer import PaperAnalyzer, DataFetcher, ReportGenerator
from paper_analyzer.main import PaperAnalysisWorkflow

# 使用工作流进行完整分析
workflow = PaperAnalysisWorkflow()
result = workflow.run_analysis(
    query="natural language processing",
    max_results=100,
    output_format="html",
    report_title="NLP研究分析报告"
)

print(f"分析完成，报告路径: {result['report_path']}")

# 或者分步骤使用
data_fetcher = DataFetcher()
analyzer = PaperAnalyzer()
report_generator = ReportGenerator()

# 1. 获取数据
papers = data_fetcher.search_papers("quantum computing", max_results=50)
papers_df = data_fetcher.create_dataset(papers)

# 2. 分析数据
analysis_results = analyzer.analyze_papers(papers_df)

# 3. 生成报告
report_path = report_generator.generate_full_report(
    analysis_results=analysis_results,
    papers_df=papers_df,
    report_title="量子计算研究报告"
)
```

## 📊 分析功能

### 基础统计分析
- 论文总数、作者数、分类数
- 平均作者数、分类数
- 标题和摘要长度统计

### 时间趋势分析
- 按年份/月份的发表趋势
- 增长率分析
- 高峰期识别

### 作者分析
- 高产作者排行
- 作者生产力分布
- 协作模式分析

### 学科分类分析
- 热门研究领域
- 跨学科研究统计
- 主要分类分布

### 关键词分析
- TF-IDF关键词提取
- 标题和摘要关键词分析
- 词云生成

### 主题建模
- LDA主题发现
- 主题词权重分析

### 文本统计
- 文本复杂度分析
- 可读性评估
- 语言特征统计

## 📈 报表格式

### HTML报表
- 交互式图表
- 响应式设计
- 完整的数据可视化
- 词云图集成

### JSON报表
- 结构化数据
- API友好格式
- 完整的分析结果
- 元数据包含

### Excel导出
- 多工作表数据
- 统计摘要
- 关键词分析表

## ⚙️ 配置选项

主要配置参数（在`config.env`中设置）：

```bash
# 日志配置
LOG_LEVEL=INFO
DEBUG=False

# 数据存储路径
DATA_DIR=data
OUTPUT_DIR=output
CACHE_DIR=cache

# API配置
MAX_RESULTS_PER_QUERY=100
REQUEST_DELAY=3

# 分析配置
TOP_KEYWORDS_COUNT=20
TOPIC_MODEL_COMPONENTS=10

# 报表配置
INCLUDE_WORDCLOUD=True
CHART_DPI=300
```

## 🧪 测试

```bash
# 运行所有测试
python -m pytest tests/

# 运行特定测试文件
python -m pytest tests/test_data_fetcher.py

# 运行测试并生成覆盖率报告
python -m pytest tests/ --cov=src/paper_analyzer --cov-report=html
```

## 🔍 使用示例

### 示例1: 机器学习研究分析

```bash
python -m paper_analyzer.main \
    --query "machine learning applications" \
    --max-results 200 \
    --title "机器学习应用研究分析" \
    --format html
```

### 示例2: 特定时间范围分析

```python
from paper_analyzer.core.data_fetcher import DataFetcher

data_fetcher = DataFetcher()
papers = data_fetcher.search_papers(
    query="deep learning",
    max_results=100,
    date_from="2023-01-01",
    date_to="2023-12-31"
)
```

### 示例3: 快速关键词分析

```bash
python -m paper_analyzer.main \
    --query "transformer neural networks" \
    --quick \
    --max-results 50
```

## 🤝 开发指南

### 代码规范
项目遵循以下Python开发规范：
- PEP 8代码风格
- 类型注解
- 详细的文档字符串
- 单元测试覆盖
- 错误处理机制

### 贡献指南
1. Fork项目
2. 创建特性分支
3. 添加测试用例
4. 确保代码质量
5. 提交Pull Request

### 代码质量工具
```bash
# 代码格式化
black src/ tests/

# 代码检查
flake8 src/ tests/

# 类型检查
mypy src/

# 导入排序
isort src/ tests/
```

## 📝 API文档

### 主要类和方法

#### DataFetcher
- `search_papers(query, max_results, ...)`: 搜索论文
- `get_paper_details(paper_id)`: 获取论文详情
- `create_dataset(papers)`: 创建数据集

#### PaperAnalyzer
- `analyze_papers(papers_df)`: 完整分析
- `generate_wordcloud_data(papers_df)`: 生成词云数据

#### ReportGenerator
- `generate_full_report(...)`: 生成完整报告
- `export_data(...)`: 导出数据

## 🐛 常见问题

### Q: 如何解决API限制问题？
A: 项目内置了请求延迟和缓存机制。可以通过调整`REQUEST_DELAY`参数来控制请求频率。

### Q: 如何处理大量数据？
A: 建议分批处理，使用缓存功能，并适当调整`MAX_RESULTS_PER_QUERY`参数。

### Q: 图表无法显示？
A: 确保安装了所有依赖，特别是plotly和matplotlib。检查输出目录权限。

### Q: 词云生成失败？
A: 可能是字体问题。在Linux系统上可能需要安装中文字体支持。

## 📄 许可证

MIT License - 详见LICENSE文件

## 🙋‍♂️ 支持

如有问题或建议，请：
1. 查看文档和FAQ
2. 搜索已有Issues
3. 创建新的Issue
4. 联系维护者

## 🔄 版本历史

- v1.0.0: 初始版本
  - 基础数据获取功能
  - 完整分析模块
  - HTML/JSON报表生成
  - 测试用例覆盖

---

⭐ 如果这个项目对您有帮助，请给我们一个星标！

