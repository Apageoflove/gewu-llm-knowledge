#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分析器测试用例
"""

import unittest
import pandas as pd
from datetime import datetime

from src.paper_analyzer.core.analyzer import PaperAnalyzer
from src.paper_analyzer.utils.exceptions import AnalysisError


class TestPaperAnalyzer(unittest.TestCase):
    """
    论文分析器测试类
    """
    
    def setUp(self) -> None:
        """
        测试前设置
        """
        self.analyzer = PaperAnalyzer()
        
        # 创建测试数据
        self.test_data = {
            'id': ['2020.00001', '2020.00002', '2020.00003'],
            'title': [
                'Machine Learning Applications',
                'Deep Learning for Computer Vision',
                'Natural Language Processing Advances'
            ],
            'authors': [
                ['John Doe', 'Jane Smith'],
                ['Alice Brown'],
                ['Bob Wilson', 'Carol Davis', 'Eve Johnson']
            ],
            'summary': [
                'This paper presents novel machine learning applications.',
                'We propose a new deep learning approach for computer vision.',
                'This work advances natural language processing techniques.'
            ],
            'published': [
                '2020-01-01T00:00:00',
                '2020-06-15T00:00:00',
                '2020-12-31T00:00:00'
            ],
            'categories': [
                ['cs.LG', 'cs.AI'],
                ['cs.CV'],
                ['cs.CL', 'cs.AI', 'cs.LG']
            ],
            'primary_category': ['cs.LG', 'cs.CV', 'cs.CL'],
            'author_count': [2, 1, 3],
            'category_count': [2, 1, 3],
            'title_length': [30, 35, 40],
            'summary_length': [50, 55, 60]
        }
        
        self.test_df = pd.DataFrame(self.test_data)
    
    def test_calculate_basic_statistics(self) -> None:
        """
        测试基础统计计算
        """
        stats = self.analyzer._calculate_basic_statistics(self.test_df)
        
        self.assertEqual(stats['total_papers'], 3)
        self.assertEqual(stats['unique_authors'], 6)  # 所有作者都是唯一的
        self.assertEqual(stats['unique_categories'], 4)  # cs.LG, cs.AI, cs.CV, cs.CL
        self.assertAlmostEqual(stats['average_authors_per_paper'], 2.0)
        self.assertAlmostEqual(stats['average_categories_per_paper'], 2.0)
        self.assertAlmostEqual(stats['average_title_length'], 35.0)
        self.assertAlmostEqual(stats['average_summary_length'], 55.0)
    
    def test_analyze_temporal_trends(self) -> None:
        """
        测试时间趋势分析
        """
        trends = self.analyzer._analyze_temporal_trends(self.test_df)
        
        self.assertIn('yearly_distribution', trends)
        self.assertEqual(trends['yearly_distribution']['2020'], 3)
        self.assertEqual(trends['peak_year'], 2020)
        self.assertIn('growth_trend', trends)
    
    def test_analyze_authors(self) -> None:
        """
        测试作者分析
        """
        author_analysis = self.analyzer._analyze_authors(self.test_df)
        
        self.assertEqual(author_analysis['total_unique_authors'], 6)
        self.assertIn('top_authors', author_analysis)
        self.assertIn('collaboration_statistics', author_analysis)
        
        # 检查协作统计
        collab_stats = author_analysis['collaboration_statistics']
        self.assertEqual(collab_stats['single_author_papers'], 1)
        self.assertEqual(collab_stats['multi_author_papers'], 2)
        self.assertEqual(collab_stats['max_authors_in_paper'], 3)
    
    def test_analyze_categories(self) -> None:
        """
        测试分类分析
        """
        category_analysis = self.analyzer._analyze_categories(self.test_df)
        
        self.assertEqual(category_analysis['total_unique_categories'], 4)
        self.assertIn('top_categories', category_analysis)
        self.assertIn('top_primary_categories', category_analysis)
        self.assertEqual(category_analysis['interdisciplinary_papers'], 2)  # 有2篇多分类论文
        self.assertAlmostEqual(category_analysis['average_categories_per_paper'], 2.0)
    
    def test_analyze_keywords(self) -> None:
        """
        测试关键词分析
        """
        keyword_analysis = self.analyzer._analyze_keywords(self.test_df)
        
        self.assertIn('top_keywords', keyword_analysis)
        self.assertIn('title_keywords', keyword_analysis)
        self.assertIn('summary_keywords', keyword_analysis)
        self.assertEqual(keyword_analysis['keyword_extraction_method'], 'TF-IDF')
        
        # 检查关键词格式
        if keyword_analysis['top_keywords']:
            keyword = keyword_analysis['top_keywords'][0]
            self.assertIn('word', keyword)
            self.assertIn('weight', keyword)
    
    def test_analyze_text_statistics(self) -> None:
        """
        测试文本统计分析
        """
        text_stats = self.analyzer._analyze_text_statistics(self.test_df)
        
        self.assertIn('title_statistics', text_stats)
        self.assertIn('summary_statistics', text_stats)
        self.assertIn('complexity_analysis', text_stats)
        
        # 检查标题统计
        title_stats = text_stats['title_statistics']
        self.assertEqual(title_stats['average_length'], 35.0)
        self.assertEqual(title_stats['min_length'], 30)
        self.assertEqual(title_stats['max_length'], 40)
        
        # 检查摘要统计
        summary_stats = text_stats['summary_statistics']
        self.assertEqual(summary_stats['average_length'], 55.0)
        self.assertEqual(summary_stats['min_length'], 50)
        self.assertEqual(summary_stats['max_length'], 60)
    
    def test_analyze_collaboration(self) -> None:
        """
        测试协作分析
        """
        collab_analysis = self.analyzer._analyze_collaboration(self.test_df)
        
        self.assertIn('single_author_ratio', collab_analysis)
        self.assertIn('two_author_ratio', collab_analysis)
        self.assertIn('multi_author_ratio', collab_analysis)
        self.assertIn('average_collaboration_size', collab_analysis)
        
        # 检查比例计算
        self.assertAlmostEqual(collab_analysis['single_author_ratio'], 1/3)
        self.assertAlmostEqual(collab_analysis['two_author_ratio'], 1/3)
        self.assertAlmostEqual(collab_analysis['multi_author_ratio'], 1/3)
        self.assertAlmostEqual(collab_analysis['average_collaboration_size'], 2.0)
    
    def test_generate_wordcloud_data(self) -> None:
        """
        测试词云数据生成
        """
        wordcloud_data = self.analyzer.generate_wordcloud_data(self.test_df)
        
        self.assertIsInstance(wordcloud_data, dict)
        # 检查是否包含预期的词语
        words = list(wordcloud_data.keys())
        self.assertTrue(any('learning' in word.lower() for word in words))
    
    def test_empty_dataframe(self) -> None:
        """
        测试空数据框处理
        """
        empty_df = pd.DataFrame()
        
        with self.assertRaises(AnalysisError):
            self.analyzer.analyze_papers(empty_df)
    
    def test_full_analysis(self) -> None:
        """
        测试完整分析流程
        """
        analysis_results = self.analyzer.analyze_papers(self.test_df)
        
        # 检查所有分析模块是否都存在
        expected_keys = [
            'basic_statistics',
            'temporal_analysis',
            'author_analysis',
            'category_analysis',
            'keyword_analysis',
            'topic_modeling',
            'text_statistics',
            'collaboration_analysis'
        ]
        
        for key in expected_keys:
            self.assertIn(key, analysis_results)
        
        # 检查基础统计
        basic_stats = analysis_results['basic_statistics']
        self.assertEqual(basic_stats['total_papers'], 3)
        self.assertEqual(basic_stats['unique_authors'], 6)
        self.assertEqual(basic_stats['unique_categories'], 4)


class TestAnalyzerEdgeCases(unittest.TestCase):
    """
    分析器边界情况测试类
    """
    
    def setUp(self) -> None:
        """
        测试前设置
        """
        self.analyzer = PaperAnalyzer()
    
    def test_single_paper_analysis(self) -> None:
        """
        测试单篇论文分析
        """
        single_paper_data = {
            'id': ['2020.00001'],
            'title': ['Test Paper'],
            'authors': [['Test Author']],
            'summary': ['Test summary.'],
            'published': ['2020-01-01T00:00:00'],
            'categories': [['cs.AI']],
            'primary_category': ['cs.AI'],
            'author_count': [1],
            'category_count': [1],
            'title_length': [10],
            'summary_length': [13]
        }
        
        test_df = pd.DataFrame(single_paper_data)
        analysis_results = self.analyzer.analyze_papers(test_df)
        
        # 验证基础统计
        basic_stats = analysis_results['basic_statistics']
        self.assertEqual(basic_stats['total_papers'], 1)
        self.assertEqual(basic_stats['unique_authors'], 1)
        self.assertEqual(basic_stats['unique_categories'], 1)
    
    def test_missing_published_date(self) -> None:
        """
        测试缺少发布日期的情况
        """
        data_without_date = {
            'id': ['2020.00001'],
            'title': ['Test Paper'],
            'authors': [['Test Author']],
            'summary': ['Test summary.'],
            'categories': [['cs.AI']],
            'primary_category': ['cs.AI'],
            'author_count': [1],
            'category_count': [1],
            'title_length': [10],
            'summary_length': [13]
        }
        
        test_df = pd.DataFrame(data_without_date)
        analysis_results = self.analyzer.analyze_papers(test_df)
        
        # 时间分析应该返回错误信息
        temporal_analysis = analysis_results['temporal_analysis']
        self.assertIn('error', temporal_analysis)


if __name__ == '__main__':
    unittest.main()

