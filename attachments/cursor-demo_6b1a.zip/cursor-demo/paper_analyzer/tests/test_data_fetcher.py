#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据获取器测试用例
"""

import unittest
from unittest.mock import Mock, patch
import pandas as pd

from src.paper_analyzer.core.data_fetcher import DataFetcher
from src.paper_analyzer.utils.exceptions import DataFetchError


class TestDataFetcher(unittest.TestCase):
    """
    数据获取器测试类
    """
    
    def setUp(self) -> None:
        """
        测试前设置
        """
        self.data_fetcher = DataFetcher(cache_enabled=False)
    
    def test_search_papers_basic(self) -> None:
        """
        测试基础论文搜索功能
        """
        # 模拟搜索结果
        with patch('src.paper_analyzer.core.data_fetcher.arxiv.Search') as mock_search:
            mock_result = Mock()
            mock_result.entry_id = 'http://arxiv.org/abs/2001.00001v1'
            mock_result.title = 'Test Paper'
            mock_result.authors = [Mock(name='Test Author')]
            mock_result.summary = 'Test summary'
            mock_result.published.isoformat.return_value = '2020-01-01T00:00:00'
            mock_result.updated = None
            mock_result.categories = ['cs.AI']
            mock_result.primary_category = 'cs.AI'
            mock_result.pdf_url = 'http://arxiv.org/pdf/2001.00001v1.pdf'
            mock_result.comment = None
            mock_result.journal_ref = None
            mock_result.doi = None
            mock_result.links = []
            
            mock_search.return_value.results.return_value = [mock_result]
            
            papers = self.data_fetcher.search_papers("test query", max_results=1)
            
            self.assertEqual(len(papers), 1)
            self.assertEqual(papers[0]['title'], 'Test Paper')
            self.assertEqual(papers[0]['id'], '2001.00001v1')
    
    def test_create_dataset(self) -> None:
        """
        测试创建数据集功能
        """
        # 模拟论文数据
        papers = [
            {
                'id': '2001.00001',
                'title': 'Test Paper 1',
                'authors': ['Author 1', 'Author 2'],
                'summary': 'This is a test summary.',
                'published': '2020-01-01T00:00:00',
                'categories': ['cs.AI', 'cs.ML'],
                'primary_category': 'cs.AI'
            },
            {
                'id': '2001.00002',
                'title': 'Test Paper 2',
                'authors': ['Author 3'],
                'summary': 'Another test summary.',
                'published': '2020-01-02T00:00:00',
                'categories': ['cs.CV'],
                'primary_category': 'cs.CV'
            }
        ]
        
        df = self.data_fetcher.create_dataset(papers)
        
        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(len(df), 2)
        self.assertIn('author_count', df.columns)
        self.assertIn('category_count', df.columns)
        self.assertIn('summary_length', df.columns)
        self.assertIn('title_length', df.columns)
        
        # 检查派生字段
        self.assertEqual(df.iloc[0]['author_count'], 2)
        self.assertEqual(df.iloc[1]['author_count'], 1)
        self.assertEqual(df.iloc[0]['category_count'], 2)
        self.assertEqual(df.iloc[1]['category_count'], 1)
    
    def test_build_search_query(self) -> None:
        """
        测试搜索查询构建
        """
        # 基础查询
        query = self.data_fetcher._build_search_query("machine learning")
        self.assertEqual(query, "machine learning")
        
        # 带日期范围的查询
        query = self.data_fetcher._build_search_query(
            "deep learning",
            date_from="2020-01-01",
            date_to="2020-12-31"
        )
        self.assertIn("submittedDate:", query)
        self.assertIn("2020-01-01", query)
        self.assertIn("2020-12-31", query)
    
    def test_extract_paper_data(self) -> None:
        """
        测试论文数据提取
        """
        # 创建模拟的arXiv结果对象
        mock_result = Mock()
        mock_result.entry_id = 'http://arxiv.org/abs/2001.00001v1'
        mock_result.title = '  Test Paper Title  '
        mock_result.authors = [Mock(name='John Doe'), Mock(name='Jane Smith')]
        mock_result.summary = '  Test paper summary.  '
        mock_result.published.isoformat.return_value = '2020-01-01T00:00:00'
        mock_result.updated = None
        mock_result.categories = ['cs.AI', 'cs.ML']
        mock_result.primary_category = 'cs.AI'
        mock_result.pdf_url = 'http://arxiv.org/pdf/2001.00001v1.pdf'
        mock_result.comment = 'Test comment'
        mock_result.journal_ref = 'Test Journal'
        mock_result.doi = '10.1000/test'
        mock_result.links = [Mock(href='http://test.com', title='Test Link')]
        
        paper_data = self.data_fetcher._extract_paper_data(mock_result)
        
        self.assertEqual(paper_data['id'], '2001.00001v1')
        self.assertEqual(paper_data['title'], 'Test Paper Title')
        self.assertEqual(len(paper_data['authors']), 2)
        self.assertEqual(paper_data['summary'], 'Test paper summary.')
        self.assertEqual(paper_data['categories'], ['cs.AI', 'cs.ML'])
        self.assertEqual(paper_data['primary_category'], 'cs.AI')


class TestDataFetcherIntegration(unittest.TestCase):
    """
    数据获取器集成测试类
    """
    
    def setUp(self) -> None:
        """
        测试前设置
        """
        self.data_fetcher = DataFetcher(cache_enabled=True)
    
    @patch('src.paper_analyzer.core.data_fetcher.arxiv.Search')
    def test_search_papers_with_cache(self, mock_search) -> None:
        """
        测试带缓存的论文搜索
        """
        # 模拟搜索结果
        mock_result = Mock()
        mock_result.entry_id = 'http://arxiv.org/abs/2001.00001v1'
        mock_result.title = 'Cached Paper'
        mock_result.authors = [Mock(name='Cached Author')]
        mock_result.summary = 'Cached summary'
        mock_result.published.isoformat.return_value = '2020-01-01T00:00:00'
        mock_result.updated = None
        mock_result.categories = ['cs.AI']
        mock_result.primary_category = 'cs.AI'
        mock_result.pdf_url = 'http://arxiv.org/pdf/2001.00001v1.pdf'
        mock_result.comment = None
        mock_result.journal_ref = None
        mock_result.doi = None
        mock_result.links = []
        
        mock_search.return_value.results.return_value = [mock_result]
        
        # 第一次搜索
        papers1 = self.data_fetcher.search_papers("cache test", max_results=1)
        
        # 第二次搜索（应该从缓存加载）
        papers2 = self.data_fetcher.search_papers("cache test", max_results=1)
        
        # 验证结果一致
        self.assertEqual(papers1[0]['title'], papers2[0]['title'])
        
        # 验证只调用了一次API
        self.assertEqual(mock_search.call_count, 1)


if __name__ == '__main__':
    unittest.main()

