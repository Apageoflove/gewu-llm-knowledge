#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文分析器使用示例
展示如何使用论文分析器的各种功能
"""

import sys
import json
from pathlib import Path

# 添加项目路径到sys.path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from paper_analyzer import PaperAnalyzer, DataFetcher, ReportGenerator
from paper_analyzer.main import PaperAnalysisWorkflow
from paper_analyzer.utils.json_formatter import create_json_response


def example_1_basic_analysis():
    """
    示例1: 基础论文分析
    """
    print("=" * 60)
    print("示例1: 基础论文分析")
    print("=" * 60)
    
    try:
        # 创建工作流实例
        workflow = PaperAnalysisWorkflow()
        
        # 执行分析
        result = workflow.run_analysis(
            query="machine learning applications",
            max_results=20,  # 限制结果数量以加快演示
            output_format="html",
            report_title="机器学习应用研究分析示例"
        )
        
        # 输出结果
        output = create_json_response(
            data=result,
            status="success",
            message="基础分析完成"
        )
        
        print(output)
        print(f"\n报告已生成: {result['report_path']}")
        print(f"数据已导出: {result['data_export_path']}")
        
    except Exception as e:
        print(f"分析失败: {e}")


def example_2_quick_analysis():
    """
    示例2: 快速分析
    """
    print("\n" + "=" * 60)
    print("示例2: 快速分析")
    print("=" * 60)
    
    try:
        workflow = PaperAnalysisWorkflow()
        
        # 快速分析
        result = workflow.quick_analysis(
            query="deep learning computer vision",
            max_results=30
        )
        
        # 输出结果
        output = create_json_response(
            data=result,
            status="success" if 'error' not in result else "error",
            message="快速分析完成"
        )
        
        print(output)
        
        # 显示关键统计信息
        if 'basic_statistics' in result:
            stats = result['basic_statistics']
            print(f"\n关键统计信息:")
            print(f"- 论文总数: {stats.get('total_papers', 0)}")
            print(f"- 独特作者数: {stats.get('unique_authors', 0)}")
            print(f"- 学科分类数: {stats.get('unique_categories', 0)}")
            
        # 显示热门关键词
        if 'top_keywords' in result:
            keywords = result['top_keywords'][:5]
            print(f"\n热门关键词:")
            for i, kw in enumerate(keywords, 1):
                print(f"{i}. {kw['word']} (权重: {kw['weight']:.3f})")
        
    except Exception as e:
        print(f"快速分析失败: {e}")


def example_3_step_by_step():
    """
    示例3: 分步骤使用各个模块
    """
    print("\n" + "=" * 60)
    print("示例3: 分步骤使用各个模块")
    print("=" * 60)
    
    try:
        # 1. 数据获取
        print("步骤1: 数据获取")
        data_fetcher = DataFetcher(cache_enabled=True)
        
        papers = data_fetcher.search_papers(
            query="natural language processing",
            max_results=15,
            sort_by="submittedDate",
            sort_order="descending"
        )
        
        print(f"获取到 {len(papers)} 篇论文")
        
        # 创建数据集
        papers_df = data_fetcher.create_dataset(papers)
        print(f"数据集形状: {papers_df.shape}")
        
        # 2. 数据分析
        print("\n步骤2: 数据分析")
        analyzer = PaperAnalyzer()
        
        analysis_results = analyzer.analyze_papers(papers_df)
        
        # 输出分析模块
        print("完成的分析模块:")
        for module_name in analysis_results.keys():
            print(f"- {module_name}")
        
        # 3. 报告生成
        print("\n步骤3: 报告生成")
        report_generator = ReportGenerator()
        
        # 生成HTML报告
        html_report_path = report_generator.generate_full_report(
            analysis_results=analysis_results,
            papers_df=papers_df,
            report_title="NLP研究分析报告（分步骤示例）",
            output_format="html"
        )
        
        # 生成JSON报告
        json_report_path = report_generator.generate_full_report(
            analysis_results=analysis_results,
            papers_df=papers_df,
            report_title="NLP研究分析报告（分步骤示例）",
            output_format="json"
        )
        
        # 导出Excel数据
        excel_path = report_generator.export_data(
            papers_df=papers_df,
            analysis_results=analysis_results,
            export_format="xlsx"
        )
        
        print(f"HTML报告: {html_report_path}")
        print(f"JSON报告: {json_report_path}")
        print(f"Excel数据: {excel_path}")
        
        # 4. 展示部分分析结果
        print("\n关键分析结果:")
        basic_stats = analysis_results.get('basic_statistics', {})
        print(f"- 论文总数: {basic_stats.get('total_papers', 0)}")
        print(f"- 平均作者数: {basic_stats.get('average_authors_per_paper', 0):.1f}")
        
        # 显示热门分类
        category_analysis = analysis_results.get('category_analysis', {})
        top_categories = category_analysis.get('top_categories', [])[:3]
        if top_categories:
            print("- 热门分类:")
            for cat in top_categories:
                print(f"  {cat['category']}: {cat['count']} 篇")
        
    except Exception as e:
        print(f"分步骤分析失败: {e}")


def example_4_keyword_analysis():
    """
    示例4: 专注于关键词分析
    """
    print("\n" + "=" * 60)
    print("示例4: 专注于关键词分析")
    print("=" * 60)
    
    try:
        data_fetcher = DataFetcher()
        analyzer = PaperAnalyzer()
        
        # 获取数据
        papers = data_fetcher.search_papers(
            query="artificial intelligence ethics",
            max_results=25
        )
        
        papers_df = data_fetcher.create_dataset(papers)
        
        # 关键词分析
        keyword_analysis = analyzer._analyze_keywords(papers_df)
        
        print("关键词分析结果:")
        print(f"提取方法: {keyword_analysis.get('keyword_extraction_method', 'Unknown')}")
        
        # 展示总体关键词
        top_keywords = keyword_analysis.get('top_keywords', [])[:10]
        print(f"\n总体热门关键词 (前10):")
        for i, kw in enumerate(top_keywords, 1):
            print(f"{i:2d}. {kw['word']:<20} (权重: {kw['weight']:.4f})")
        
        # 展示标题关键词
        title_keywords = keyword_analysis.get('title_keywords', [])[:5]
        print(f"\n标题关键词 (前5):")
        for i, kw in enumerate(title_keywords, 1):
            print(f"{i}. {kw['word']:<15} (权重: {kw['weight']:.4f})")
        
        # 展示摘要关键词
        summary_keywords = keyword_analysis.get('summary_keywords', [])[:5]
        print(f"\n摘要关键词 (前5):")
        for i, kw in enumerate(summary_keywords, 1):
            print(f"{i}. {kw['word']:<15} (权重: {kw['weight']:.4f})")
        
        # 生成词云数据
        wordcloud_data = analyzer.generate_wordcloud_data(papers_df)
        print(f"\n词云数据包含 {len(wordcloud_data)} 个词语")
        
        # 显示词云权重最高的词
        sorted_words = sorted(
            wordcloud_data.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:5]
        
        print("词云权重最高的词语:")
        for word, weight in sorted_words:
            print(f"- {word}: {weight}")
        
    except Exception as e:
        print(f"关键词分析失败: {e}")


def example_5_temporal_analysis():
    """
    示例5: 时间趋势分析
    """
    print("\n" + "=" * 60)
    print("示例5: 时间趋势分析")
    print("=" * 60)
    
    try:
        data_fetcher = DataFetcher()
        analyzer = PaperAnalyzer()
        
        # 获取较多数据以便进行时间分析
        papers = data_fetcher.search_papers(
            query="quantum computing",
            max_results=50,
            sort_by="submittedDate",
            sort_order="descending"
        )
        
        papers_df = data_fetcher.create_dataset(papers)
        
        # 时间趋势分析
        temporal_analysis = analyzer._analyze_temporal_trends(papers_df)
        
        if 'error' in temporal_analysis:
            print(f"时间分析错误: {temporal_analysis['error']}")
            return
        
        print("时间趋势分析结果:")
        
        # 年度分布
        yearly_dist = temporal_analysis.get('yearly_distribution', {})
        if yearly_dist:
            print(f"\n年度发表分布:")
            for year, count in sorted(yearly_dist.items()):
                print(f"{year}: {count} 篇")
        
        # 趋势信息
        print(f"\n趋势信息:")
        print(f"- 高峰年份: {temporal_analysis.get('peak_year', 'Unknown')}")
        print(f"- 增长趋势: {temporal_analysis.get('growth_trend', 'Unknown')}")
        
        # 日期范围
        basic_stats = analyzer._calculate_basic_statistics(papers_df)
        date_range = basic_stats.get('date_range', {})
        if date_range:
            print(f"- 日期范围: {date_range.get('earliest', '')} 到 {date_range.get('latest', '')}")
            print(f"- 时间跨度: {date_range.get('span_days', 0)} 天")
        
    except Exception as e:
        print(f"时间趋势分析失败: {e}")


def main():
    """
    主函数，运行所有示例
    """
    print("论文分析器使用示例")
    print("本示例将演示论文分析器的各种功能")
    print("注意: 示例会进行真实的API调用，请确保网络连接正常")
    
    try:
        # 运行示例（注释掉一些示例以减少API调用）
        example_2_quick_analysis()    # 快速分析
        example_4_keyword_analysis()  # 关键词分析
        example_5_temporal_analysis() # 时间趋势分析
        
        # 完整分析示例（可能需要较长时间）
        # example_1_basic_analysis()    # 基础分析
        # example_3_step_by_step()      # 分步骤分析
        
        print("\n" + "=" * 60)
        print("所有示例运行完成！")
        print("=" * 60)
        
    except KeyboardInterrupt:
        print("\n用户中断了示例运行")
    except Exception as e:
        print(f"\n示例运行出错: {e}")


if __name__ == "__main__":
    main()
