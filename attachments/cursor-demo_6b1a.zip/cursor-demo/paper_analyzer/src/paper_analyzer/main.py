#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文分析器主程序
提供命令行接口和主要功能入口
"""

import json
import logging
import argparse
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

from .config import config
from .core.data_fetcher import DataFetcher
from .core.analyzer import PaperAnalyzer
from .core.report_generator import ReportGenerator
from .utils.exceptions import PaperAnalyzerError
from .utils.json_formatter import create_json_response, create_error_response

# 配置日志
logging.basicConfig(
    level=getattr(logging, config.get('log_level', 'INFO')),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('paper_analyzer.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class PaperAnalysisWorkflow:
    """
    论文分析工作流
    协调数据获取、分析和报告生成的完整流程
    """
    
    def __init__(self) -> None:
        """
        初始化工作流
        """
        self.data_fetcher = DataFetcher()
        self.analyzer = PaperAnalyzer()
        self.report_generator = ReportGenerator()
        
        # 确保必要目录存在
        config.ensure_directories()
    
    def run_analysis(
        self,
        query: str,
        max_results: int = 100,
        output_format: str = "html",
        report_title: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        运行完整的论文分析流程
        
        Args:
            query: 搜索查询
            max_results: 最大结果数
            output_format: 输出格式
            report_title: 报告标题
            
        Returns:
            分析结果和报告信息
            
        Raises:
            PaperAnalyzerError: 分析过程中出现错误时
        """
        try:
            logger.info(f"开始论文分析流程: {query}")
            
            # 1. 数据获取
            logger.info("步骤1: 获取论文数据")
            papers = self.data_fetcher.search_papers(
                query=query,
                max_results=max_results
            )
            
            if not papers:
                raise PaperAnalyzerError("未找到匹配的论文")
            
            # 2. 创建数据集
            logger.info("步骤2: 创建数据集")
            papers_df = self.data_fetcher.create_dataset(papers)
            
            # 3. 数据分析
            logger.info("步骤3: 执行数据分析")
            analysis_results = self.analyzer.analyze_papers(papers_df)
            
            # 4. 生成报告
            logger.info("步骤4: 生成分析报告")
            if not report_title:
                report_title = f"论文分析报告 - {query}"
            
            report_path = self.report_generator.generate_full_report(
                analysis_results=analysis_results,
                papers_df=papers_df,
                report_title=report_title,
                output_format=output_format
            )
            
            # 5. 导出数据
            data_export_path = self.report_generator.export_data(
                papers_df=papers_df,
                analysis_results=analysis_results,
                export_format="xlsx"
            )
            
            # 准备返回结果
            result = {
                'query': query,
                'papers_found': len(papers),
                'analysis_completed': True,
                'report_path': report_path,
                'data_export_path': data_export_path,
                'analysis_summary': {
                    'total_papers': analysis_results.get(
                        'basic_statistics', {}
                    ).get('total_papers', 0),
                    'unique_authors': analysis_results.get(
                        'basic_statistics', {}
                    ).get('unique_authors', 0),
                    'unique_categories': analysis_results.get(
                        'basic_statistics', {}
                    ).get('unique_categories', 0),
                    'top_keywords': analysis_results.get(
                        'keyword_analysis', {}
                    ).get('top_keywords', [])[:5]
                }
            }
            
            logger.info("论文分析流程完成")
            return result
            
        except Exception as e:
            logger.error(f"分析流程失败: {e}")
            raise PaperAnalyzerError(f"分析流程失败: {e}") from e
    
    def quick_analysis(
        self, 
        query: str, 
        max_results: int = 50
    ) -> Dict[str, Any]:
        """
        快速分析（仅返回基础统计信息）
        
        Args:
            query: 搜索查询
            max_results: 最大结果数
            
        Returns:
            快速分析结果
        """
        try:
            logger.info(f"开始快速分析: {query}")
            
            # 获取数据
            papers = self.data_fetcher.search_papers(
                query=query,
                max_results=max_results
            )
            
            if not papers:
                return {'error': '未找到匹配的论文'}
            
            # 创建数据集
            papers_df = self.data_fetcher.create_dataset(papers)
            
            # 基础分析
            basic_stats = self.analyzer._calculate_basic_statistics(papers_df)
            keyword_analysis = self.analyzer._analyze_keywords(papers_df)
            
            return {
                'query': query,
                'papers_found': len(papers),
                'basic_statistics': basic_stats,
                'top_keywords': keyword_analysis.get('top_keywords', [])[:10]
            }
            
        except Exception as e:
            logger.error(f"快速分析失败: {e}")
            return {'error': f'快速分析失败: {str(e)}'}


def create_argument_parser() -> argparse.ArgumentParser:
    """
    创建命令行参数解析器
    
    Returns:
        参数解析器
    """
    parser = argparse.ArgumentParser(
        description='论文分析器 - 分析在线论文并生成统计报表',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python -m paper_analyzer.main --query "machine learning" --max-results 100
  python -m paper_analyzer.main --query "artificial intelligence" --format json
  python -m paper_analyzer.main --quick "deep learning" --max-results 50
        """
    )
    
    parser.add_argument(
        '--query', '-q',
        type=str,
        required=True,
        help='搜索查询字符串'
    )
    
    parser.add_argument(
        '--max-results', '-n',
        type=int,
        default=100,
        help='最大结果数量 (默认: 100)'
    )
    
    parser.add_argument(
        '--format', '-f',
        choices=['html', 'json'],
        default='html',
        help='报告输出格式 (默认: html)'
    )
    
    parser.add_argument(
        '--title', '-t',
        type=str,
        help='自定义报告标题'
    )
    
    parser.add_argument(
        '--quick',
        action='store_true',
        help='执行快速分析（仅基础统计）'
    )
    
    parser.add_argument(
        '--output-dir', '-o',
        type=str,
        help='输出目录路径'
    )
    
    return parser


def main() -> None:
    """
    主函数
    """
    parser = create_argument_parser()
    args = parser.parse_args()
    
    try:
        # 更新输出目录配置
        if args.output_dir:
            config._config['output_dir'] = Path(args.output_dir)
            config.ensure_directories()
        
        # 创建工作流实例
        workflow = PaperAnalysisWorkflow()
        
        # 执行分析
        if args.quick:
            result = workflow.quick_analysis(
                query=args.query,
                max_results=args.max_results
            )
            
            # 输出JSON格式结果
            output = create_json_response(
                data=result,
                status="success" if 'error' not in result else "error",
                message="快速分析完成" if 'error' not in result else "快速分析失败"
            )
            
        else:
            result = workflow.run_analysis(
                query=args.query,
                max_results=args.max_results,
                output_format=args.format,
                report_title=args.title
            )
            
            # 输出JSON格式结果
            output = create_json_response(
                data=result,
                status="success",
                message="完整分析流程完成"
            )
        
        print(output)
        
    except PaperAnalyzerError as e:
        error_output = create_error_response(
            error_type="PaperAnalyzerError",
            error_message=str(e)
        )
        print(error_output)
        
    except Exception as e:
        error_output = create_error_response(
            error_type="UnexpectedError",
            error_message=f"意外错误: {str(e)}"
        )
        print(error_output)


if __name__ == "__main__":
    main()

