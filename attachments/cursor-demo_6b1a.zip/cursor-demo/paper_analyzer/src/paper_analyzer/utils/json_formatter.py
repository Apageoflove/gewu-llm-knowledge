#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JSON格式化工具
提供统一的JSON输出格式
"""

import json
from datetime import datetime
from typing import Dict, Any, Optional


def create_json_response(
    data: Any,
    status: str = "success",
    message: Optional[str] = None
) -> str:
    """
    创建标准JSON响应格式
    
    Args:
        data: 要输出的数据
        status: 状态（success/error/warning）
        message: 可选的消息说明
        
    Returns:
        格式化的JSON字符串
    """
    response = {
        "timestamp": datetime.now().isoformat(),
        "status": status,
        "data": data
    }
    
    if message:
        response["message"] = message
        
    return json.dumps(response, ensure_ascii=False, indent=2)


def format_output(data: Dict[str, Any]) -> str:
    """
    格式化输出为JSON字符串
    
    Args:
        data: 要输出的数据字典
        
    Returns:
        格式化的JSON字符串
    """
    return json.dumps(data, ensure_ascii=False, indent=2)


def create_error_response(
    error_type: str,
    error_message: str,
    details: Optional[Dict[str, Any]] = None
) -> str:
    """
    创建错误响应
    
    Args:
        error_type: 错误类型
        error_message: 错误消息
        details: 可选的错误详情
        
    Returns:
        格式化的错误响应JSON字符串
    """
    error_data = {
        "error_type": error_type,
        "error_message": error_message
    }
    
    if details:
        error_data["details"] = details
    
    return create_json_response(
        data=error_data,
        status="error",
        message="操作失败"
    )


def create_success_response(
    data: Any,
    message: str = "操作成功"
) -> str:
    """
    创建成功响应
    
    Args:
        data: 成功返回的数据
        message: 成功消息
        
    Returns:
        格式化的成功响应JSON字符串
    """
    return create_json_response(
        data=data,
        status="success",
        message=message
    )

