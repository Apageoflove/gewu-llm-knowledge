#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文本处理工具
用于处理论文文本数据的预处理和分析
"""

import re
import string
from typing import List, Dict, Set, Optional
from collections import Counter

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.tag import pos_tag
from sklearn.feature_extraction.text import TfidfVectorizer

from ..config import config


class TextProcessor:
    """
    文本处理器
    提供文本清理、分词、词性标注等功能
    """
    
    def __init__(self) -> None:
        """
        初始化文本处理器
        """
        self.min_word_length = config.get('min_word_length', 3)
        self.max_word_length = config.get('max_word_length', 20)
        
        # 下载必要的NLTK数据
        self._download_nltk_data()
        
        # 初始化组件
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # 添加学术论文常见停用词
        self.academic_stopwords = {
            'paper', 'study', 'research', 'analysis', 'method', 'approach',
            'result', 'conclusion', 'data', 'model', 'algorithm', 'system',
            'experiment', 'evaluation', 'performance', 'based', 'using',
            'proposed', 'novel', 'new', 'show', 'present', 'describe'
        }
        
        self.stop_words.update(self.academic_stopwords)
    
    def _download_nltk_data(self) -> None:
        """
        下载必要的NLTK数据包
        """
        required_data = [
            'punkt', 'stopwords', 'wordnet', 'averaged_perceptron_tagger',
            'omw-1.4'
        ]
        
        for data_name in required_data:
            try:
                nltk.data.find(f'tokenizers/{data_name}')
            except LookupError:
                try:
                    nltk.download(data_name, quiet=True)
                except Exception:
                    pass  # 忽略下载失败
    
    def clean_text(self, text: str) -> str:
        """
        清理文本
        
        Args:
            text: 原始文本
            
        Returns:
            清理后的文本
        """
        if not text:
            return ""
        
        # 转换为小写
        text = text.lower()
        
        # 移除特殊字符和数字
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\d+', ' ', text)
        
        # 移除多余空格
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def tokenize(self, text: str) -> List[str]:
        """
        文本分词
        
        Args:
            text: 输入文本
            
        Returns:
            词语列表
        """
        if not text:
            return []
        
        # 清理文本
        cleaned_text = self.clean_text(text)
        
        # 分词
        tokens = word_tokenize(cleaned_text)
        
        # 过滤词语
        filtered_tokens = []
        for token in tokens:
            if (self.min_word_length <= len(token) <= self.max_word_length
                and token not in self.stop_words
                and token.isalpha()):
                filtered_tokens.append(token)
        
        return filtered_tokens
    
    def lemmatize_tokens(self, tokens: List[str]) -> List[str]:
        """
        词形还原
        
        Args:
            tokens: 词语列表
            
        Returns:
            还原后的词语列表
        """
        if not tokens:
            return []
        
        # 获取词性标注
        pos_tags = pos_tag(tokens)
        
        lemmatized_tokens = []
        for token, pos in pos_tags:
            # 转换词性标签为WordNet格式
            wordnet_pos = self._get_wordnet_pos(pos)
            if wordnet_pos:
                lemmatized_token = self.lemmatizer.lemmatize(
                    token, pos=wordnet_pos
                )
            else:
                lemmatized_token = self.lemmatizer.lemmatize(token)
            
            lemmatized_tokens.append(lemmatized_token)
        
        return lemmatized_tokens
    
    def _get_wordnet_pos(self, treebank_tag: str) -> Optional[str]:
        """
        将树库词性标签转换为WordNet词性标签
        
        Args:
            treebank_tag: 树库词性标签
            
        Returns:
            WordNet词性标签或None
        """
        if treebank_tag.startswith('J'):
            return 'a'  # 形容词
        elif treebank_tag.startswith('V'):
            return 'v'  # 动词
        elif treebank_tag.startswith('N'):
            return 'n'  # 名词
        elif treebank_tag.startswith('R'):
            return 'r'  # 副词
        else:
            return None
    
    def extract_keywords(
        self, 
        texts: List[str], 
        top_k: int = 20
    ) -> List[Dict[str, float]]:
        """
        提取关键词
        
        Args:
            texts: 文本列表
            top_k: 返回前k个关键词
            
        Returns:
            关键词及其权重列表
        """
        if not texts:
            return []
        
        # 预处理文本
        processed_texts = []
        for text in texts:
            tokens = self.tokenize(text)
            lemmatized_tokens = self.lemmatize_tokens(tokens)
            processed_texts.append(' '.join(lemmatized_tokens))
        
        # 过滤空文本
        processed_texts = [text for text in processed_texts if text.strip()]
        
        if not processed_texts:
            return []
        
        # 使用TF-IDF提取关键词
        try:
            vectorizer = TfidfVectorizer(
                max_features=1000,
                ngram_range=(1, 2),
                min_df=2
            )
            
            tfidf_matrix = vectorizer.fit_transform(processed_texts)
            feature_names = vectorizer.get_feature_names_out()
            
            # 计算每个词的平均TF-IDF权重
            mean_scores = tfidf_matrix.mean(axis=0).A1
            
            # 创建词-权重对
            word_scores = [
                {"word": feature_names[i], "weight": float(mean_scores[i])}
                for i in range(len(feature_names))
            ]
            
            # 按权重排序并返回前k个
            word_scores.sort(key=lambda x: x['weight'], reverse=True)
            return word_scores[:top_k]
            
        except Exception:
            # 如果TF-IDF失败，使用简单词频统计
            return self._extract_keywords_by_frequency(texts, top_k)
    
    def _extract_keywords_by_frequency(
        self, 
        texts: List[str], 
        top_k: int
    ) -> List[Dict[str, float]]:
        """
        基于词频提取关键词
        
        Args:
            texts: 文本列表
            top_k: 返回前k个关键词
            
        Returns:
            关键词及其频率列表
        """
        all_tokens = []
        for text in texts:
            tokens = self.tokenize(text)
            lemmatized_tokens = self.lemmatize_tokens(tokens)
            all_tokens.extend(lemmatized_tokens)
        
        # 统计词频
        word_freq = Counter(all_tokens)
        total_words = len(all_tokens)
        
        # 转换为权重格式
        word_scores = [
            {"word": word, "weight": float(freq / total_words)}
            for word, freq in word_freq.most_common(top_k)
        ]
        
        return word_scores
    
    def extract_sentences(self, text: str, num_sentences: int = 5) -> List[str]:
        """
        提取文本中的重要句子
        
        Args:
            text: 输入文本
            num_sentences: 返回句子数量
            
        Returns:
            重要句子列表
        """
        if not text:
            return []
        
        # 句子分割
        sentences = sent_tokenize(text)
        
        if len(sentences) <= num_sentences:
            return sentences
        
        # 简单策略：返回前几句和后几句
        if num_sentences <= 3:
            return sentences[:num_sentences]
        else:
            front_count = num_sentences // 2
            back_count = num_sentences - front_count
            return sentences[:front_count] + sentences[-back_count:]
    
    def calculate_text_statistics(self, text: str) -> Dict[str, int]:
        """
        计算文本统计信息
        
        Args:
            text: 输入文本
            
        Returns:
            统计信息字典
        """
        if not text:
            return {
                'char_count': 0,
                'word_count': 0,
                'sentence_count': 0,
                'unique_word_count': 0
            }
        
        # 基础统计
        char_count = len(text)
        sentences = sent_tokenize(text)
        sentence_count = len(sentences)
        
        # 词语统计
        tokens = self.tokenize(text)
        word_count = len(tokens)
        unique_word_count = len(set(tokens))
        
        return {
            'char_count': char_count,
            'word_count': word_count,
            'sentence_count': sentence_count,
            'unique_word_count': unique_word_count
        }

