#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自定义异常类
定义项目中使用的各种异常类型
"""


class PaperAnalyzerError(Exception):
    """
    论文分析器基础异常类
    所有项目相关异常的基类
    """
    pass


class DataFetchError(PaperAnalyzerError):
    """
    数据获取异常
    当从外部API或数据源获取数据失败时抛出
    """
    pass


class AnalysisError(PaperAnalyzerError):
    """
    数据分析异常
    当数据分析过程中出现错误时抛出
    """
    pass


class ReportGenerationError(PaperAnalyzerError):
    """
    报表生成异常
    当生成报表过程中出现错误时抛出
    """
    pass


class APIError(PaperAnalyzerError):
    """
    API调用异常
    当调用外部API出现错误时抛出
    """
    pass


class ValidationError(PaperAnalyzerError):
    """
    数据验证异常
    当输入数据不符合预期格式时抛出
    """
    pass


class ConfigurationError(PaperAnalyzerError):
    """
    配置错误异常
    当配置文件或配置参数有误时抛出
    """
    pass

