#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置管理模块
负责加载和管理项目配置
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv


class Config:
    """
    配置管理类
    负责从环境变量和配置文件加载配置信息
    """
    
    def __init__(self, config_file: Optional[str] = None) -> None:
        """
        初始化配置管理器
        
        Args:
            config_file: 可选的配置文件路径
        """
        self.base_dir = Path(__file__).parent.parent.parent
        
        # 加载环境变量
        if config_file:
            load_dotenv(config_file)
        else:
            # 尝试加载默认配置文件
            for env_file in ['.env', 'config.env']:
                env_path = self.base_dir / env_file
                if env_path.exists():
                    load_dotenv(env_path)
                    break
        
        self._config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置信息
        
        Returns:
            配置字典
        """
        return {
            # 基础配置
            'debug': self._get_bool('DEBUG', False),
            'log_level': os.getenv('LOG_LEVEL', 'INFO'),
            
            # 路径配置
            'base_dir': self.base_dir,
            'data_dir': self.base_dir / os.getenv('DATA_DIR', 'data'),
            'output_dir': self.base_dir / os.getenv('OUTPUT_DIR', 'output'),
            'cache_dir': self.base_dir / os.getenv('CACHE_DIR', 'cache'),
            
            # API配置
            'arxiv_base_url': os.getenv(
                'ARXIV_BASE_URL', 
                'http://export.arxiv.org/api/query'
            ),
            'max_results_per_query': int(
                os.getenv('MAX_RESULTS_PER_QUERY', '100')
            ),
            'request_delay': float(os.getenv('REQUEST_DELAY', '3')),
            
            # 分析配置
            'min_word_length': int(os.getenv('MIN_WORD_LENGTH', '3')),
            'max_word_length': int(os.getenv('MAX_WORD_LENGTH', '20')),
            'top_keywords_count': int(
                os.getenv('TOP_KEYWORDS_COUNT', '20')
            ),
            'topic_model_components': int(
                os.getenv('TOPIC_MODEL_COMPONENTS', '10')
            ),
            
            # 报表配置
            'report_template_dir': self.base_dir / os.getenv(
                'REPORT_TEMPLATE_DIR', 'templates'
            ),
            'report_output_format': os.getenv(
                'REPORT_OUTPUT_FORMAT', 'html'
            ),
            'include_wordcloud': self._get_bool('INCLUDE_WORDCLOUD', True),
            'chart_dpi': int(os.getenv('CHART_DPI', '300')),
        }
    
    def _get_bool(self, key: str, default: bool = False) -> bool:
        """
        获取布尔型环境变量
        
        Args:
            key: 环境变量键名
            default: 默认值
            
        Returns:
            布尔值
        """
        value = os.getenv(key)
        if value is None:
            return default
        return value.lower() in ('true', '1', 'yes', 'on')
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key: 配置键名
            default: 默认值
            
        Returns:
            配置值
        """
        return self._config.get(key, default)
    
    def ensure_directories(self) -> None:
        """
        确保必要的目录存在
        """
        for dir_key in ['data_dir', 'output_dir', 'cache_dir']:
            directory = self.get(dir_key)
            if directory:
                Path(directory).mkdir(parents=True, exist_ok=True)


# 全局配置实例
config = Config()

