#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
报表生成器模块
负责生成各种格式的分析报表
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from jinja2 import Environment, FileSystemLoader, Template
from wordcloud import WordCloud

from ..config import config
from ..utils.exceptions import ReportGenerationError
from ..utils.json_formatter import create_json_response

logger = logging.getLogger(__name__)

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class ReportGenerator:
    """
    报表生成器
    支持生成HTML、PDF、JSON等格式的分析报表
    """
    
    def __init__(self) -> None:
        """
        初始化报表生成器
        """
        self.output_dir = Path(config.get('output_dir'))
        self.template_dir = Path(config.get('report_template_dir'))
        self.chart_dpi = config.get('chart_dpi', 300)
        self.include_wordcloud = config.get('include_wordcloud', True)
        
        # 确保输出目录存在
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 设置图表样式
        sns.set_style("whitegrid")
        sns.set_palette("husl")
    
    def generate_full_report(
        self,
        analysis_results: Dict[str, Any],
        papers_df: pd.DataFrame,
        report_title: str = "论文分析报告",
        output_format: str = "html"
    ) -> str:
        """
        生成完整的分析报告
        
        Args:
            analysis_results: 分析结果
            papers_df: 论文数据框
            report_title: 报告标题
            output_format: 输出格式 (html, json)
            
        Returns:
            报告文件路径
            
        Raises:
            ReportGenerationError: 生成报告失败时
        """
        try:
            logger.info(f"开始生成{output_format.upper()}格式报告")
            
            # 生成图表
            charts_data = self._generate_charts(analysis_results, papers_df)
            
            # 生成词云
            wordcloud_path = None
            if self.include_wordcloud:
                wordcloud_path = self._generate_wordcloud(analysis_results)
            
            # 根据格式生成报告
            if output_format.lower() == 'html':
                report_path = self._generate_html_report(
                    analysis_results, charts_data, wordcloud_path, report_title
                )
            elif output_format.lower() == 'json':
                report_path = self._generate_json_report(
                    analysis_results, report_title
                )
            else:
                raise ReportGenerationError(f"不支持的输出格式: {output_format}")
            
            logger.info(f"报告生成完成: {report_path}")
            return str(report_path)
            
        except Exception as e:
            logger.error(f"生成报告失败: {e}")
            raise ReportGenerationError(f"生成报告失败: {e}") from e
    
    def _generate_charts(
        self,
        analysis_results: Dict[str, Any],
        papers_df: pd.DataFrame
    ) -> Dict[str, str]:
        """
        生成各种图表
        
        Args:
            analysis_results: 分析结果
            papers_df: 论文数据框
            
        Returns:
            图表文件路径字典
        """
        logger.info("生成分析图表")
        
        charts_data = {}
        charts_dir = self.output_dir / "charts"
        charts_dir.mkdir(exist_ok=True)
        
        # 1. 时间趋势图
        if 'temporal_analysis' in analysis_results:
            temporal_chart = self._create_temporal_chart(
                analysis_results['temporal_analysis']
            )
            if temporal_chart:
                charts_data['temporal_trend'] = temporal_chart
        
        # 2. 作者分布图
        if 'author_analysis' in analysis_results:
            author_chart = self._create_author_chart(
                analysis_results['author_analysis']
            )
            if author_chart:
                charts_data['author_distribution'] = author_chart
        
        # 3. 分类分布图
        if 'category_analysis' in analysis_results:
            category_chart = self._create_category_chart(
                analysis_results['category_analysis']
            )
            if category_chart:
                charts_data['category_distribution'] = category_chart
        
        # 4. 关键词图表
        if 'keyword_analysis' in analysis_results:
            keyword_chart = self._create_keyword_chart(
                analysis_results['keyword_analysis']
            )
            if keyword_chart:
                charts_data['keyword_analysis'] = keyword_chart
        
        # 5. 协作分析图
        if 'collaboration_analysis' in analysis_results:
            collab_chart = self._create_collaboration_chart(
                analysis_results['collaboration_analysis']
            )
            if collab_chart:
                charts_data['collaboration_analysis'] = collab_chart
        
        return charts_data
    
    def _create_temporal_chart(
        self, 
        temporal_data: Dict[str, Any]
    ) -> Optional[str]:
        """
        创建时间趋势图
        
        Args:
            temporal_data: 时间分析数据
            
        Returns:
            图表文件路径
        """
        try:
            if 'yearly_distribution' not in temporal_data:
                return None
            
            yearly_data = temporal_data['yearly_distribution']
            
            # 创建Plotly图表
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=list(yearly_data.keys()),
                y=list(yearly_data.values()),
                mode='lines+markers',
                name='论文数量',
                line=dict(width=3),
                marker=dict(size=8)
            ))
            
            fig.update_layout(
                title='论文发表时间趋势',
                xaxis_title='年份',
                yaxis_title='论文数量',
                template='plotly_white',
                height=500
            )
            
            chart_path = self.output_dir / "charts" / "temporal_trend.html"
            fig.write_html(str(chart_path))
            
            return str(chart_path)
            
        except Exception as e:
            logger.warning(f"创建时间趋势图失败: {e}")
            return None
    
    def _create_author_chart(
        self, 
        author_data: Dict[str, Any]
    ) -> Optional[str]:
        """
        创建作者分析图表
        
        Args:
            author_data: 作者分析数据
            
        Returns:
            图表文件路径
        """
        try:
            if 'top_authors' not in author_data:
                return None
            
            top_authors = author_data['top_authors'][:15]  # 前15位作者
            
            authors = [author['name'] for author in top_authors]
            counts = [author['paper_count'] for author in top_authors]
            
            # 创建水平条形图
            fig = go.Figure(go.Bar(
                x=counts,
                y=authors,
                orientation='h',
                marker_color='skyblue'
            ))
            
            fig.update_layout(
                title='高产作者排行榜',
                xaxis_title='论文数量',
                yaxis_title='作者',
                template='plotly_white',
                height=600,
                yaxis={'categoryorder': 'total ascending'}
            )
            
            chart_path = self.output_dir / "charts" / "author_distribution.html"
            fig.write_html(str(chart_path))
            
            return str(chart_path)
            
        except Exception as e:
            logger.warning(f"创建作者图表失败: {e}")
            return None
    
    def _create_category_chart(
        self, 
        category_data: Dict[str, Any]
    ) -> Optional[str]:
        """
        创建分类分布图表
        
        Args:
            category_data: 分类分析数据
            
        Returns:
            图表文件路径
        """
        try:
            if 'top_categories' not in category_data:
                return None
            
            top_categories = category_data['top_categories'][:20]
            
            categories = [cat['category'] for cat in top_categories]
            counts = [cat['count'] for cat in top_categories]
            
            # 创建饼图
            fig = go.Figure(go.Pie(
                labels=categories,
                values=counts,
                hole=0.3
            ))
            
            fig.update_layout(
                title='学科分类分布',
                template='plotly_white',
                height=600
            )
            
            chart_path = self.output_dir / "charts" / "category_distribution.html"
            fig.write_html(str(chart_path))
            
            return str(chart_path)
            
        except Exception as e:
            logger.warning(f"创建分类图表失败: {e}")
            return None
    
    def _create_keyword_chart(
        self, 
        keyword_data: Dict[str, Any]
    ) -> Optional[str]:
        """
        创建关键词分析图表
        
        Args:
            keyword_data: 关键词分析数据
            
        Returns:
            图表文件路径
        """
        try:
            if 'top_keywords' not in keyword_data:
                return None
            
            top_keywords = keyword_data['top_keywords'][:20]
            
            words = [kw['word'] for kw in top_keywords]
            weights = [kw['weight'] for kw in top_keywords]
            
            # 创建条形图
            fig = go.Figure(go.Bar(
                x=weights,
                y=words,
                orientation='h',
                marker_color='lightcoral'
            ))
            
            fig.update_layout(
                title='关键词权重分析',
                xaxis_title='TF-IDF权重',
                yaxis_title='关键词',
                template='plotly_white',
                height=700,
                yaxis={'categoryorder': 'total ascending'}
            )
            
            chart_path = self.output_dir / "charts" / "keyword_analysis.html"
            fig.write_html(str(chart_path))
            
            return str(chart_path)
            
        except Exception as e:
            logger.warning(f"创建关键词图表失败: {e}")
            return None
    
    def _create_collaboration_chart(
        self, 
        collab_data: Dict[str, Any]
    ) -> Optional[str]:
        """
        创建协作分析图表
        
        Args:
            collab_data: 协作分析数据
            
        Returns:
            图表文件路径
        """
        try:
            # 创建协作分布图表
            labels = ['单作者', '双作者', '多作者']
            values = [
                collab_data.get('single_author_ratio', 0),
                collab_data.get('two_author_ratio', 0),
                collab_data.get('multi_author_ratio', 0)
            ]
            
            fig = go.Figure(go.Pie(
                labels=labels,
                values=values,
                hole=0.3,
                marker_colors=['lightblue', 'lightgreen', 'lightyellow']
            ))
            
            fig.update_layout(
                title='作者协作模式分布',
                template='plotly_white',
                height=500
            )
            
            chart_path = self.output_dir / "charts" / "collaboration_analysis.html"
            fig.write_html(str(chart_path))
            
            return str(chart_path)
            
        except Exception as e:
            logger.warning(f"创建协作图表失败: {e}")
            return None
    
    def _generate_wordcloud(
        self, 
        analysis_results: Dict[str, Any]
    ) -> Optional[str]:
        """
        生成词云图
        
        Args:
            analysis_results: 分析结果
            
        Returns:
            词云文件路径
        """
        try:
            if 'keyword_analysis' not in analysis_results:
                return None
            
            keywords = analysis_results['keyword_analysis'].get('top_keywords', [])
            
            if not keywords:
                return None
            
            # 准备词云数据
            wordcloud_dict = {
                kw['word']: kw['weight'] * 100 
                for kw in keywords[:50]
            }
            
            # 生成词云
            wordcloud = WordCloud(
                width=800,
                height=600,
                background_color='white',
                max_words=100,
                colormap='viridis',
                font_path=None  # 使用默认字体
            ).generate_from_frequencies(wordcloud_dict)
            
            # 保存词云图
            wordcloud_path = self.output_dir / "charts" / "wordcloud.png"
            wordcloud.to_file(str(wordcloud_path))
            
            return str(wordcloud_path)
            
        except Exception as e:
            logger.warning(f"生成词云失败: {e}")
            return None
    
    def _generate_html_report(
        self,
        analysis_results: Dict[str, Any],
        charts_data: Dict[str, str],
        wordcloud_path: Optional[str],
        report_title: str
    ) -> Path:
        """
        生成HTML格式报告
        
        Args:
            analysis_results: 分析结果
            charts_data: 图表数据
            wordcloud_path: 词云路径
            report_title: 报告标题
            
        Returns:
            HTML报告文件路径
        """
        # HTML模板
        html_template = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ report_title }}</title>
    <style>
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #007acc;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .section {
            margin-bottom: 40px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        .section h2 {
            color: #007acc;
            border-bottom: 2px solid #007acc;
            padding-bottom: 10px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #007acc;
        }
        .chart-container {
            margin: 20px 0;
            text-align: center;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .table th {
            background-color: #007acc;
            color: white;
        }
        .wordcloud {
            text-align: center;
            margin: 20px 0;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ report_title }}</h1>
        <p>生成时间: {{ generation_time }}</p>
    </div>

    <!-- 基础统计 -->
    <div class="section">
        <h2>📊 基础统计信息</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{{ basic_stats.total_papers }}</div>
                <div>论文总数</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ basic_stats.unique_authors }}</div>
                <div>独特作者数</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ basic_stats.unique_categories }}</div>
                <div>学科分类数</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ "%.1f"|format(basic_stats.average_authors_per_paper) }}</div>
                <div>平均作者数</div>
            </div>
        </div>
    </div>

    <!-- 图表展示 -->
    {% if charts_data %}
    <div class="section">
        <h2>📈 数据可视化</h2>
        {% for chart_name, chart_path in charts_data.items() %}
        <div class="chart-container">
            <iframe src="{{ chart_path }}" width="100%" height="600" frameborder="0"></iframe>
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- 词云图 -->
    {% if wordcloud_path %}
    <div class="section">
        <h2>☁️ 关键词词云</h2>
        <div class="wordcloud">
            <img src="{{ wordcloud_path }}" alt="关键词词云" style="max-width: 100%; height: auto;">
        </div>
    </div>
    {% endif %}

    <!-- 详细分析结果 -->
    <div class="section">
        <h2>📋 详细分析结果</h2>
        <pre style="background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto;">{{ analysis_results_json }}</pre>
    </div>

    <div class="footer">
        <p>报告由论文分析器自动生成 | {{ generation_time }}</p>
    </div>
</body>
</html>
        """
        
        # 渲染模板
        template = Template(html_template)
        
        html_content = template.render(
            report_title=report_title,
            generation_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            basic_stats=analysis_results.get('basic_statistics', {}),
            charts_data=charts_data,
            wordcloud_path=wordcloud_path,
            analysis_results_json=json.dumps(
                analysis_results, 
                ensure_ascii=False, 
                indent=2
            )
        )
        
        # 保存HTML文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        html_path = self.output_dir / f"paper_analysis_report_{timestamp}.html"
        
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_path
    
    def _generate_json_report(
        self,
        analysis_results: Dict[str, Any],
        report_title: str
    ) -> Path:
        """
        生成JSON格式报告
        
        Args:
            analysis_results: 分析结果
            report_title: 报告标题
            
        Returns:
            JSON报告文件路径
        """
        report_data = {
            "report_metadata": {
                "title": report_title,
                "generation_time": datetime.now().isoformat(),
                "version": "1.0.0"
            },
            "analysis_results": analysis_results
        }
        
        # 使用JSON格式化器
        json_content = create_json_response(
            data=report_data,
            status="success",
            message="论文分析报告生成完成"
        )
        
        # 保存JSON文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = self.output_dir / f"paper_analysis_report_{timestamp}.json"
        
        with open(json_path, 'w', encoding='utf-8') as f:
            f.write(json_content)
        
        return json_path
    
    def export_data(
        self,
        papers_df: pd.DataFrame,
        analysis_results: Dict[str, Any],
        export_format: str = "xlsx"
    ) -> str:
        """
        导出数据到Excel或CSV文件
        
        Args:
            papers_df: 论文数据框
            analysis_results: 分析结果
            export_format: 导出格式 (xlsx, csv)
            
        Returns:
            导出文件路径
            
        Raises:
            ReportGenerationError: 导出失败时
        """
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            if export_format.lower() == 'xlsx':
                file_path = self.output_dir / f"paper_data_{timestamp}.xlsx"
                
                with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                    # 主数据表
                    papers_df.to_excel(writer, sheet_name='论文数据', index=False)
                    
                    # 统计摘要表
                    stats_df = pd.DataFrame([analysis_results.get('basic_statistics', {})])
                    stats_df.to_excel(writer, sheet_name='统计摘要', index=False)
                    
                    # 关键词表
                    if 'keyword_analysis' in analysis_results:
                        keywords_data = analysis_results['keyword_analysis'].get('top_keywords', [])
                        if keywords_data:
                            keywords_df = pd.DataFrame(keywords_data)
                            keywords_df.to_excel(writer, sheet_name='关键词分析', index=False)
            
            elif export_format.lower() == 'csv':
                file_path = self.output_dir / f"paper_data_{timestamp}.csv"
                papers_df.to_csv(file_path, index=False, encoding='utf-8-sig')
            
            else:
                raise ReportGenerationError(f"不支持的导出格式: {export_format}")
            
            logger.info(f"数据导出完成: {file_path}")
            return str(file_path)
            
        except Exception as e:
            logger.error(f"导出数据失败: {e}")
            raise ReportGenerationError(f"导出数据失败: {e}") from e

