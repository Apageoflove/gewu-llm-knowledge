#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文分析器核心模块
提供论文数据的综合分析功能
"""

import logging
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from collections import Counter, defaultdict

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.cluster import KMeans
from wordcloud import WordCloud

from ..config import config
from ..utils.exceptions import AnalysisError
from ..utils.text_processor import TextProcessor
from ..utils.json_formatter import create_json_response

logger = logging.getLogger(__name__)


class PaperAnalyzer:
    """
    论文分析器
    提供论文数据的全面分析功能，包括统计分析、主题建模、关键词提取等
    """
    
    def __init__(self) -> None:
        """
        初始化论文分析器
        """
        self.text_processor = TextProcessor()
        self.top_keywords_count = config.get('top_keywords_count', 20)
        self.topic_components = config.get('topic_model_components', 10)
        
    def analyze_papers(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析论文数据集
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            分析结果字典
            
        Raises:
            AnalysisError: 分析过程中出现错误时
        """
        try:
            logger.info("开始分析论文数据集")
            
            if papers_df.empty:
                raise AnalysisError("论文数据集为空")
            
            analysis_results = {
                'basic_statistics': self._calculate_basic_statistics(papers_df),
                'temporal_analysis': self._analyze_temporal_trends(papers_df),
                'author_analysis': self._analyze_authors(papers_df),
                'category_analysis': self._analyze_categories(papers_df),
                'keyword_analysis': self._analyze_keywords(papers_df),
                'topic_modeling': self._perform_topic_modeling(papers_df),
                'text_statistics': self._analyze_text_statistics(papers_df),
                'collaboration_analysis': self._analyze_collaboration(papers_df)
            }
            
            logger.info("论文数据集分析完成")
            return analysis_results
            
        except Exception as e:
            logger.error(f"分析论文数据集失败: {e}")
            raise AnalysisError(f"分析论文数据集失败: {e}") from e
    
    def _calculate_basic_statistics(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        计算基础统计信息
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            基础统计信息
        """
        logger.info("计算基础统计信息")
        
        stats = {
            'total_papers': len(papers_df),
            'unique_authors': len(set(
                author for authors in papers_df['authors'] 
                for author in authors
            )),
            'unique_categories': len(set(
                cat for categories in papers_df['categories'] 
                for cat in categories
            )),
            'date_range': {},
            'average_authors_per_paper': papers_df['author_count'].mean(),
            'average_categories_per_paper': papers_df['category_count'].mean(),
            'average_title_length': papers_df['title_length'].mean(),
            'average_summary_length': papers_df['summary_length'].mean()
        }
        
        # 日期范围分析
        if 'published' in papers_df.columns:
            published_dates = pd.to_datetime(papers_df['published'])
            stats['date_range'] = {
                'earliest': published_dates.min().isoformat(),
                'latest': published_dates.max().isoformat(),
                'span_days': (published_dates.max() - published_dates.min()).days
            }
        
        return stats
    
    def _analyze_temporal_trends(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析时间趋势
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            时间趋势分析结果
        """
        logger.info("分析时间趋势")
        
        if 'published' not in papers_df.columns:
            return {'error': '缺少发布日期信息'}
        
        # 转换日期
        papers_df['published_date'] = pd.to_datetime(papers_df['published'])
        papers_df['year'] = papers_df['published_date'].dt.year
        papers_df['month'] = papers_df['published_date'].dt.month
        papers_df['year_month'] = papers_df['published_date'].dt.to_period('M')
        
        # 按年份统计
        yearly_counts = papers_df['year'].value_counts().sort_index()
        
        # 按月份统计
        monthly_counts = papers_df['year_month'].value_counts().sort_index()
        
        # 发布趋势
        trend_data = {
            'yearly_distribution': {
                str(year): int(count) 
                for year, count in yearly_counts.items()
            },
            'monthly_distribution': {
                str(month): int(count) 
                for month, count in monthly_counts.items()
            },
            'peak_year': int(yearly_counts.idxmax()),
            'peak_month': str(monthly_counts.idxmax()),
            'growth_trend': self._calculate_growth_trend(yearly_counts)
        }
        
        return trend_data
    
    def _calculate_growth_trend(self, yearly_counts: pd.Series) -> str:
        """
        计算增长趋势
        
        Args:
            yearly_counts: 年度论文数量
            
        Returns:
            趋势描述
        """
        if len(yearly_counts) < 2:
            return "数据不足"
        
        # 计算年度增长率
        growth_rates = yearly_counts.pct_change().dropna()
        avg_growth_rate = growth_rates.mean()
        
        if avg_growth_rate > 0.1:
            return "快速增长"
        elif avg_growth_rate > 0.05:
            return "稳定增长"
        elif avg_growth_rate > -0.05:
            return "基本稳定"
        else:
            return "下降趋势"
    
    def _analyze_authors(self, papers_df: pd.DataFrame) -> Dict[str, Any]:
        """
        分析作者信息
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            作者分析结果
        """
        logger.info("分析作者信息")
        
        # 展开所有作者
        all_authors = []
        for authors in papers_df['authors']:
            all_authors.extend(authors)
        
        # 作者统计
        author_counts = Counter(all_authors)
        
        # 高产作者
        top_authors = [
            {'name': author, 'paper_count': count}
            for author, count in author_counts.most_common(20)
        ]
        
        # 作者合作网络分析
        collaboration_stats = self._analyze_author_collaboration(papers_df)
        
        return {
            'total_unique_authors': len(author_counts),
            'top_authors': top_authors,
            'author_productivity_distribution': {
                '1_paper': sum(1 for count in author_counts.values() if count == 1),
                '2-5_papers': sum(1 for count in author_counts.values() if 2 <= count <= 5),
                '6-10_papers': sum(1 for count in author_counts.values() if 6 <= count <= 10),
                '10+_papers': sum(1 for count in author_counts.values() if count > 10)
            },
            'collaboration_statistics': collaboration_stats
        }
    
    def _analyze_author_collaboration(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析作者合作情况
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            合作分析结果
        """
        collaboration_counts = papers_df['author_count'].value_counts().sort_index()
        
        return {
            'single_author_papers': int(collaboration_counts.get(1, 0)),
            'multi_author_papers': int(collaboration_counts[collaboration_counts.index > 1].sum()),
            'average_authors_per_paper': float(papers_df['author_count'].mean()),
            'max_authors_in_paper': int(papers_df['author_count'].max()),
            'collaboration_distribution': {
                str(count): int(papers) 
                for count, papers in collaboration_counts.items()
            }
        }
    
    def _analyze_categories(self, papers_df: pd.DataFrame) -> Dict[str, Any]:
        """
        分析学科分类
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            分类分析结果
        """
        logger.info("分析学科分类")
        
        # 展开所有分类
        all_categories = []
        primary_categories = []
        
        for idx, row in papers_df.iterrows():
            categories = row['categories']
            primary_category = row.get('primary_category', '')
            
            all_categories.extend(categories)
            if primary_category:
                primary_categories.append(primary_category)
        
        # 分类统计
        category_counts = Counter(all_categories)
        primary_category_counts = Counter(primary_categories)
        
        return {
            'total_unique_categories': len(category_counts),
            'top_categories': [
                {'category': cat, 'count': count}
                for cat, count in category_counts.most_common(20)
            ],
            'top_primary_categories': [
                {'category': cat, 'count': count}
                for cat, count in primary_category_counts.most_common(20)
            ],
            'interdisciplinary_papers': sum(
                1 for categories in papers_df['categories'] 
                if len(categories) > 1
            ),
            'average_categories_per_paper': float(papers_df['category_count'].mean())
        }
    
    def _analyze_keywords(self, papers_df: pd.DataFrame) -> Dict[str, Any]:
        """
        分析关键词
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            关键词分析结果
        """
        logger.info("分析关键词")
        
        # 合并标题和摘要文本
        combined_texts = (
            papers_df['title'] + ' ' + papers_df['summary']
        ).tolist()
        
        # 提取关键词
        keywords = self.text_processor.extract_keywords(
            combined_texts, 
            top_k=self.top_keywords_count
        )
        
        # 分别分析标题和摘要关键词
        title_keywords = self.text_processor.extract_keywords(
            papers_df['title'].tolist(),
            top_k=10
        )
        
        summary_keywords = self.text_processor.extract_keywords(
            papers_df['summary'].tolist(),
            top_k=10
        )
        
        return {
            'top_keywords': keywords,
            'title_keywords': title_keywords,
            'summary_keywords': summary_keywords,
            'keyword_extraction_method': 'TF-IDF'
        }
    
    def _perform_topic_modeling(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        执行主题建模
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            主题建模结果
        """
        logger.info("执行主题建模")
        
        try:
            # 准备文本数据
            texts = (papers_df['title'] + ' ' + papers_df['summary']).tolist()
            
            # 预处理文本
            processed_texts = []
            for text in texts:
                tokens = self.text_processor.tokenize(text)
                lemmatized_tokens = self.text_processor.lemmatize_tokens(tokens)
                processed_texts.append(' '.join(lemmatized_tokens))
            
            # 过滤空文本
            processed_texts = [text for text in processed_texts if text.strip()]
            
            if len(processed_texts) < self.topic_components:
                return {'error': '文本数量不足以进行主题建模'}
            
            # TF-IDF向量化
            vectorizer = TfidfVectorizer(
                max_features=1000,
                min_df=2,
                max_df=0.8,
                ngram_range=(1, 2)
            )
            
            doc_term_matrix = vectorizer.fit_transform(processed_texts)
            feature_names = vectorizer.get_feature_names_out()
            
            # LDA主题建模
            lda = LatentDirichletAllocation(
                n_components=self.topic_components,
                random_state=42,
                max_iter=10
            )
            
            lda.fit(doc_term_matrix)
            
            # 提取主题
            topics = []
            for topic_idx, topic in enumerate(lda.components_):
                top_words_idx = topic.argsort()[-10:][::-1]
                top_words = [
                    {
                        'word': feature_names[i],
                        'weight': float(topic[i])
                    }
                    for i in top_words_idx
                ]
                
                topics.append({
                    'topic_id': topic_idx,
                    'words': top_words
                })
            
            return {
                'topics': topics,
                'num_topics': self.topic_components,
                'algorithm': 'Latent Dirichlet Allocation'
            }
            
        except Exception as e:
            logger.warning(f"主题建模失败: {e}")
            return {'error': f'主题建模失败: {str(e)}'}
    
    def _analyze_text_statistics(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析文本统计信息
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            文本统计结果
        """
        logger.info("分析文本统计信息")
        
        # 标题统计
        title_stats = {
            'average_length': float(papers_df['title_length'].mean()),
            'median_length': float(papers_df['title_length'].median()),
            'min_length': int(papers_df['title_length'].min()),
            'max_length': int(papers_df['title_length'].max())
        }
        
        # 摘要统计
        summary_stats = {
            'average_length': float(papers_df['summary_length'].mean()),
            'median_length': float(papers_df['summary_length'].median()),
            'min_length': int(papers_df['summary_length'].min()),
            'max_length': int(papers_df['summary_length'].max())
        }
        
        # 语言复杂度分析
        complexity_analysis = self._analyze_text_complexity(papers_df)
        
        return {
            'title_statistics': title_stats,
            'summary_statistics': summary_stats,
            'complexity_analysis': complexity_analysis
        }
    
    def _analyze_text_complexity(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析文本复杂度
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            复杂度分析结果
        """
        # 计算摘要的句子数量
        sentence_counts = []
        word_counts = []
        
        for summary in papers_df['summary'].head(100):  # 限制样本数量
            stats = self.text_processor.calculate_text_statistics(summary)
            sentence_counts.append(stats['sentence_count'])
            word_counts.append(stats['word_count'])
        
        if sentence_counts and word_counts:
            avg_sentences = sum(sentence_counts) / len(sentence_counts)
            avg_words_per_sentence = sum(word_counts) / sum(sentence_counts) if sum(sentence_counts) > 0 else 0
            
            return {
                'average_sentences_per_abstract': avg_sentences,
                'average_words_per_sentence': avg_words_per_sentence,
                'readability_score': self._calculate_readability_score(
                    avg_words_per_sentence, avg_sentences
                )
            }
        
        return {'error': '无法计算文本复杂度'}
    
    def _calculate_readability_score(
        self, 
        avg_words_per_sentence: float, 
        avg_sentences: float
    ) -> str:
        """
        计算可读性评分
        
        Args:
            avg_words_per_sentence: 平均每句词数
            avg_sentences: 平均句数
            
        Returns:
            可读性等级
        """
        # 简化的可读性评分
        if avg_words_per_sentence < 15:
            return "相对简单"
        elif avg_words_per_sentence < 20:
            return "中等复杂"
        else:
            return "较为复杂"
    
    def _analyze_collaboration(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        分析合作模式
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            合作分析结果
        """
        logger.info("分析合作模式")
        
        # 机构合作分析（如果有机构信息）
        collaboration_patterns = {
            'single_author_ratio': len(papers_df[papers_df['author_count'] == 1]) / len(papers_df),
            'two_author_ratio': len(papers_df[papers_df['author_count'] == 2]) / len(papers_df),
            'multi_author_ratio': len(papers_df[papers_df['author_count'] > 2]) / len(papers_df),
            'average_collaboration_size': float(papers_df['author_count'].mean())
        }
        
        # 合作网络密度（简化计算）
        total_collaborations = papers_df[papers_df['author_count'] > 1]['author_count'].sum()
        collaboration_patterns['total_collaborations'] = int(total_collaborations)
        
        return collaboration_patterns
    
    def generate_wordcloud_data(
        self, 
        papers_df: pd.DataFrame
    ) -> Dict[str, int]:
        """
        生成词云数据
        
        Args:
            papers_df: 论文数据框
            
        Returns:
            词云数据字典
        """
        logger.info("生成词云数据")
        
        # 合并所有文本
        all_text = ' '.join(
            papers_df['title'] + ' ' + papers_df['summary']
        )
        
        # 提取关键词
        keywords = self.text_processor.extract_keywords([all_text], top_k=100)
        
        # 转换为词云格式
        wordcloud_data = {
            keyword['word']: int(keyword['weight'] * 1000)
            for keyword in keywords
        }
        
        return wordcloud_data

