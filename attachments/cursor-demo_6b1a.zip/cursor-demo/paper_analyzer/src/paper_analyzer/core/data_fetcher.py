#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据获取模块
负责从arXiv等在线平台获取论文数据
"""

import json
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
from urllib.parse import quote_plus

import requests
import arxiv
import pandas as pd
from bs4 import BeautifulSoup

from ..config import config
from ..utils.exceptions import DataFetchError, APIError
from ..utils.json_formatter import create_json_response

logger = logging.getLogger(__name__)


class DataFetcher:
    """
    论文数据获取器
    支持从arXiv API获取论文元数据和全文信息
    """
    
    def __init__(self, cache_enabled: bool = True) -> None:
        """
        初始化数据获取器
        
        Args:
            cache_enabled: 是否启用缓存
        """
        self.cache_enabled = cache_enabled
        self.cache_dir = Path(config.get('cache_dir'))
        self.request_delay = config.get('request_delay', 3)
        self.max_results = config.get('max_results_per_query', 100)
        
        if self.cache_enabled:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def search_papers(
        self,
        query: str,
        max_results: Optional[int] = None,
        sort_by: str = "submittedDate",
        sort_order: str = "descending",
        date_from: Optional[str] = None,
        date_to: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        搜索论文
        
        Args:
            query: 搜索查询字符串
            max_results: 最大结果数量
            sort_by: 排序字段 (submittedDate, lastUpdatedDate, relevance)
            sort_order: 排序顺序 (ascending, descending)
            date_from: 开始日期 (YYYY-MM-DD)
            date_to: 结束日期 (YYYY-MM-DD)
            
        Returns:
            论文列表
            
        Raises:
            DataFetchError: 数据获取失败时
        """
        try:
            logger.info(f"开始搜索论文: {query}")
            
            # 构建搜索查询
            search_query = self._build_search_query(
                query, date_from, date_to
            )
            
            # 设置搜索参数
            max_results = max_results or self.max_results
            
            # 检查缓存
            cache_key = self._get_cache_key(
                search_query, max_results, sort_by, sort_order
            )
            
            if self.cache_enabled:
                cached_result = self._load_from_cache(cache_key)
                if cached_result:
                    logger.info("从缓存加载搜索结果")
                    return cached_result
            
            # 执行搜索
            papers = self._fetch_from_arxiv(
                search_query, max_results, sort_by, sort_order
            )
            
            # 保存到缓存
            if self.cache_enabled:
                self._save_to_cache(cache_key, papers)
            
            logger.info(f"成功获取 {len(papers)} 篇论文")
            return papers
            
        except Exception as e:
            logger.error(f"搜索论文失败: {e}")
            raise DataFetchError(f"搜索论文失败: {e}") from e
    
    def _build_search_query(
        self,
        query: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None
    ) -> str:
        """
        构建搜索查询字符串
        
        Args:
            query: 基础查询
            date_from: 开始日期
            date_to: 结束日期
            
        Returns:
            完整的查询字符串
        """
        search_query = query
        
        # 添加日期范围过滤
        if date_from or date_to:
            date_filter = []
            if date_from:
                date_filter.append(f"submittedDate:[{date_from}0000")
            if date_to:
                if date_from:
                    date_filter.append(f"TO {date_to}2359]")
                else:
                    date_filter.append(f"submittedDate:[* TO {date_to}2359]")
            
            if date_filter:
                search_query += f" AND {' '.join(date_filter)}"
        
        return search_query
    
    def _fetch_from_arxiv(
        self,
        query: str,
        max_results: int,
        sort_by: str,
        sort_order: str
    ) -> List[Dict[str, Any]]:
        """
        从arXiv API获取论文数据
        
        Args:
            query: 搜索查询
            max_results: 最大结果数
            sort_by: 排序字段
            sort_order: 排序顺序
            
        Returns:
            论文数据列表
        """
        try:
            # 设置排序参数
            sort_criterion = getattr(arxiv.SortCriterion, sort_by, None)
            if not sort_criterion:
                sort_criterion = arxiv.SortCriterion.SubmittedDate
            
            sort_order_enum = getattr(arxiv.SortOrder, sort_order.title(), None)
            if not sort_order_enum:
                sort_order_enum = arxiv.SortOrder.Descending
            
            # 创建搜索对象
            search = arxiv.Search(
                query=query,
                max_results=max_results,
                sort_by=sort_criterion,
                sort_order=sort_order_enum
            )
            
            papers = []
            for result in search.results():
                paper_data = self._extract_paper_data(result)
                papers.append(paper_data)
                
                # 添加请求延迟
                time.sleep(self.request_delay)
            
            return papers
            
        except Exception as e:
            logger.error(f"从arXiv获取数据失败: {e}")
            raise APIError(f"arXiv API错误: {e}") from e
    
    def _extract_paper_data(self, result: arxiv.Result) -> Dict[str, Any]:
        """
        提取论文数据
        
        Args:
            result: arXiv搜索结果
            
        Returns:
            论文数据字典
        """
        return {
            'id': result.entry_id.split('/')[-1],
            'title': result.title.strip(),
            'authors': [author.name for author in result.authors],
            'summary': result.summary.strip(),
            'published': result.published.isoformat(),
            'updated': result.updated.isoformat() if result.updated else None,
            'categories': result.categories,
            'primary_category': result.primary_category,
            'pdf_url': result.pdf_url,
            'entry_url': result.entry_id,
            'comment': result.comment,
            'journal_ref': result.journal_ref,
            'doi': result.doi,
            'links': [{'href': link.href, 'title': link.title} 
                     for link in result.links]
        }
    
    def _get_cache_key(self, *args: Any) -> str:
        """
        生成缓存键
        
        Args:
            *args: 用于生成键的参数
            
        Returns:
            缓存键字符串
        """
        import hashlib
        key_string = '_'.join(str(arg) for arg in args)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _load_from_cache(self, cache_key: str) -> Optional[List[Dict[str, Any]]]:
        """
        从缓存加载数据
        
        Args:
            cache_key: 缓存键
            
        Returns:
            缓存的数据或None
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if not cache_file.exists():
            return None
        
        # 检查缓存是否过期（24小时）
        cache_time = datetime.fromtimestamp(cache_file.stat().st_mtime)
        if datetime.now() - cache_time > timedelta(hours=24):
            cache_file.unlink()  # 删除过期缓存
            return None
        
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"读取缓存文件失败: {e}")
            return None
    
    def _save_to_cache(
        self, 
        cache_key: str, 
        data: List[Dict[str, Any]]
    ) -> None:
        """
        保存数据到缓存
        
        Args:
            cache_key: 缓存键
            data: 要缓存的数据
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"保存缓存文件失败: {e}")
    
    def get_paper_details(self, paper_id: str) -> Dict[str, Any]:
        """
        获取单篇论文的详细信息
        
        Args:
            paper_id: 论文ID
            
        Returns:
            论文详细信息
            
        Raises:
            DataFetchError: 获取失败时
        """
        try:
            logger.info(f"获取论文详情: {paper_id}")
            
            # 检查缓存
            cache_key = f"detail_{paper_id}"
            if self.cache_enabled:
                cached_result = self._load_from_cache(cache_key)
                if cached_result:
                    return cached_result[0] if cached_result else {}
            
            # 从arXiv获取
            search = arxiv.Search(id_list=[paper_id])
            result = next(search.results(), None)
            
            if not result:
                raise DataFetchError(f"未找到论文: {paper_id}")
            
            paper_data = self._extract_paper_data(result)
            
            # 保存到缓存
            if self.cache_enabled:
                self._save_to_cache(cache_key, [paper_data])
            
            return paper_data
            
        except Exception as e:
            logger.error(f"获取论文详情失败: {e}")
            raise DataFetchError(f"获取论文详情失败: {e}") from e
    
    def create_dataset(
        self, 
        papers: List[Dict[str, Any]], 
        output_path: Optional[str] = None
    ) -> pd.DataFrame:
        """
        创建论文数据集
        
        Args:
            papers: 论文数据列表
            output_path: 可选的输出文件路径
            
        Returns:
            论文数据框
        """
        try:
            df = pd.DataFrame(papers)
            
            # 数据预处理
            if not df.empty:
                # 转换日期列
                if 'published' in df.columns:
                    df['published'] = pd.to_datetime(df['published'])
                if 'updated' in df.columns:
                    df['updated'] = pd.to_datetime(df['updated'])
                
                # 添加派生字段
                df['author_count'] = df['authors'].apply(len)
                df['category_count'] = df['categories'].apply(len)
                df['summary_length'] = df['summary'].apply(len)
                df['title_length'] = df['title'].apply(len)
            
            # 保存数据集
            if output_path:
                output_file = Path(output_path)
                output_file.parent.mkdir(parents=True, exist_ok=True)
                
                if output_file.suffix == '.csv':
                    df.to_csv(output_file, index=False, encoding='utf-8')
                elif output_file.suffix == '.xlsx':
                    df.to_excel(output_file, index=False)
                else:
                    df.to_json(output_file, orient='records', indent=2)
                
                logger.info(f"数据集已保存: {output_file}")
            
            return df
            
        except Exception as e:
            logger.error(f"创建数据集失败: {e}")
            raise DataFetchError(f"创建数据集失败: {e}") from e

