#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文分析器包
用于分析在线论文并生成统计报表
"""

__version__ = "1.0.0"
__author__ = "Paper Analyzer Team"
__email__ = "team@example.com"

from .core.analyzer import PaperAnalyzer
from .core.data_fetcher import DataFetcher
from .core.report_generator import ReportGenerator

__all__ = [
    "PaperAnalyzer",
    "DataFetcher", 
    "ReportGenerator",
]

