package com.example.encrypt.dto;

import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 *
 */
@Data
@ToString
@Accessors(chain = true)
public class TestDto {
    private String userId;
    private String userName;
    private Integer age;
    private String info;

}
