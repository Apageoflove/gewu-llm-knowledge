package com.example.encrypt.utils;

import org.apache.commons.codec.binary.Base64;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

public class RsaUtils {
    public static final String KEY_ALGORITHM = "RSA";
    public static final String SIGNATURE_MD5_ALGORITHM = "MD5withRSA";
    public static final String SIGNATURE_SHA1_ALGORITHM = "SHA1withRSA";
    public static final String PUBLIC_KEY = "RSAPublicKey";
    public static final String PRIVATE_KEY = "RSAPrivateKey";
    public static final String CHARSET_NAME = "UTF-8";
    private static final int MAX_ENCRYPT_BLOCK = 117;
    private static final int MAX_DECRYPT_BLOCK = 128;
    private static final int INITIALIZE_LENGTH = 1024;

    public RsaUtils() {
    }

    public static Map<String, String> genKeyPair() throws Exception {
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        keyPairGen.initialize(1024);
        KeyPair keyPair = keyPairGen.generateKeyPair();
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        Map<String, String> keyMap = new HashMap(2);
        keyMap.put("RSAPublicKey", Base64.encodeBase64String(publicKey.getEncoded()));
        keyMap.put("RSAPrivateKey", Base64.encodeBase64String(privateKey.getEncoded()));
        return keyMap;
    }

    public static String sign(String signAlgorithm, String privateKey, byte[] data) throws Exception {
        PrivateKey privateK = getPrivateKey(privateKey);
        Signature signature = Signature.getInstance(signAlgorithm);
        signature.initSign(privateK);
        signature.update(data);
        return Base64.encodeBase64String(signature.sign());
    }

    public static boolean verify(String signAlgorithm, String publicKey, byte[] data, String sign) throws Exception {
        PublicKey publicK = getPublicKey(publicKey);
        Signature signature = Signature.getInstance(signAlgorithm);
        signature.initVerify(publicK);
        signature.update(data);
        return signature.verify(Base64.decodeBase64(sign));
    }

    public static byte[] decryptByPrivateKey(String privateKey, byte[] encryptedData) throws Exception {
        Cipher cipher = getCipher(2, getPrivateKey(privateKey));
        return segmentBytes(cipher, encryptedData, 128);
    }

    public static byte[] decryptByPublicKey(String publicKey, byte[] encryptedData) throws Exception {
        Cipher cipher = getCipher(2, getPublicKey(publicKey));
        return segmentBytes(cipher, encryptedData, 128);
    }

    public static byte[] encryptByPublicKey(String publicKey, byte[] data) throws Exception {
        Cipher cipher = getCipher(1, getPublicKey(publicKey));
        return segmentBytes(cipher, data, 117);
    }

    public static byte[] encryptByPrivateKey(String privateKey, byte[] data) throws Exception {
        Cipher cipher = getCipher(1, getPrivateKey(privateKey));
        return segmentBytes(cipher, data, 117);
    }

    private static byte[] segmentBytes(Cipher cipher, byte[] data, int maxBlock) {
        byte[] result = null;

        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int len = data.length;
            int offSet = 0;

            for (int i = 0; len - offSet > 0; offSet = i * maxBlock) {
                byte[] cache;
                if (len - offSet > maxBlock) {
                    cache = cipher.doFinal(data, offSet, maxBlock);
                } else {
                    cache = cipher.doFinal(data, offSet, len - offSet);
                }

                out.write(cache, 0, cache.length);
                ++i;
            }

            result = out.toByteArray();
            out.close();
        } catch (Exception var9) {
            var9.printStackTrace();
        }

        return result;
    }

    private static Cipher getCipher(int mode, Key key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        Cipher cipher = Cipher.getInstance(key.getAlgorithm());
        cipher.init(mode, key);
        return cipher;
    }

    public static PrivateKey getPrivateKey(String privateKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey));
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(pkcs8KeySpec);
    }

    public static PublicKey getPublicKey(String publicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(Base64.decodeBase64(publicKey));
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(x509KeySpec);
    }

    public static String encodeBase64PublicKey(String publicKey, String data) throws Exception {
        return Base64.encodeBase64String(encryptByPublicKey(publicKey, data.getBytes()));
    }

    public static String encodeBase64PrivateKey(String privateKey, String data) throws Exception {
        return Base64.encodeBase64String(encryptByPrivateKey(privateKey, data.getBytes()));
    }

    public static String decodeBase64ByPrivate(String privateKey, String data) throws Exception {
        return new String(decryptByPrivateKey(privateKey, Base64.decodeBase64(data)), "UTF-8");
    }

    public static String decodeBase64ByPublicKey(String publicKey, String data) throws Exception {
        return new String(decryptByPublicKey(publicKey, Base64.decodeBase64(data)), "UTF-8");
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> keyMap = genKeyPair();
        String myPublicKey = (String) keyMap.get("RSAPublicKey");
        String myPrivateKey = (String) keyMap.get("RSAPrivateKey");
        String text = "我是需要加密的文本abc";
        String encodePublicKey = encodeBase64PublicKey(myPublicKey, text);
        String encodePrivateKey = encodeBase64PrivateKey(myPrivateKey, text);
        System.out.println("公钥加密=" + encodePublicKey);
        System.out.println("私钥加密=" + encodePrivateKey);
        String decodeByPublicKey = decodeBase64ByPublicKey(myPublicKey, encodePrivateKey);
        String decodeByPrivate = decodeBase64ByPrivate(myPrivateKey, encodePublicKey);
        System.out.println();
        System.out.println("私钥解密=" + decodeByPrivate);
        System.out.println("公钥解密=" + decodeByPublicKey);
        String sign = sign("SHA1withRSA", myPrivateKey, text.getBytes());
        System.out.println("sign=" + sign);
        boolean verify = verify("SHA1withRSA", myPublicKey, text.getBytes(), sign);
        System.out.println("is verify=" + verify);
    }
}

