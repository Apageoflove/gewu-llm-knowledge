
#安装LLaMA-Factory
cd LLaMA-Factory
pip install -e ".[torch,metrics]"
pip install -e ".[gptq]" --no-build-isolation
pip install --no-deps -e .

cd GPTQModel-2.2.0
pip install -e .

#微调命令
llamafactory-cli train examples/train_lora/llama3_lora_sft.yaml
#推理命令
llamafactory-cli chat examples/inference/llama3_lora_sft.yaml
#合并命令
llamafactory-cli export examples/merge_lora/llama3_lora_sft.yaml
#评估命令
llamafactory-cli eval examples/train_lora/llama3_lora_eval.yaml
#NLG评估命令
llamafactory-cli train examples/extras/nlg_eval/llama3_lora_predict.yaml

#DDP训练
FORCE_TORCHRUN=1 llamafactory-cli train examples/train_lora/llama3_lora_sft_ds3.yaml

#单卡训练
torchrun  --standalone --nnodes=1 --nproc-per-node=1  src/train.py \
--stage sft \
--model_name_or_path /mnt/workspace/.cache/modelscope/models/LLM-Research/Meta-Llama-3-8B-Instruct  \
--do_train \
--dataset alpaca_en_demo \
--template llama3 \
--finetuning_type lora \
--output_dir  saves/llama3-8b/lora/ \
--overwrite_cache \
--per_device_train_batch_size 1 \
--gradient_accumulation_steps 8 \
--lr_scheduler_type cosine \
--max_samples 10 \
--logging_steps 5 \
--save_steps 5 \
--learning_rate 1e-4 \
--num_train_epochs 2.0 \
--plot_loss \
--bf16


#accelerate加速训练
accelerate launch \
--config_file accelerate_singleNode_config.yaml \
src/train.py training_config.yaml

#量化导出命令
需要先安装gptq库
pip install gptqmodel>=2.2.0
llamafactory-cli export examples/merge_lora/llama3_gptq.yaml


#配置推理服务端口，可以支持批量推理
API_PORT=8000 CUDA_VISIBLE_DEVICES=0 llamafactory-cli api examples/inference/llama3_lora_sft.yaml

#通过vllm进行推理
python scripts/vllm_infer.py --model_name_or_path /mnt/workspace/LLaMA-Factory/output/llama3_lora_sft --dataset alpaca_zh_demo

#评估命令
llamafactory-cli \
    --stage sft \
    --model_name_or_path /mnt/workspace/LLaMA-Factory/output/llama3_lora_eval \
    --preprocessing_num_workers 16 \
    --finetuning_type lora \
    --quantization_method bnb \
    --template default \
    --flash_attn auto \
    --dataset_dir data \
    --eval_dataset alpaca_zh_demo \
    --cutoff_len 1024 \
    --max_samples 100000 \
    --per_device_eval_batch_size 2 \
    --predict_with_generate True \
    --max_new_tokens 512 \
    --top_p 0.7 \
    --temperature 0.95 \
    --output_dir saves/Custom/lora/eval_2025-06-04-08-11-49 \
    --trust_remote_code True \
    --do_predict True

#训练命令
llamafactory-cli train \
    --stage sft \
    --do_train True \
    --model_name_or_path /mnt/workspace/.cache/modelscope/models/LLM-Research/Meta-Llama-3-8B-Instruct \
    --preprocessing_num_workers 16 \
    --finetuning_type lora \
    --template default \
    --flash_attn auto \
    --dataset_dir data \
    --dataset alpaca_zh,alpaca_en \
    --cutoff_len 2048 \
    --learning_rate 5e-05 \
    --num_train_epochs 3.0 \
    --max_samples 100 \
    --per_device_train_batch_size 2 \
    --gradient_accumulation_steps 8 \
    --lr_scheduler_type cosine \
    --max_grad_norm 1.0 \
    --logging_steps 5 \
    --save_steps 100 \
    --warmup_steps 0 \
    --packing False \
    --enable_thinking True \
    --report_to none \
    --output_dir saves/Custom/lora/train_2025-06-04-08-11-49 \
    --bf16 True \
    --plot_loss True \
    --trust_remote_code True \
    --ddp_timeout 180000000 \
    --include_num_input_tokens_seen True \
    --optim adamw_torch \
    --lora_rank 8 \
    --lora_alpha 16 \
    --lora_dropout 0 \
    --lora_target all