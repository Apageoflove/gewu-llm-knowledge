# 从peft库导入LoraConfig和TaskType类
# peft是Parameter-Efficient Fine-Tuning的缩写，是一种高效微调大型模型的方法
# 例如：我们有一个大型语言模型，但没有足够的计算资源进行完整微调，可以使用peft方法
from peft import LoraConfig, TaskType

# 创建一个LoRA配置对象
# LoRA是Low-Rank Adaptation的缩写，通过添加小型低秩矩阵来微调模型
# r=16: 低秩分解的秩，类似于压缩比例，越小训练参数越少
# target_modules: 指定要应用LoRA的模块，这里只微调注意力机制中的查询(q_proj)和值(v_proj)矩阵
# 例如：原始模型可能有上亿参数，但我们只更新这两个矩阵的参数
# task_type: 指定任务类型为因果语言模型(CAUSAL_LM)，如GPT类模型
# lora_alpha: 缩放参数，控制LoRA更新的强度，通常设为r的2倍
# lora_dropout: LoRA层的dropout率，防止过拟合
lora_config = LoraConfig(
    r=16,
    target_modules=["q_proj", "v_proj"],
    task_type=TaskType.CAUSAL_LM,
    lora_alpha=32,
    lora_dropout=0.05
)

# 打印LoRA配置信息，方便检查设置是否正确
print(lora_config)

# 从peft库导入PromptEncoderConfig类，用于P-Tuning配置
# P-Tuning是另一种参数高效微调方法，通过学习连续的虚拟token嵌入来提升性能
from peft import PromptEncoderConfig, TaskType

# 创建P-Tuning配置对象
# encoder_reparameterization_type="MLP": 使用多层感知机作为编码器
# encoder_hidden_size=128: 编码器隐藏层大小
# num_attention_heads=16: 注意力头数量，需要与原始模型匹配
# num_layers=24: 模型层数，需要与原始模型匹配
# num_transformer_submodules=1: Transformer子模块数量
# num_virtual_tokens=20: 虚拟token数量，相当于添加20个可学习的前缀token
# 例如：不直接修改模型参数，而是在输入前添加20个特殊token，只学习这些token的表示
# token_dim=1024: token维度，需要与模型的隐藏层维度匹配
# task_type=TaskType.SEQ_CLS: 任务类型为序列分类
p_tuning_config = PromptEncoderConfig(
    encoder_reparameterization_type="MLP",
    encoder_hidden_size=128,
    num_attention_heads=16,
    num_layers=24,
    num_transformer_submodules=1,
    num_virtual_tokens=20,
    token_dim=1024,
    task_type=TaskType.SEQ_CLS
)

# 从transformers库导入自动模型加载类
# transformers是Hugging Face的库，提供了各种预训练模型的接口
from transformers import AutoModelForCausalLM

# 加载预训练的OPT-350M模型
# OPT是Meta(Facebook)开发的开放预训练Transformer语言模型
# 350M表示模型有3.5亿参数，相对较小，适合实验和学习
model = AutoModelForCausalLM.from_pretrained("facebook/opt-350m")

# 从peft库导入get_peft_model函数，用于将普通模型转换为PEFT模型
from peft import get_peft_model

# 将原始模型转换为LoRA模型
# 这一步会在原始模型基础上添加LoRA适配器层，但不修改原始权重
# 例如：原始模型可能有350M参数，但添加LoRA后可能只需要训练不到1M的参数
lora_model = get_peft_model(model, lora_config)
# 打印可训练参数的数量和比例
# 这有助于确认LoRA是否正确应用，通常可训练参数比例会非常小(<1%)
lora_model.print_trainable_parameters()

# 将模型保存到本地
# 只保存LoRA适配器的权重，原始模型权重不变
# 这使得保存的文件非常小，便于分享和部署
lora_model.save_pretrained("VergilDante//opt-350m-lora")

# 将模型推送到Hugging Face Hub
# 这样其他人可以直接使用你微调的模型
# 例如：其他用户可以通过"VergilDante/opt-350m-lora"名称加载你的模型
lora_model.push_to_hub("VergilDante/opt-350m-lora")