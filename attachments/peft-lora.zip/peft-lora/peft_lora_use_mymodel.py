# 从peft库导入必要的类和函数
# PeftModel: 参数高效微调模型的基类
# PeftConfig: 用于加载已保存的PEFT模型配置
# get_peft_model: 将普通模型转换为PEFT模型的函数
# LoraConfig: LoRA方法的配置类
# TaskType: 定义任务类型的枚举类
from peft import PeftModel, PeftConfig, get_peft_model, LoraConfig, TaskType
# 从transformers库导入自动模型加载类
# AutoModelForCausalLM用于加载因果语言模型，如GPT类模型
from transformers import AutoModelForCausalLM

# 创建一个LoRA配置对象
# LoRA是一种参数高效微调技术，通过添加小型低秩矩阵来微调大模型
# 例如：原始模型可能有数十亿参数，但使用LoRA后只需训练几百万参数
lora_config = LoraConfig(
    r=16,  # 低秩分解的秩，类似于压缩比例，值越小训练参数越少
    target_modules=["q_proj", "v_proj"],  # 指定要应用LoRA的模块，这里只微调注意力机制中的查询和值矩阵
    task_type=TaskType.CAUSAL_LM,  # 指定任务类型为因果语言模型，适用于生成式任务
    lora_alpha=32,  # 缩放参数，控制LoRA更新的强度，通常设为r的2倍
    lora_dropout=0.05  # LoRA层的dropout率，防止过拟合，类似于给模型随机"蒙眼"训练
)

# 从Hugging Face Hub加载预训练的LoRA模型配置
# 这一步会获取之前保存的模型配置信息，包括基础模型路径等
# 例如：就像获取一本书的目录，了解书的结构，但还没有拿到书的内容
config = PeftConfig.from_pretrained("VergilDante/opt-350m-lora")
# 根据配置加载基础模型
# config.base_model_name_or_path包含了原始模型的位置信息
# 例如：先有房子的设计图(config)，然后根据图纸找到并搭建好基础房子结构(model)
model = AutoModelForCausalLM.from_pretrained(config.base_model_name_or_path)
# 将基础模型转换为LoRA模型
# 这一步会在原始模型基础上添加LoRA适配器层，但不修改原始权重
# 例如：在房子(model)上安装可调节的新设备(lora_config)，形成升级版房子(lora_model)
lora_model = get_peft_model(model, lora_config)
# 打印可训练参数的数量和比例
# 这有助于确认LoRA是否正确应用，通常可训练参数比例会非常小(<1%)
# 例如：查看在整栋大楼中，实际需要调整的只是几个门把手和窗户
lora_model.print_trainable_parameters()
# 将模型保存到本地（当前被注释掉）
# 只保存LoRA适配器的权重，原始模型权重不变，使得保存的文件非常小
#lora_model.save_pretrained("VergilDante//opt-350m-lora")
