from peft import LoraConfig, TaskType, PromptEncoderConfig

lora_config = LoraConfig(
    r =16,
    target_modules=["q_proj", "v_proj"],
    task_type=TaskType.CAUSAL_LM,
    lora_alpha=32,
    lora_dropout=0.05
)

print(lora_config)

#PromptEncoderConfig，用P-Tuning配置

p_tuning_config = PromptEncoderConfig(
    #使用多层感知机作为编码器
    encoder_reparameterization_type="MLP",
    encoder_hidden_size=128,
    num_attention_heads=16,
    num_layers=24,
    num_transformer_submodules=1,
    num_virtual_tokens=20,
    token_dim=1024,
    task_type = TaskType.SEQ_CLS
)

#从transformers库导入自动配置加载类
from transformers import AutoModelForCausalLM

model = AutoModelForCausalLM.from_pretrained("facebook/opt-350m")

from peft import get_peft_model
lora_model  = get_peft_model(model,lora_config)
lora_model.print_trainable_parameters()
#将模型保存在本地
#只保存Lora适配器的权重，原始模型权重不变
# 这使得保存的文件非常小，便于分享和部署
lora_model.save_pretrained("VergilDante/opt-350m-lora")

#将模型推送到Huggingface hub
lora_model.push_to_hub("VergilDante/opt-350m-lora")

