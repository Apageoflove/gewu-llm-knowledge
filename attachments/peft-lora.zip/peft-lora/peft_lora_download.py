# 从peft库导入LoraConfig和TaskType类
# peft是Parameter-Efficient Fine-Tuning的缩写，是一种高效微调大型模型的方法
# 例如：我们有一个大型语言模型，但没有足够的计算资源进行完整微调，可以使用peft方法
from peft import LoraConfig, TaskType, PeftConfig, get_peft_model
from transformers import AutoModelForCausalLM

lora_config = LoraConfig(
    r=16,
    target_modules=["q_proj", "v_proj"],
    task_type=TaskType.CAUSAL_LM,
    lora_alpha=64,
    lora_dropout=0.05

)

config = PeftConfig.from_pretrained("VergilDante/opt-350m-lora")

model = AutoModelForCausalLM.from_pretrained(config.base_model_name_or_path)

#将基础模型转换为LoRA模型
lora_model = get_peft_model(model, lora_config)

lora_model.print_trainable_parameters();

lora_model.save_pretrained("VergilDante/opt-350m-lora")