CUDA_VISIBLE_DEVICES=0 \
swift infer \
    --adapters output/v3-20250517-110115/checkpoint-6 \
    --infer_backend pt \
    --stream true \
    --temperature 0 \
    --max_new_tokens 2048

 