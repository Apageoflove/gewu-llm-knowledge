from swift.llm import sft_main, TrainArguments
result = sft_main(TrainArguments(
    model='Qwen/Qwen2-1.5B',
    train_type='lora',
    dataset=['AI-ModelScope/alpaca-gpt4-data-zh#30',
             'AI-ModelScope/alpaca-gpt4-data-en#30',
             'swift/self-cognition#40'],
    torch_dtype='bfloat16'
))
print(result)