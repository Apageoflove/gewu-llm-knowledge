# 导入load_dataset函数，用于加载数据集
from datasets import load_dataset

# 加载financial_phrasebank数据集中的sentences_allagree子集
# 例如：这个数据集包含金融新闻句子及其情感标签（积极、消极、中性）
ds = load_dataset("financial_phrasebank", "sentences_allagree")
# 将训练集分割成训练集和测试集，测试集占10%
ds = ds["train"].train_test_split(test_size=0.1)
# 将测试集重命名为验证集
ds["validation"] = ds["test"]
# 删除原来的测试集，因为已经将其重命名为验证集
del ds["test"]

# 获取标签类别名称列表
classes = ds["train"].features["label"].names
# 为数据集添加文本标签列，将数字标签转换为对应的文本标签
# 例如：将0转换为"positive"，1转换为"neutral"，2转换为"negative"
ds = ds.map(
    lambda x: {"text_label": [classes[label] for label in x["label"]]},
    batched=True,
    num_proc=1,
)

# 查看训练集的第一个样本，了解数据结构
ds["train"][0]
{'sentence': 'It will be operated by Nokia , and supported by its Nokia NetAct network and service management system .',
 'label': 1,
 'text_label': 'neutral'}

# 导入AutoTokenizer用于文本标记化处理
from transformers import AutoTokenizer

# 定义输入文本列名、标签列名和最大序列长度
text_column = "sentence"
label_column = "text_label"
max_length = 128

# 加载预训练的mt0-small模型的分词器
tokenizer = AutoTokenizer.from_pretrained("bigscience/mt0-small")


# 定义预处理函数，将文本和标签转换为模型输入格式
def preprocess_function(examples):
    # 获取输入文本和目标标签
    inputs = examples[text_column]
    targets = examples[label_column]
    # 对输入文本进行标记化处理，设置最大长度、填充和截断
    model_inputs = tokenizer(inputs, max_length=max_length, padding="max_length", truncation=True, return_tensors="pt")
    # 对目标标签进行标记化处理
    labels = tokenizer(targets, max_length=3, padding="max_length", truncation=True, return_tensors="pt")
    # 提取标签的input_ids
    labels = labels["input_ids"]
    # 将填充标记替换为-100，在计算损失时会忽略这些位置
    labels[labels == tokenizer.pad_token_id] = -100
    # 将标签添加到模型输入中
    model_inputs["labels"] = labels
    return model_inputs


# 对数据集应用预处理函数，转换为模型可用的格式
processed_ds = ds.map(
    preprocess_function,
    batched=True,
    num_proc=1,
    remove_columns=ds["train"].column_names,  # 移除原始列，只保留处理后的列
    load_from_cache_file=False,  # 不使用缓存，每次都重新处理
    desc="Running tokenizer on dataset",  # 进度条描述
)

# 导入DataLoader用于批处理数据和default_data_collator用于整理批次数据
from torch.utils.data import DataLoader
from transformers import default_data_collator

# 选择训练集的前50个样本和验证集的50个样本
# 这里是为了快速演示，实际应用中通常使用全部数据
train_ds = processed_ds["train"].select(range(50))
eval_ds = processed_ds["validation"].select(range(50))

# 设置批次大小为3
batch_size = 3

# 创建训练数据加载器，启用随机打乱和内存固定
train_dataloader = DataLoader(
    train_ds, shuffle=True, collate_fn=default_data_collator, batch_size=batch_size, pin_memory=True
)
# 创建评估数据加载器
eval_dataloader = DataLoader(eval_ds, collate_fn=default_data_collator, batch_size=batch_size, pin_memory=True)

# 导入序列到序列模型类
from transformers import AutoModelForSeq2SeqLM

# 加载预训练的mt0-small模型
model = AutoModelForSeq2SeqLM.from_pretrained("bigscience/mt0-small")

# 导入IA3配置和PEFT模型获取函数
from peft import IA3Config, get_peft_model

# 创建IA3配置，指定任务类型为序列到序列语言模型
# IA3（Infused Adapter by Inhibiting and Amplifying Inner Activations）是一种参数高效微调方法
peft_config = IA3Config(task_type="SEQ_2_SEQ_LM")
# 将原始模型转换为PEFT模型
model = get_peft_model(model, peft_config)
# 打印可训练参数信息
model.print_trainable_parameters()
"trainable params: 282,624 || all params: 1,229,863,936 || trainable%: 0.022980103060766553"

# 导入PyTorch和学习率调度器
import torch
from transformers import get_linear_schedule_with_warmup

# 设置学习率和训练轮数
lr = 8e-3
num_epochs = 3

# 创建AdamW优化器
optimizer = torch.optim.AdamW(model.parameters(), lr=lr)
# 创建带预热的线性学习率调度器
lr_scheduler = get_linear_schedule_with_warmup(
    optimizer=optimizer,
    num_warmup_steps=0,  # 不使用预热步骤
    num_training_steps=(len(train_dataloader) * num_epochs),  # 总训练步数
)

# 导入tqdm用于显示进度条
from tqdm import tqdm

# 设置设备为CUDA（GPU）
device = "cuda"
# 将模型移至GPU
model = model.to(device)

# 开始训练循环
for epoch in range(num_epochs):
    # 设置模型为训练模式
    model.train()
    total_loss = 0
    # 遍历训练数据批次
    for step, batch in enumerate(tqdm(train_dataloader)):
        # 将批次数据移至GPU
        batch = {k: v.to(device) for k, v in batch.items()}
        # 前向传播，计算模型输出
        outputs = model(**batch)
        # 获取损失
        loss = outputs.loss
        # 累加损失（用于计算平均损失）
        total_loss += loss.detach().float()
        # 反向传播，计算梯度
        loss.backward()
        # 更新模型参数
        optimizer.step()
        # 更新学习率
        lr_scheduler.step()
        # 清零梯度，准备下一批次
        optimizer.zero_grad()

    # 评估阶段：设置模型为评估模式
    model.eval()
    eval_loss = 0
    eval_preds = []
    # 遍历评估数据批次
    for step, batch in enumerate(tqdm(eval_dataloader)):
        # 将批次数据移至GPU
        batch = {k: v.to(device) for k, v in batch.items()}
        # 禁用梯度计算，节省内存
        with torch.no_grad():
            outputs = model(**batch)
        # 获取损失
        loss = outputs.loss
        # 累加损失
        eval_loss += loss.detach().float()
        # 获取预测结果：将logits转换为token ID，再解码为文本
        eval_preds.extend(
            tokenizer.batch_decode(torch.argmax(outputs.logits, -1).detach().cpu().numpy(), skip_special_tokens=True)
        )

    # 计算评估集的平均损失和困惑度
    eval_epoch_loss = eval_loss / len(eval_dataloader)
    eval_ppl = torch.exp(eval_epoch_loss)
    # 计算训练集的平均损失和困惑度
    train_epoch_loss = total_loss / len(train_dataloader)
    train_ppl = torch.exp(train_epoch_loss)
    # 打印当前轮次的训练和评估指标
    print(f"{epoch=}: {train_ppl=} {train_epoch_loss=} {eval_ppl=} {eval_epoch_loss=}")


# 设置Hugging Face账户名
account = 'VergilDante'
# 设置模型ID，用于上传到Hugging Face Hub
peft_model_id = f"{account}/mt0-small-ia3"
# 注释掉的模型上传代码
model.push_to_hub(peft_model_id)

# 导入自动PEFT模型加载函数
from peft import AutoPeftModelForSeq2SeqLM

# 从Hub加载已训练的PEFT模型并移至GPU
model = AutoPeftModelForSeq2SeqLM.from_pretrained(account+"/mt0-small-ia3").to("cuda")
# 加载对应的分词器
tokenizer = AutoTokenizer.from_pretrained("bigscience/mt0-small")

# 选择验证集中的第15个样本进行预测
i = 15
# 对输入文本进行标记化处理
inputs = tokenizer(ds["validation"][text_column][i], return_tensors="pt")
# 打印原始输入文本
print(ds["validation"][text_column][i])
"The robust growth was the result of the inclusion of clothing chain Lindex in the Group in December 2007 ."

# 使用模型生成预测结果
with torch.no_grad():
    # 将输入移至GPU
    inputs = {k: v.to(device) for k, v in inputs.items()}
    # 生成文本，最多生成10个新token
    outputs = model.generate(input_ids=inputs["input_ids"], max_new_tokens=10)
    # 解码并打印预测结果
    print(tokenizer.batch_decode(outputs.detach().cpu().numpy(), skip_special_tokens=True))
