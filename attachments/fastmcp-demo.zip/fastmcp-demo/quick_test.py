#!/usr/bin/env python3
"""
快速测试脚本 - 验证SSE客户端基本功能
"""

import asyncio
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from sse_calculator_client import SSECalculatorClient
    print("✅ SSE客户端模块导入成功")
except ImportError as e:
    print(f"❌ 无法导入SSE客户端模块: {e}")
    print("请确保已安装所需依赖：pip install -r requirements.txt")
    sys.exit(1)


async def quick_test():
    """快速测试基本功能"""
    print("🚀 开始快速测试...")
    
    try:
        # 创建客户端
        client = SSECalculatorClient()
        await client.connect()
        print("✅ 客户端创建成功")
        
        # 尝试健康检查（可能失败，如果服务器未运行）
        try:
            health = await client.health_check()
            print(f"✅ 健康检查成功: {health}")
            
            # 如果健康检查成功，尝试一个简单计算
            result = await client.calculate("2 + 2")
            if result.get('success'):
                print(f"✅ 计算测试成功: 2 + 2 = {result.get('result')}")
            else:
                print(f"❌ 计算测试失败: {result}")
            
        except Exception as e:
            print(f"⚠️  健康检查失败（正常，服务器可能未运行）: {e}")
        
        await client.disconnect()
        print("✅ 客户端断开连接成功")
        
        print("\n🎉 快速测试完成！客户端代码基本功能正常。")
        print("💡 提示：要进行完整测试，请运行：python test_sse_mcp_complete.py --mode integration")
        
    except Exception as e:
        print(f"❌ 快速测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    success = asyncio.run(quick_test())
    sys.exit(0 if success else 1)
