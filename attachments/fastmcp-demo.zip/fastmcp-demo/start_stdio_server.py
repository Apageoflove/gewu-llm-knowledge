#!/usr/bin/env python3
"""
启动STDIO MCP服务器的测试脚本
"""

# 导入异步编程模块
import asyncio
# 导入系统相关模块
import sys
# 导入操作系统相关模块
import os

# 添加src目录到Python路径，以便导入stdio_mcp_server模块
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# 从stdio_mcp_server模块导入main函数
from stdio_mcp_server import main

# 程序入口点
if __name__ == "__main__":
    # 打印启动提示信息
    print("启动STDIO MCP服务器...")
    # 打印服务器名称
    print("服务器名称: stdio-demo-server")
    # 打印支持的工具列表
    print("支持的工具:")
    # 打印第一个工具
    print("  - get_server_info: 获取服务器信息")
    # 打印第二个工具
    print("  - calculate_math: 数学计算")
    # 打印第三个工具
    print("  - text_analysis: 文本分析")
    # 打印第四个工具
    print("  - list_tools: 列出所有工具")
    # 打印操作提示
    print("\n按Ctrl+C停止服务器")
    
    # 使用try-except块来捕获异常
    try:
        # 使用asyncio运行MCP服务器的main函数
        asyncio.run(main())
    except KeyboardInterrupt:
        # 捕获键盘中断信号（Ctrl+C）
        print("\n服务器已停止")
    except Exception as e:
        # 捕获其他异常
        print(f"启动失败: {e}")
        # 以错误状态码退出程序
        sys.exit(1)
