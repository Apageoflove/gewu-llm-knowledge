# MCP服务器启动脚本 (PowerShell)
Write-Host "正在启动MCP服务器..." -ForegroundColor Green

# 检查Python是否安装
try {
    python --version
} catch {
    Write-Host "错误: 未找到Python，请确保Python已安装并添加到PATH" -ForegroundColor Red
    exit 1
}

# 检查依赖是否安装
Write-Host "检查依赖..." -ForegroundColor Yellow
pip install -r requirements.txt

# 启动服务器
Write-Host "启动MCP服务器..." -ForegroundColor Green
python start_server.py
