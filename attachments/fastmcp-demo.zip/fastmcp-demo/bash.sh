#Claude Code Yolo模式
claude --dangerously-skip-permissions

pip install mcp[cli]

#mcp服务 cli启动命令
mcp dev src/basic_mcp_server.py

#启动stdio mcp服务
mcp dev src/stdio_mcp_server.py 

#不要用这个路径，会报错：mcp dev .\src\basic_mcp_server.py  