#!/usr/bin/env python3
"""
MCP服务器启动脚本
"""

import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from basic_mcp_server import main
    import asyncio
    
    print("正在启动MCP服务器...")
    asyncio.run(main())
    
except ImportError as e:
    print(f"导入错误: {e}")
    print("请确保已安装所有依赖: pip install -r requirements.txt")
except Exception as e:
    print(f"启动错误: {e}")
    print("请检查basic_mcp_server.py文件配置")
