# 🚀 STDIO MCP服务器快速启动指南

## ⚡ 5分钟快速启动

### 1️⃣ 安装依赖
```bash
pip install -r requirements.txt
```

### 2️⃣ 启动服务器
```bash
# 方式1: 使用mcp dev命令（推荐）
mcp dev src/stdio_mcp_server.py

# 方式2: 直接运行Python
python src/stdio_mcp_server.py

# 方式3: 使用PowerShell脚本（Windows）
.\start_stdio_server.ps1
```

### 3️⃣ 测试功能
```bash
python test/test_stdio_server.py
```

## 🎯 核心特性

- ✅ **STDIO传输**: 支持标准输入输出
- ✅ **FastMCP框架**: 基于最新框架
- ✅ **多种工具**: 数学计算、文本分析等
- ✅ **类型安全**: 完整类型注解
- ✅ **异步支持**: asyncio架构

## 🛠️ 可用工具

| 工具名称 | 功能 | 示例 |
|---------|------|------|
| `get_server_info` | 获取服务器信息 | 查看服务器状态 |
| `calculate_math` | 数学计算 | `"2+3*4"` → `14` |
| `text_analysis` | 文本分析 | 字符统计、反转、转大写 |
| `list_tools` | 列出所有工具 | 查看可用功能 |

## 🔧 配置说明

### MCP配置文件已更新
```json
{
  "mcpServers": {
    "stdio-server": {
      "command": "python",
      "args": ["src/stdio_mcp_server.py"],
      "env": {},
      "cwd": "."
    }
  }
}
```

## 🐛 常见问题

### Q: mcp dev命令找不到文件？
**A**: 确保在项目根目录中执行命令

### Q: 依赖安装失败？
**A**: 检查Python版本（需要3.8+），使用虚拟环境

### Q: 权限问题？
**A**: Windows上可能需要以管理员身份运行PowerShell

## 📚 详细文档

- 📖 [完整使用指南](STDIO_SERVER_README.md)
- 🧪 [测试说明](test/test_stdio_server.py)
- ⚙️ [配置参考](mcp_config.json)

## 🎉 开始使用！

现在你可以：
1. 启动服务器
2. 测试各种工具
3. 根据需要扩展功能
4. 集成到你的MCP客户端中

**Happy Coding! 🚀**
