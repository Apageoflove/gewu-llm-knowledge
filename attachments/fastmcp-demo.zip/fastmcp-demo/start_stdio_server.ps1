# STDIO MCP服务器启动脚本 (PowerShell)
# 基于FastMCP框架实现

# 打印启动提示信息，使用绿色字体
Write-Host "🚀 启动STDIO MCP服务器..." -ForegroundColor Green
# 打印服务器名称，使用青色字体
Write-Host "服务器名称: stdio-demo-server" -ForegroundColor Cyan
# 打印传输方式，使用青色字体
Write-Host "传输方式: STDIO" -ForegroundColor Cyan
# 打印空行
Write-Host ""

# 检查Python是否可用的代码块
try {
    # 尝试获取Python版本信息
    $pythonVersion = python --version 2>&1
    # 如果成功，打印Python版本信息，使用绿色字体
    Write-Host "✅ Python版本: $pythonVersion" -ForegroundColor Green
} catch {
    # 如果失败，打印错误信息，使用红色字体
    Write-Host "❌ Python未找到，请确保Python已安装并在PATH中" -ForegroundColor Red
    # 退出脚本，返回错误码1
    exit 1
}

# 检查依赖是否安装的代码块
Write-Host "📦 检查依赖..." -ForegroundColor Yellow
try {
    # 尝试导入MCP和FastMCP模块
    python -c "import mcp; import fastmcp; print('✅ 依赖检查通过')" 2>$null
    # 如果成功，打印成功信息，使用绿色字体
    Write-Host "✅ 依赖检查通过" -ForegroundColor Green
} catch {
    # 如果失败，打印错误信息，使用红色字体
    Write-Host "❌ 依赖检查失败，请运行: pip install -r requirements.txt" -ForegroundColor Red
    # 退出脚本，返回错误码1
    exit 1
}

# 打印空行
Write-Host ""
# 打印可用工具标题，使用黄色字体
Write-Host "🛠️  可用工具:" -ForegroundColor Yellow
# 打印第一个工具信息，使用白色字体
Write-Host "  - get_server_info: 获取服务器信息" -ForegroundColor White
# 打印第二个工具信息，使用白色字体
Write-Host "  - calculate_math: 数学计算" -ForegroundColor White
# 打印第三个工具信息，使用白色字体
Write-Host "  - text_analysis: 文本分析" -ForegroundColor White
# 打印第四个工具信息，使用白色字体
Write-Host "  - list_tools: 列出所有工具" -ForegroundColor White
# 打印空行
Write-Host ""

# 打印提示信息标题，使用蓝色字体
Write-Host "💡 提示:" -ForegroundColor Blue
# 打印第一个提示，使用白色字体
Write-Host "  - 按Ctrl+C停止服务器" -ForegroundColor White
# 打印第二个提示，使用白色字体
Write-Host "  - 使用mcp dev src/stdio_mcp_server.py启动" -ForegroundColor White
# 打印空行
Write-Host ""

# 启动服务器的代码块
Write-Host "🔄 启动服务器..." -ForegroundColor Green
try {
    # 尝试启动Python服务器
    python src/stdio_mcp_server.py
} catch {
    # 如果启动失败，打印错误信息，使用红色字体
    Write-Host "❌ 启动失败: $_" -ForegroundColor Red
    # 打印空行
    Write-Host ""
    # 打印故障排除标题，使用黄色字体
    Write-Host "🔧 故障排除:" -ForegroundColor Yellow
    # 打印第一个故障排除建议，使用白色字体
    Write-Host "  1. 确保在项目根目录中" -ForegroundColor White
    # 打印第二个故障排除建议，使用白色字体
    Write-Host "  2. 检查src/stdio_mcp_server.py文件是否存在" -ForegroundColor White
    # 打印第三个故障排除建议，使用白色字体
    Write-Host "  3. 检查Python路径设置" -ForegroundColor White
    # 打印第四个故障排除建议，使用白色字体
    Write-Host "  4. 尝试: python -m src.stdio_mcp_server" -ForegroundColor White
}
