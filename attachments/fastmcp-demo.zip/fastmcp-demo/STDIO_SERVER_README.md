# STDIO MCP服务器使用指南

这是一个基于FastMCP框架实现的STDIO传输MCP服务器，支持通过`mcp dev`命令启动。

## 🚀 特性

- **STDIO传输**: 支持标准输入输出传输
- **FastMCP框架**: 基于最新的FastMCP 2.0+框架
- **多种工具**: 提供数学计算、文本分析等实用工具
- **类型安全**: 完整的类型注解支持
- **异步支持**: 基于asyncio的异步架构

## 📋 系统要求

- Python 3.8+
- FastMCP 2.0+
- MCP 1.2+

## 🛠️ 安装依赖

```bash
pip install -r requirements.txt
```

## 🚀 启动方式

### 方式1: 使用mcp dev命令（推荐）

```bash
# 在项目根目录下执行
mcp dev src/stdio_mcp_server.py
```

### 方式2: 直接运行Python文件

```bash
python src/stdio_mcp_server.py
```

### 方式3: 使用启动脚本

```bash
python start_stdio_server.py
```

## 🧪 测试功能

运行测试脚本来验证服务器功能：

```bash
python test/test_stdio_server.py
```

## 🛠️ 可用工具

### 1. get_server_info()
获取服务器基本信息

**返回示例:**
```json
{
  "name": "STDIO MCP Server",
  "version": "1.0.0",
  "protocol": "MCP",
  "transport": "stdio",
  "description": "基于FastMCP框架的STDIO传输MCP服务器",
  "features": ["stdio", "fastmcp", "tools", "async"]
}
```

### 2. calculate_math(expression: str)
计算数学表达式

**参数:**
- `expression`: 数学表达式字符串，如 "2+3*4"

**返回示例:**
```json
{
  "success": true,
  "expression": "2+3*4",
  "result": 14,
  "type": "int"
}
```

**安全特性:**
- 只允许数字、基本运算符和括号
- 阻止危险的Python代码执行

### 3. text_analysis(text: str, operation: str = "count")
文本分析工具

**参数:**
- `text`: 要分析的文本
- `operation`: 操作类型
  - `"count"`: 字符、单词、行数统计
  - `"reverse"`: 文本反转
  - `"uppercase"`: 转换为大写

**返回示例:**
```json
{
  "operation": "count",
  "text": "Hello World!",
  "char_count": 12,
  "word_count": 2,
  "line_count": 1
}
```

### 4. list_tools()
列出所有可用的工具

**返回示例:**
```json
{
  "total_tools": 4,
  "tools": [
    {
      "name": "get_server_info",
      "description": "获取服务器基本信息",
      "parameters": {}
    },
    // ... 其他工具
  ]
}
```

## ⚙️ 配置说明

### MCP配置文件 (mcp_config.json)

```json
{
  "mcpServers": {
    "stdio-server": {
      "command": "python",
      "args": ["src/stdio_mcp_server.py"],
      "env": {},
      "cwd": "."
    }
  }
}
```

### 环境变量

- `PYTHONPATH`: 确保src目录在Python路径中
- `MCP_LOG_LEVEL`: 设置日志级别（可选）

## 🔧 开发指南

### 添加新工具

1. 在`stdio_mcp_server.py`中添加新函数
2. 使用`@mcp.tool()`装饰器
3. 添加类型注解和文档字符串
4. 更新`list_tools()`函数

**示例:**
```python
@mcp.tool()
def new_tool(param: str) -> Dict[str, Any]:
    """新工具的描述"""
    # 工具实现
    return {"result": "success"}
```

### 自定义传输

当前使用STDIO传输，如需其他传输方式：

```python
# 替换stdio_server为其他传输方式
from mcp.server.tcp import tcp_server
# 或
from mcp.server.websocket import websocket_server
```

## 🐛 故障排除

### 常见问题

1. **ImportError: No module named 'mcp'**
   - 确保已安装MCP依赖: `pip install mcp>=1.2.0`

2. **FastMCP导入失败**
   - 检查FastMCP版本: `pip install fastmcp>=2.0.0`

3. **权限问题**
   - 确保有执行Python文件的权限
   - 在Windows上可能需要以管理员身份运行

4. **路径问题**
   - 确保在正确的项目目录中
   - 检查Python路径设置

### 调试模式

启用详细日志：

```bash
export MCP_LOG_LEVEL=DEBUG
mcp dev src/stdio_mcp_server.py
```

## 📚 相关资源

- [MCP协议文档](https://modelcontextprotocol.io/)
- [FastMCP文档](https://github.com/fastmcp/fastmcp)
- [Python asyncio文档](https://docs.python.org/3/library/asyncio.html)

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个项目！

## 📄 许可证

MIT License
