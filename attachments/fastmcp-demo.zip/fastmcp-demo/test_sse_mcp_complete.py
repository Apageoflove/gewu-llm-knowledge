#!/usr/bin/env python3
"""
SSE MCP完整测试脚本
运行所有SSE计算器相关的测试
"""

import asyncio
import sys
import os
import subprocess
import argparse

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))
sys.path.insert(0, os.path.join(project_root, 'test'))


def run_sync_test(test_script: str, description: str) -> bool:
    """运行同步测试脚本"""
    print(f"\n{'='*60}")
    print(f"🧪 运行测试: {description}")
    print(f"脚本: {test_script}")
    print('='*60)
    
    try:
        result = subprocess.run(
            [sys.executable, test_script],
            capture_output=True,
            text=True,
            cwd=project_root
        )
        
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        
        if result.returncode == 0:
            print(f"✅ {description}: 通过")
            return True
        else:
            print(f"❌ {description}: 失败 (退出码: {result.returncode})")
            return False
            
    except Exception as e:
        print(f"❌ {description}: 异常 - {e}")
        return False


async def run_async_test(test_module: str, description: str) -> bool:
    """运行异步测试模块"""
    print(f"\n{'='*60}")
    print(f"🧪 运行异步测试: {description}")
    print(f"模块: {test_module}")
    print('='*60)
    
    try:
        # 动态导入测试模块
        module = __import__(test_module)
        
        # 运行主函数
        if hasattr(module, 'main'):
            result = await module.main()
            if result == 0:
                print(f"✅ {description}: 通过")
                return True
            else:
                print(f"❌ {description}: 失败")
                return False
        else:
            print(f"❌ {description}: 模块缺少main函数")
            return False
            
    except Exception as e:
        print(f"❌ {description}: 异常 - {e}")
        return False


async def test_client_only():
    """仅测试客户端（需要外部服务器运行）"""
    print("=== 客户端测试模式 ===")
    print("注意: 请确保SSE服务器已在 http://127.0.0.1:8000 运行")
    
    sys.path.insert(0, os.path.join(project_root, 'test'))
    from test_sse_client import run_client_tests
    
    try:
        success = await run_client_tests()
        return success
    except Exception as e:
        print(f"❌ 客户端测试失败: {e}")
        return False


async def test_server_functions():
    """测试服务器函数（不启动HTTP服务）"""
    print("=== 服务器函数测试 ===")
    
    # 运行简单的核心函数测试
    test_script = os.path.join(project_root, 'test', 'test_sse_calculator_simple.py')
    return run_sync_test(test_script, "服务器核心函数")


async def test_full_integration():
    """完整集成测试"""
    print("=== 完整集成测试 ===")
    
    sys.path.insert(0, os.path.join(project_root, 'test'))
    
    # 直接调用相关测试函数，避免命令行参数冲突
    try:
        # 导入测试函数
        from test_sse_integration import test_full_integration as run_full_integration
        from test_sse_integration import test_concurrent_clients
        from test_sse_integration import test_long_running_connection
        
        # 运行各项集成测试
        results = {}
        results['integration'] = await run_full_integration()
        results['concurrent'] = await test_concurrent_clients()
        results['long_connection'] = await test_long_running_connection()
        
        # 检查结果
        all_passed = all(results.values())
        
        print("\n集成测试结果:")
        for test_name, result in results.items():
            status = "✅ 通过" if result else "❌ 失败"
            print(f"   {test_name}: {status}")
        
        return all_passed
        
    except Exception as e:
        print(f"❌ 集成测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


async def run_demo():
    """运行客户端演示"""
    print("=== 客户端演示 ===")
    
    sys.path.insert(0, os.path.join(project_root, 'src'))
    from sse_calculator_client import demo_client
    
    try:
        await demo_client()
        return True
    except Exception as e:
        print(f"❌ 演示运行失败: {e}")
        return False


async def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='SSE MCP完整测试套件')
    parser.add_argument('--mode', choices=['all', 'server', 'client', 'integration', 'demo'], 
                       default='all', help='测试模式')
    parser.add_argument('--verbose', '-v', action='store_true', help='详细输出')
    
    args = parser.parse_args()
    
    print("🚀 SSE MCP计算器测试套件")
    print(f"模式: {args.mode}")
    print("="*60)
    
    results = {}
    
    try:
        if args.mode in ['all', 'server']:
            results['server_functions'] = await test_server_functions()
        
        if args.mode in ['all', 'client']:
            results['client_only'] = await test_client_only()
        
        if args.mode in ['all', 'integration']:
            results['integration'] = await test_full_integration()
        
        if args.mode == 'demo':
            results['demo'] = await run_demo()
        
        # 输出总结
        print("\n" + "="*60)
        print("📊 测试总结:")
        
        total_tests = len(results)
        passed_tests = sum(1 for result in results.values() if result)
        
        for test_name, result in results.items():
            status = "✅ 通过" if result else "❌ 失败"
            print(f"   {test_name}: {status}")
        
        print(f"\n总体结果: {passed_tests}/{total_tests} 测试通过")
        
        if passed_tests == total_tests:
            print("🎉 所有测试都通过了!")
            return 0
        else:
            print("⚠️  部分测试失败")
            return 1
    
    except KeyboardInterrupt:
        print("\n⚠️  测试被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 测试套件异常: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
