# 计算器MCP服务器

这是一个基于FastMCP框架实现的简单MCP（Model Context Protocol）服务器，提供基础的计算器加法功能。

## 功能特性

- **基础加法**: 支持两个数字相加
- **批量加法**: 支持多个数字求和
- **数字验证**: 验证输入是否为有效数字
- **服务器信息**: 获取服务器基本信息

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 直接运行服务器

```bash
python src/simple_mcp_server.py
```

### 2. 测试功能

```bash
python test/test_calculator.py
```

### 3. 作为MCP服务器使用

这个服务器实现了MCP协议，可以被支持MCP的客户端调用。

## 可用的工具

### add_numbers(a, b)
计算两个数字的加法

**参数:**
- `a`: 第一个数字（整数或浮点数）
- `b`: 第二个数字（整数或浮点数）

**返回:**
```json
{
    "expression": "5 + 3",
    "result": 8,
    "operation": "addition",
    "status": "success"
}
```

### add_multiple_numbers(numbers)
计算多个数字的总和

**参数:**
- `numbers`: 数字列表

**返回:**
```json
{
    "expression": "1 + 2 + 3 + 4 + 5",
    "result": 15,
    "operation": "multiple_addition",
    "count": 5,
    "status": "success"
}
```

### validate_number(value)
验证输入是否为有效数字

**参数:**
- `value`: 要验证的字符串

**返回:**
```json
{
    "value": "123",
    "is_valid": true,
    "numeric_value": 123.0,
    "type": "integer"
}
```

### get_calculator_info()
获取服务器信息

**返回:**
```json
{
    "name": "Calculator MCP Server",
    "version": "1.0.0",
    "description": "提供基础数学计算功能的MCP服务器",
    "supported_operations": ["addition", "multiple_addition"],
    "protocol": "MCP"
}
```

## 项目结构

```
fastmcp-demo/
├── src/
│   ├── simple_mcp_server.py    # 计算器MCP服务器
│   └── basic_mcp_server.py     # 基础MCP服务器示例
├── test/
│   └── test_calculator.py      # 功能测试文件
├── requirements.txt             # 项目依赖
└── README.md                   # 项目说明
```

## 技术架构

- **框架**: FastMCP 2.0+
- **协议**: MCP (Model Context Protocol)
- **语言**: Python 3.8+
- **类型提示**: 完整的类型注解支持

## 扩展功能

你可以轻松扩展这个服务器，添加更多数学运算功能：

- 减法、乘法、除法
- 幂运算、开方
- 三角函数
- 统计计算

只需要在`simple_mcp_server.py`中添加新的`@mcp.tool()`装饰器函数即可。

## 许可证

MIT License
