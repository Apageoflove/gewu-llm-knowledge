from mcp.server.fastmcp import FastMCP
from mcp.server.models import InitializationOptions
import asyncio

# 基础MCP服务器初始化
mcp = FastMCP("demo-server")

@mcp.tool()
def get_server_info() -> dict:
    """获取服务器基本信息"""
    return {
        "name": "Demo MCP Server",
        "version": "1.0.0",
        "protocol": "MCP",
        "description": "演示用MCP服务器"
    }

@mcp.tool()
def hello_world(name: str = "World") -> str:
    """简单的问候工具"""
    return f"Hello, {name}!"

@mcp.tool()
def add_numbers(a: float, b: float) -> dict:
    """计算两个数字的和"""
    result = a + b
    return {
        "expression": f"{a} + {b}",
        "result": result,
        "operation": "addition"
    }

async def main():
    """主函数，用于启动MCP服务器"""
    await mcp.run()

if __name__ == "__main__":
    # 使用asyncio运行MCP服务器
    asyncio.run(main())