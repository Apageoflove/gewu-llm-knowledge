#!/usr/bin/env python3
"""
MCP SSE计算器客户端
连接到SSE计算器服务器，提供计算器功能的客户端接口
"""

import asyncio
import json
import logging
import aiohttp
import time
from typing import Dict, Any, Optional, AsyncGenerator, Callable, List
from contextlib import asynccontextmanager


# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SSECalculatorClient:
    """MCP SSE计算器客户端"""
    
    def __init__(self, server_url: str = "http://127.0.0.1:8000"):
        """
        初始化SSE计算器客户端
        
        Args:
            server_url: 服务器基础URL
        """
        self.server_url = server_url
        self.sse_url = f"{server_url}/sse"
        self.calculate_url = f"{server_url}/calculate"
        self.health_url = f"{server_url}/health"
        
        self.session: Optional[aiohttp.ClientSession] = None
        self.is_connected = False
        self.server_info: Optional[Dict[str, Any]] = None
        
        # 事件回调
        self.on_connection = None
        self.on_server_info = None
        self.on_heartbeat = None
        self.on_error = None
        self.on_disconnect = None
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.disconnect()
    
    async def connect(self):
        """连接到服务器"""
        if self.session is None:
            self.session = aiohttp.ClientSession()
        
        logger.info(f"连接到SSE计算器服务器: {self.server_url}")
    
    async def disconnect(self):
        """断开连接"""
        if self.session:
            await self.session.close()
            self.session = None
        
        self.is_connected = False
        logger.info("已断开与SSE计算器服务器的连接")
        
        if self.on_disconnect:
            await self.on_disconnect()
    
    async def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        if not self.session:
            await self.connect()
        
        try:
            async with self.session.get(self.health_url) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"服务器健康检查通过: {data}")
                    return data
                else:
                    raise Exception(f"健康检查失败: HTTP {response.status}")
        except Exception as e:
            logger.error(f"健康检查错误: {e}")
            raise
    
    async def listen_sse_events(self) -> AsyncGenerator[Dict[str, Any], None]:
        """监听SSE事件流"""
        if not self.session:
            await self.connect()
        
        try:
            logger.info(f"开始监听SSE事件流: {self.sse_url}")
            
            async with self.session.get(self.sse_url) as response:
                if response.status != 200:
                    raise Exception(f"SSE连接失败: HTTP {response.status}")
                
                async for line in response.content:
                    line = line.decode('utf-8').strip()
                    
                    if line.startswith('data: '):
                        data_str = line[6:]  # 移除 'data: ' 前缀
                        try:
                            event_data = json.loads(data_str)
                            yield event_data
                            
                            # 处理不同类型的事件
                            await self._handle_sse_event(event_data)
                            
                        except json.JSONDecodeError as e:
                            logger.warning(f"无法解析SSE数据: {data_str}, 错误: {e}")
                    
        except asyncio.CancelledError:
            logger.info("SSE事件监听被取消")
        except Exception as e:
            logger.error(f"SSE事件监听错误: {e}")
            if self.on_error:
                await self.on_error(str(e))
            raise
    
    async def _handle_sse_event(self, event_data: Dict[str, Any]):
        """处理SSE事件"""
        event_type = event_data.get('type', '')
        
        if event_type == 'connection':
            self.is_connected = True
            logger.info(f"SSE连接已建立: {event_data}")
            if self.on_connection:
                await self.on_connection(event_data)
        
        elif event_type == 'server_info':
            self.server_info = event_data.get('data', {})
            logger.info(f"收到服务器信息: {self.server_info}")
            if self.on_server_info:
                await self.on_server_info(self.server_info)
        
        elif event_type == 'heartbeat':
            logger.debug(f"收到心跳: {event_data}")
            if self.on_heartbeat:
                await self.on_heartbeat(event_data)
        
        elif event_type == 'error':
            error_msg = event_data.get('message', '未知错误')
            logger.error(f"服务器错误: {error_msg}")
            if self.on_error:
                await self.on_error(error_msg)
    
    async def calculate(self, expression: str) -> Dict[str, Any]:
        """
        发送计算请求到服务器
        
        Args:
            expression: 数学表达式
            
        Returns:
            计算结果字典
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {"expression": expression}
            
            async with self.session.post(
                self.calculate_url,
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"计算请求成功: {expression} -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"计算请求失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"计算请求错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "expression": expression
            }
    
    async def add(self, a: float, b: float) -> Dict[str, Any]:
        """加法运算（通过表达式计算）"""
        return await self.calculate(f"{a} + {b}")
    
    async def subtract(self, a: float, b: float) -> Dict[str, Any]:
        """减法运算（通过表达式计算）"""
        return await self.calculate(f"{a} - {b}")
    
    async def multiply(self, a: float, b: float) -> Dict[str, Any]:
        """乘法运算（通过表达式计算）"""
        return await self.calculate(f"{a} * {b}")
    
    async def divide(self, a: float, b: float) -> Dict[str, Any]:
        """除法运算（通过表达式计算）"""
        return await self.calculate(f"{a} / {b}")
    
    async def power(self, base: float, exponent: float) -> Dict[str, Any]:
        """幂运算（通过表达式计算）"""
        return await self.calculate(f"{base} ** {exponent}")
    
    async def square_root(self, number: float) -> Dict[str, Any]:
        """平方根运算（通过表达式计算）"""
        return await self.calculate(f"sqrt({number})")
    
    # ========== 高级数学函数客户端方法 ==========
    
    async def trigonometric_function(self, function: str, angle: float, unit: str = "radians") -> Dict[str, Any]:
        """
        高级三角函数计算
        
        Args:
            function: 函数名 (sin, cos, tan, asin, acos, atan, sinh, cosh, tanh, asinh, acosh, atanh)
            angle: 角度值
            unit: 角度单位 ('radians' 或 'degrees')
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {
                "function": function,
                "angle": angle,
                "unit": unit
            }
            
            async with self.session.post(
                f"{self.server_url}/trigonometric_functions",
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"三角函数计算成功: {function}({angle}) -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"三角函数计算失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"三角函数计算错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "function": function,
                "angle": angle
            }
    
    async def logarithmic_function(self, function: str, value: float, base: Optional[float] = None) -> Dict[str, Any]:
        """
        对数函数计算
        
        Args:
            function: 对数类型 ('ln', 'log', 'log10', 'log2', 'logn')
            value: 真数
            base: 底数 (仅对 'logn' 需要)
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {
                "function": function,
                "value": value
            }
            if base is not None:
                data["base"] = base
            
            async with self.session.post(
                f"{self.server_url}/logarithmic_functions",
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"对数计算成功: {function}({value}) -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"对数计算失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"对数计算错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "function": function,
                "value": value
            }
    
    async def statistical_analysis(self, data: List[float]) -> Dict[str, Any]:
        """
        统计分析工具
        
        Args:
            data: 数据列表
        """
        if not self.session:
            await self.connect()
        
        try:
            request_data = {"data": data}
            
            async with self.session.post(
                f"{self.server_url}/statistical_analysis",
                json=request_data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"统计分析成功: {len(data)}个数据点 -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"统计分析失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"统计分析错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "data": data
            }
    
    async def polynomial_evaluation(self, coefficients: List[float], x: float) -> Dict[str, Any]:
        """
        多项式求值
        
        Args:
            coefficients: 多项式系数（高次到低次）
            x: 自变量值
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {
                "coefficients": coefficients,
                "x": x
            }
            
            async with self.session.post(
                f"{self.server_url}/polynomial_evaluation",
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"多项式求值成功: P({x}) -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"多项式求值失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"多项式求值错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "coefficients": coefficients,
                "x": x
            }
    
    async def complex_number_operation(self, operation: str, z1_real: float, z1_imag: float,
                                     z2_real: Optional[float] = None, z2_imag: Optional[float] = None) -> Dict[str, Any]:
        """
        复数运算工具
        
        Args:
            operation: 运算类型 ('add', 'subtract', 'multiply', 'divide', 'modulus', 'phase', 'conjugate')
            z1_real: 第一个复数的实部
            z1_imag: 第一个复数的虚部
            z2_real: 第二个复数的实部 (二元运算时需要)
            z2_imag: 第二个复数的虚部 (二元运算时需要)
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {
                "operation": operation,
                "z1_real": z1_real,
                "z1_imag": z1_imag
            }
            if z2_real is not None:
                data["z2_real"] = z2_real
            if z2_imag is not None:
                data["z2_imag"] = z2_imag
            
            async with self.session.post(
                f"{self.server_url}/complex_number_operations",
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"复数运算成功: {operation} -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"复数运算失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"复数运算错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "operation": operation
            }
    
    async def expression_parser_advanced(self, expression: str) -> Dict[str, Any]:
        """
        高级数学表达式解析器
        
        Args:
            expression: 要解析的数学表达式
        """
        if not self.session:
            await self.connect()
        
        try:
            data = {"expression": expression}
            
            async with self.session.post(
                f"{self.server_url}/expression_parser_advanced",
                json=data,
                headers={"Content-Type": "application/json"}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"表达式解析成功: {expression} -> {result}")
                    return result
                else:
                    error_text = await response.text()
                    raise Exception(f"表达式解析失败: HTTP {response.status}, {error_text}")
                    
        except Exception as e:
            logger.error(f"表达式解析错误: {e}")
            return {
                "success": False,
                "error": str(e),
                "expression": expression
            }
    
    # 便捷方法
    async def sin_degrees(self, angle: float) -> Dict[str, Any]:
        """正弦函数（角度）"""
        return await self.trigonometric_function("sin", angle, "degrees")
    
    async def cos_degrees(self, angle: float) -> Dict[str, Any]:
        """余弦函数（角度）"""
        return await self.trigonometric_function("cos", angle, "degrees")
    
    async def tan_degrees(self, angle: float) -> Dict[str, Any]:
        """正切函数（角度）"""
        return await self.trigonometric_function("tan", angle, "degrees")
    
    async def natural_log(self, value: float) -> Dict[str, Any]:
        """自然对数"""
        return await self.logarithmic_function("ln", value)
    
    async def log_base_10(self, value: float) -> Dict[str, Any]:
        """常用对数（以10为底）"""
        return await self.logarithmic_function("log10", value)
    
    async def log_base_2(self, value: float) -> Dict[str, Any]:
        """二进制对数（以2为底）"""
        return await self.logarithmic_function("log2", value)
    
    async def complex_add(self, a_real: float, a_imag: float, b_real: float, b_imag: float) -> Dict[str, Any]:
        """复数加法"""
        return await self.complex_number_operation("add", a_real, a_imag, b_real, b_imag)
    
    async def complex_multiply(self, a_real: float, a_imag: float, b_real: float, b_imag: float) -> Dict[str, Any]:
        """复数乘法"""
        return await self.complex_number_operation("multiply", a_real, a_imag, b_real, b_imag)
    
    async def complex_modulus(self, real: float, imag: float) -> Dict[str, Any]:
        """复数模长"""
        return await self.complex_number_operation("modulus", real, imag)
    
    def set_event_handlers(self, 
                          on_connection: Optional[Callable] = None,
                          on_server_info: Optional[Callable] = None,
                          on_heartbeat: Optional[Callable] = None,
                          on_error: Optional[Callable] = None,
                          on_disconnect: Optional[Callable] = None):
        """设置事件处理回调"""
        if on_connection:
            self.on_connection = on_connection
        if on_server_info:
            self.on_server_info = on_server_info
        if on_heartbeat:
            self.on_heartbeat = on_heartbeat
        if on_error:
            self.on_error = on_error
        if on_disconnect:
            self.on_disconnect = on_disconnect


@asynccontextmanager
async def create_sse_calculator_client(server_url: str = "http://127.0.0.1:8000"):
    """
    创建SSE计算器客户端的上下文管理器
    
    Args:
        server_url: 服务器URL
        
    Yields:
        SSECalculatorClient: 客户端实例
    """
    client = SSECalculatorClient(server_url)
    try:
        await client.connect()
        yield client
    finally:
        await client.disconnect()


async def demo_client():
    """客户端演示"""
    print("=== SSE计算器客户端演示 ===")
    
    # 事件处理回调
    async def on_connection(event_data):
        print(f"✅ 已连接到服务器: {event_data}")
    
    async def on_server_info(server_info):
        print(f"📋 服务器信息:")
        print(f"   名称: {server_info.get('name')}")
        print(f"   版本: {server_info.get('version')}")
        print(f"   协议: {server_info.get('protocol')}")
        print(f"   描述: {server_info.get('description')}")
    
    async def on_heartbeat(event_data):
        print(f"💗 心跳: {event_data.get('timestamp')}")
    
    async def on_error(error_msg):
        print(f"❌ 错误: {error_msg}")
    
    async def on_disconnect():
        print("🔌 连接已断开")
    
    # 使用客户端
    async with create_sse_calculator_client() as client:
        # 设置事件处理器
        client.set_event_handlers(
            on_connection=on_connection,
            on_server_info=on_server_info,
            on_heartbeat=on_heartbeat,
            on_error=on_error,
            on_disconnect=on_disconnect
        )
        
        # 健康检查
        try:
            health = await client.health_check()
            print(f"🩺 健康检查: {health}")
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return
        
        # 启动SSE事件监听（在后台）
        sse_task = None
        try:
            async def sse_listener():
                async for event in client.listen_sse_events():
                    pass  # 事件已在_handle_sse_event中处理
            
            sse_task = asyncio.create_task(sse_listener())
            
            # 等待连接建立
            await asyncio.sleep(2)
            
            # 执行一些计算
            print("\n🧮 开始计算测试:")
            
            # 基本运算
            result = await client.calculate("2 + 3")
            print(f"计算: 2 + 3 = {result.get('result')} ({'成功' if result.get('success') else '失败'})")
            
            result = await client.add(10, 5)
            print(f"加法: 10 + 5 = {result.get('result')} ({'成功' if result.get('success') else '失败'})")
            
            result = await client.divide(20, 4)
            print(f"除法: 20 ÷ 4 = {result.get('result')} ({'成功' if result.get('success') else '失败'})")
            
            # 复杂表达式
            result = await client.calculate("sin(pi/2) + cos(0)")
            print(f"复杂表达式: sin(π/2) + cos(0) = {result.get('result')} ({'成功' if result.get('success') else '失败'})")
            
            # 平方根
            result = await client.square_root(16)
            print(f"平方根: √16 = {result.get('result')} ({'成功' if result.get('success') else '失败'})")
            
            # 错误处理
            result = await client.divide(1, 0)
            print(f"除零测试: {result.get('error')} ({'预期错误' if not result.get('success') else '意外成功'})")
            
            print("\n⏱️  监听3秒钟的心跳...")
            await asyncio.sleep(3)
            
        finally:
            if sse_task:
                sse_task.cancel()
                try:
                    await sse_task
                except asyncio.CancelledError:
                    pass
    
    print("\n✅ 客户端演示完成")


if __name__ == "__main__":
    asyncio.run(demo_client())
