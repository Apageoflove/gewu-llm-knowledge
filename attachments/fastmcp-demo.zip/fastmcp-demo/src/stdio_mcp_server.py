#!/usr/bin/env python3
"""
支持stdio的MCP服务器
基于FastMCP框架实现，可以通过mcp dev命令启动
"""

# 导入异步编程模块
import asyncio
# 导入JSON处理模块
import json
# 导入系统相关模块
import sys
# 导入类型提示模块
from typing import Any, Dict, List, Optional, Union
# 导入FastMCP框架
from mcp.server.fastmcp import FastMCP
# 导入MCP服务器模型
from mcp.server.models import InitializationOptions
# 导入STDIO传输模块
from mcp.server.stdio import stdio_server


# 创建FastMCP实例，设置服务器名称为"stdio-demo-server"
mcp = FastMCP("stdio-demo-server")


# 使用装饰器定义MCP工具函数
@mcp.tool()
# 定义获取服务器信息的工具函数
def get_server_info() -> Dict[str, Any]:
    """获取服务器基本信息"""
    # 返回服务器信息的字典
    return {
        # 服务器名称
        "name": "STDIO MCP Server",
        # 服务器版本
        "version": "1.0.0",
        # 协议类型
        "protocol": "MCP",
        # 传输方式
        "transport": "stdio",
        # 服务器描述
        "description": "基于FastMCP框架的STDIO传输MCP服务器",
        # 服务器特性列表
        "features": ["stdio", "fastmcp", "tools", "async"]
    }


# 使用装饰器定义数学计算工具函数
@mcp.tool()
# 定义数学表达式计算工具
def calculate_math(expression: str) -> Dict[str, Any]:
    """计算数学表达式"""
    try:
        # 定义允许的字符集合（数字、运算符、括号、空格）
        allowed_chars = set('0123456789+-*/.() ')
        # 检查表达式是否只包含允许的字符
        if not all(c in allowed_chars for c in expression):
            # 如果包含不允许的字符，返回错误信息
            return {
                # 计算成功标志
                "success": False,
                # 错误信息
                "error": "表达式包含不允许的字符",
                # 原始表达式
                "expression": expression
            }
        
        # 使用eval函数安全地计算数学表达式
        result = eval(expression)
        
        # 返回计算成功的详细信息
        return {
            # 计算成功标志
            "success": True,
            # 原始表达式
            "expression": expression,
            # 计算结果
            "result": result,
            # 结果的数据类型
            "type": type(result).__name__
        }
    except Exception as e:
        # 捕获异常并返回错误信息
        return {
            # 计算失败标志
            "success": False,
            # 异常信息
            "error": str(e),
            # 原始表达式
            "expression": expression
        }


# 使用装饰器定义文本分析工具函数
@mcp.tool()
# 定义文本分析工具
def text_analysis(text: str, operation: str = "count") -> Dict[str, Any]:
    """文本分析工具"""
    # 如果操作类型是统计
    if operation == "count":
        # 返回文本统计信息
        return {
            # 操作类型
            "operation": "count",
            # 原始文本
            "text": text,
            # 字符数量
            "char_count": len(text),
            # 单词数量（按空格分割）
            "word_count": len(text.split()),
            # 行数（按换行符分割）
            "line_count": len(text.splitlines())
        }
    # 如果操作类型是反转
    elif operation == "reverse":
        # 返回文本反转结果
        return {
            # 操作类型
            "operation": "reverse",
            # 原始文本
            "original": text,
            # 反转后的文本
            "reversed": text[::-1]
        }
    # 如果操作类型是转大写
    elif operation == "uppercase":
        # 返回转大写后的文本
        return {
            # 操作类型
            "operation": "uppercase",
            # 原始文本
            "original": text,
            # 转换后的文本
            "transformed": text.upper()
        }
    else:
        # 如果是不支持的操作类型，返回错误信息
        return {
            # 操作类型
            "operation": operation,
            # 错误信息
            "error": "不支持的操作",
            # 支持的操作类型列表
            "supported_operations": ["count", "reverse", "uppercase"]
        }


# 使用装饰器定义工具列表函数
@mcp.tool()
# 定义列出所有可用工具的函数
def list_tools() -> Dict[str, Any]:
    """列出所有可用的工具"""
    # 定义工具信息列表
    tools = [
        # 第一个工具：获取服务器信息
        {
            # 工具名称
            "name": "get_server_info",
            # 工具描述
            "description": "获取服务器基本信息",
            # 工具参数（无参数）
            "parameters": {}
        },
        # 第二个工具：数学计算
        {
            # 工具名称
            "name": "calculate_math",
            # 工具描述
            "description": "计算数学表达式",
            # 工具参数
            "parameters": {
                # 表达式参数说明
                "expression": "string - 数学表达式，如 '2+3*4'"
            }
        },
        # 第三个工具：文本分析
        {
            # 工具名称
            "name": "text_analysis",
            # 工具描述
            "description": "文本分析工具",
            # 工具参数
            "parameters": {
                # 文本参数说明
                "text": "string - 要分析的文本",
                # 操作类型参数说明
                "operation": "string - 操作类型：count/reverse/uppercase"
            }
        },
        # 第四个工具：列出工具
        {
            # 工具名称
            "name": "list_tools",
            # 工具描述
            "description": "列出所有可用的工具",
            # 工具参数（无参数）
            "parameters": {}
        }
    ]
    
    # 返回工具列表信息
    return {
        # 工具总数
        "total_tools": len(tools),
        # 工具详细信息列表
        "tools": tools
    }


# 定义异步主函数
async def main():
    """主函数 - 启动STDIO MCP服务器"""
    # 创建MCP服务器初始化选项
    init_options = InitializationOptions(
        # 服务器名称
        server_name="stdio-demo-server",
        # 服务器版本
        server_version="1.0.0",
        # 服务器能力配置
        capabilities={
            # 工具能力
            "tools": {},
            # 资源能力
            "resources": {},
            # 提示能力
            "prompts": {}
        }
    )
    
    # 启动STDIO传输的MCP服务器
    await stdio_server(mcp, init_options)


# 程序入口点
if __name__ == "__main__":
    # 使用asyncio运行MCP服务器
    asyncio.run(main())
