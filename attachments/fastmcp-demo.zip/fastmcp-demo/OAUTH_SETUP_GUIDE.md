# OAuth 2.0 鉴权设置指南

## 概述

本MCP服务器现已集成了完整的OAuth 2.0鉴权系统，支持多种授权流程，提供安全的API访问控制。

## 功能特性

### 🔐 安全特性
- **OAuth 2.0 标准协议** - 完全符合RFC 6749规范
- **JWT令牌认证** - 安全的无状态认证机制
- **多种授权流程** - 支持Authorization Code、Client Credentials、Password等
- **作用域权限控制** - 精细化的权限管理（read、write、admin）
- **令牌刷新机制** - 支持访问令牌的无缝续期
- **令牌撤销** - 支持主动撤销访问令牌

### 👥 用户管理
- **角色分离** - 支持管理员和普通用户角色
- **用户CRUD** - 完整的用户创建、查询、更新、删除功能
- **密码加密** - 使用bcrypt进行安全的密码哈希存储

### 🔑 客户端管理
- **客户端注册** - 动态创建OAuth客户端应用
- **重定向URI验证** - 安全的回调地址验证
- **客户端凭据** - 自动生成安全的客户端ID和密钥

## 快速开始

### 1. 启动服务器

```bash
# 安装依赖
pip install -r requirements.txt

# 启动服务器
python src/sse_calculator_server.py
```

服务器将启动在 `http://localhost:8000`

### 2. 默认凭据

系统预设了以下默认凭据：

```
管理员用户:
- 用户名: admin
- 密码: admin123
- 权限: read, write, admin

默认OAuth客户端:
- 客户端名称: Calculator MCP Client
- 重定向URI: http://localhost:3000/callback
- 支持的流程: authorization_code, refresh_token, client_credentials
```

### 3. 获取访问令牌

#### 方法1: 密码模式 (Password Grant)

```bash
curl -X POST http://localhost:8000/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin123&grant_type=password"
```

#### 方法2: 客户端凭据模式 (Client Credentials)

```bash
curl -X POST http://localhost:8000/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=<CLIENT_ID>&password=<CLIENT_SECRET>&grant_type=client_credentials"
```

### 4. 使用访问令牌

获取到访问令牌后，在请求头中添加授权信息：

```bash
curl -X POST http://localhost:8000/calculate \
  -H "Authorization: Bearer <ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"expression": "2 + 3 * sqrt(4)"}'
```

## 支持的授权流程

### 1. 授权码模式 (Authorization Code Flow)

最安全的授权流程，适用于Web应用：

```
1. 重定向到授权端点:
   GET /authorize?response_type=code&client_id=<CLIENT_ID>&redirect_uri=<REDIRECT_URI>&scope=read write

2. 用户授权后，获取授权码
3. 使用授权码交换访问令牌:
   POST /token/authorization_code
   - grant_type: authorization_code
   - code: <AUTHORIZATION_CODE>
   - redirect_uri: <REDIRECT_URI>
   - client_id: <CLIENT_ID>
   - client_secret: <CLIENT_SECRET>
```

### 2. 客户端凭据模式 (Client Credentials Flow)

适用于服务器到服务器的通信：

```
POST /token
- username: <CLIENT_ID>
- password: <CLIENT_SECRET>
- grant_type: client_credentials
```

### 3. 密码模式 (Password Grant)

适用于受信任的应用：

```
POST /token
- username: <USERNAME>
- password: <PASSWORD>
- grant_type: password
```

### 4. 刷新令牌 (Refresh Token)

用于续期访问令牌：

```
POST /refresh
- refresh_token: <REFRESH_TOKEN>
```

## API端点

### OAuth 认证端点

| 端点 | 方法 | 描述 | 权限要求 |
|------|------|------|----------|
| `/token` | POST | 获取访问令牌 | 无 |
| `/refresh` | POST | 刷新访问令牌 | 无 |
| `/authorize` | GET | 授权端点 | 无 |
| `/oauth/info` | GET | OAuth服务器信息 | 无 |

### 用户管理端点

| 端点 | 方法 | 描述 | 权限要求 |
|------|------|------|----------|
| `/oauth/me` | GET | 获取当前用户信息 | 需要认证 |
| `/oauth/users` | GET | 列出所有用户 | 管理员 |
| `/oauth/users` | POST | 创建新用户 | 管理员 |

### 客户端管理端点

| 端点 | 方法 | 描述 | 权限要求 |
|------|------|------|----------|
| `/oauth/clients` | GET | 列出所有客户端 | 管理员 |
| `/oauth/clients` | POST | 创建新客户端 | 管理员 |
| `/oauth/clients/{id}` | GET | 获取客户端详情 | 管理员 |
| `/oauth/clients/{id}` | PUT | 更新客户端 | 管理员 |
| `/oauth/clients/{id}` | DELETE | 删除客户端 | 管理员 |

### 令牌管理端点

| 端点 | 方法 | 描述 | 权限要求 |
|------|------|------|----------|
| `/oauth/tokens` | GET | 列出活跃令牌 | 管理员 |
| `/oauth/revoke` | POST | 撤销令牌 | 需要认证 |

### 受保护的MCP端点

所有计算相关的端点现在都需要OAuth认证：

| 端点 | 方法 | 描述 | 权限要求 |
|------|------|------|----------|
| `/calculate` | POST | 数学表达式计算 | read 或 write |
| `/trigonometric_functions` | POST | 三角函数计算 | read 或 write |
| `/logarithmic_functions` | POST | 对数函数计算 | read 或 write |
| `/statistical_analysis` | POST | 统计分析 | read 或 write |
| `/polynomial_evaluation` | POST | 多项式求值 | read 或 write |
| `/complex_number_operations` | POST | 复数运算 | read 或 write |
| `/expression_parser_advanced` | POST | 高级表达式解析 | read 或 write |
| `/performance` | GET | 性能监控 | read 或 admin |

## 权限作用域

系统定义了三个权限作用域：

- **read**: 只读权限，可以查看信息和执行基本计算
- **write**: 写权限，可以执行所有计算操作
- **admin**: 管理员权限，可以管理用户和客户端

## 测试OAuth功能

运行综合测试套件：

```bash
python test/test_oauth_auth.py
```

测试套件将验证：
- 服务器连接
- 用户认证
- 客户端认证
- 权限控制
- 令牌管理
- 受保护端点访问

## 安全建议

### 生产环境配置

1. **更改默认密码**：
   ```bash
   # 创建新的管理员用户，删除默认用户
   ```

2. **设置强密钥**：
   ```bash
   export OAUTH_SECRET_KEY="your-very-secure-secret-key-here"
   ```

3. **配置HTTPS**：
   ```bash
   # 在生产环境中启用HTTPS
   ```

4. **限制CORS源**：
   ```python
   allow_origins=["https://yourdomain.com"]  # 替换通配符
   ```

5. **使用数据库**：
   - 当前使用内存存储，生产环境建议使用PostgreSQL或MySQL

### 安全最佳实践

- 定期轮换客户端密钥
- 设置适当的令牌过期时间
- 监控异常的API访问模式
- 使用HTTPS传输所有OAuth令牌
- 实施适当的速率限制
- 定期审查用户和客户端权限

## 故障排除

### 常见错误

1. **401 Unauthorized**
   - 检查令牌是否有效
   - 确认令牌未过期
   - 验证Authorization头格式正确

2. **403 Forbidden**
   - 检查用户/客户端是否有足够权限
   - 确认作用域包含所需权限

3. **400 Bad Request**
   - 检查请求参数格式
   - 验证客户端ID和密钥
   - 确认重定向URI匹配

### 调试技巧

1. 启用详细日志：
   ```python
   logging.basicConfig(level=logging.DEBUG)
   ```

2. 检查令牌内容：
   ```bash
   # 使用jwt.io解码JWT令牌查看内容
   ```

3. 监控服务器日志：
   ```bash
   tail -f server.log
   ```

## 高级配置

### 环境变量

创建`.env`文件：

```bash
OAUTH_SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=30
SERVER_HOST=0.0.0.0
SERVER_PORT=8000
```

### 自定义权限

可以扩展权限系统：

```python
# 添加自定义作用域
custom_scopes = ["read", "write", "admin", "analytics", "billing"]
```

### 集成外部身份提供商

支持集成Google、GitHub等第三方OAuth提供商。

## 支持和反馈

如果您在使用OAuth功能时遇到问题，请：

1. 查看服务器日志
2. 运行测试套件诊断
3. 检查配置是否正确
4. 参考OAuth 2.0规范文档

---

**注意**: 这是演示版本的OAuth实现，生产环境使用前请进行充分的安全审查和测试。
