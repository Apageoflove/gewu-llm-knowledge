# SSE MCP 计算器客户端

基于 `sse_calculator_server.py` 实现的 MCP SSE 客户端代码，提供完整的客户端-服务器交互功能。

## 🚀 功能特性

### SSE 客户端 (`src/sse_calculator_client.py`)

- **SSE 连接管理**: 连接到服务器的 `/sse` 端点，处理服务器发送的事件流
- **事件处理**: 处理连接确认、服务器信息、心跳等 SSE 事件
- **计算功能**: 通过 `/calculate` 端点发送计算请求
- **便捷方法**: 提供 `add()`, `subtract()`, `multiply()`, `divide()`, `power()`, `square_root()` 等方法
- **异步设计**: 完全基于 asyncio 的异步实现
- **上下文管理**: 支持 `async with` 语法自动管理连接

### 核心功能

```python
from src.sse_calculator_client import create_sse_calculator_client

# 使用上下文管理器
async with create_sse_calculator_client() as client:
    # 健康检查
    health = await client.health_check()
    
    # 基本计算
    result = await client.calculate("2 + 3 * 4")
    print(f"结果: {result['result']}")  # 14
    
    # 便捷方法
    result = await client.add(10, 5)
    result = await client.divide(20, 4)
    result = await client.square_root(16)
```

## 📁 项目结构

```
fastmcp-demo/
├── src/
│   ├── sse_calculator_server.py      # SSE 服务器（原有）
│   └── sse_calculator_client.py      # SSE 客户端（新增）
├── test/
│   ├── test_sse_client.py           # 客户端单元测试
│   └── test_sse_integration.py      # 集成测试
├── test_sse_mcp_complete.py         # 完整测试套件
├── quick_test.py                    # 快速验证脚本
└── requirements.txt                 # 更新了依赖
```

## 🛠️ 安装依赖

```bash
pip install -r requirements.txt
```

新增依赖：
- `aiohttp>=3.8.0` - HTTP 客户端库

## 🧪 测试使用

### 1. 快速验证
```bash
python quick_test.py
```
验证客户端基本功能是否正常。

### 2. 启动服务器
```bash
python src/sse_calculator_server.py
```
在新终端窗口启动 SSE 计算器服务器。

### 3. 运行客户端测试
```bash
# 仅测试客户端（需要服务器运行）
python test_sse_mcp_complete.py --mode client

# 完整集成测试（自动启动服务器）
python test_sse_mcp_complete.py --mode integration

# 运行演示
python test_sse_mcp_complete.py --mode demo
```

### 4. 单独运行测试模块
```bash
# 客户端单元测试
python test/test_sse_client.py

# 集成测试
python test/test_sse_integration.py
```

## 💡 使用示例

### 基本使用

```python
import asyncio
from src.sse_calculator_client import SSECalculatorClient

async def main():
    client = SSECalculatorClient("http://127.0.0.1:8000")
    await client.connect()
    
    # 计算表达式
    result = await client.calculate("sin(pi/2) + cos(0)")
    print(f"sin(π/2) + cos(0) = {result['result']}")
    
    await client.disconnect()

asyncio.run(main())
```

### 事件处理

```python
async def main():
    async with create_sse_calculator_client() as client:
        # 设置事件回调
        async def on_heartbeat(data):
            print(f"收到心跳: {data['timestamp']}")
        
        client.set_event_handlers(on_heartbeat=on_heartbeat)
        
        # 启动事件监听
        async def sse_listener():
            async for event in client.listen_sse_events():
                print(f"收到事件: {event}")
        
        task = asyncio.create_task(sse_listener())
        
        # 执行计算
        await client.calculate("2 ** 10")
        
        # 监听一段时间
        await asyncio.sleep(5)
        task.cancel()
```

## 🔧 API 参考

### SSECalculatorClient

**初始化参数：**
- `server_url`: 服务器 URL（默认: `http://127.0.0.1:8000`）

**主要方法：**
- `connect()`: 连接到服务器
- `disconnect()`: 断开连接
- `health_check()`: 健康检查
- `listen_sse_events()`: 监听 SSE 事件流
- `calculate(expression)`: 计算数学表达式
- `add(a, b)`: 加法
- `subtract(a, b)`: 减法
- `multiply(a, b)`: 乘法
- `divide(a, b)`: 除法
- `power(base, exponent)`: 幂运算
- `square_root(number)`: 平方根

**事件回调设置：**
```python
client.set_event_handlers(
    on_connection=callback_func,
    on_server_info=callback_func,
    on_heartbeat=callback_func,
    on_error=callback_func,
    on_disconnect=callback_func
)
```

## ✅ 测试验证

所有测试均已通过验证：

1. **健康检查测试** - 验证服务器状态
2. **基本计算测试** - 测试各种数学表达式
3. **计算方法测试** - 测试专用计算方法
4. **错误处理测试** - 测试各种错误场景
5. **SSE事件测试** - 测试事件流处理
6. **并发客户端测试** - 测试多客户端并发访问
7. **长连接测试** - 测试长时间连接稳定性

## 🎯 核心特色

- **完全异步**: 基于 asyncio 实现，支持高并发
- **事件驱动**: 完整的 SSE 事件处理机制  
- **错误处理**: 全面的异常处理和错误恢复
- **易于使用**: 简洁的 API 设计和上下文管理器
- **全面测试**: 包含单元测试、集成测试、并发测试

## 🔍 故障排除

### 连接失败
- 确保服务器在正确端口运行：`python src/sse_calculator_server.py`
- 检查防火墙设置
- 验证端口未被占用

### 依赖问题
```bash
pip install --upgrade -r requirements.txt
```

### 测试失败
- 确保没有其他程序占用端口 8000
- 检查系统资源（内存、CPU）
- 运行 `python quick_test.py` 验证基本功能

---

🎉 **客户端实现完成！** 现在您可以通过 SSE 客户端与计算器服务器进行完整的交互通信。
