#!/usr/bin/env python3
"""
OAuth鉴权测试案例
测试MCP服务器的OAuth 2.0鉴权功能
"""

import asyncio
import json
import time
import requests
from typing import Dict, Any
import uuid

class OAuthTestSuite:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.admin_token = None
        self.user_token = None
        self.client_credentials_token = None
        self.test_client_id = None
        self.test_client_secret = None
        self.test_user_id = None

    def log(self, message: str):
        """打印测试日志"""
        print(f"[OAuth Test] {message}")

    def test_server_status(self) -> bool:
        """测试服务器状态"""
        try:
            self.log("测试服务器连接...")
            response = requests.get(f"{self.base_url}/health")
            if response.status_code == 200:
                self.log("✅ 服务器连接成功")
                return True
            else:
                self.log(f"❌ 服务器连接失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ 服务器连接异常: {e}")
            return False

    def test_oauth_info(self) -> bool:
        """测试OAuth服务器信息"""
        try:
            self.log("获取OAuth服务器信息...")
            response = requests.get(f"{self.base_url}/oauth/info")
            if response.status_code == 200:
                info = response.json()
                self.log(f"✅ OAuth服务器信息获取成功: {info['supported_grant_types']}")
                return True
            else:
                self.log(f"❌ OAuth服务器信息获取失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ OAuth服务器信息获取异常: {e}")
            return False

    def test_admin_login(self) -> bool:
        """测试管理员登录（密码模式）"""
        try:
            self.log("测试管理员登录...")
            data = {
                "username": "admin",
                "password": "admin123",
                "grant_type": "password"
            }
            
            response = requests.post(f"{self.base_url}/token", data=data)
            if response.status_code == 200:
                token_info = response.json()
                self.admin_token = token_info["access_token"]
                self.log(f"✅ 管理员登录成功，Token: {self.admin_token[:20]}...")
                return True
            else:
                self.log(f"❌ 管理员登录失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ 管理员登录异常: {e}")
            return False

    def test_invalid_credentials(self) -> bool:
        """测试无效凭据"""
        try:
            self.log("测试无效凭据...")
            data = {
                "username": "invalid_user",
                "password": "wrong_password",
                "grant_type": "password"
            }
            
            response = requests.post(f"{self.base_url}/token", data=data)
            if response.status_code == 401:
                self.log("✅ 无效凭据正确拒绝")
                return True
            else:
                self.log(f"❌ 无效凭据测试失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ 无效凭据测试异常: {e}")
            return False

    def test_create_user(self) -> bool:
        """测试创建用户（需要管理员权限）"""
        if not self.admin_token:
            self.log("❌ 需要管理员Token")
            return False
            
        try:
            self.log("测试创建用户...")
            headers = {"Authorization": f"Bearer {self.admin_token}"}
            user_data = {
                "username": f"test_user_{uuid.uuid4().hex[:8]}",
                "password": "test123",
                "email": "test@example.com",
                "is_admin": False
            }
            
            response = requests.post(f"{self.base_url}/oauth/users", json=user_data, headers=headers)
            if response.status_code == 201:
                user_info = response.json()
                self.test_user_id = user_info["user_id"]
                self.test_username = user_data["username"]
                self.log(f"✅ 用户创建成功: {user_info['username']}")
                return True
            else:
                self.log(f"❌ 用户创建失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 用户创建异常: {e}")
            return False

    def test_create_oauth_client(self) -> bool:
        """测试创建OAuth客户端（需要管理员权限）"""
        if not self.admin_token:
            self.log("❌ 需要管理员Token")
            return False
            
        try:
            self.log("测试创建OAuth客户端...")
            headers = {"Authorization": f"Bearer {self.admin_token}"}
            client_data = {
                "client_name": f"Test Client {uuid.uuid4().hex[:8]}",
                "redirect_uris": ["http://localhost:3000/callback"],
                "scope": "read write"
            }
            
            response = requests.post(f"{self.base_url}/oauth/clients", json=client_data, headers=headers)
            if response.status_code == 201:
                client_info = response.json()
                self.test_client_id = client_info["client_id"]
                self.test_client_secret = client_info["client_secret"]
                self.log(f"✅ OAuth客户端创建成功: {client_info['client_name']}")
                return True
            else:
                self.log(f"❌ OAuth客户端创建失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ OAuth客户端创建异常: {e}")
            return False

    def test_client_credentials_flow(self) -> bool:
        """测试客户端凭据模式"""
        if not self.test_client_id or not self.test_client_secret:
            self.log("❌ 需要测试客户端凭据")
            return False
            
        try:
            self.log("测试客户端凭据模式...")
            data = {
                "username": self.test_client_id,
                "password": self.test_client_secret,
                "grant_type": "client_credentials"
            }
            
            response = requests.post(f"{self.base_url}/token", data=data)
            if response.status_code == 200:
                token_info = response.json()
                self.client_credentials_token = token_info["access_token"]
                self.log(f"✅ 客户端凭据模式成功，Token: {self.client_credentials_token[:20]}...")
                return True
            else:
                self.log(f"❌ 客户端凭据模式失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 客户端凭据模式异常: {e}")
            return False

    def test_user_login(self) -> bool:
        """测试普通用户登录"""
        if not hasattr(self, 'test_username'):
            self.log("❌ 需要测试用户")
            return False
            
        try:
            self.log("测试普通用户登录...")
            data = {
                "username": self.test_username,
                "password": "test123",
                "grant_type": "password"
            }
            
            response = requests.post(f"{self.base_url}/token", data=data)
            if response.status_code == 200:
                token_info = response.json()
                self.user_token = token_info["access_token"]
                self.log(f"✅ 普通用户登录成功，Token: {self.user_token[:20]}...")
                return True
            else:
                self.log(f"❌ 普通用户登录失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 普通用户登录异常: {e}")
            return False

    def test_protected_endpoint_without_token(self) -> bool:
        """测试受保护端点（无令牌）"""
        try:
            self.log("测试受保护端点（无令牌）...")
            data = {"expression": "2 + 3"}
            
            response = requests.post(f"{self.base_url}/calculate", json=data)
            if response.status_code == 401:
                self.log("✅ 无令牌访问受保护端点正确拒绝")
                return True
            else:
                self.log(f"❌ 无令牌访问测试失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ 无令牌访问测试异常: {e}")
            return False

    def test_protected_endpoint_with_token(self) -> bool:
        """测试受保护端点（有效令牌）"""
        if not self.admin_token:
            self.log("❌ 需要有效Token")
            return False
            
        try:
            self.log("测试受保护端点（有效令牌）...")
            headers = {"Authorization": f"Bearer {self.admin_token}"}
            data = {"expression": "2 + 3 * sqrt(4)"}
            
            response = requests.post(f"{self.base_url}/calculate", json=data, headers=headers)
            if response.status_code == 200:
                result = response.json()
                self.log(f"✅ 有效令牌访问成功: {result.get('result')}")
                return True
            else:
                self.log(f"❌ 有效令牌访问失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 有效令牌访问异常: {e}")
            return False

    def test_scope_permissions(self) -> bool:
        """测试作用域权限"""
        if not self.user_token:
            self.log("❌ 需要用户Token")
            return False
            
        try:
            self.log("测试用户权限访问管理员端点...")
            headers = {"Authorization": f"Bearer {self.user_token}"}
            
            # 普通用户尝试访问管理员端点
            response = requests.get(f"{self.base_url}/oauth/users", headers=headers)
            if response.status_code == 403:
                self.log("✅ 普通用户无法访问管理员端点（正确）")
                
                # 测试普通用户可以访问计算端点
                calc_data = {"expression": "5 * 6"}
                calc_response = requests.post(f"{self.base_url}/calculate", json=calc_data, headers=headers)
                if calc_response.status_code == 200:
                    self.log("✅ 普通用户可以访问计算端点")
                    return True
                else:
                    self.log(f"❌ 普通用户访问计算端点失败: {calc_response.status_code}")
                    return False
            else:
                self.log(f"❌ 权限测试失败: {response.status_code}")
                return False
        except Exception as e:
            self.log(f"❌ 权限测试异常: {e}")
            return False

    def test_token_refresh(self) -> bool:
        """测试令牌刷新"""
        try:
            self.log("测试令牌刷新...")
            # 先获取带刷新令牌的访问令牌
            data = {
                "username": "admin",
                "password": "admin123",
                "grant_type": "password"
            }
            
            response = requests.post(f"{self.base_url}/token", data=data)
            if response.status_code != 200:
                self.log(f"❌ 获取令牌失败: {response.status_code}")
                return False
            
            token_info = response.json()
            refresh_token = token_info.get("refresh_token")
            
            if not refresh_token:
                self.log("❌ 没有刷新令牌")
                return False
            
            # 使用刷新令牌获取新的访问令牌
            refresh_data = {"refresh_token": refresh_token}
            refresh_response = requests.post(f"{self.base_url}/refresh", data=refresh_data)
            
            if refresh_response.status_code == 200:
                new_token_info = refresh_response.json()
                self.log(f"✅ 令牌刷新成功: {new_token_info['access_token'][:20]}...")
                return True
            else:
                self.log(f"❌ 令牌刷新失败: {refresh_response.status_code} - {refresh_response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 令牌刷新异常: {e}")
            return False

    def test_token_revocation(self) -> bool:
        """测试令牌撤销"""
        if not self.user_token:
            self.log("❌ 需要用户Token")
            return False
            
        try:
            self.log("测试令牌撤销...")
            headers = {"Authorization": f"Bearer {self.user_token}"}
            data = {"token": self.user_token}
            
            response = requests.post(f"{self.base_url}/oauth/revoke", data=data, headers=headers)
            if response.status_code == 200:
                self.log("✅ 令牌撤销成功")
                
                # 验证撤销的令牌无法使用
                calc_data = {"expression": "1 + 1"}
                calc_response = requests.post(f"{self.base_url}/calculate", json=calc_data, headers=headers)
                if calc_response.status_code == 401:
                    self.log("✅ 撤销的令牌无法访问（正确）")
                    return True
                else:
                    self.log(f"❌ 撤销的令牌仍可使用: {calc_response.status_code}")
                    return False
            else:
                self.log(f"❌ 令牌撤销失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 令牌撤销异常: {e}")
            return False

    def test_list_clients(self) -> bool:
        """测试列出客户端（管理员功能）"""
        if not self.admin_token:
            self.log("❌ 需要管理员Token")
            return False
            
        try:
            self.log("测试列出OAuth客户端...")
            headers = {"Authorization": f"Bearer {self.admin_token}"}
            
            response = requests.get(f"{self.base_url}/oauth/clients", headers=headers)
            if response.status_code == 200:
                clients = response.json()
                self.log(f"✅ 客户端列表获取成功，共 {clients['total']} 个客户端")
                return True
            else:
                self.log(f"❌ 客户端列表获取失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 客户端列表获取异常: {e}")
            return False

    def test_current_user_info(self) -> bool:
        """测试获取当前用户信息"""
        if not self.admin_token:
            self.log("❌ 需要Token")
            return False
            
        try:
            self.log("测试获取当前用户信息...")
            headers = {"Authorization": f"Bearer {self.admin_token}"}
            
            response = requests.get(f"{self.base_url}/oauth/me", headers=headers)
            if response.status_code == 200:
                user_info = response.json()
                self.log(f"✅ 用户信息获取成功: {user_info['username']} (管理员: {user_info['is_admin']})")
                return True
            else:
                self.log(f"❌ 用户信息获取失败: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"❌ 用户信息获取异常: {e}")
            return False

    def run_all_tests(self) -> Dict[str, bool]:
        """运行所有测试"""
        tests = [
            ("服务器状态", self.test_server_status),
            ("OAuth服务器信息", self.test_oauth_info),
            ("管理员登录", self.test_admin_login),
            ("无效凭据", self.test_invalid_credentials),
            ("创建用户", self.test_create_user),
            ("创建OAuth客户端", self.test_create_oauth_client),
            ("客户端凭据模式", self.test_client_credentials_flow),
            ("用户登录", self.test_user_login),
            ("无令牌访问受保护端点", self.test_protected_endpoint_without_token),
            ("有令牌访问受保护端点", self.test_protected_endpoint_with_token),
            ("作用域权限测试", self.test_scope_permissions),
            ("令牌刷新", self.test_token_refresh),
            ("获取当前用户信息", self.test_current_user_info),
            ("列出客户端", self.test_list_clients),
            ("令牌撤销", self.test_token_revocation),
        ]
        
        results = {}
        passed = 0
        total = len(tests)
        
        self.log("=" * 50)
        self.log("开始OAuth鉴权测试套件")
        self.log("=" * 50)
        
        for test_name, test_func in tests:
            try:
                self.log(f"\n--- 执行测试: {test_name} ---")
                result = test_func()
                results[test_name] = result
                if result:
                    passed += 1
                time.sleep(0.5)  # 防止请求过快
            except Exception as e:
                self.log(f"❌ 测试异常: {test_name} - {e}")
                results[test_name] = False
        
        self.log("\n" + "=" * 50)
        self.log("测试结果汇总")
        self.log("=" * 50)
        
        for test_name, result in results.items():
            status = "✅ 通过" if result else "❌ 失败"
            self.log(f"{test_name}: {status}")
        
        self.log(f"\n总结: {passed}/{total} 项测试通过 ({passed/total*100:.1f}%)")
        
        return results


def main():
    """主函数"""
    print("OAuth鉴权测试套件")
    print("请确保MCP服务器运行在 http://localhost:8000")
    print("启动命令: python src/sse_calculator_server.py")
    
    input("\n按Enter键开始测试...")
    
    test_suite = OAuthTestSuite()
    results = test_suite.run_all_tests()
    
    # 检查是否所有测试都通过
    all_passed = all(results.values())
    if all_passed:
        print("\n🎉 所有测试都通过了！OAuth鉴权功能正常工作。")
    else:
        failed_tests = [name for name, result in results.items() if not result]
        print(f"\n⚠️  有 {len(failed_tests)} 项测试失败:")
        for test_name in failed_tests:
            print(f"  - {test_name}")
    
    return all_passed


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)

