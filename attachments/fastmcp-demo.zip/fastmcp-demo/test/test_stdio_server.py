#!/usr/bin/env python3
"""
测试STDIO MCP服务器功能的脚本
"""

# 导入异步编程模块
import asyncio
# 导入JSON处理模块
import json
# 导入系统相关模块
import sys
# 导入操作系统相关模块
import os

# 添加src目录到Python路径，以便导入模块
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# 从stdio_mcp_server模块导入需要测试的函数
from stdio_mcp_server import (
    # 获取服务器信息函数
    get_server_info,
    # 数学计算函数
    calculate_math,
    # 文本分析函数
    text_analysis,
    # 列出工具函数
    list_tools
)


# 定义异步测试函数，测试服务器的所有功能
async def test_server_functions():
    """测试服务器的所有功能"""
    # 打印测试开始提示
    print("🧪 测试STDIO MCP服务器功能\n")
    
    # 测试1: 获取服务器信息
    print("1️⃣ 测试 get_server_info:")
    # 调用获取服务器信息函数
    info = get_server_info()
    # 将结果格式化为JSON并打印
    print(f"   结果: {json.dumps(info, ensure_ascii=False, indent=2)}")
    print()
    
    # 测试2: 数学计算
    print("2️⃣ 测试 calculate_math:")
    # 定义要测试的数学表达式列表
    test_expressions = ["2+3", "10*5", "(3+4)*2", "100/4"]
    # 遍历每个表达式进行测试
    for expr in test_expressions:
        # 调用数学计算函数
        result = calculate_math(expr)
        # 打印计算结果或错误信息
        print(f"   {expr} = {result['result'] if result['success'] else result['error']}")
    print()
    
    # 测试3: 文本分析
    print("3️⃣ 测试 text_analysis:")
    # 定义测试文本
    test_text = "Hello World! 这是一个测试文本。"
    
    # 测试字符统计功能
    count_result = text_analysis(test_text, "count")
    print(f"   字符统计: {count_result}")
    
    # 测试文本反转功能
    reverse_result = text_analysis(test_text, "reverse")
    print(f"   文本反转: {reverse_result['reversed']}")
    
    # 测试转大写功能
    upper_result = text_analysis(test_text, "uppercase")
    print(f"   转大写: {upper_result['transformed']}")
    print()
    
    # 测试4: 列出工具
    print("4️⃣ 测试 list_tools:")
    # 调用列出工具函数
    tools = list_tools()
    # 打印可用工具数量
    print(f"   可用工具数量: {tools['total_tools']}")
    # 遍历并打印每个工具的详细信息
    for tool in tools['tools']:
        print(f"   - {tool['name']}: {tool['description']}")
    print()
    
    # 打印测试完成提示
    print("✅ 所有测试完成！")


# 定义测试数学计算安全性的函数
def test_math_security():
    """测试数学计算的安全性"""
    # 打印安全性测试提示
    print("🔒 测试数学计算安全性:")
    
    # 定义危险的表达式列表
    dangerous_expressions = [
        # 尝试导入模块
        "import os",
        # 尝试执行系统命令
        "os.system('dir')",
        # 尝试动态导入
        "__import__('os')",
        # 尝试嵌套eval
        "eval('2+3')"
    ]
    
    # 遍历每个危险表达式进行测试
    for expr in dangerous_expressions:
        # 调用数学计算函数
        result = calculate_math(expr)
        # 根据结果判断是否安全
        print(f"   {expr}: {'✅ 安全' if not result['success'] else '❌ 危险'}")
    
    print()


# 程序入口点
if __name__ == "__main__":
    # 打印测试开始标题
    print("🚀 STDIO MCP服务器功能测试")
    # 打印分隔线
    print("=" * 50)
    
    # 运行功能测试
    asyncio.run(test_server_functions())
    
    # 运行安全性测试
    test_math_security()
    
    # 打印测试完成提示
    print("🎉 测试完成！")
