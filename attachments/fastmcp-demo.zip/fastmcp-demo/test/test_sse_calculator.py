#!/usr/bin/env python3
"""
测试SSE计算器服务器
"""

import asyncio
import json
import sys
import os
from typing import Dict, Any

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sse_calculator_server import (
    calculate, add, subtract, multiply, divide, 
    power, square_root, get_calculator_info, list_calculator_tools
)


class TestCalculatorTools:
    """测试计算器工具函数"""
    
    def test_calculate_basic(self):
        """测试基本表达式计算"""
        # 测试简单加法
        result = calculate("2 + 3")
        assert result["success"] is True
        assert result["result"] == 5
        
        # 测试复杂表达式
        result = calculate("2 + 3 * 4")
        assert result["success"] is True
        assert result["result"] == 14
        
        # 测试括号
        result = calculate("(2 + 3) * 4")
        assert result["success"] is True
        assert result["result"] == 20
    
    def test_calculate_math_functions(self):
        """测试数学函数"""
        # 测试平方根
        result = calculate("sqrt(16)")
        assert result["success"] is True
        assert result["result"] == 4.0
        
        # 测试正弦函数
        result = calculate("sin(0)")
        assert result["success"] is True
        assert result["result"] == 0.0
        
        # 测试圆周率
        result = calculate("pi")
        assert result["success"] is True
        assert abs(result["result"] - 3.14159) < 0.001
    
    def test_calculate_errors(self):
        """测试计算错误处理"""
        # 测试除零错误
        result = calculate("1 / 0")
        assert result["success"] is False
        assert "除零错误" in result["error"]
        
        # 测试语法错误
        result = calculate("2 + + 3")
        assert result["success"] is False
        
        # 测试禁用关键字
        result = calculate("import os")
        assert result["success"] is False
        assert "禁用关键字" in result["error"]
    
    def test_add(self):
        """测试加法工具"""
        result = add(2.5, 3.7)
        assert result["success"] is True
        assert result["result"] == 6.2
        assert result["operation"] == "addition"
    
    def test_subtract(self):
        """测试减法工具"""
        result = subtract(10, 3)
        assert result["success"] is True
        assert result["result"] == 7
        assert result["operation"] == "subtraction"
    
    def test_multiply(self):
        """测试乘法工具"""
        result = multiply(4, 5)
        assert result["success"] is True
        assert result["result"] == 20
        assert result["operation"] == "multiplication"
    
    def test_divide(self):
        """测试除法工具"""
        # 正常除法
        result = divide(15, 3)
        assert result["success"] is True
        assert result["result"] == 5
        assert result["operation"] == "division"
        
        # 除零错误
        result = divide(5, 0)
        assert result["success"] is False
        assert "除数不能为零" in result["error"]
    
    def test_power(self):
        """测试幂运算工具"""
        result = power(2, 3)
        assert result["success"] is True
        assert result["result"] == 8
        assert result["operation"] == "power"
        
        # 测试负指数
        result = power(2, -1)
        assert result["success"] is True
        assert result["result"] == 0.5
    
    def test_square_root(self):
        """测试平方根工具"""
        # 正数平方根
        result = square_root(9)
        assert result["success"] is True
        assert result["result"] == 3.0
        
        # 负数平方根
        result = square_root(-4)
        assert result["success"] is False
        assert "负数没有实数平方根" in result["error"]
    
    def test_get_calculator_info(self):
        """测试获取计算器信息"""
        info = get_calculator_info()
        assert "name" in info
        assert "version" in info
        assert "protocol" in info
        assert info["name"] == "SSE Calculator MCP Server"
    
    def test_list_calculator_tools(self):
        """测试列出计算器工具"""
        tools = list_calculator_tools()
        assert "total_tools" in tools
        assert "tools" in tools
        assert tools["total_tools"] > 0
        assert len(tools["tools"]) == tools["total_tools"]
        
        # 检查是否包含主要工具
        tool_names = [tool["name"] for tool in tools["tools"]]
        assert "calculate" in tool_names
        assert "add" in tool_names
        assert "subtract" in tool_names
        assert "multiply" in tool_names
        assert "divide" in tool_names


def run_tests():
    """运行所有测试"""
    print("开始测试SSE计算器服务器...")
    
    test_class = TestCalculatorTools()
    
    # 运行所有测试方法
    test_methods = [
        method for method in dir(test_class) 
        if method.startswith('test_')
    ]
    
    passed = 0
    failed = 0
    
    for method_name in test_methods:
        try:
            method = getattr(test_class, method_name)
            method()
            print(f"✅ {method_name}: PASSED")
            passed += 1
        except Exception as e:
            print(f"❌ {method_name}: FAILED - {e}")
            failed += 1
    
    print(f"\n测试结果:")
    print(f"通过: {passed}")
    print(f"失败: {failed}")
    print(f"总计: {passed + failed}")
    
    return failed == 0


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)