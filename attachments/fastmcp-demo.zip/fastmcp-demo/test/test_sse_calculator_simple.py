#!/usr/bin/env python3
"""
简化版SSE计算器服务器测试（不依赖FastAPI）
只测试核心计算功能
"""

import sys
import os
import math

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


def calculate(expression: str) -> dict:
    """
    简化版计算函数（从SSE服务器复制）
    """
    try:
        # 安全的计算环境
        safe_dict = {
            "__builtins__": {},
            "abs": abs,
            "round": round,
            "min": min,
            "max": max,
            "sum": sum,
            "pow": pow,
            "sqrt": math.sqrt,
            "sin": math.sin,
            "cos": math.cos,
            "tan": math.tan,
            "log": math.log,
            "log10": math.log10,
            "exp": math.exp,
            "pi": math.pi,
            "e": math.e,
        }
        
        # 检查表达式安全性
        forbidden_chars = ['import', 'exec', 'eval', '__', 'open', 'file']
        expression_lower = expression.lower()
        for forbidden in forbidden_chars:
            if forbidden in expression_lower:
                return {
                    "success": False,
                    "error": f"表达式包含禁用关键字: {forbidden}",
                    "expression": expression
                }
        
        # 计算表达式
        result = eval(expression, safe_dict, {})
        
        return {
            "success": True,
            "expression": expression,
            "result": result,
            "result_type": type(result).__name__
        }
        
    except ZeroDivisionError:
        return {
            "success": False,
            "error": "除零错误",
            "expression": expression
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "expression": expression
        }


def add(a: float, b: float) -> dict:
    """加法运算"""
    result = a + b
    return {
        "success": True,
        "operation": "addition",
        "operands": [a, b],
        "result": result,
        "expression": f"{a} + {b} = {result}"
    }


def divide(a: float, b: float) -> dict:
    """除法运算"""
    if b == 0:
        return {
            "success": False,
            "operation": "division",
            "operands": [a, b],
            "error": "除数不能为零",
            "expression": f"{a} ÷ {b}"
        }
    
    result = a / b
    return {
        "success": True,
        "operation": "division",
        "operands": [a, b],
        "result": result,
        "expression": f"{a} ÷ {b} = {result}"
    }


def square_root(number: float) -> dict:
    """平方根运算"""
    if number < 0:
        return {
            "success": False,
            "operation": "square_root",
            "operand": number,
            "error": "负数没有实数平方根",
            "expression": f"√{number}"
        }
    
    result = math.sqrt(number)
    return {
        "success": True,
        "operation": "square_root",
        "operand": number,
        "result": result,
        "expression": f"√{number} = {result}"
    }


class TestCalculatorTools:
    """测试计算器工具函数"""
    
    def test_calculate_basic(self):
        """测试基本表达式计算"""
        # 测试简单加法
        result = calculate("2 + 3")
        assert result["success"] is True
        assert result["result"] == 5
        print(f"OK 基本加法: {result['expression']} = {result['result']}")
        
        # 测试复杂表达式
        result = calculate("2 + 3 * 4")
        assert result["success"] is True
        assert result["result"] == 14
        print(f"OK 复杂表达式: {result['expression']} = {result['result']}")
        
        # 测试括号
        result = calculate("(2 + 3) * 4")
        assert result["success"] is True
        assert result["result"] == 20
        print(f"OK 括号运算: {result['expression']} = {result['result']}")
    
    def test_calculate_math_functions(self):
        """测试数学函数"""
        # 测试平方根
        result = calculate("sqrt(16)")
        assert result["success"] is True
        assert result["result"] == 4.0
        print(f"OK 平方根: {result['expression']} = {result['result']}")
        
        # 测试正弦函数
        result = calculate("sin(0)")
        assert result["success"] is True
        assert result["result"] == 0.0
        print(f"OK 正弦函数: {result['expression']} = {result['result']}")
        
        # 测试圆周率
        result = calculate("pi")
        assert result["success"] is True
        assert abs(result["result"] - 3.14159) < 0.001
        print(f"OK 圆周率: {result['expression']} = {result['result']}")
    
    def test_calculate_errors(self):
        """测试计算错误处理"""
        # 测试除零错误
        result = calculate("1 / 0")
        assert result["success"] is False
        assert "除零错误" in result["error"]
        print(f"OK 除零错误处理: {result['error']}")
        
        # 测试禁用关键字
        result = calculate("import os")
        assert result["success"] is False
        assert "禁用关键字" in result["error"]
        print(f"OK 禁用关键字检测: {result['error']}")
    
    def test_add(self):
        """测试加法工具"""
        result = add(2.5, 3.7)
        assert result["success"] is True
        assert result["result"] == 6.2
        assert result["operation"] == "addition"
        print(f"OK 加法工具: {result['expression']}")
    
    def test_divide(self):
        """测试除法工具"""
        # 正常除法
        result = divide(15, 3)
        assert result["success"] is True
        assert result["result"] == 5
        print(f"OK 正常除法: {result['expression']}")
        
        # 除零错误
        result = divide(5, 0)
        assert result["success"] is False
        assert "除数不能为零" in result["error"]
        print(f"OK 除零错误: {result['error']}")
    
    def test_square_root(self):
        """测试平方根工具"""
        # 正数平方根
        result = square_root(9)
        assert result["success"] is True
        assert result["result"] == 3.0
        print(f"OK 正数平方根: {result['expression']}")
        
        # 负数平方根
        result = square_root(-4)
        assert result["success"] is False
        assert "负数没有实数平方根" in result["error"]
        print(f"OK 负数平方根错误: {result['error']}")


def run_tests():
    """运行所有测试"""
    print("开始测试SSE计算器核心功能...")
    print("=" * 50)
    
    test_class = TestCalculatorTools()
    
    # 运行所有测试方法
    test_methods = [
        method for method in dir(test_class) 
        if method.startswith('test_')
    ]
    
    passed = 0
    failed = 0
    
    for method_name in test_methods:
        try:
            print(f"\n测试 {method_name}:")
            method = getattr(test_class, method_name)
            method()
            print(f"PASS {method_name}: 通过")
            passed += 1
        except Exception as e:
            print(f"FAIL {method_name}: 失败 - {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"测试结果:")
    print(f"通过: {passed}")
    print(f"失败: {failed}")
    print(f"总计: {passed + failed}")
    
    if failed == 0:
        print("SUCCESS 所有测试都通过了!")
    
    return failed == 0


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)