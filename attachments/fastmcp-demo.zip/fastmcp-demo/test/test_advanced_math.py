#!/usr/bin/env python3
"""
高级数学函数测试
测试新增的高级数学函数功能
"""

import asyncio
import sys
import os
import math
import time

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sse_calculator_client import create_sse_calculator_client


class TestAdvancedMath:
    """高级数学函数测试类"""
    
    def __init__(self, server_url: str = "http://127.0.0.1:8000"):
        self.server_url = server_url
        self.client = None
    
    async def setup(self):
        """设置测试环境"""
        from sse_calculator_client import SSECalculatorClient
        self.client = SSECalculatorClient(self.server_url)
        await self.client.connect()
    
    async def cleanup(self):
        """清理测试环境"""
        if self.client:
            await self.client.disconnect()
    
    async def test_advanced_expression_calculation(self):
        """测试高级表达式计算"""
        test_cases = [
            # 基本高级函数
            ("gamma(5)", 24.0),  # 4! = 24
            ("log2(8)", 3.0),    # log₂(8) = 3
            ("sinh(0)", 0.0),    # sinh(0) = 0
            ("factorial(4)", 24), # 4! = 24
            ("degrees(pi/2)", 90.0), # π/2 弧度 = 90度
            
            # 复杂表达式
            ("sin(pi/6) + cos(pi/3)", 1.0),  # sin(30°) + cos(60°) = 0.5 + 0.5 = 1
            ("log(e)", 1.0),      # ln(e) = 1
            ("exp(0)", 1.0),      # e⁰ = 1
            ("sqrt(2)**2", 2.0),  # (√2)² = 2
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("🧮 测试高级表达式计算:")
        for expression, expected in test_cases:
            try:
                result = await self.client.calculate(expression)
                
                if result.get('success'):
                    actual = result.get('result')
                    if abs(actual - expected) < 0.001:
                        print(f"  ✅ {expression} = {actual} (预期: {expected})")
                        passed += 1
                    else:
                        print(f"  ❌ {expression} = {actual} (预期: {expected})")
                else:
                    print(f"  ❌ {expression} 计算失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ {expression} 异常: {e}")
        
        print(f"高级表达式计算: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_trigonometric_functions(self):
        """测试三角函数"""
        test_cases = [
            # 基本三角函数（弧度）
            ("sin", 0, "radians", 0.0),
            ("cos", 0, "radians", 1.0),
            ("tan", 0, "radians", 0.0),
            
            # 三角函数（角度）
            ("sin", 90, "degrees", 1.0),
            ("cos", 90, "degrees", 0.0),
            ("sin", 30, "degrees", 0.5),
            ("cos", 60, "degrees", 0.5),
            
            # 反三角函数
            ("asin", 1, "radians", math.pi/2),
            ("acos", 0, "radians", math.pi/2),
            ("atan", 1, "radians", math.pi/4),
            
            # 双曲函数
            ("sinh", 0, "radians", 0.0),
            ("cosh", 0, "radians", 1.0),
            ("tanh", 0, "radians", 0.0),
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("📐 测试三角函数:")
        for function, angle, unit, expected in test_cases:
            try:
                result = await self.client.trigonometric_function(function, angle, unit)
                
                if result.get('success'):
                    actual = result.get('result')
                    if abs(actual - expected) < 0.001:
                        print(f"  ✅ {function}({angle}°/{unit}) = {actual:.4f}")
                        passed += 1
                    else:
                        print(f"  ❌ {function}({angle}°/{unit}) = {actual:.4f} (预期: {expected:.4f})")
                else:
                    print(f"  ❌ {function}({angle}°/{unit}) 失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ {function}({angle}) 异常: {e}")
        
        print(f"三角函数测试: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_logarithmic_functions(self):
        """测试对数函数"""
        test_cases = [
            ("ln", math.e, None, 1.0),
            ("log10", 100, None, 2.0),
            ("log2", 8, None, 3.0),
            ("logn", 8, 2, 3.0),
            ("logn", 125, 5, 3.0),
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("📊 测试对数函数:")
        for function, value, base, expected in test_cases:
            try:
                result = await self.client.logarithmic_function(function, value, base)
                
                if result.get('success'):
                    actual = result.get('result')
                    if abs(actual - expected) < 0.001:
                        base_str = f"(底数{base})" if base else ""
                        print(f"  ✅ {function}({value}){base_str} = {actual:.4f}")
                        passed += 1
                    else:
                        print(f"  ❌ {function}({value}) = {actual:.4f} (预期: {expected:.4f})")
                else:
                    print(f"  ❌ {function}({value}) 失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ {function}({value}) 异常: {e}")
        
        print(f"对数函数测试: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_statistical_analysis(self):
        """测试统计分析"""
        test_cases = [
            ([1, 2, 3, 4, 5], {"mean": 3.0, "median": 3.0, "variance": 2.5}),
            ([10, 20, 30], {"mean": 20.0, "median": 20.0}),
            ([1, 1, 2, 3, 5, 8, 13], {"mean": 4.714, "median": 3.0}),
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("📈 测试统计分析:")
        for data, expected_stats in test_cases:
            try:
                result = await self.client.statistical_analysis(data)
                
                if result.get('success'):
                    checks_passed = 0
                    total_checks = 0
                    
                    for stat_name, expected_value in expected_stats.items():
                        actual_value = result.get(stat_name)
                        total_checks += 1
                        if actual_value is not None and abs(actual_value - expected_value) < 0.001:
                            checks_passed += 1
                    
                    if checks_passed == total_checks:
                        print(f"  ✅ 数据{data}: 均值={result.get('mean'):.3f}, 中位数={result.get('median'):.3f}")
                        passed += 1
                    else:
                        print(f"  ❌ 数据{data}: 统计量不匹配")
                else:
                    print(f"  ❌ 统计分析失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ 统计分析异常: {e}")
        
        print(f"统计分析测试: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_polynomial_evaluation(self):
        """测试多项式求值"""
        test_cases = [
            # P(x) = x² + 2x + 1, P(2) = 9
            ([1, 2, 1], 2, 9),
            # P(x) = x³ - 1, P(2) = 7
            ([1, 0, 0, -1], 2, 7),
            # P(x) = 3x + 5, P(1) = 8
            ([3, 5], 1, 8),
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("🔢 测试多项式求值:")
        for coefficients, x, expected in test_cases:
            try:
                result = await self.client.polynomial_evaluation(coefficients, x)
                
                if result.get('success'):
                    actual = result.get('result')
                    if abs(actual - expected) < 0.001:
                        polynomial = result.get('polynomial', '')
                        print(f"  ✅ P({x}) = {actual} (多项式: {polynomial})")
                        passed += 1
                    else:
                        print(f"  ❌ P({x}) = {actual} (预期: {expected})")
                else:
                    print(f"  ❌ 多项式求值失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ 多项式求值异常: {e}")
        
        print(f"多项式求值测试: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_complex_number_operations(self):
        """测试复数运算"""
        test_cases = [
            # (1+2i) + (3+4i) = (4+6i)
            ("add", 1, 2, 3, 4, (4, 6)),
            # (2+3i) * (1+1i) = (-1+5i)
            ("multiply", 2, 3, 1, 1, (-1, 5)),
            # |3+4i| = 5
            ("modulus", 3, 4, None, None, 5),
            # conj(1+2i) = (1-2i)
            ("conjugate", 1, 2, None, None, (1, -2)),
        ]
        
        passed = 0
        total = len(test_cases)
        
        print("🔢 测试复数运算:")
        for operation, z1_real, z1_imag, z2_real, z2_imag, expected in test_cases:
            try:
                result = await self.client.complex_number_operation(
                    operation, z1_real, z1_imag, z2_real, z2_imag
                )
                
                if result.get('success'):
                    if operation == "modulus":
                        actual = result.get('result')
                        if abs(actual - expected) < 0.001:
                            print(f"  ✅ |{z1_real}+{z1_imag}i| = {actual}")
                            passed += 1
                        else:
                            print(f"  ❌ 模长计算错误: {actual} (预期: {expected})")
                    elif operation in ["add", "subtract", "multiply", "divide"]:
                        result_complex = result.get('result', {})
                        actual_real = result_complex.get('real', 0)
                        actual_imag = result_complex.get('imaginary', 0)
                        expected_real, expected_imag = expected
                        
                        if (abs(actual_real - expected_real) < 0.001 and 
                            abs(actual_imag - expected_imag) < 0.001):
                            print(f"  ✅ ({z1_real}+{z1_imag}i) {operation} ({z2_real}+{z2_imag}i) = ({actual_real}+{actual_imag}i)")
                            passed += 1
                        else:
                            print(f"  ❌ 复数运算错误: ({actual_real}+{actual_imag}i) (预期: ({expected_real}+{expected_imag}i))")
                    elif operation == "conjugate":
                        result_complex = result.get('result', {})
                        actual_real = result_complex.get('real', 0)
                        actual_imag = result_complex.get('imaginary', 0)
                        expected_real, expected_imag = expected
                        
                        if (abs(actual_real - expected_real) < 0.001 and 
                            abs(actual_imag - expected_imag) < 0.001):
                            print(f"  ✅ conj({z1_real}+{z1_imag}i) = ({actual_real}+{actual_imag}i)")
                            passed += 1
                        else:
                            print(f"  ❌ 共轭计算错误: ({actual_real}+{actual_imag}i)")
                else:
                    print(f"  ❌ 复数运算失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ 复数运算异常: {e}")
        
        print(f"复数运算测试: {passed}/{total} 通过\n")
        return passed == total
    
    async def test_expression_parser_advanced(self):
        """测试高级表达式解析器"""
        test_expressions = [
            "2 + 3 * sin(pi/2)",
            "log(exp(5)) + sqrt(16)",
            "gamma(4) / factorial(3)",
            "sinh(1) + cosh(1) - exp(1)",
        ]
        
        passed = 0
        total = len(test_expressions)
        
        print("🔍 测试高级表达式解析:")
        for expression in test_expressions:
            try:
                result = await self.client.expression_parser_advanced(expression)
                
                if result.get('success'):
                    functions_used = result.get('functions_used', [])
                    complexity = result.get('complexity_score', 0)
                    print(f"  ✅ '{expression}'")
                    print(f"     结果: {result.get('result')}")
                    print(f"     使用函数: {functions_used}")
                    print(f"     复杂度: {complexity}")
                    passed += 1
                else:
                    print(f"  ❌ 解析失败: {result.get('error')}")
                    
            except Exception as e:
                print(f"  ❌ 解析异常: {e}")
        
        print(f"表达式解析测试: {passed}/{total} 通过\n")
        return passed == total


async def run_advanced_math_tests(server_url: str = "http://127.0.0.1:8000"):
    """运行高级数学函数测试"""
    print("=== 高级数学函数测试 ===")
    print(f"服务器URL: {server_url}")
    print("=" * 50)
    
    test_runner = TestAdvancedMath(server_url)
    
    try:
        await test_runner.setup()
        
        # 运行所有测试
        test_methods = [
            ("高级表达式计算", test_runner.test_advanced_expression_calculation),
            ("三角函数", test_runner.test_trigonometric_functions),
            ("对数函数", test_runner.test_logarithmic_functions),
            ("统计分析", test_runner.test_statistical_analysis),
            ("多项式求值", test_runner.test_polynomial_evaluation),
            ("复数运算", test_runner.test_complex_number_operations),
            ("表达式解析", test_runner.test_expression_parser_advanced),
        ]
        
        passed = 0
        total = len(test_methods)
        
        for test_name, test_method in test_methods:
            print(f"\n{'='*20} {test_name} {'='*20}")
            try:
                result = await test_method()
                if result:
                    print(f"✅ {test_name}: 通过")
                    passed += 1
                else:
                    print(f"❌ {test_name}: 失败")
            except Exception as e:
                print(f"❌ {test_name}: 异常 - {e}")
        
        print("\n" + "=" * 60)
        print(f"🎯 测试总结:")
        print(f"通过: {passed}")
        print(f"失败: {total - passed}")
        print(f"总计: {total}")
        
        if passed == total:
            print("🎉 所有高级数学函数测试都通过了!")
        else:
            print("⚠️  部分测试失败，请检查服务器功能")
        
        return passed == total
        
    finally:
        await test_runner.cleanup()


async def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='高级数学函数测试')
    parser.add_argument('--server', default='http://127.0.0.1:8000',
                       help='服务器URL (默认: http://127.0.0.1:8000)')
    
    args = parser.parse_args()
    
    success = await run_advanced_math_tests(args.server)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
