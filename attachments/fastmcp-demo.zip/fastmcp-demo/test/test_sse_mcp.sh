#!/bin/bash
# SSE MCP Calculator Server 测试脚本
# 测试所有API端点的功能

echo "======================================================"
echo "SSE MCP Calculator Server API 测试"
echo "======================================================"

# 设置服务器基础URL
BASE_URL="http://127.0.0.1:8000"

echo ""
echo "1. 测试服务器根路径..."
echo "------------------------------------------------------"
curl -s $BASE_URL/ | python -m json.tool
echo ""

echo "2. 测试健康检查端点..."
echo "------------------------------------------------------"
curl -s $BASE_URL/health | python -m json.tool
echo ""

echo "3. 测试基本算术计算..."
echo "------------------------------------------------------"
echo "计算: 2 + 3 * 4"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"2 + 3 * 4\"}" | python -m json.tool
echo ""

echo "4. 测试数学函数计算..."
echo "------------------------------------------------------"
echo "计算: sqrt(16) + sin(0)"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"sqrt(16) + sin(0)\"}" | python -m json.tool
echo ""

echo "5. 测试复杂数学表达式..."
echo "------------------------------------------------------"
echo "计算: (2 + 3) * pi / 2"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"(2 + 3) * pi / 2\"}" | python -m json.tool
echo ""

echo "6. 测试三角函数计算..."
echo "------------------------------------------------------"
echo "计算: cos(0) + sin(pi/2)"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"cos(0) + sin(pi/2)\"}" | python -m json.tool
echo ""

echo "7. 测试对数和指数函数..."
echo "------------------------------------------------------"
echo "计算: log(e) + exp(0)"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"log(e) + exp(0)\"}" | python -m json.tool
echo ""

echo "8. 测试错误处理 - 除零错误..."
echo "------------------------------------------------------"
echo "计算: 1 / 0"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"1 / 0\"}" | python -m json.tool
echo ""

echo "9. 测试错误处理 - 语法错误..."
echo "------------------------------------------------------"
echo "计算: 2 + + 3"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"2 + + 3\"}" | python -m json.tool
echo ""

echo "10. 测试安全性 - 禁用关键字..."
echo "------------------------------------------------------"
echo "计算: import os"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{\"expression\": \"import os\"}" | python -m json.tool
echo ""

echo "11. 测试缺失参数..."
echo "------------------------------------------------------"
echo "发送空请求体"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "{}" | python -m json.tool
echo ""

echo "12. 测试无效JSON..."
echo "------------------------------------------------------"
echo "发送无效JSON"
curl -s -X POST $BASE_URL/calculate \
  -H "Content-Type: application/json" \
  -d "invalid json" 
echo ""

echo "13. 测试SSE连接 (前5秒)..."
echo "------------------------------------------------------"
echo "连接到SSE端点，显示前5秒的数据..."
timeout 5s curl -s $BASE_URL/sse 2>/dev/null | head -10
echo ""

echo "======================================================"
echo "测试完成!"
echo "======================================================"
echo ""
echo "可用端点:"
echo "- 根路径:     $BASE_URL/"
echo "- 健康检查:   $BASE_URL/health"  
echo "- 计算接口:   $BASE_URL/calculate"
echo "- SSE连接:    $BASE_URL/sse"
echo "- API文档:    $BASE_URL/docs"
echo ""