#!/usr/bin/env python3
"""
SSE计算器集成测试
启动服务器并测试完整的客户端-服务器交互
"""

import asyncio
import sys
import os
import subprocess
import time
import signal
import json
from typing import Optional

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sse_calculator_client import create_sse_calculator_client
from test_sse_client import run_client_tests


class SSEServerManager:
    """SSE服务器管理器"""
    
    def __init__(self, server_script: str = None, host: str = "127.0.0.1", port: int = 8000):
        self.server_script = server_script or os.path.join(
            os.path.dirname(__file__), '..', 'src', 'sse_calculator_server.py'
        )
        self.host = host
        self.port = port
        self.server_url = f"http://{host}:{port}"
        self.process: Optional[subprocess.Popen] = None
        self.startup_timeout = 10  # 启动超时时间(秒)
    
    async def start_server(self):
        """启动服务器"""
        print(f"启动SSE服务器: {self.server_script}")
        print(f"监听地址: {self.server_url}")
        
        try:
            # 启动服务器进程
            self.process = subprocess.Popen(
                [sys.executable, self.server_script],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            print(f"服务器进程启动，PID: {self.process.pid}")
            
            # 等待服务器启动
            await self._wait_for_server()
            print("✅ 服务器启动成功")
            return True
            
        except Exception as e:
            print(f"❌ 服务器启动失败: {e}")
            await self.stop_server()
            return False
    
    async def _wait_for_server(self):
        """等待服务器启动完成"""
        import aiohttp
        
        start_time = time.time()
        
        while time.time() - start_time < self.startup_timeout:
            if self.process and self.process.poll() is not None:
                stdout, stderr = self.process.communicate()
                raise Exception(f"服务器进程退出: stdout={stdout}, stderr={stderr}")
            
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"{self.server_url}/health", timeout=2) as response:
                        if response.status == 200:
                            return True
            except (aiohttp.ClientError, asyncio.TimeoutError):
                pass
            
            await asyncio.sleep(0.5)
        
        raise TimeoutError(f"服务器启动超时 ({self.startup_timeout}秒)")
    
    async def stop_server(self):
        """停止服务器"""
        if self.process:
            print(f"停止服务器进程 PID: {self.process.pid}")
            
            try:
                # 发送终止信号
                if os.name == 'nt':  # Windows
                    self.process.terminate()
                else:  # Unix-like
                    self.process.send_signal(signal.SIGTERM)
                
                # 等待进程结束
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    print("强制结束服务器进程")
                    self.process.kill()
                    self.process.wait()
                
                print("✅ 服务器已停止")
                
            except Exception as e:
                print(f"⚠️  停止服务器时出错: {e}")
            finally:
                self.process = None
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.start_server()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.stop_server()


async def test_full_integration():
    """完整集成测试"""
    print("=== SSE计算器完整集成测试 ===")
    print("这将启动服务器并运行完整的客户端测试")
    print("=" * 60)
    
    # 启动服务器并运行测试
    async with SSEServerManager() as server_manager:
        print("\n🔄 等待服务器稳定...")
        await asyncio.sleep(2)
        
        # 运行客户端测试
        print("\n🧪 开始运行客户端测试...")
        success = await run_client_tests(server_manager.server_url)
        
        if success:
            print("\n🎉 集成测试完全成功!")
        else:
            print("\n❌ 集成测试存在失败项")
        
        return success


async def test_concurrent_clients():
    """测试并发客户端"""
    print("\n=== 并发客户端测试 ===")
    
    async with SSEServerManager() as server_manager:
        print("\n🔄 等待服务器稳定...")
        await asyncio.sleep(2)
        
        async def client_task(client_id: int, calculations: int = 5):
            """单个客户端任务"""
            try:
                async with create_sse_calculator_client(server_manager.server_url) as client:
                    # 健康检查
                    await client.health_check()
                    
                    # 执行计算
                    results = []
                    for i in range(calculations):
                        expression = f"{client_id * 10 + i} + {i}"
                        result = await client.calculate(expression)
                        results.append(result.get('success', False))
                        await asyncio.sleep(0.1)  # 小延迟
                    
                    success_count = sum(results)
                    print(f"客户端{client_id}: {success_count}/{calculations} 计算成功")
                    return success_count == calculations
                    
            except Exception as e:
                print(f"客户端{client_id} 错误: {e}")
                return False
        
        # 启动多个并发客户端
        num_clients = 3
        tasks = [client_task(i) for i in range(num_clients)]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        successful_clients = sum(1 for r in results if r is True)
        print(f"并发测试结果: {successful_clients}/{num_clients} 客户端成功")
        
        return successful_clients == num_clients


async def test_long_running_connection():
    """测试长连接"""
    print("\n=== 长连接测试 ===")
    
    async with SSEServerManager() as server_manager:
        print("\n🔄 等待服务器稳定...")
        await asyncio.sleep(2)
        
        try:
            async with create_sse_calculator_client(server_manager.server_url) as client:
                # 设置事件计数器
                event_counts = {'heartbeat': 0, 'connection': 0, 'server_info': 0}
                
                async def count_heartbeat(data):
                    event_counts['heartbeat'] += 1
                    print(f"💗 收到心跳 #{event_counts['heartbeat']}")
                
                async def count_connection(data):
                    event_counts['connection'] += 1
                    print("🔗 收到连接事件")
                
                async def count_server_info(data):
                    event_counts['server_info'] += 1
                    print("📋 收到服务器信息")
                
                client.set_event_handlers(
                    on_heartbeat=count_heartbeat,
                    on_connection=count_connection,
                    on_server_info=count_server_info
                )
                
                # 启动SSE监听
                sse_task = None
                try:
                    async def sse_listener():
                        async for event in client.listen_sse_events():
                            pass
                    
                    sse_task = asyncio.create_task(sse_listener())
                    
                    # 在长连接期间执行计算
                    print("🧮 在长连接期间执行计算...")
                    for i in range(10):
                        result = await client.calculate(f"sqrt({i * i + 1})")
                        if result.get('success'):
                            print(f"计算 √{i * i + 1} = {result.get('result'):.2f}")
                        await asyncio.sleep(1)
                    
                    print(f"\n📊 事件统计:")
                    print(f"   连接事件: {event_counts['connection']}")
                    print(f"   服务器信息: {event_counts['server_info']}")
                    print(f"   心跳事件: {event_counts['heartbeat']}")
                    
                    return event_counts['connection'] > 0 and event_counts['server_info'] > 0
                    
                finally:
                    if sse_task:
                        sse_task.cancel()
                        try:
                            await sse_task
                        except asyncio.CancelledError:
                            pass
            
        except Exception as e:
            print(f"❌ 长连接测试失败: {e}")
            return False


async def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='SSE计算器集成测试')
    parser.add_argument('--test', choices=['all', 'integration', 'concurrent', 'long'], 
                       default='all', help='选择测试类型')
    parser.add_argument('--port', type=int, default=8000, help='服务器端口')
    
    args = parser.parse_args()
    
    print(f"🚀 开始集成测试 (端口: {args.port})")
    
    try:
        results = {}
        
        if args.test in ['all', 'integration']:
            print("\n" + "="*60)
            results['integration'] = await test_full_integration()
        
        if args.test in ['all', 'concurrent']:
            print("\n" + "="*60)
            results['concurrent'] = await test_concurrent_clients()
        
        if args.test in ['all', 'long']:
            print("\n" + "="*60) 
            results['long_connection'] = await test_long_running_connection()
        
        # 总结结果
        print("\n" + "="*60)
        print("📊 集成测试总结:")
        
        all_passed = True
        for test_name, result in results.items():
            status = "✅ 通过" if result else "❌ 失败"
            print(f"   {test_name}: {status}")
            if not result:
                all_passed = False
        
        if all_passed:
            print("\n🎉 所有集成测试都通过了!")
            return 0
        else:
            print("\n⚠️  部分集成测试失败")
            return 1
            
    except KeyboardInterrupt:
        print("\n⚠️  测试被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 集成测试异常: {e}")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
