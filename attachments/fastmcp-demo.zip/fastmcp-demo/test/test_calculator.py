#!/usr/bin/env python3
"""
测试计算器MCP服务器功能
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from simple_mcp_server import add_numbers, add_multiple_numbers, get_calculator_info, validate_number

def test_add_numbers():
    """测试两个数字相加功能"""
    print("测试 add_numbers 功能:")
    
    # 测试整数相加
    result = add_numbers(5, 3)
    print(f"5 + 3 = {result}")
    
    # 测试浮点数相加
    result = add_numbers(3.14, 2.86)
    print(f"3.14 + 2.86 = {result}")
    
    # 测试负数相加
    result = add_numbers(-5, 10)
    print(f"-5 + 10 = {result}")
    
    print()

def test_add_multiple_numbers():
    """测试多个数字相加功能"""
    print("测试 add_multiple_numbers 功能:")
    
    # 测试多个整数
    result = add_multiple_numbers([1, 2, 3, 4, 5])
    print(f"[1, 2, 3, 4, 5] 的总和 = {result}")
    
    # 测试包含浮点数
    result = add_multiple_numbers([1.5, 2.5, 3.0])
    print(f"[1.5, 2.5, 3.0] 的总和 = {result}")
    
    # 测试空列表
    result = add_multiple_numbers([])
    print(f"空列表的结果 = {result}")
    
    print()

def test_get_calculator_info():
    """测试获取服务器信息功能"""
    print("测试 get_calculator_info 功能:")
    info = get_calculator_info()
    print(f"服务器信息: {info}")
    print()

def test_validate_number():
    """测试数字验证功能"""
    print("测试 validate_number 功能:")
    
    # 测试有效整数
    result = validate_number("123")
    print(f"验证 '123': {result}")
    
    # 测试有效浮点数
    result = validate_number("3.14")
    print(f"验证 '3.14': {result}")
    
    # 测试无效输入
    result = validate_number("abc")
    print(f"验证 'abc': {result}")
    
    # 测试负数
    result = validate_number("-42")
    print(f"验证 '-42': {result}")
    
    print()

def main():
    """运行所有测试"""
    print("=" * 50)
    print("计算器MCP服务器功能测试")
    print("=" * 50)
    print()
    
    test_add_numbers()
    test_add_multiple_numbers()
    test_get_calculator_info()
    test_validate_number()
    
    print("=" * 50)
    print("所有测试完成！")
    print("=" * 50)

if __name__ == "__main__":
    main()
