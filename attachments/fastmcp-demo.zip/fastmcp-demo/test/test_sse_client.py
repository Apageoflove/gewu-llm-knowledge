#!/usr/bin/env python3
"""
SSE计算器客户端测试
测试客户端与服务器的交互
"""

import asyncio
import sys
import os
import time
from typing import Dict, Any

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sse_calculator_client import SSECalculatorClient, create_sse_calculator_client


class TestSSECalculatorClient:
    """测试SSE计算器客户端"""
    
    def __init__(self, server_url: str = "http://127.0.0.1:8000"):
        self.server_url = server_url
        self.client = None
        self.test_results = []
    
    async def setup(self):
        """设置测试环境"""
        self.client = SSECalculatorClient(self.server_url)
        await self.client.connect()
        
        # 设置事件处理器
        self.events_received = []
        
        async def capture_event(event_data, event_type):
            self.events_received.append({
                'type': event_type,
                'data': event_data,
                'timestamp': time.time()
            })
        
        self.client.set_event_handlers(
            on_connection=lambda data: capture_event(data, 'connection'),
            on_server_info=lambda data: capture_event(data, 'server_info'),
            on_heartbeat=lambda data: capture_event(data, 'heartbeat'),
            on_error=lambda data: capture_event(data, 'error')
        )
    
    async def cleanup(self):
        """清理测试环境"""
        if self.client:
            await self.client.disconnect()
    
    async def test_health_check(self):
        """测试健康检查"""
        try:
            health = await self.client.health_check()
            
            assert isinstance(health, dict), "健康检查应返回字典"
            assert health.get('status') == 'healthy', f"服务器状态不健康: {health}"
            assert 'server' in health, "健康检查响应缺少server字段"
            assert 'version' in health, "健康检查响应缺少version字段"
            
            print(f"✅ 健康检查通过: {health}")
            return True
            
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return False
    
    async def test_basic_calculation(self):
        """测试基本计算功能"""
        test_cases = [
            ("2 + 3", 5),
            ("10 - 4", 6),
            ("3 * 7", 21),
            ("15 / 3", 5),
            ("2 ** 3", 8),
            ("sqrt(16)", 4.0),
        ]
        
        passed = 0
        total = len(test_cases)
        
        for expression, expected in test_cases:
            try:
                result = await self.client.calculate(expression)
                
                assert result.get('success') is True, f"计算失败: {result}"
                assert abs(result.get('result', 0) - expected) < 0.001, f"结果不正确: 期望{expected}, 得到{result.get('result')}"
                
                print(f"✅ {expression} = {result.get('result')}")
                passed += 1
                
            except Exception as e:
                print(f"❌ 计算 {expression} 失败: {e}")
        
        print(f"基本计算测试: {passed}/{total} 通过")
        return passed == total
    
    async def test_calculation_methods(self):
        """测试专用计算方法"""
        test_cases = [
            ("add", [5.5, 3.2], 8.7),
            ("subtract", [10, 3], 7),
            ("multiply", [4, 6], 24),
            ("divide", [20, 5], 4),
            ("power", [3, 2], 9),
            ("square_root", [25], 5.0),
        ]
        
        passed = 0
        total = len(test_cases)
        
        for method_name, args, expected in test_cases:
            try:
                method = getattr(self.client, method_name)
                result = await method(*args)
                
                assert result.get('success') is True, f"{method_name}计算失败: {result}"
                assert abs(result.get('result', 0) - expected) < 0.001, f"结果不正确: 期望{expected}, 得到{result.get('result')}"
                
                print(f"✅ {method_name}({', '.join(map(str, args))}) = {result.get('result')}")
                passed += 1
                
            except Exception as e:
                print(f"❌ {method_name} 方法测试失败: {e}")
        
        print(f"计算方法测试: {passed}/{total} 通过")
        return passed == total
    
    async def test_error_handling(self):
        """测试错误处理"""
        error_test_cases = [
            ("1 / 0", "除零"),
            ("sqrt(-1)", "负数"),
            ("import os", "禁用关键字"),
            ("invalid syntax", "语法"),
        ]
        
        passed = 0
        total = len(error_test_cases)
        
        for expression, error_type in error_test_cases:
            try:
                result = await self.client.calculate(expression)
                
                assert result.get('success') is False, f"应该失败但成功了: {expression}"
                assert 'error' in result, f"错误响应缺少error字段: {result}"
                
                print(f"✅ {error_type}错误正确处理: {expression}")
                passed += 1
                
            except Exception as e:
                print(f"❌ 错误处理测试失败 {expression}: {e}")
        
        print(f"错误处理测试: {passed}/{total} 通过")
        return passed == total
    
    async def test_sse_events(self):
        """测试SSE事件接收"""
        print("开始SSE事件测试...")
        
        # 启动SSE监听
        sse_task = None
        try:
            async def sse_listener():
                async for event in self.client.listen_sse_events():
                    pass  # 事件处理在客户端内部完成
            
            sse_task = asyncio.create_task(sse_listener())
            
            # 等待事件接收
            await asyncio.sleep(3)
            
            # 检查接收到的事件
            connection_events = [e for e in self.events_received if e['type'] == 'connection']
            server_info_events = [e for e in self.events_received if e['type'] == 'server_info']
            
            assert len(connection_events) > 0, "未收到连接事件"
            assert len(server_info_events) > 0, "未收到服务器信息事件"
            
            print(f"✅ SSE事件接收正常:")
            print(f"   连接事件: {len(connection_events)}")
            print(f"   服务器信息事件: {len(server_info_events)}")
            print(f"   总事件数: {len(self.events_received)}")
            
            return True
            
        except Exception as e:
            print(f"❌ SSE事件测试失败: {e}")
            return False
        finally:
            if sse_task:
                sse_task.cancel()
                try:
                    await sse_task
                except asyncio.CancelledError:
                    pass
    
    async def test_context_manager(self):
        """测试上下文管理器"""
        try:
            async with create_sse_calculator_client(self.server_url) as client:
                # 执行健康检查
                health = await client.health_check()
                assert health.get('status') == 'healthy', "上下文管理器中健康检查失败"
                
                # 执行简单计算
                result = await client.calculate("5 + 5")
                assert result.get('success') is True, "上下文管理器中计算失败"
                assert result.get('result') == 10, "上下文管理器中计算结果错误"
            
            print("✅ 上下文管理器测试通过")
            return True
            
        except Exception as e:
            print(f"❌ 上下文管理器测试失败: {e}")
            return False


async def run_client_tests(server_url: str = "http://127.0.0.1:8000"):
    """运行客户端测试"""
    print("=== SSE计算器客户端测试 ===")
    print(f"服务器URL: {server_url}")
    print("=" * 50)
    
    test_client = TestSSECalculatorClient(server_url)
    
    try:
        # 设置测试环境
        await test_client.setup()
        
        # 运行测试
        test_methods = [
            ("健康检查", test_client.test_health_check),
            ("基本计算", test_client.test_basic_calculation),
            ("计算方法", test_client.test_calculation_methods),
            ("错误处理", test_client.test_error_handling),
            ("SSE事件", test_client.test_sse_events),
            ("上下文管理器", test_client.test_context_manager),
        ]
        
        passed = 0
        total = len(test_methods)
        
        for test_name, test_method in test_methods:
            print(f"\n--- 测试: {test_name} ---")
            try:
                result = await test_method()
                if result:
                    print(f"✅ {test_name}: 通过")
                    passed += 1
                else:
                    print(f"❌ {test_name}: 失败")
                    
            except Exception as e:
                print(f"❌ {test_name}: 异常 - {e}")
        
        print("\n" + "=" * 50)
        print(f"测试结果:")
        print(f"通过: {passed}")
        print(f"失败: {total - passed}")
        print(f"总计: {total}")
        
        if passed == total:
            print("🎉 所有客户端测试都通过了!")
        else:
            print("⚠️  部分测试失败，请检查服务器是否正在运行")
        
        return passed == total
        
    finally:
        await test_client.cleanup()


async def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='SSE计算器客户端测试')
    parser.add_argument('--server', default='http://127.0.0.1:8000', 
                       help='服务器URL (默认: http://127.0.0.1:8000)')
    parser.add_argument('--demo', action='store_true', 
                       help='运行演示而不是测试')
    
    args = parser.parse_args()
    
    if args.demo:
        # 运行客户端演示
        from sse_calculator_client import demo_client
        await demo_client()
    else:
        # 运行测试
        success = await run_client_tests(args.server)
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
