#!/usr/bin/env python3
"""
SSE MCP Calculator Server 测试脚本 (Python版本)
测试所有API端点的功能
"""

import requests
import json
import sys
from typing import Dict, Any


def test_endpoint(name: str, description: str, method: str = "GET", 
                 url: str = "", data: Dict[str, Any] = None, 
                 headers: Dict[str, str] = None) -> None:
    """测试单个端点"""
    print(f"\n{name}. {description}")
    print("-" * 50)
    
    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, timeout=10)
        elif method.upper() == "POST":
            response = requests.post(url, json=data, headers=headers, timeout=10)
        
        # 打印状态码
        print(f"状态码: {response.status_code}")
        
        # 尝试解析JSON
        try:
            result = response.json()
            print(json.dumps(result, indent=2, ensure_ascii=False))
        except:
            print(f"响应文本: {response.text}")
            
    except Exception as e:
        print(f"请求失败: {e}")


def main():
    """主测试函数"""
    base_url = "http://127.0.0.1:8000"
    
    print("=" * 60)
    print("SSE MCP Calculator Server API 测试")
    print("=" * 60)
    
    # 测试用例列表
    test_cases = [
        {
            "name": "1",
            "description": "测试服务器根路径",
            "method": "GET",
            "url": f"{base_url}/"
        },
        {
            "name": "2", 
            "description": "测试健康检查端点",
            "method": "GET",
            "url": f"{base_url}/health"
        },
        {
            "name": "3",
            "description": "测试基本算术计算 (2 + 3 * 4)",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "2 + 3 * 4"}
        },
        {
            "name": "4",
            "description": "测试数学函数计算 (sqrt(16) + sin(0))",
            "method": "POST", 
            "url": f"{base_url}/calculate",
            "data": {"expression": "sqrt(16) + sin(0)"}
        },
        {
            "name": "5",
            "description": "测试复杂数学表达式 ((2 + 3) * pi / 2)",
            "method": "POST",
            "url": f"{base_url}/calculate", 
            "data": {"expression": "(2 + 3) * pi / 2"}
        },
        {
            "name": "6",
            "description": "测试三角函数计算 (cos(0) + sin(pi/2))",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "cos(0) + sin(pi/2)"}
        },
        {
            "name": "7", 
            "description": "测试对数和指数函数 (log(e) + exp(0))",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "log(e) + exp(0)"}
        },
        {
            "name": "8",
            "description": "测试幂运算 (pow(2, 3) + 2**4)",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "pow(2, 3) + 2**4"}
        },
        {
            "name": "9",
            "description": "测试错误处理 - 除零错误 (1 / 0)",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "1 / 0"}
        },
        {
            "name": "10",
            "description": "测试错误处理 - 语法错误 (2 + + 3)",
            "method": "POST",
            "url": f"{base_url}/calculate", 
            "data": {"expression": "2 + + 3"}
        },
        {
            "name": "11",
            "description": "测试安全性 - 禁用关键字 (import os)",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": "import os"}
        },
        {
            "name": "12",
            "description": "测试安全性 - 禁用关键字 (__import__)",
            "method": "POST", 
            "url": f"{base_url}/calculate",
            "data": {"expression": "__import__('os')"}
        },
        {
            "name": "13",
            "description": "测试缺失参数",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {}
        },
        {
            "name": "14",
            "description": "测试空表达式",
            "method": "POST",
            "url": f"{base_url}/calculate",
            "data": {"expression": ""}
        }
    ]
    
    # 执行所有测试
    passed = 0
    failed = 0
    
    for test_case in test_cases:
        try:
            test_endpoint(**test_case)
            passed += 1
        except Exception as e:
            print(f"测试失败: {e}")
            failed += 1
    
    # 测试结果统计
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)
    print(f"执行测试: {passed + failed}")
    print(f"成功执行: {passed}")
    print(f"执行失败: {failed}")
    
    # 显示可用端点
    print(f"\n可用端点:")
    print(f"- 根路径:     {base_url}/")
    print(f"- 健康检查:   {base_url}/health")
    print(f"- 计算接口:   {base_url}/calculate")
    print(f"- SSE连接:    {base_url}/sse")
    print(f"- API文档:    {base_url}/docs")
    
    return failed == 0


def test_sse_connection():
    """测试SSE连接"""
    print("\n15. 测试SSE连接")
    print("-" * 50)
    
    try:
        import sseclient  # pip install sseclient-py
        response = requests.get("http://127.0.0.1:8000/sse", stream=True)
        client = sseclient.SSEClient(response)
        
        print("SSE连接成功，接收前3个事件:")
        count = 0
        for event in client.events():
            if count >= 3:
                break
            print(f"事件: {event.data}")
            count += 1
            
    except ImportError:
        print("提示: 安装 sseclient-py 库可测试SSE连接")
        print("pip install sseclient-py")
    except Exception as e:
        print(f"SSE连接测试失败: {e}")


if __name__ == "__main__":
    success = main()
    
    # 可选测试SSE连接
    try:
        test_sse_connection()
    except:
        pass
        
    sys.exit(0 if success else 1)