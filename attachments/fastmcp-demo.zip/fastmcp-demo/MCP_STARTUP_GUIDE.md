# MCP服务器启动指南

## 问题分析

你遇到的错误 `File not found: D:\work\my\course\sc\ai\list\169.基于FastMCP框架开发智能问答应用\fastmcp-demo\src\.basic_mcp_server.py` 表明：

1. **文件名问题**: 系统在寻找 `.basic_mcp_server.py`（前面有个点），但实际文件名是 `basic_mcp_server.py`
2. **MCP命令行配置问题**: 需要正确的配置来启动MCP服务器

## 解决方案

### 方法1: 直接运行Python文件（推荐）

```bash
# 在项目根目录下运行
python src/basic_mcp_server.py
```

### 方法2: 使用启动脚本

```bash
# 使用Python启动脚本
python start_server.py

# 或使用PowerShell脚本（Windows）
.\start_server.ps1
```

### 方法3: 使用MCP命令行工具

如果你确实需要使用MCP命令行工具，需要：

1. 安装MCP CLI工具
2. 创建正确的配置文件
3. 使用正确的启动命令

## 当前可用的工具

启动服务器后，你将获得以下MCP工具：

- `get_server_info()`: 获取服务器信息
- `hello_world(name)`: 问候工具
- `add_numbers(a, b)`: 数字加法计算

## 故障排除

### 1. 依赖问题
```bash
pip install -r requirements.txt
```

### 2. Python路径问题
确保在项目根目录下运行命令

### 3. 权限问题
在Windows上，可能需要以管理员身份运行PowerShell

## 测试服务器

启动服务器后，你应该看到类似这样的输出：
```
正在启动MCP服务器...
[INFO] MCP服务器已启动
```

## 注意事项

- 确保Python 3.8+已安装
- 确保所有依赖已正确安装
- 在项目根目录下运行命令
- 如果使用MCP CLI，需要正确的配置文件
