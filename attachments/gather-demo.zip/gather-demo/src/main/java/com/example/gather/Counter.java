package com.example.gather;

import lombok.Data;

@Data
public class Counter {
    public int counter;

    public Counter(int counter) {
        this.counter = counter;
    }
}