package com.example.stream;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Apple {

    private int id ;

    private String country;

    public Apple(int id, String country) {
        this.id = id;
        this.country = country;
    }

    @Override
    public String toString() {
        return "Apple{" +
                "id=" + id +
                ", country='" + country + '\'' +
                '}';
    }
}
