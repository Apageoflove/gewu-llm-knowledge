import com.example.stream.Apple;
import com.example.stream.MyCollectors;

import java.util.List;
import java.util.stream.Stream;

public static void main(String[] args) {
    //将以下对象放入stream进行运算合并
    Apple chinaApple = new Apple(10, "中国");
    Apple usApple = new Apple(20, "美国");
    Apple koreaApple = new Apple(30, "韩国");
    Apple japanApple = new Apple(40, "日本");

    List<Apple> collect = Stream.of(chinaApple, usApple, koreaApple, japanApple)
            // 使用自定义的收集器
            .collect(new MyCollectors.ToList<>());
    System.out.println(collect);
}