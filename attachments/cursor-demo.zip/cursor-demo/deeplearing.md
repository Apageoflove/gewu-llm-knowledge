﻿import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Conv2D, MaxPooling2D, Flatten, Concatenate
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
import cv2

# 数据加载函数
def load_data():
    # 加载烹饪参数CSV
    params_df = pd.read_csv('cooking_params.csv')
    
    # 加载图像数据
    images = []
    for img_path in params_df['image_path']:
        img = cv2.imread(img_path)
        img = cv2.resize(img, (224, 224))
        img = img / 255.0  # 归一化
        images.append(img)
    
    # 加载评分标签
    scores = params_df['overall_score'].values
    
    return np.array(images), params_df[['tomato_egg_ratio', 'cooking_order', 'heat_level']].values, scores

# 多模态模型架构
def create_multimodal_model():
    # 图像输入分支
    image_input = Input(shape=(224, 224, 3))
    x = Conv2D(32, (3, 3), activation='relu')(image_input)
    x = MaxPooling2D((2, 2))(x)
    x = Conv2D(64, (3, 3), activation='relu')(x)
    x = MaxPooling2D((2, 2))(x)
    x = Flatten()(x)
    image_branch = Dense(64, activation='relu')(x)
    
    # 参数输入分支
    param_input = Input(shape=(3,))
    param_branch = Dense(16, activation='relu')(param_input)
    
    # 融合分支
    combined = Concatenate()([image_branch, param_branch])
    z = Dense(32, activation='relu')(combined)
    output = Dense(1, activation='linear')(z)  # 回归输出
    
    model = Model(inputs=[image_input, param_input], outputs=output)
    model.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
    return model

# 主程序
if __name__ == "__main__":
    # 加载数据
    images, params, scores = load_data()
    
    # 划分训练测试集
    X_img_train, X_img_test, X_param_train, X_param_test, y_train, y_test = train_test_split(
        images, params, scores, test_size=0.2, random_state=42
    )
    
    # 创建并训练模型
    model = create_multimodal_model()
    history = model.fit(
        [X_img_train, X_param_train],
        y_train,
        epochs=50,
        batch_size=32,
        validation_split=0.1
    )
    
    # 评估模型
    test_loss, test_mae = model.evaluate([X_img_test, X_param_test], y_test)
    print(f"测试集MAE: {test_mae:.4f}")
    
    # 保存模型
    model.save('tomato_egg_model.h5')
    
    # 使用模型预测最佳参数组合
    # (此处需要实现参数搜索算法)
