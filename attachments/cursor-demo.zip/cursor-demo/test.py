
# 生成一个计算平均值的函数
def average(numbers):
    return sum(numbers) / len(numbers)

# 测试average函数的准确性
def test_average():
    # 测试用例1
    nums1 = [1, 2, 3, 4, 5]
    assert average(nums1) == 3, f"测试失败: {average(nums1)} != 3"

    # 测试用例2
    nums2 = [10, 20, 30]
    assert average(nums2) == 20, f"测试失败: {average(nums2)} != 20"

    # 测试用例3
    nums3 = [0, 0, 0, 0]
    assert average(nums3) == 0, f"测试失败: {average(nums3)} != 0"

    # 测试用例4
    nums4 = [2.5, 3.5, 4.0]
    assert average(nums4) == 3.3333333333333335, f"测试失败: {average(nums4)} != 3.3333333333333335"

    print("所有平均值测试通过！")

# 调用测试函数
test_average()
