#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化版银行客户信用评分分析系统
Simplified Bank Customer Credit Scoring Analysis
去掉seaborn依赖，仅使用matplotlib和基础库
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class SimpleBankCreditAnalysis:
    def __init__(self):
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.scaler = StandardScaler()
        self.models = {}
        self.results = {}
        
    def generate_sample_data(self, n_samples=1000):
        """生成模拟银行客户数据"""
        print("🏦 正在生成银行客户样本数据...")
        
        np.random.seed(42)
        
        # 基础信息
        age = np.random.normal(40, 12, n_samples).astype(int)
        age = np.clip(age, 18, 80)
        
        gender = np.random.choice(['男', '女'], n_samples)
        
        # 收入相关
        income = np.random.lognormal(10.5, 0.8, n_samples)
        income = np.clip(income, 20000, 500000).astype(int)
        
        # 工作年限
        work_years = np.random.exponential(8, n_samples)
        work_years = np.clip(work_years, 0, 40).astype(int)
        
        # 教育水平
        education = np.random.choice(['高中', '大专', '本科', '硕士', '博士'], 
                                   n_samples, p=[0.2, 0.25, 0.35, 0.15, 0.05])
        
        # 婚姻状况
        marital_status = np.random.choice(['未婚', '已婚', '离异'], 
                                        n_samples, p=[0.3, 0.6, 0.1])
        
        # 房产情况
        house_ownership = np.random.choice(['无房', '有房贷', '全款房'], 
                                         n_samples, p=[0.3, 0.5, 0.2])
        
        # 历史贷款次数
        loan_history = np.random.poisson(2, n_samples)
        loan_history = np.clip(loan_history, 0, 10)
        
        # 信用卡数量
        credit_cards = np.random.poisson(1.5, n_samples)
        credit_cards = np.clip(credit_cards, 0, 8)
        
        # 债务收入比
        debt_to_income = np.random.beta(2, 5, n_samples) * 0.8
        
        # 储蓄金额
        savings = income * np.random.uniform(0.1, 2.0, n_samples)
        savings = savings.astype(int)
        
        # 逾期次数
        overdue_times = np.random.poisson(0.5, n_samples)
        overdue_times = np.clip(overdue_times, 0, 10)
        
        # 银行关系年限
        bank_relation_years = np.random.exponential(5, n_samples)
        bank_relation_years = np.clip(bank_relation_years, 0.5, 25)
        
        # 生成信用评级（目标变量）
        credit_score = (
            (income / 1000) * 0.3 +
            work_years * 0.2 +
            (age - 18) * 0.1 +
            (5 - overdue_times) * 0.2 +
            bank_relation_years * 0.1 +
            (1 - debt_to_income) * 0.3 +
            np.random.normal(0, 5, n_samples)
        )
        
        # 将评分转换为分类
        credit_rating = pd.cut(credit_score, 
                             bins=[-np.inf, 20, 40, 60, np.inf],
                             labels=['差', '一般', '良好', '优秀'])
        
        # 创建DataFrame
        self.data = pd.DataFrame({
            '年龄': age,
            '性别': gender,
            '年收入': income,
            '工作年限': work_years,
            '教育水平': education,
            '婚姻状况': marital_status,
            '房产情况': house_ownership,
            '历史贷款次数': loan_history,
            '信用卡数量': credit_cards,
            '债务收入比': debt_to_income.round(3),
            '储蓄金额': savings,
            '逾期次数': overdue_times,
            '银行关系年限': bank_relation_years.round(1),
            '信用评级': credit_rating
        })
        
        print(f"✅ 成功生成 {n_samples} 条银行客户数据")
        return self.data
    
    def data_exploration(self):
        """数据探索性分析"""
        print("\n" + "="*50)
        print("📊 数据探索性分析")
        print("="*50)
        
        # 基本信息
        print("\n1. 数据基本信息:")
        print(f"数据维度: {self.data.shape}")
        print(f"缺失值: {self.data.isnull().sum().sum()}")
        
        print("\n2. 数值特征统计:")
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        print(self.data[numeric_cols].describe().round(2))
        
        print("\n3. 信用评级分布:")
        credit_counts = self.data['信用评级'].value_counts()
        print(credit_counts)
        print("\n信用评级比例:")
        print((credit_counts / len(self.data)).round(3))
        
        # 简单可视化
        try:
            fig, axes = plt.subplots(2, 2, figsize=(12, 10))
            
            # 信用评级分布
            credit_counts.plot(kind='bar', ax=axes[0,0], color=['red', 'orange', 'lightblue', 'green'])
            axes[0,0].set_title('信用评级分布')
            axes[0,0].set_xlabel('信用评级')
            axes[0,0].set_ylabel('客户数量')
            axes[0,0].tick_params(axis='x', rotation=45)
            
            # 年龄分布
            axes[0,1].hist(self.data['年龄'], bins=20, color='lightblue', alpha=0.7)
            axes[0,1].set_title('年龄分布')
            axes[0,1].set_xlabel('年龄')
            axes[0,1].set_ylabel('频数')
            
            # 收入分布
            axes[1,0].hist(self.data['年收入'], bins=30, color='lightgreen', alpha=0.7)
            axes[1,0].set_title('年收入分布')
            axes[1,0].set_xlabel('年收入')
            axes[1,0].set_ylabel('频数')
            
            # 债务收入比分布
            axes[1,1].hist(self.data['债务收入比'], bins=20, color='lightcoral', alpha=0.7)
            axes[1,1].set_title('债务收入比分布')
            axes[1,1].set_xlabel('债务收入比')
            axes[1,1].set_ylabel('频数')
            
            plt.tight_layout()
            plt.show()
        except Exception as e:
            print(f"可视化显示遇到问题: {e}")
            print("继续进行数据分析...")
        
    def feature_engineering(self):
        """特征工程"""
        print("\n" + "="*50)
        print("⚙️ 特征工程")
        print("="*50)
        
        # 创建特征副本
        features_df = self.data.copy()
        
        # 1. 创建新特征
        features_df['收入年龄比'] = features_df['年收入'] / features_df['年龄']
        features_df['储蓄收入比'] = features_df['储蓄金额'] / features_df['年收入']
        features_df['平均年收入'] = features_df['年收入'] / features_df['工作年限'].replace(0, 1)
        features_df['风险指数'] = (features_df['逾期次数'] + features_df['债务收入比'] * 10) / 2
        
        # 2. 对类别变量进行编码
        categorical_cols = ['性别', '教育水平', '婚姻状况', '房产情况']
        
        for col in categorical_cols:
            le = LabelEncoder()
            features_df[f'{col}_编码'] = le.fit_transform(features_df[col])
        
        # 3. 对目标变量编码
        target_le = LabelEncoder()
        features_df['信用评级_编码'] = target_le.fit_transform(features_df['信用评级'])
        
        # 4. 选择最终特征
        feature_columns = [
            '年龄', '年收入', '工作年限', '历史贷款次数', '信用卡数量', 
            '债务收入比', '储蓄金额', '逾期次数', '银行关系年限',
            '收入年龄比', '储蓄收入比', '平均年收入', '风险指数',
            '性别_编码', '教育水平_编码', '婚姻状况_编码', '房产情况_编码'
        ]
        
        X = features_df[feature_columns]
        y = features_df['信用评级_编码']
        
        # 5. 划分训练集和测试集
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        
        # 6. 特征标准化
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        print(f"✅ 特征工程完成！")
        print(f"训练集大小: {self.X_train.shape}")
        print(f"测试集大小: {self.X_test.shape}")
        print(f"特征数量: {len(feature_columns)}")
        
        return target_le
        
    def train_models(self):
        """训练多个机器学习模型"""
        print("\n" + "="*50)
        print("🤖 模型训练与评估")
        print("="*50)
        
        # 定义模型（去掉SVM以加快速度）
        models = {
            '逻辑回归': LogisticRegression(random_state=42, max_iter=1000),
            '随机森林': RandomForestClassifier(n_estimators=100, random_state=42),
            '梯度提升': GradientBoostingClassifier(random_state=42)
        }
        
        self.models = {}
        self.results = {}
        
        for name, model in models.items():
            print(f"\n🔄 正在训练 {name} 模型...")
            
            # 训练模型
            model.fit(self.X_train, self.y_train)
            
            # 预测
            y_pred = model.predict(self.X_test)
            
            # 评估
            accuracy = accuracy_score(self.y_test, y_pred)
            
            # 交叉验证
            cv_scores = cross_val_score(model, self.X_train, self.y_train, cv=5)
            
            self.models[name] = model
            self.results[name] = {
                'accuracy': accuracy,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'y_pred': y_pred
            }
            
            print(f"✅ {name} - 准确率: {accuracy:.4f}, CV均值: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")
        
        return self.models, self.results
    
    def model_evaluation(self):
        """模型评估和可视化"""
        print("\n" + "="*50)
        print("📈 详细模型评估")
        print("="*50)
        
        # 结果对比
        results_df = pd.DataFrame({
            name: {
                '准确率': results['accuracy'],
                'CV均值': results['cv_mean'],
                'CV标准差': results['cv_std']
            }
            for name, results in self.results.items()
        }).T
        
        print("\n模型性能对比:")
        print(results_df.round(4))
        
        # 找出最佳模型
        best_model_name = max(self.results.keys(), 
                            key=lambda x: self.results[x]['accuracy'])
        best_pred = self.results[best_model_name]['y_pred']
        
        print(f"\n🏆 最佳模型: {best_model_name}")
        print(f"最佳准确率: {self.results[best_model_name]['accuracy']:.4f}")
        
        # 详细分类报告
        print(f"\n📋 {best_model_name} 详细分类报告:")
        target_names = ['差', '一般', '良好', '优秀']
        print(classification_report(self.y_test, best_pred, target_names=target_names))
        
        # 混淆矩阵
        cm = confusion_matrix(self.y_test, best_pred)
        print(f"\n📊 {best_model_name} 混淆矩阵:")
        print("预测\\真实  ", end="")
        for name in target_names:
            print(f"{name:>6}", end="")
        print()
        for i, true_label in enumerate(target_names):
            print(f"{true_label:<8}", end="")
            for j in range(len(target_names)):
                print(f"{cm[i][j]:>6}", end="")
            print()
        
        return best_model_name
        
    def feature_importance_analysis(self):
        """特征重要性分析（仅对随机森林）"""
        print("\n" + "="*50)
        print("🎯 特征重要性分析")
        print("="*50)
        
        if '随机森林' in self.models:
            rf_model = self.models['随机森林']
            feature_names = self.X_train.columns
            importance_scores = rf_model.feature_importances_
            
            # 创建特征重要性DataFrame
            feature_importance_df = pd.DataFrame({
                '特征': feature_names,
                '重要性': importance_scores
            }).sort_values('重要性', ascending=False)
            
            print("\n📈 特征重要性排序 (Top 10):")
            print(feature_importance_df.head(10).to_string(index=False))
            
            return feature_importance_df
        else:
            print("❌ 随机森林模型未找到，无法分析特征重要性")
            return None
    
    def predict_customer_credit(self, customer_data, customer_name="新客户"):
        """预测新客户的信用评级"""
        best_model_name = max(self.results.keys(), 
                            key=lambda x: self.results[x]['accuracy'])
        best_model = self.models[best_model_name]
        
        # 预测
        prediction = best_model.predict([customer_data])[0]
        probability = best_model.predict_proba([customer_data])[0]
        
        credit_labels = ['差', '一般', '良好', '优秀']
        predicted_label = credit_labels[prediction]
        
        print(f"\n🔮 {customer_name} 使用 {best_model_name} 模型预测结果:")
        print(f"📊 预测信用评级: {predicted_label}")
        print("📈 各等级概率:")
        for i, (label, prob) in enumerate(zip(credit_labels, probability)):
            print(f"  {label}: {prob:.1%}")
        
        return predicted_label, probability
    
    def run_complete_analysis(self):
        """运行完整的信用评分分析"""
        print("🚀 开始银行客户信用评分分析...")
        print("="*60)
        
        try:
            # 1. 生成数据
            self.generate_sample_data(1000)
            
            # 2. 数据探索
            self.data_exploration()
            
            # 3. 特征工程
            target_le = self.feature_engineering()
            
            # 4. 模型训练
            self.train_models()
            
            # 5. 模型评估
            best_model = self.model_evaluation()
            
            # 6. 特征重要性分析
            feature_importance = self.feature_importance_analysis()
            
            # 7. 示例预测
            print("\n" + "="*50)
            print("🎯 示例客户信用评级预测")
            print("="*50)
            
            # 创建几个示例客户
            test_customers = [
                {
                    'name': '高收入低风险客户',
                    'data': [45, 150000, 15, 1, 3, 0.2, 100000, 0, 10.0, 
                            150000/45, 100000/150000, 150000/15, (0+0.2*10)/2, 
                            1, 3, 1, 2]
                },
                {
                    'name': '年轻高风险客户', 
                    'data': [25, 40000, 2, 5, 1, 0.7, 5000, 3, 1.0,
                            40000/25, 5000/40000, 40000/2, (3+0.7*10)/2,
                            0, 1, 0, 0]
                },
                {
                    'name': '中等收入稳定客户',
                    'data': [35, 80000, 8, 2, 2, 0.3, 50000, 1, 5.0,
                            80000/35, 50000/80000, 80000/8, (1+0.3*10)/2,
                            1, 2, 1, 1]
                }
            ]
            
            for customer in test_customers:
                self.predict_customer_credit(customer['data'], customer['name'])
            
            # 8. 保存结果
            print("\n" + "="*50)
            print("💾 保存分析结果")
            print("="*50)
            
            self.data.to_csv('银行客户信用分析数据.csv', index=False, encoding='utf-8-sig')
            print("✅ 数据已保存到: 银行客户信用分析数据.csv")
            
            print("\n🎉 分析完成！主要发现：")
            print("="*50)
            print(f"1. 🏆 最佳模型: {best_model}")
            print(f"2. 📊 数据集包含 {len(self.data)} 个客户样本")
            print(f"3. 🎯 模型准确率: {self.results[best_model]['accuracy']:.1%}")
            if feature_importance is not None:
                print(f"4. 🔑 最重要特征: {feature_importance.iloc[0]['特征']}")
            
            return {
                'data': self.data,
                'models': self.models,
                'results': self.results,
                'best_model': best_model
            }
            
        except Exception as e:
            print(f"❌ 分析过程中出现错误: {e}")
            return None

def main():
    """主函数"""
    print("🏦 简化版银行客户信用评分分析系统")
    print("="*60)
    
    # 创建分析实例
    analysis = SimpleBankCreditAnalysis()
    
    # 运行完整分析
    results = analysis.run_complete_analysis()
    
    if results:
        print("\n✅ 系统运行成功！")
        print("📄 可以查看生成的CSV文件了解详细数据")
    else:
        print("\n❌ 系统运行出现问题")
    
    return analysis, results

if __name__ == "__main__":
    try:
        analyzer, analysis_results = main()
    except KeyboardInterrupt:
        print("\n\n👋 分析已终止")
    except Exception as e:
        print(f"❌ 运行出错: {e}")
