// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化所有功能
    initNavigation();
    initScrollEffects();
    initProgressBars();
    initTypingEffect();
    initChatDemo();
    initParallaxEffects();
    initMobileMenu();
    initSmoothScrolling();
    initDownloadFeatures();
    initAIStoreFeatures();
});

// 导航栏功能
function initNavigation() {
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // 滚动时改变导航栏样式
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = 'none';
        }
    });

    // 高亮当前页面部分
    window.addEventListener('scroll', () => {
        let current = '';
        const sections = document.querySelectorAll('section');
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (scrollY >= (sectionTop - 200)) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// 滚动效果
function initScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                
                // 为技能卡片添加延迟动画
                if (entry.target.classList.contains('skill-card')) {
                    const cards = document.querySelectorAll('.skill-card');
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, index * 150);
                    });
                }
            }
        });
    }, observerOptions);

    // 观察所有需要动画的元素
    const animatedElements = document.querySelectorAll('.skill-card, .project-card, .feature, .method');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        observer.observe(el);
    });
}

// 进度条动画
function initProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');
    
    const progressObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBar = entry.target;
                const progress = progressBar.getAttribute('data-progress');
                
                setTimeout(() => {
                    progressBar.style.width = progress + '%';
                }, 500);
            }
        });
    }, { threshold: 0.5 });

    progressBars.forEach(bar => {
        progressObserver.observe(bar);
    });
}

// 打字机效果
function initTypingEffect() {
    const heroTitle = document.querySelector('.hero-title');
    if (!heroTitle) return;

    const originalText = heroTitle.innerHTML;
    heroTitle.innerHTML = '';
    
    let currentText = '';
    let charIndex = 0;
    const text = '你好，我是 AI智能体';
    
    function typeWriter() {
        if (charIndex < text.length) {
            if (text.charAt(charIndex) === ' ') {
                currentText += ' ';
            } else if (charIndex >= 6 && charIndex <= 13) {
                // 为"AI智能体"添加高亮
                if (charIndex === 6) {
                    currentText += '<span class="highlight">';
                }
                currentText += text.charAt(charIndex);
                if (charIndex === 13) {
                    currentText += '</span>';
                }
            } else {
                currentText += text.charAt(charIndex);
            }
            
            heroTitle.innerHTML = currentText + '<span class="cursor">|</span>';
            charIndex++;
            setTimeout(typeWriter, 100);
        } else {
            // 移除光标并添加完整样式
            heroTitle.innerHTML = originalText;
            heroTitle.classList.add('typing-complete');
        }
    }

    // 延迟开始打字效果
    setTimeout(typeWriter, 1000);
}

// 聊天演示功能
function initChatDemo() {
    const chatInput = document.querySelector('.chat-input input');
    const chatButton = document.querySelector('.chat-input button');
    const chatMessages = document.querySelector('.chat-messages');
    
    if (!chatInput || !chatButton || !chatMessages) return;

    const aiResponses = [
        "很好的问题！我可以帮您编写各种类型的代码。",
        "当然！我精通多种编程语言，包括Python、JavaScript、HTML/CSS等。",
        "我可以帮您分析数据、创建图表、编写算法等各种任务。",
        "请告诉我您的具体需求，我会为您提供最佳的解决方案。",
        "我随时准备为您提供技术支持和代码帮助！"
    ];

    let responseIndex = 0;

    function addMessage(text, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
        
        const bubbleDiv = document.createElement('div');
        bubbleDiv.className = 'message-bubble';
        bubbleDiv.textContent = text;
        
        messageDiv.appendChild(bubbleDiv);
        chatMessages.appendChild(messageDiv);
        
        // 滚动到底部
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        // 添加出现动画
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            messageDiv.style.opacity = '1';
            messageDiv.style.transform = 'translateY(0)';
            messageDiv.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        }, 100);
    }

    function handleSendMessage() {
        const message = chatInput.value.trim();
        if (!message) return;

        // 添加用户消息
        addMessage(message, true);
        chatInput.value = '';

        // 模拟AI思考时间
        setTimeout(() => {
            const response = aiResponses[responseIndex % aiResponses.length];
            addMessage(response, false);
            responseIndex++;
        }, 1000 + Math.random() * 1000);
    }

    chatButton.addEventListener('click', handleSendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSendMessage();
        }
    });

    // 添加输入提示
    chatInput.addEventListener('focus', () => {
        chatInput.placeholder = '我在听，请说...';
    });

    chatInput.addEventListener('blur', () => {
        chatInput.placeholder = '输入您的问题...';
    });
}

// 视差效果
function initParallaxEffects() {
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.ai-avatar, .neural-network');
        
        parallaxElements.forEach(element => {
            const speed = 0.5;
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// 移动端菜单
function initMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    if (!hamburger || !navMenu) return;

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // 点击菜单项时关闭菜单
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // 点击外部区域关闭菜单
    document.addEventListener('click', (e) => {
        if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        }
    });
}

// 平滑滚动
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 70; // 导航栏高度
                
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// 鼠标跟随效果
function initMouseFollowEffect() {
    const cursor = document.createElement('div');
    cursor.className = 'custom-cursor';
    document.body.appendChild(cursor);

    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX + 'px';
        cursor.style.top = e.clientY + 'px';
    });

    // 悬停效果
    const interactiveElements = document.querySelectorAll('a, button, .skill-card, .project-card');
    
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.classList.add('cursor-hover');
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.classList.remove('cursor-hover');
        });
    });
}

// 粒子效果（可选）
function initParticleEffect() {
    const canvas = document.createElement('canvas');
    canvas.className = 'particle-canvas';
    document.querySelector('.hero').appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    const particles = [];
    const particleCount = 50;
    
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.vx = (Math.random() - 0.5) * 2;
            this.vy = (Math.random() - 0.5) * 2;
            this.size = Math.random() * 3 + 1;
            this.opacity = Math.random() * 0.5 + 0.3;
        }
        
        update() {
            this.x += this.vx;
            this.y += this.vy;
            
            if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
            if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
        }
        
        draw() {
            ctx.save();
            ctx.globalAlpha = this.opacity;
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }
    
    // 创建粒子
    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }
    
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(particle => {
            particle.update();
            particle.draw();
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
}

// 主题切换功能（可选）
function initThemeToggle() {
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    document.body.appendChild(themeToggle);

    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        const isDark = document.body.classList.contains('dark-theme');
        themeToggle.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        
        // 保存主题偏好
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });

    // 加载保存的主题
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
}

// 滚动进度条
function initScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    document.body.appendChild(progressBar);

    window.addEventListener('scroll', () => {
        const scrollTop = document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrollProgress = (scrollTop / scrollHeight) * 100;
        
        progressBar.style.width = scrollProgress + '%';
    });
}

// 性能优化 - 节流函数
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 防抖函数
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// 下载页面功能
function initDownloadFeatures() {
    initDownloadButtons();
    initDownloadStats();
    initPlatformCards();
}

// 下载按钮功能
function initDownloadButtons() {
    const downloadButtons = document.querySelectorAll('.download-btn');
    
    downloadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const platform = this.getAttribute('data-platform');
            const action = this.getAttribute('data-action');
            
            // 添加点击动画
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);

            if (platform) {
                handleDownload(platform);
            } else if (action) {
                handleAction(action);
            }
        });

        // 悬浮效果
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });

        button.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
}

// 处理下载
function handleDownload(platform) {
    const downloadUrls = {
        'windows': '#', // 这里替换为实际的下载链接
        'android': 'https://play.google.com/store', // Google Play链接
        'android-apk': '#', // APK直接下载链接
        'ios': 'https://apps.apple.com/', // App Store链接
    };

    // 统计下载次数
    updateDownloadCount(platform);
    
    // 显示下载提示
    showDownloadToast(platform);
    
    // 跳转到下载链接（实际使用时取消注释）
    // window.open(downloadUrls[platform], '_blank');
    
    console.log(`开始下载 ${platform} 版本`);
}

// 处理其他动作
function handleAction(action) {
    switch(action) {
        case 'view-changelog':
            showChangelog();
            break;
        case 'testflight':
            showTestFlight();
            break;
        default:
            console.log(`执行动作: ${action}`);
    }
}

// 显示更新日志
function showChangelog() {
    const changelogContent = `
        <h3>更新日志 v2.1.0</h3>
        <ul>
            <li>✨ 新增语音识别功能</li>
            <li>🚀 优化响应速度提升30%</li>
            <li>🎨 全新UI设计</li>
            <li>🐛 修复已知问题</li>
            <li>📱 改进移动端体验</li>
        </ul>
    `;
    
    showModal('更新日志', changelogContent);
}

// 显示TestFlight信息
function showTestFlight() {
    const testFlightContent = `
        <h3>TestFlight测试版</h3>
        <p>加入我们的TestFlight计划，体验最新功能：</p>
        <ul>
            <li>🔬 提前体验新功能</li>
            <li>💬 直接反馈问题</li>
            <li>🎁 测试者专属奖励</li>
        </ul>
        <p>请通过邮件联系我们获取邀请码。</p>
    `;
    
    showModal('TestFlight测试', testFlightContent);
}

// 显示模态框
function showModal(title, content) {
    // 创建模态框
    const modal = document.createElement('div');
    modal.className = 'download-modal';
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 显示动画
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
    
    // 关闭事件
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(modal);
        }, 300);
    });
    
    modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
        if (e.target === modal.querySelector('.modal-overlay')) {
            modal.querySelector('.modal-close').click();
        }
    });
}

// 显示下载提示
function showDownloadToast(platform) {
    const platformNames = {
        'windows': 'Windows版',
        'android': 'Android版',
        'android-apk': 'Android APK',
        'ios': 'iOS版'
    };
    
    const toast = document.createElement('div');
    toast.className = 'download-toast';
    toast.innerHTML = `
        <i class="fas fa-download"></i>
        <span>正在准备下载 ${platformNames[platform]}...</span>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// 更新下载统计
function updateDownloadCount(platform) {
    const countElement = document.querySelector('[data-count="50000"]');
    if (countElement) {
        let currentCount = parseInt(countElement.textContent.replace(/,/g, ''));
        currentCount += 1;
        
        // 数字动画
        animateNumber(countElement, currentCount);
    }
}

// 数字动画
function animateNumber(element, targetNumber) {
    const startNumber = parseInt(element.textContent.replace(/,/g, ''));
    const duration = 1000;
    const increment = (targetNumber - startNumber) / (duration / 16);
    let currentNumber = startNumber;
    
    const timer = setInterval(() => {
        currentNumber += increment;
        if (currentNumber >= targetNumber) {
            currentNumber = targetNumber;
            clearInterval(timer);
        }
        
        element.textContent = Math.floor(currentNumber).toLocaleString();
    }, 16);
}

// 下载统计动画
function initDownloadStats() {
    const statNumbers = document.querySelectorAll('.download .stat-number');
    
    const statsObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalNumber = target.getAttribute('data-count');
                
                if (finalNumber) {
                    animateStatNumber(target, finalNumber);
                    statsObserver.unobserve(target);
                }
            }
        });
    }, { threshold: 0.5 });

    statNumbers.forEach(stat => {
        stat.textContent = '0';
        statsObserver.observe(stat);
    });
}

// 统计数字动画
function animateStatNumber(element, target) {
    const isDecimal = target.includes('.');
    const targetNum = parseFloat(target);
    const duration = 2000;
    const increment = targetNum / (duration / 16);
    let current = 0;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= targetNum) {
            current = targetNum;
            clearInterval(timer);
        }
        
        if (isDecimal) {
            element.textContent = current.toFixed(1);
        } else {
            element.textContent = Math.floor(current).toLocaleString();
        }
    }, 16);
}

// 平台卡片交互
function initPlatformCards() {
    const platformCards = document.querySelectorAll('.platform-card');
    
    platformCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
}

// AI应用商店功能
function initAIStoreFeatures() {
    initStoreSearch();
    initStoreFilters();
    initStoreSorting();
    initAICards();
    initAIModals();
    initStoreStats();
}

// 智能体数据
const aiData = {
    'ai-assistant': {
        name: '智能助手Pro',
        type: 'assistant',
        category: 'assistant',
        description: '专业的个人助手，帮您管理日程、处理邮件、安排会议',
        price: '¥99/月',
        rating: 4.8,
        users: '2.5k用户',
        features: ['日程管理', '邮件处理', '智能提醒', '会议安排'],
        capabilities: ['智能对话', '任务管理', '提醒服务', '邮件处理'],
        avatar: 'fas fa-user-tie',
        avatarClass: '',
        responses: [
            '我可以帮您安排今天的会议，请告诉我具体时间。',
            '您的邮件已经整理完毕，有3封重要邮件需要回复。',
            '根据您的日程，建议在下午2点安排休息时间。'
        ]
    },
    'ai-writer': {
        name: '创作大师',
        type: 'creative',
        category: 'creative',
        description: '专业的内容创作工具，支持文章写作、广告文案、创意策划',
        price: '¥199/月',
        rating: 4.9,
        users: '1.8k用户',
        features: ['文章写作', '广告文案', '创意策划', '内容优化'],
        capabilities: ['智能写作', '文案生成', '创意策划', '内容优化'],
        avatar: 'fas fa-feather-alt',
        avatarClass: 'creative',
        responses: [
            '我可以为您创作各种类型的文章，请告诉我主题和风格要求。',
            '这是一个关于产品推广的广告文案草稿，您觉得如何？',
            '建议使用情感化的语言来增强文案的感染力。'
        ]
    },
    'ai-analyst': {
        name: '商务分析师',
        type: 'business',
        category: 'business',
        description: '专业的商务数据分析，提供市场洞察和商业建议',
        price: '¥299/月',
        rating: 4.7,
        users: '3.2k用户',
        features: ['数据分析', '市场洞察', '商业策略', '报告生成'],
        capabilities: ['数据处理', '趋势分析', '商业建议', '报告生成'],
        avatar: 'fas fa-chart-line',
        avatarClass: 'business',
        responses: [
            '根据市场数据分析，建议在Q4增加营销投入。',
            '您的销售数据显示上升趋势，建议扩大产品线。',
            '竞争对手分析报告已生成，请查看关键指标。'
        ]
    },
    'ai-tutor': {
        name: '智能导师',
        type: 'education',
        category: 'education',
        description: '个性化学习指导，支持多学科教学和学习进度跟踪',
        price: '¥149/月',
        rating: 4.6,
        users: '1.5k用户',
        features: ['个性化教学', '进度跟踪', '多学科支持', '学习分析'],
        capabilities: ['教学指导', '学习规划', '知识问答', '进度跟踪'],
        avatar: 'fas fa-graduation-cap',
        avatarClass: 'education',
        responses: [
            '根据您的学习进度，建议加强数学基础练习。',
            '这道题的解题思路是什么？我来为您详细讲解。',
            '您本周的学习目标已完成80%，继续加油！'
        ]
    },
    'ai-entertainer': {
        name: '娱乐伙伴',
        type: 'entertainment',
        category: 'entertainment',
        description: '趣味聊天机器人，支持游戏、音乐推荐、笑话分享',
        price: '免费',
        rating: 4.5,
        users: '5.1k用户',
        features: ['趣味聊天', '音乐推荐', '游戏娱乐', '笑话分享'],
        capabilities: ['娱乐聊天', '音乐推荐', '游戏互动', '幽默对话'],
        avatar: 'fas fa-music',
        avatarClass: 'entertainment',
        responses: [
            '今天心情怎么样？我来为您推荐一些好听的音乐吧！',
            '要不要来玩个猜谜游戏？我有很多有趣的谜题。',
            '哈哈，这个笑话您一定会喜欢的：为什么程序员喜欢黑暗？'
        ]
    },
    'ai-designer': {
        name: '设计师助手',
        type: 'creative',
        category: 'creative',
        description: '专业的设计助手，提供配色方案、布局建议、设计灵感',
        price: '¥159/月',
        rating: 4.8,
        users: '2.1k用户',
        features: ['配色方案', '布局设计', '设计灵感', '素材推荐'],
        capabilities: ['配色建议', '布局优化', '设计灵感', '风格指导'],
        avatar: 'fas fa-palette',
        avatarClass: 'creative',
        responses: [
            '这个配色方案很不错，建议使用蓝色作为主色调。',
            '您的布局可以采用黄金比例来优化视觉效果。',
            '推荐几个设计灵感网站，可以参考最新的设计趋势。'
        ]
    }
};

// 商店搜索功能
function initStoreSearch() {
    const searchInput = document.getElementById('aiSearch');
    if (!searchInput) return;

    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        filterAICards(searchTerm);
    });
}

// 筛选功能
function initStoreFilters() {
    const filterTabs = document.querySelectorAll('.filter-tab');
    
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // 移除其他active类
            filterTabs.forEach(t => t.classList.remove('active'));
            // 添加当前active类
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            filterByCategory(category);
        });
    });
}

// 排序功能
function initStoreSorting() {
    const sortSelect = document.getElementById('sortSelect');
    if (!sortSelect) return;

    sortSelect.addEventListener('change', function() {
        const sortType = this.value;
        sortAICards(sortType);
    });
}

// AI卡片交互
function initAICards() {
    const tryButtons = document.querySelectorAll('.btn-try');
    const buyButtons = document.querySelectorAll('.btn-buy');
    
    tryButtons.forEach(button => {
        button.addEventListener('click', function() {
            const aiId = this.getAttribute('data-ai');
            openExperienceModal(aiId);
        });
    });
    
    buyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const aiId = this.getAttribute('data-ai');
            openPurchaseModal(aiId);
        });
    });
}

// 模态框功能
function initAIModals() {
    const experienceModal = document.getElementById('aiExperienceModal');
    const purchaseModal = document.getElementById('aiPurchaseModal');
    
    // 关闭按钮
    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function() {
            closeAllModals();
        });
    });
    
    // 点击背景关闭
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', function(e) {
            if (e.target === this) {
                closeAllModals();
            }
        });
    });
    
    // 体验页面的聊天功能
    initExperienceChat();
    
    // 购买页面功能
    initPurchaseActions();
}

// 筛选AI卡片
function filterAICards(searchTerm = '', category = 'all') {
    const aiCards = document.querySelectorAll('.ai-card');
    
    aiCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        const cardText = card.textContent.toLowerCase();
        
        const matchesSearch = !searchTerm || cardText.includes(searchTerm);
        const matchesCategory = category === 'all' || cardCategory === category;
        
        if (matchesSearch && matchesCategory) {
            card.style.display = 'block';
            card.style.animation = 'fadeIn 0.5s ease-in-out';
        } else {
            card.style.display = 'none';
        }
    });
}

// 按分类筛选
function filterByCategory(category) {
    filterAICards('', category);
}

// 排序AI卡片
function sortAICards(sortType) {
    const aiGrid = document.getElementById('aiGrid');
    const cards = Array.from(aiGrid.querySelectorAll('.ai-card'));
    
    cards.sort((a, b) => {
        switch(sortType) {
            case 'rating':
                const ratingA = parseFloat(a.querySelector('.rating span').textContent);
                const ratingB = parseFloat(b.querySelector('.rating span').textContent);
                return ratingB - ratingA;
                
            case 'price-low':
                const priceA = extractPrice(a.querySelector('.price').textContent);
                const priceB = extractPrice(b.querySelector('.price').textContent);
                return priceA - priceB;
                
            case 'price-high':
                const priceA2 = extractPrice(a.querySelector('.price').textContent);
                const priceB2 = extractPrice(b.querySelector('.price').textContent);
                return priceB2 - priceA2;
                
            default: // popular, newest
                return 0;
        }
    });
    
    // 重新排列卡片
    cards.forEach(card => aiGrid.appendChild(card));
}

// 提取价格数字
function extractPrice(priceText) {
    if (priceText.includes('免费')) return 0;
    const match = priceText.match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}

// 打开体验模态框
function openExperienceModal(aiId) {
    const modal = document.getElementById('aiExperienceModal');
    const ai = aiData[aiId];
    
    if (!ai) return;
    
    // 更新模态框内容
    document.getElementById('experienceTitle').textContent = `体验 ${ai.name}`;
    document.getElementById('experienceAiName').textContent = ai.name;
    document.getElementById('experienceAiType').textContent = ai.type;
    
    // 更新头像
    const avatar = document.getElementById('experienceAvatar');
    avatar.innerHTML = `<i class="${ai.avatar}"></i>`;
    avatar.className = `ai-info-avatar ${ai.avatarClass}`;
    
    // 更新能力列表
    const capabilitiesList = document.getElementById('experienceCapabilities');
    capabilitiesList.innerHTML = ai.capabilities.map(cap => `<li>${cap}</li>`).join('');
    
    // 清空聊天记录
    const messagesContainer = document.getElementById('experienceMessages');
    messagesContainer.innerHTML = `
        <div class="message ai-message">
            <div class="message-bubble">
                您好！我是${ai.name}，请问有什么可以帮助您的吗？
            </div>
        </div>
    `;
    
    // 显示模态框
    modal.classList.add('show');
    
    // 设置当前AI
    window.currentExperienceAI = aiId;
}

// 打开购买模态框
function openPurchaseModal(aiId) {
    const modal = document.getElementById('aiPurchaseModal');
    const ai = aiData[aiId];
    
    if (!ai) return;
    
    // 更新模态框内容
    document.getElementById('purchaseTitle').textContent = ai.name;
    document.getElementById('purchaseAiName').textContent = ai.name;
    document.getElementById('purchaseAiDescription').textContent = ai.description;
    document.getElementById('purchaseRating').textContent = ai.rating;
    document.getElementById('purchaseUsers').textContent = `(${ai.users})`;
    
    // 更新头像
    const avatar = document.getElementById('purchaseAvatar');
    avatar.innerHTML = `<i class="${ai.avatar}"></i>`;
    avatar.className = `ai-showcase-avatar ${ai.avatarClass}`;
    
    // 更新功能特色
    const featuresGrid = document.getElementById('purchaseFeatures');
    featuresGrid.innerHTML = ai.features.map(feature => `
        <div class="feature-item">
            <i class="fas fa-check-circle"></i>
            <span>${feature}</span>
        </div>
    `).join('');
    
    // 更新价格
    const priceText = ai.price;
    if (priceText.includes('免费')) {
        document.getElementById('purchasePrice').textContent = '免费';
        document.getElementById('purchasePeriod').textContent = '';
        document.getElementById('purchasePlan').textContent = '基础版';
    } else {
        const price = priceText.split('/')[0];
        const period = '/' + priceText.split('/')[1];
        document.getElementById('purchasePrice').textContent = price;
        document.getElementById('purchasePeriod').textContent = period;
        document.getElementById('purchasePlan').textContent = '专业版';
    }
    
    // 显示模态框
    modal.classList.add('show');
    
    // 设置当前AI
    window.currentPurchaseAI = aiId;
}

// 关闭所有模态框
function closeAllModals() {
    document.querySelectorAll('.ai-modal').forEach(modal => {
        modal.classList.remove('show');
    });
}

// 体验聊天功能
function initExperienceChat() {
    const input = document.getElementById('experienceInput');
    const sendBtn = document.getElementById('experienceSend');
    const messagesContainer = document.getElementById('experienceMessages');
    
    function sendMessage() {
        const message = input.value.trim();
        if (!message) return;
        
        // 添加用户消息
        addExperienceMessage(message, true);
        input.value = '';
        
        // 模拟AI回复
        setTimeout(() => {
            const aiId = window.currentExperienceAI;
            const ai = aiData[aiId];
            const responses = ai?.responses || ['我明白了，请告诉我更多详情。'];
            const response = responses[Math.floor(Math.random() * responses.length)];
            addExperienceMessage(response, false);
        }, 1000);
    }
    
    sendBtn.addEventListener('click', sendMessage);
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

// 添加体验消息
function addExperienceMessage(text, isUser) {
    const messagesContainer = document.getElementById('experienceMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
    messageDiv.innerHTML = `<div class="message-bubble">${text}</div>`;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// 购买功能
function initPurchaseActions() {
    const purchaseBtn = document.getElementById('purchaseNowBtn');
    const tryBtn = document.getElementById('tryFirstBtn');
    const planOptions = document.querySelectorAll('.plan-option');
    
    purchaseBtn.addEventListener('click', function() {
        const aiId = window.currentPurchaseAI;
        handlePurchase(aiId);
    });
    
    tryBtn.addEventListener('click', function() {
        const aiId = window.currentPurchaseAI;
        closeAllModals();
        setTimeout(() => openExperienceModal(aiId), 300);
    });
    
    planOptions.forEach(option => {
        option.addEventListener('click', function() {
            planOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            const radio = this.querySelector('input[type="radio"]');
            radio.checked = true;
            
            updatePricing(this.getAttribute('data-plan'));
        });
    });
}

// 更新定价
function updatePricing(plan) {
    const priceAmount = document.getElementById('purchasePrice');
    const pricePeriod = document.getElementById('purchasePeriod');
    
    if (plan === 'yearly') {
        const monthlyPrice = parseInt(priceAmount.textContent.replace('¥', ''));
        const yearlyPrice = monthlyPrice * 10; // 年付优惠
        priceAmount.textContent = `¥${yearlyPrice}`;
        pricePeriod.textContent = '/年';
    } else {
        const aiId = window.currentPurchaseAI;
        const ai = aiData[aiId];
        const originalPrice = ai.price.split('/')[0];
        priceAmount.textContent = originalPrice;
        pricePeriod.textContent = '/月';
    }
}

// 处理购买
function handlePurchase(aiId) {
    const ai = aiData[aiId];
    
    // 显示购买成功提示
    showPurchaseToast(`成功购买 ${ai.name}！`);
    
    // 关闭模态框
    closeAllModals();
    
    console.log(`购买 ${ai.name}`);
}

// 显示购买成功提示
function showPurchaseToast(message) {
    const toast = document.createElement('div');
    toast.className = 'purchase-toast';
    toast.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// 商店统计动画
function initStoreStats() {
    const statNumbers = document.querySelectorAll('.ai-store .stat-number');
    
    const statsObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalNumber = target.getAttribute('data-count');
                
                if (finalNumber) {
                    animateStatNumber(target, finalNumber);
                    statsObserver.unobserve(target);
                }
            }
        });
    }, { threshold: 0.5 });

    statNumbers.forEach(stat => {
        stat.textContent = '0';
        statsObserver.observe(stat);
    });
}

// 懒加载图片（如果需要）
function initLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// 错误处理
window.addEventListener('error', (e) => {
    console.error('页面错误:', e.error);
});

// 页面加载完成提示
window.addEventListener('load', () => {
    console.log('AI智能体主页加载完成！');
    
    // 添加加载完成的动画效果
    document.body.classList.add('loaded');
    
    // 可选：显示欢迎提示
    setTimeout(() => {
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification('AI智能体', {
                body: '欢迎访问我的个人主页！',
                icon: '/favicon.ico'
            });
        }
    }, 2000);
});

// CSS动画类
const style = document.createElement('style');
style.textContent = `
    .particle-canvas {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
    }
    
    .custom-cursor {
        position: fixed;
        width: 20px;
        height: 20px;
        background: rgba(59, 130, 246, 0.5);
        border-radius: 50%;
        pointer-events: none;
        mix-blend-mode: difference;
        z-index: 9999;
        transition: transform 0.1s ease;
    }
    
    .cursor-hover {
        transform: scale(2);
    }
    
    .theme-toggle {
        position: fixed;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        cursor: pointer;
        box-shadow: var(--shadow-lg);
        z-index: 1000;
        transition: all 0.3s ease;
    }
    
    .theme-toggle:hover {
        transform: translateY(-50%) scale(1.1);
    }
    
    .scroll-progress {
        position: fixed;
        top: 0;
        left: 0;
        height: 3px;
        background: var(--gradient-ai);
        z-index: 1001;
        transition: width 0.1s ease;
    }
    
    .typing-complete {
        animation: glow 2s ease-in-out infinite alternate;
    }
    
    @keyframes glow {
        from {
            text-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }
        to {
            text-shadow: 0 0 20px rgba(59, 130, 246, 0.8);
        }
    }
    
    .nav-link.active {
        color: var(--primary-color);
    }
    
    .nav-link.active::after {
        width: 100%;
    }
    
    body.loaded {
        animation: pageLoad 1s ease-out;
    }
    
    @keyframes pageLoad {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
    
    .dark-theme {
        --bg-primary: #0f172a;
        --bg-secondary: #1e293b;
        --text-primary: #f8fafc;
        --text-secondary: #cbd5e1;
        --border-color: #334155;
    }
    
    @media (max-width: 768px) {
        .hamburger.active .bar:nth-child(2) {
            opacity: 0;
        }
        
        .hamburger.active .bar:nth-child(1) {
            transform: translateY(8px) rotate(45deg);
        }
        
        .hamburger.active .bar:nth-child(3) {
            transform: translateY(-8px) rotate(-45deg);
        }
    }
`;

document.head.appendChild(style);
