#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
银行信用评分分析演示脚本
Demo script for Bank Credit Analysis
"""

from bank_credit_analysis import BankCreditAnalysis
import pandas as pd

def demo_analysis():
    """演示银行信用分析的主要功能"""
    print("🏦 银行客户信用评分分析系统演示")
    print("="*60)
    
    # 创建分析器实例
    analyzer = BankCreditAnalysis()
    
    # 1. 生成样本数据
    print("\n📊 第一步：生成银行客户样本数据")
    data = analyzer.generate_sample_data(n_samples=1500)
    print(f"✅ 成功生成 {len(data)} 条客户记录")
    
    # 显示前几条数据
    print("\n数据样本预览:")
    print(data.head())
    
    # 2. 数据探索
    print("\n🔍 第二步：数据探索分析")
    analyzer.data_exploration()
    
    # 3. 相关性分析
    print("\n📈 第三步：特征相关性分析")
    analyzer.correlation_analysis()
    
    # 4. 特征工程
    print("\n⚙️ 第四步：特征工程")
    target_le, le_dict = analyzer.feature_engineering()
    
    # 5. 模型训练和评估
    print("\n🤖 第五步：机器学习模型训练")
    models, results = analyzer.train_models()
    
    # 6. 模型评估
    print("\n📋 第六步：模型性能评估")
    analyzer.model_evaluation()
    
    # 7. 特征重要性分析
    print("\n🎯 第七步：特征重要性分析")
    feature_importance = analyzer.feature_importance_analysis()
    
    # 8. 新客户预测示例
    print("\n🔮 第八步：新客户信用评级预测示例")
    
    # 定义几个不同类型的客户进行预测
    test_customers = [
        {
            'name': '高收入低风险客户',
            'data': [45, 150000, 15, 1, 3, 0.2, 100000, 0, 10.0, 
                    150000/45, 100000/150000, 150000/15, (0+0.2*10)/2, 
                    1, 3, 1, 2]
        },
        {
            'name': '年轻高风险客户', 
            'data': [25, 40000, 2, 5, 1, 0.7, 5000, 3, 1.0,
                    40000/25, 5000/40000, 40000/2, (3+0.7*10)/2,
                    0, 1, 0, 0]
        },
        {
            'name': '中等收入稳定客户',
            'data': [35, 80000, 8, 2, 2, 0.3, 50000, 1, 5.0,
                    80000/35, 50000/80000, 80000/8, (1+0.3*10)/2,
                    1, 2, 1, 1]
        }
    ]
    
    for customer in test_customers:
        print(f"\n--- {customer['name']} ---")
        predicted_credit, probabilities = analyzer.predict_customer_credit(customer['data'])
    
    # 9. 保存结果
    print("\n💾 第九步：保存分析结果")
    analyzer.data.to_csv('bank_customer_analysis_data.csv', index=False, encoding='utf-8-sig')
    
    # 保存模型性能报告
    results_summary = pd.DataFrame({
        name: {
            '准确率': results['accuracy'],
            'AUC分数': results['auc_score'], 
            'CV均值': results['cv_mean'],
            'CV标准差': results['cv_std']
        }
        for name, results in analyzer.results.items()
    }).T
    
    results_summary.to_csv('model_performance_report.csv', encoding='utf-8-sig')
    
    print("✅ 分析完成！文件已保存：")
    print("  - bank_customer_analysis_data.csv: 客户数据")
    print("  - model_performance_report.csv: 模型性能报告")
    
    # 返回分析器以供进一步使用
    return analyzer

def interactive_prediction():
    """交互式信用评级预测"""
    print("\n" + "="*60)
    print("🎯 交互式信用评级预测")
    print("="*60)
    
    # 首先运行基础分析（如果还没有运行）
    analyzer = BankCreditAnalysis()
    print("正在初始化模型...")
    analyzer.generate_sample_data(1000)
    analyzer.feature_engineering()
    analyzer.train_models()
    
    print("\n✅ 模型已准备就绪！")
    print("\n请输入客户信息进行信用评级预测：")
    
    try:
        # 收集用户输入
        age = int(input("年龄: "))
        income = int(input("年收入 (元): "))
        work_years = int(input("工作年限 (年): "))
        loan_history = int(input("历史贷款次数: "))
        credit_cards = int(input("信用卡数量: "))
        debt_ratio = float(input("债务收入比 (0-1): "))
        savings = int(input("储蓄金额 (元): "))
        overdue = int(input("逾期次数: "))
        bank_years = float(input("银行关系年限 (年): "))
        
        print("\n请选择以下选项：")
        print("性别: 0-女, 1-男")
        gender = int(input("性别: "))
        
        print("教育水平: 0-高中, 1-大专, 2-本科, 3-硕士, 4-博士")
        education = int(input("教育水平: "))
        
        print("婚姻状况: 0-未婚, 1-已婚, 2-离异") 
        marital = int(input("婚姻状况: "))
        
        print("房产情况: 0-无房, 1-有房贷, 2-全款房")
        house = int(input("房产情况: "))
        
        # 计算衍生特征
        income_age_ratio = income / age
        savings_income_ratio = savings / income if income > 0 else 0
        avg_income = income / work_years if work_years > 0 else income
        risk_index = (overdue + debt_ratio * 10) / 2
        
        # 构建特征向量
        customer_features = [
            age, income, work_years, loan_history, credit_cards,
            debt_ratio, savings, overdue, bank_years,
            income_age_ratio, savings_income_ratio, avg_income, risk_index,
            gender, education, marital, house
        ]
        
        # 进行预测
        predicted_credit, probabilities = analyzer.predict_customer_credit(customer_features)
        
        print(f"\n🎯 预测结果: {predicted_credit}")
        print("📊 详细概率分布:")
        credit_labels = ['差', '一般', '良好', '优秀']
        for label, prob in zip(credit_labels, probabilities):
            print(f"  {label}: {prob:.1%}")
            
    except ValueError:
        print("❌ 输入格式错误，请确保输入正确的数字格式。")
    except Exception as e:
        print(f"❌ 发生错误: {e}")

if __name__ == "__main__":
    print("选择运行模式:")
    print("1. 完整演示分析")
    print("2. 交互式预测")
    
    try:
        choice = input("请选择 (1 或 2): ")
        
        if choice == "1":
            analyzer = demo_analysis()
        elif choice == "2":
            interactive_prediction()
        else:
            print("运行完整演示...")
            analyzer = demo_analysis()
            
    except KeyboardInterrupt:
        print("\n\n👋 分析已终止")
    except Exception as e:
        print(f"❌ 运行出错: {e}")
        print("正在运行完整演示...")
        analyzer = demo_analysis()
