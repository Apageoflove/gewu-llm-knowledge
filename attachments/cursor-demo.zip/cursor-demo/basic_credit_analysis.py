#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基础版银行客户信用评分分析系统
Basic Bank Customer Credit Scoring Analysis
仅使用pandas和numpy等基础库，不依赖机器学习库
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class BasicBankCreditAnalysis:
    def __init__(self):
        self.data = None
        
    def generate_sample_data(self, n_samples=1000):
        """生成模拟银行客户数据"""
        print("🏦 正在生成银行客户样本数据...")
        
        np.random.seed(42)
        
        # 基础信息
        age = np.random.normal(40, 12, n_samples).astype(int)
        age = np.clip(age, 18, 80)
        
        gender = np.random.choice(['男', '女'], n_samples)
        
        # 收入相关
        income = np.random.lognormal(10.5, 0.8, n_samples)
        income = np.clip(income, 20000, 500000).astype(int)
        
        # 工作年限
        work_years = np.random.exponential(8, n_samples)
        work_years = np.clip(work_years, 0, 40).astype(int)
        
        # 教育水平
        education = np.random.choice(['高中', '大专', '本科', '硕士', '博士'], 
                                   n_samples, p=[0.2, 0.25, 0.35, 0.15, 0.05])
        
        # 婚姻状况
        marital_status = np.random.choice(['未婚', '已婚', '离异'], 
                                        n_samples, p=[0.3, 0.6, 0.1])
        
        # 房产情况
        house_ownership = np.random.choice(['无房', '有房贷', '全款房'], 
                                         n_samples, p=[0.3, 0.5, 0.2])
        
        # 历史贷款次数
        loan_history = np.random.poisson(2, n_samples)
        loan_history = np.clip(loan_history, 0, 10)
        
        # 信用卡数量
        credit_cards = np.random.poisson(1.5, n_samples)
        credit_cards = np.clip(credit_cards, 0, 8)
        
        # 债务收入比
        debt_to_income = np.random.beta(2, 5, n_samples) * 0.8
        
        # 储蓄金额
        savings = income * np.random.uniform(0.1, 2.0, n_samples)
        savings = savings.astype(int)
        
        # 逾期次数
        overdue_times = np.random.poisson(0.5, n_samples)
        overdue_times = np.clip(overdue_times, 0, 10)
        
        # 银行关系年限
        bank_relation_years = np.random.exponential(5, n_samples)
        bank_relation_years = np.clip(bank_relation_years, 0.5, 25)
        
        # 创建DataFrame
        self.data = pd.DataFrame({
            '年龄': age,
            '性别': gender,
            '年收入': income,
            '工作年限': work_years,
            '教育水平': education,
            '婚姻状况': marital_status,
            '房产情况': house_ownership,
            '历史贷款次数': loan_history,
            '信用卡数量': credit_cards,
            '债务收入比': debt_to_income.round(3),
            '储蓄金额': savings,
            '逾期次数': overdue_times,
            '银行关系年限': bank_relation_years.round(1)
        })
        
        print(f"✅ 成功生成 {n_samples} 条银行客户数据")
        return self.data
    
    def calculate_credit_score(self):
        """基于规则的信用评分计算"""
        print("\n⚙️ 正在计算信用评分...")
        
        # 初始化评分为50分
        scores = np.full(len(self.data), 50.0)
        
        # 年龄评分 (25-65岁为最佳)
        age_score = np.where((self.data['年龄'] >= 25) & (self.data['年龄'] <= 65), 10, 
                           np.where((self.data['年龄'] >= 18) & (self.data['年龄'] <= 80), 5, 0))
        scores += age_score
        
        # 收入评分 (收入越高分数越高)
        income_percentiles = np.percentile(self.data['年收入'], [25, 50, 75, 90])
        income_score = np.where(self.data['年收入'] >= income_percentiles[3], 20,
                              np.where(self.data['年收入'] >= income_percentiles[2], 15,
                                     np.where(self.data['年收入'] >= income_percentiles[1], 10,
                                            np.where(self.data['年收入'] >= income_percentiles[0], 5, 0))))
        scores += income_score
        
        # 工作年限评分
        work_score = np.where(self.data['工作年限'] >= 10, 15,
                            np.where(self.data['工作年限'] >= 5, 10,
                                   np.where(self.data['工作年限'] >= 2, 5, 0)))
        scores += work_score
        
        # 教育水平评分
        education_map = {'博士': 15, '硕士': 12, '本科': 10, '大专': 7, '高中': 5}
        education_score = self.data['教育水平'].map(education_map)
        scores += education_score
        
        # 房产情况评分
        house_map = {'全款房': 15, '有房贷': 10, '无房': 0}
        house_score = self.data['房产情况'].map(house_map)
        scores += house_score
        
        # 债务收入比扣分 (比例越高扣分越多)
        debt_penalty = self.data['债务收入比'] * 30
        scores -= debt_penalty
        
        # 逾期次数扣分
        overdue_penalty = self.data['逾期次数'] * 10
        scores -= overdue_penalty
        
        # 银行关系年限加分
        relation_score = np.where(self.data['银行关系年限'] >= 10, 10,
                                np.where(self.data['银行关系年限'] >= 5, 7,
                                       np.where(self.data['银行关系年限'] >= 2, 5, 2)))
        scores += relation_score
        
        # 储蓄收入比加分
        savings_ratio = self.data['储蓄金额'] / self.data['年收入']
        savings_score = np.where(savings_ratio >= 1.0, 10,
                               np.where(savings_ratio >= 0.5, 7,
                                      np.where(savings_ratio >= 0.2, 5, 2)))
        scores += savings_score
        
        # 限制评分范围在0-100之间
        scores = np.clip(scores, 0, 100)
        
        # 根据评分划分信用等级
        credit_rating = np.where(scores >= 80, '优秀',
                               np.where(scores >= 65, '良好',
                                      np.where(scores >= 50, '一般', '差')))
        
        self.data['信用评分'] = scores.round(1)
        self.data['信用评级'] = credit_rating
        
        print("✅ 信用评分计算完成！")
        return self.data
    
    def data_exploration(self):
        """数据探索性分析"""
        print("\n" + "="*50)
        print("📊 数据探索性分析")
        print("="*50)
        
        # 基本信息
        print("\n1. 数据基本信息:")
        print(f"数据维度: {self.data.shape}")
        print(f"缺失值: {self.data.isnull().sum().sum()}")
        
        print("\n2. 数值特征统计:")
        numeric_cols = ['年龄', '年收入', '工作年限', '债务收入比', '储蓄金额', '逾期次数', '银行关系年限', '信用评分']
        print(self.data[numeric_cols].describe().round(2))
        
        print("\n3. 信用评级分布:")
        credit_counts = self.data['信用评级'].value_counts()
        print(credit_counts)
        print("\n信用评级比例:")
        credit_proportions = credit_counts / len(self.data)
        for rating, count in credit_counts.items():
            proportion = credit_proportions[rating]
            print(f"  {rating}: {count}人 ({proportion:.1%})")
        
        print("\n4. 各评级平均信用评分:")
        avg_scores = self.data.groupby('信用评级')['信用评分'].mean().sort_values(ascending=False)
        for rating, score in avg_scores.items():
            print(f"  {rating}: {score:.1f}分")
        
        # 可视化
        try:
            fig, axes = plt.subplots(2, 3, figsize=(15, 10))
            
            # 信用评级分布
            credit_counts.plot(kind='bar', ax=axes[0,0], 
                             color=['red', 'orange', 'lightblue', 'green'])
            axes[0,0].set_title('信用评级分布')
            axes[0,0].set_xlabel('信用评级')
            axes[0,0].set_ylabel('客户数量')
            axes[0,0].tick_params(axis='x', rotation=45)
            
            # 信用评分分布
            axes[0,1].hist(self.data['信用评分'], bins=20, color='skyblue', alpha=0.7)
            axes[0,1].set_title('信用评分分布')
            axes[0,1].set_xlabel('信用评分')
            axes[0,1].set_ylabel('频数')
            
            # 年龄分布
            axes[0,2].hist(self.data['年龄'], bins=20, color='lightgreen', alpha=0.7)
            axes[0,2].set_title('年龄分布')
            axes[0,2].set_xlabel('年龄')
            axes[0,2].set_ylabel('频数')
            
            # 收入分布
            axes[1,0].hist(self.data['年收入'], bins=30, color='lightcoral', alpha=0.7)
            axes[1,0].set_title('年收入分布')
            axes[1,0].set_xlabel('年收入')
            axes[1,0].set_ylabel('频数')
            
            # 债务收入比分布
            axes[1,1].hist(self.data['债务收入比'], bins=20, color='gold', alpha=0.7)
            axes[1,1].set_title('债务收入比分布')
            axes[1,1].set_xlabel('债务收入比')
            axes[1,1].set_ylabel('频数')
            
            # 各评级的收入分布箱线图
            ratings = ['差', '一般', '良好', '优秀']
            income_by_rating = [self.data[self.data['信用评级'] == rating]['年收入'] 
                              for rating in ratings if rating in self.data['信用评级'].values]
            if income_by_rating:
                axes[1,2].boxplot(income_by_rating, labels=[r for r in ratings if r in self.data['信用评级'].values])
                axes[1,2].set_title('各信用评级的收入分布')
                axes[1,2].set_xlabel('信用评级')
                axes[1,2].set_ylabel('年收入')
            
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            print(f"可视化显示遇到问题: {e}")
            print("继续进行分析...")
    
    def correlation_analysis(self):
        """相关性分析"""
        print("\n" + "="*50)
        print("📈 相关性分析")
        print("="*50)
        
        # 数值特征相关性
        numeric_cols = ['年龄', '年收入', '工作年限', '债务收入比', '储蓄金额', '逾期次数', '银行关系年限', '信用评分']
        correlation_matrix = self.data[numeric_cols].corr()
        
        print("\n与信用评分相关性最高的特征:")
        score_correlations = correlation_matrix['信用评分'].abs().sort_values(ascending=False)[1:]  # 除了自己
        for feature, corr in score_correlations.head(8).items():
            direction = "正相关" if correlation_matrix.loc[feature, '信用评分'] > 0 else "负相关"
            print(f"  {feature}: {corr:.3f} ({direction})")
        
        # 类别特征分析
        print("\n📊 类别特征分析:")
        categorical_features = ['性别', '教育水平', '婚姻状况', '房产情况']
        
        for feature in categorical_features:
            print(f"\n{feature} vs 信用评级:")
            crosstab = pd.crosstab(self.data[feature], self.data['信用评级'], margins=True)
            print(crosstab)
            
            # 计算各类别的平均信用评分
            avg_scores = self.data.groupby(feature)['信用评分'].mean().sort_values(ascending=False)
            print(f"\n{feature}各类别平均信用评分:")
            for category, score in avg_scores.items():
                print(f"  {category}: {score:.1f}分")
    
    def risk_analysis(self):
        """风险分析"""
        print("\n" + "="*50)
        print("⚠️ 风险分析")
        print("="*50)
        
        # 高风险客户识别
        high_risk = self.data[self.data['信用评级'] == '差']
        print(f"\n🔴 高风险客户数量: {len(high_risk)} ({len(high_risk)/len(self.data):.1%})")
        
        if len(high_risk) > 0:
            print("\n高风险客户特征分析:")
            print(f"  平均年龄: {high_risk['年龄'].mean():.1f}岁")
            print(f"  平均年收入: {high_risk['年收入'].mean():,.0f}元")
            print(f"  平均债务收入比: {high_risk['债务收入比'].mean():.3f}")
            print(f"  平均逾期次数: {high_risk['逾期次数'].mean():.1f}次")
            print(f"  平均信用评分: {high_risk['信用评分'].mean():.1f}分")
        
        # 优质客户识别
        excellent = self.data[self.data['信用评级'] == '优秀']
        print(f"\n🟢 优质客户数量: {len(excellent)} ({len(excellent)/len(self.data):.1%})")
        
        if len(excellent) > 0:
            print("\n优质客户特征分析:")
            print(f"  平均年龄: {excellent['年龄'].mean():.1f}岁")
            print(f"  平均年收入: {excellent['年收入'].mean():,.0f}元")
            print(f"  平均债务收入比: {excellent['债务收入比'].mean():.3f}")
            print(f"  平均逾期次数: {excellent['逾期次数'].mean():.1f}次")
            print(f"  平均信用评分: {excellent['信用评分'].mean():.1f}分")
        
        # 风险提示
        print("\n📋 风险管理建议:")
        if len(high_risk) > 0:
            print("1. 对'差'等级客户应谨慎放贷，提高利率或要求担保")
            print("2. 重点关注债务收入比>0.5和有逾期记录的客户")
        if len(excellent) > 0:
            print("3. 对'优秀'等级客户可提供优惠利率和增值服务")
            print("4. 优质客户可作为交叉销售的重点对象")
    
    def predict_single_customer(self, customer_info):
        """预测单个客户的信用评级"""
        print(f"\n🔮 客户信用评级预测")
        print("="*30)
        
        # 按照相同逻辑计算评分
        score = 50.0  # 基础分
        
        # 年龄评分
        age = customer_info['年龄']
        if 25 <= age <= 65:
            score += 10
        elif 18 <= age <= 80:
            score += 5
        
        # 收入评分 (根据数据集的收入分位数)
        income = customer_info['年收入']
        income_percentiles = np.percentile(self.data['年收入'], [25, 50, 75, 90])
        if income >= income_percentiles[3]:
            score += 20
        elif income >= income_percentiles[2]:
            score += 15
        elif income >= income_percentiles[1]:
            score += 10
        elif income >= income_percentiles[0]:
            score += 5
        
        # 工作年限评分
        work_years = customer_info['工作年限']
        if work_years >= 10:
            score += 15
        elif work_years >= 5:
            score += 10
        elif work_years >= 2:
            score += 5
        
        # 教育水平评分
        education_map = {'博士': 15, '硕士': 12, '本科': 10, '大专': 7, '高中': 5}
        score += education_map.get(customer_info['教育水平'], 0)
        
        # 房产情况评分
        house_map = {'全款房': 15, '有房贷': 10, '无房': 0}
        score += house_map.get(customer_info['房产情况'], 0)
        
        # 债务收入比扣分
        score -= customer_info['债务收入比'] * 30
        
        # 逾期次数扣分
        score -= customer_info['逾期次数'] * 10
        
        # 银行关系年限加分
        relation_years = customer_info['银行关系年限']
        if relation_years >= 10:
            score += 10
        elif relation_years >= 5:
            score += 7
        elif relation_years >= 2:
            score += 5
        else:
            score += 2
        
        # 储蓄收入比加分
        savings_ratio = customer_info['储蓄金额'] / customer_info['年收入']
        if savings_ratio >= 1.0:
            score += 10
        elif savings_ratio >= 0.5:
            score += 7
        elif savings_ratio >= 0.2:
            score += 5
        else:
            score += 2
        
        # 限制评分范围
        score = max(0, min(100, score))
        
        # 确定信用等级
        if score >= 80:
            rating = '优秀'
        elif score >= 65:
            rating = '良好'
        elif score >= 50:
            rating = '一般'
        else:
            rating = '差'
        
        print(f"📊 预测信用评分: {score:.1f}分")
        print(f"🎯 预测信用评级: {rating}")
        
        # 给出具体建议
        if rating == '优秀':
            print("💼 建议: 可提供优惠利率，推荐高端金融产品")
        elif rating == '良好':
            print("💼 建议: 正常放贷，可适当降低利率")
        elif rating == '一般':
            print("💼 建议: 谨慎放贷，标准利率")
        else:
            print("💼 建议: 高风险客户，建议拒绝或要求担保")
        
        return score, rating
    
    def run_complete_analysis(self):
        """运行完整的信用评分分析"""
        print("🚀 开始银行客户信用评分分析...")
        print("="*60)
        
        try:
            # 1. 生成数据
            self.generate_sample_data(1200)
            
            # 2. 计算信用评分
            self.calculate_credit_score()
            
            # 3. 数据探索
            self.data_exploration()
            
            # 4. 相关性分析
            self.correlation_analysis()
            
            # 5. 风险分析
            self.risk_analysis()
            
            # 6. 示例预测
            print("\n" + "="*50)
            print("🎯 示例客户信用评级预测")
            print("="*50)
            
            # 创建几个示例客户
            test_customers = [
                {
                    'name': '高收入低风险客户',
                    'info': {
                        '年龄': 45, '年收入': 150000, '工作年限': 15, '教育水平': '本科',
                        '房产情况': '全款房', '债务收入比': 0.2, '逾期次数': 0,
                        '银行关系年限': 10.0, '储蓄金额': 100000
                    }
                },
                {
                    'name': '年轻高风险客户',
                    'info': {
                        '年龄': 25, '年收入': 40000, '工作年限': 2, '教育水平': '高中',
                        '房产情况': '无房', '债务收入比': 0.7, '逾期次数': 3,
                        '银行关系年限': 1.0, '储蓄金额': 5000
                    }
                },
                {
                    'name': '中等收入稳定客户',
                    'info': {
                        '年龄': 35, '年收入': 80000, '工作年限': 8, '教育水平': '本科',
                        '房产情况': '有房贷', '债务收入比': 0.3, '逾期次数': 1,
                        '银行关系年限': 5.0, '储蓄金额': 50000
                    }
                }
            ]
            
            for customer in test_customers:
                print(f"\n--- {customer['name']} ---")
                self.predict_single_customer(customer['info'])
            
            # 7. 保存结果
            print("\n" + "="*50)
            print("💾 保存分析结果")
            print("="*50)
            
            self.data.to_csv('银行客户信用分析数据.csv', index=False, encoding='utf-8-sig')
            print("✅ 完整数据已保存到: 银行客户信用分析数据.csv")
            
            # 保存统计摘要
            summary_stats = {
                '总客户数': len(self.data),
                '优秀客户数': len(self.data[self.data['信用评级'] == '优秀']),
                '良好客户数': len(self.data[self.data['信用评级'] == '良好']),
                '一般客户数': len(self.data[self.data['信用评级'] == '一般']),
                '差客户数': len(self.data[self.data['信用评级'] == '差']),
                '平均信用评分': self.data['信用评分'].mean(),
                '平均年收入': self.data['年收入'].mean(),
                '平均债务收入比': self.data['债务收入比'].mean()
            }
            
            summary_df = pd.DataFrame(list(summary_stats.items()), columns=['指标', '数值'])
            summary_df.to_csv('信用分析摘要.csv', index=False, encoding='utf-8-sig')
            print("✅ 分析摘要已保存到: 信用分析摘要.csv")
            
            print("\n🎉 分析完成！主要发现：")
            print("="*50)
            total_customers = len(self.data)
            excellent_pct = len(self.data[self.data['信用评级'] == '优秀']) / total_customers * 100
            poor_pct = len(self.data[self.data['信用评级'] == '差']) / total_customers * 100
            avg_score = self.data['信用评分'].mean()
            
            print(f"1. 📊 数据集包含 {total_customers} 个客户样本")
            print(f"2. 🏆 优秀客户占比: {excellent_pct:.1f}%")
            print(f"3. ⚠️ 高风险客户占比: {poor_pct:.1f}%")
            print(f"4. 📈 平均信用评分: {avg_score:.1f}分")
            print(f"5. 🔑 主要风险因素: 逾期次数、债务收入比")
            print(f"6. 💡 主要正面因素: 高收入、房产、教育水平")
            
            return self.data
            
        except Exception as e:
            print(f"❌ 分析过程中出现错误: {e}")
            import traceback
            traceback.print_exc()
            return None

def main():
    """主函数"""
    print("🏦 基础版银行客户信用评分分析系统")
    print("使用基于规则的信用评分算法")
    print("="*60)
    
    # 创建分析实例
    analysis = BasicBankCreditAnalysis()
    
    # 运行完整分析
    results = analysis.run_complete_analysis()
    
    if results is not None:
        print("\n✅ 系统运行成功！")
        print("📄 可以查看生成的CSV文件了解详细数据")
        print("📊 可以查看生成的图表了解数据分布")
    else:
        print("\n❌ 系统运行出现问题")
    
    return analysis, results

if __name__ == "__main__":
    try:
        analyzer, analysis_results = main()
    except KeyboardInterrupt:
        print("\n\n👋 分析已终止")
    except Exception as e:
        print(f"❌ 运行出错: {e}")
        import traceback
        traceback.print_exc()
