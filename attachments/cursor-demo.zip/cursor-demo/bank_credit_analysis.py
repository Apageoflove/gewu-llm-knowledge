#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
银行客户信用评分分析系统
Bank Customer Credit Scoring Analysis

功能：
1. 生成模拟银行客户数据
2. 数据预处理和特征工程
3. 多种机器学习模型训练和评估
4. 可视化分析和结果展示
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class BankCreditAnalysis:
    def __init__(self):
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.scaler = StandardScaler()
        self.models = {}
        self.results = {}
        
    def generate_sample_data(self, n_samples=2000):
        """生成模拟银行客户数据"""
        print("正在生成银行客户样本数据...")
        
        np.random.seed(42)
        
        # 基础信息
        age = np.random.normal(40, 12, n_samples).astype(int)
        age = np.clip(age, 18, 80)
        
        gender = np.random.choice(['男', '女'], n_samples)
        
        # 收入相关
        income = np.random.lognormal(10.5, 0.8, n_samples)
        income = np.clip(income, 20000, 500000).astype(int)
        
        # 工作年限
        work_years = np.random.exponential(8, n_samples)
        work_years = np.clip(work_years, 0, 40).astype(int)
        
        # 教育水平
        education = np.random.choice(['高中', '大专', '本科', '硕士', '博士'], 
                                   n_samples, p=[0.2, 0.25, 0.35, 0.15, 0.05])
        
        # 婚姻状况
        marital_status = np.random.choice(['未婚', '已婚', '离异'], 
                                        n_samples, p=[0.3, 0.6, 0.1])
        
        # 房产情况
        house_ownership = np.random.choice(['无房', '有房贷', '全款房'], 
                                         n_samples, p=[0.3, 0.5, 0.2])
        
        # 历史贷款次数
        loan_history = np.random.poisson(2, n_samples)
        loan_history = np.clip(loan_history, 0, 10)
        
        # 信用卡数量
        credit_cards = np.random.poisson(1.5, n_samples)
        credit_cards = np.clip(credit_cards, 0, 8)
        
        # 债务收入比
        debt_to_income = np.random.beta(2, 5, n_samples) * 0.8
        
        # 储蓄金额
        savings = income * np.random.uniform(0.1, 2.0, n_samples)
        savings = savings.astype(int)
        
        # 逾期次数
        overdue_times = np.random.poisson(0.5, n_samples)
        overdue_times = np.clip(overdue_times, 0, 10)
        
        # 银行关系年限
        bank_relation_years = np.random.exponential(5, n_samples)
        bank_relation_years = np.clip(bank_relation_years, 0.5, 25)
        
        # 生成信用评级（目标变量）
        # 基于多个因素计算信用评分
        credit_score = (
            (income / 1000) * 0.3 +
            work_years * 0.2 +
            (age - 18) * 0.1 +
            (5 - overdue_times) * 0.2 +
            bank_relation_years * 0.1 +
            (1 - debt_to_income) * 0.3 +
            np.random.normal(0, 5, n_samples)
        )
        
        # 将评分转换为分类
        credit_rating = pd.cut(credit_score, 
                             bins=[-np.inf, 20, 40, 60, np.inf],
                             labels=['差', '一般', '良好', '优秀'])
        
        # 创建DataFrame
        self.data = pd.DataFrame({
            '年龄': age,
            '性别': gender,
            '年收入': income,
            '工作年限': work_years,
            '教育水平': education,
            '婚姻状况': marital_status,
            '房产情况': house_ownership,
            '历史贷款次数': loan_history,
            '信用卡数量': credit_cards,
            '债务收入比': debt_to_income.round(3),
            '储蓄金额': savings,
            '逾期次数': overdue_times,
            '银行关系年限': bank_relation_years.round(1),
            '信用评级': credit_rating
        })
        
        print(f"成功生成 {n_samples} 条银行客户数据")
        return self.data
    
    def data_exploration(self):
        """数据探索性分析"""
        print("\n" + "="*50)
        print("数据探索性分析")
        print("="*50)
        
        # 基本信息
        print("\n1. 数据基本信息:")
        print(f"数据维度: {self.data.shape}")
        print(f"缺失值: {self.data.isnull().sum().sum()}")
        
        print("\n2. 数值特征统计:")
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        print(self.data[numeric_cols].describe())
        
        print("\n3. 信用评级分布:")
        print(self.data['信用评级'].value_counts())
        print("\n信用评级比例:")
        print(self.data['信用评级'].value_counts(normalize=True).round(3))
        
        # 可视化
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 信用评级分布
        self.data['信用评级'].value_counts().plot(kind='bar', ax=axes[0,0], color='skyblue')
        axes[0,0].set_title('信用评级分布')
        axes[0,0].set_xlabel('信用评级')
        axes[0,0].set_ylabel('客户数量')
        
        # 年龄分布
        axes[0,1].hist(self.data['年龄'], bins=20, color='lightgreen', alpha=0.7)
        axes[0,1].set_title('年龄分布')
        axes[0,1].set_xlabel('年龄')
        axes[0,1].set_ylabel('频数')
        
        # 收入分布
        axes[1,0].hist(self.data['年收入'], bins=30, color='lightcoral', alpha=0.7)
        axes[1,0].set_title('年收入分布')
        axes[1,0].set_xlabel('年收入')
        axes[1,0].set_ylabel('频数')
        
        # 债务收入比 vs 信用评级
        sns.boxplot(data=self.data, x='信用评级', y='债务收入比', ax=axes[1,1])
        axes[1,1].set_title('信用评级与债务收入比关系')
        
        plt.tight_layout()
        plt.show()
        
    def correlation_analysis(self):
        """相关性分析"""
        print("\n" + "="*50)
        print("相关性分析")
        print("="*50)
        
        # 数值特征相关性矩阵
        numeric_data = self.data.select_dtypes(include=[np.number])
        correlation_matrix = numeric_data.corr()
        
        plt.figure(figsize=(12, 10))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, fmt='.2f')
        plt.title('数值特征相关性矩阵')
        plt.tight_layout()
        plt.show()
        
        # 特征与信用评级的关系
        self.categorical_analysis()
        
    def categorical_analysis(self):
        """类别特征分析"""
        categorical_cols = ['性别', '教育水平', '婚姻状况', '房产情况']
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        axes = axes.ravel()
        
        for i, col in enumerate(categorical_cols):
            pd.crosstab(self.data[col], self.data['信用评级']).plot(kind='bar', 
                                                                  ax=axes[i], 
                                                                  rot=45)
            axes[i].set_title(f'{col} vs 信用评级')
            axes[i].legend(title='信用评级', bbox_to_anchor=(1.05, 1), loc='upper left')
        
        plt.tight_layout()
        plt.show()
        
    def feature_engineering(self):
        """特征工程"""
        print("\n" + "="*50)
        print("特征工程")
        print("="*50)
        
        # 创建特征副本
        features_df = self.data.copy()
        
        # 1. 创建新特征
        features_df['收入年龄比'] = features_df['年收入'] / features_df['年龄']
        features_df['储蓄收入比'] = features_df['储蓄金额'] / features_df['年收入']
        features_df['平均年收入'] = features_df['年收入'] / features_df['工作年限'].replace(0, 1)
        features_df['风险指数'] = (features_df['逾期次数'] + features_df['债务收入比'] * 10) / 2
        
        # 2. 对类别变量进行编码
        le_dict = {}
        categorical_cols = ['性别', '教育水平', '婚姻状况', '房产情况']
        
        for col in categorical_cols:
            le = LabelEncoder()
            features_df[f'{col}_编码'] = le.fit_transform(features_df[col])
            le_dict[col] = le
        
        # 3. 对目标变量编码
        target_le = LabelEncoder()
        features_df['信用评级_编码'] = target_le.fit_transform(features_df['信用评级'])
        
        # 4. 选择最终特征
        feature_columns = [
            '年龄', '年收入', '工作年限', '历史贷款次数', '信用卡数量', 
            '债务收入比', '储蓄金额', '逾期次数', '银行关系年限',
            '收入年龄比', '储蓄收入比', '平均年收入', '风险指数',
            '性别_编码', '教育水平_编码', '婚姻状况_编码', '房产情况_编码'
        ]
        
        X = features_df[feature_columns]
        y = features_df['信用评级_编码']
        
        # 5. 划分训练集和测试集
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        
        # 6. 特征标准化
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        print(f"特征工程完成！")
        print(f"训练集大小: {self.X_train.shape}")
        print(f"测试集大小: {self.X_test.shape}")
        print(f"特征数量: {len(feature_columns)}")
        
        return target_le, le_dict
        
    def train_models(self):
        """训练多个机器学习模型"""
        print("\n" + "="*50)
        print("模型训练与评估")
        print("="*50)
        
        # 定义模型
        models = {
            '逻辑回归': LogisticRegression(random_state=42, max_iter=1000),
            '随机森林': RandomForestClassifier(n_estimators=100, random_state=42),
            '梯度提升': GradientBoostingClassifier(random_state=42),
            '支持向量机': SVC(probability=True, random_state=42)
        }
        
        self.models = {}
        self.results = {}
        
        for name, model in models.items():
            print(f"\n训练 {name} 模型...")
            
            # 选择合适的数据
            if name == '支持向量机':
                X_train_data = self.X_train_scaled
                X_test_data = self.X_test_scaled
            else:
                X_train_data = self.X_train
                X_test_data = self.X_test
            
            # 训练模型
            model.fit(X_train_data, self.y_train)
            
            # 预测
            y_pred = model.predict(X_test_data)
            y_pred_proba = model.predict_proba(X_test_data)
            
            # 评估
            accuracy = model.score(X_test_data, self.y_test)
            auc_score = roc_auc_score(self.y_test, y_pred_proba, multi_class='ovr')
            
            # 交叉验证
            cv_scores = cross_val_score(model, X_train_data, self.y_train, cv=5)
            
            self.models[name] = model
            self.results[name] = {
                'accuracy': accuracy,
                'auc_score': auc_score,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'y_pred': y_pred,
                'y_pred_proba': y_pred_proba
            }
            
            print(f"{name} - 准确率: {accuracy:.4f}, AUC: {auc_score:.4f}, "
                  f"CV均值: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")
        
        return self.models, self.results
    
    def model_evaluation(self):
        """模型评估和可视化"""
        print("\n" + "="*50)
        print("详细模型评估")
        print("="*50)
        
        # 结果对比
        results_df = pd.DataFrame({
            name: {
                '准确率': results['accuracy'],
                'AUC分数': results['auc_score'],
                'CV均值': results['cv_mean'],
                'CV标准差': results['cv_std']
            }
            for name, results in self.results.items()
        }).T
        
        print("\n模型性能对比:")
        print(results_df.round(4))
        
        # 可视化对比
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # 准确率对比
        results_df['准确率'].plot(kind='bar', ax=axes[0,0], color='skyblue')
        axes[0,0].set_title('模型准确率对比')
        axes[0,0].set_ylabel('准确率')
        axes[0,0].tick_params(axis='x', rotation=45)
        
        # AUC分数对比
        results_df['AUC分数'].plot(kind='bar', ax=axes[0,1], color='lightgreen')
        axes[0,1].set_title('模型AUC分数对比')
        axes[0,1].set_ylabel('AUC分数')
        axes[0,1].tick_params(axis='x', rotation=45)
        
        # 交叉验证结果
        cv_data = [self.results[name]['cv_mean'] for name in self.results.keys()]
        cv_std = [self.results[name]['cv_std'] for name in self.results.keys()]
        x_pos = range(len(self.results))
        
        axes[1,0].bar(x_pos, cv_data, yerr=cv_std, capsize=5, color='lightcoral')
        axes[1,0].set_title('交叉验证结果')
        axes[1,0].set_ylabel('CV准确率')
        axes[1,0].set_xticks(x_pos)
        axes[1,0].set_xticklabels(self.results.keys(), rotation=45)
        
        # 最佳模型的混淆矩阵
        best_model_name = max(self.results.keys(), 
                            key=lambda x: self.results[x]['accuracy'])
        best_pred = self.results[best_model_name]['y_pred']
        
        cm = confusion_matrix(self.y_test, best_pred)
        sns.heatmap(cm, annot=True, fmt='d', ax=axes[1,1], cmap='Blues')
        axes[1,1].set_title(f'{best_model_name} 混淆矩阵')
        axes[1,1].set_xlabel('预测值')
        axes[1,1].set_ylabel('真实值')
        
        plt.tight_layout()
        plt.show()
        
        # 详细分类报告
        print(f"\n最佳模型 ({best_model_name}) 详细分类报告:")
        print(classification_report(self.y_test, best_pred, 
                                  target_names=['差', '一般', '良好', '优秀']))
        
    def feature_importance_analysis(self):
        """特征重要性分析"""
        print("\n" + "="*50)
        print("特征重要性分析")
        print("="*50)
        
        # 获取随机森林的特征重要性
        rf_model = self.models['随机森林']
        feature_names = self.X_train.columns
        importance_scores = rf_model.feature_importances_
        
        # 创建特征重要性DataFrame
        feature_importance_df = pd.DataFrame({
            '特征': feature_names,
            '重要性': importance_scores
        }).sort_values('重要性', ascending=False)
        
        print("\n特征重要性排序:")
        print(feature_importance_df)
        
        # 可视化特征重要性
        plt.figure(figsize=(12, 8))
        top_features = feature_importance_df.head(10)
        plt.barh(range(len(top_features)), top_features['重要性'])
        plt.yticks(range(len(top_features)), top_features['特征'])
        plt.xlabel('重要性分数')
        plt.title('Top 10 特征重要性')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.show()
        
        return feature_importance_df
    
    def predict_customer_credit(self, customer_data):
        """预测新客户的信用评级"""
        best_model_name = max(self.results.keys(), 
                            key=lambda x: self.results[x]['accuracy'])
        best_model = self.models[best_model_name]
        
        # 预处理客户数据
        if best_model_name == '支持向量机':
            customer_scaled = self.scaler.transform([customer_data])
            prediction = best_model.predict(customer_scaled)[0]
            probability = best_model.predict_proba(customer_scaled)[0]
        else:
            prediction = best_model.predict([customer_data])[0]
            probability = best_model.predict_proba([customer_data])[0]
        
        credit_labels = ['差', '一般', '良好', '优秀']
        predicted_label = credit_labels[prediction]
        
        print(f"\n使用 {best_model_name} 模型预测结果:")
        print(f"预测信用评级: {predicted_label}")
        print("各等级概率:")
        for i, (label, prob) in enumerate(zip(credit_labels, probability)):
            print(f"  {label}: {prob:.3f}")
        
        return predicted_label, probability
    
    def run_complete_analysis(self):
        """运行完整的信用评分分析"""
        print("开始银行客户信用评分分析...")
        
        # 1. 生成数据
        self.generate_sample_data()
        
        # 2. 数据探索
        self.data_exploration()
        
        # 3. 相关性分析
        self.correlation_analysis()
        
        # 4. 特征工程
        target_le, le_dict = self.feature_engineering()
        
        # 5. 模型训练
        self.train_models()
        
        # 6. 模型评估
        self.model_evaluation()
        
        # 7. 特征重要性分析
        feature_importance = self.feature_importance_analysis()
        
        print("\n" + "="*50)
        print("分析完成！主要发现：")
        print("="*50)
        
        best_model = max(self.results.keys(), 
                        key=lambda x: self.results[x]['accuracy'])
        best_accuracy = self.results[best_model]['accuracy']
        
        print(f"1. 最佳模型: {best_model} (准确率: {best_accuracy:.3f})")
        print(f"2. 最重要的特征: {feature_importance.iloc[0]['特征']}")
        print(f"3. 数据集包含 {len(self.data)} 个客户样本")
        print(f"4. 信用评级分布相对均衡")
        
        # 示例预测
        print("\n" + "="*50)
        print("示例客户信用评级预测")
        print("="*50)
        
        # 创建一个示例客户
        example_customer = [
            35,      # 年龄
            80000,   # 年收入
            8,       # 工作年限
            2,       # 历史贷款次数
            2,       # 信用卡数量
            0.3,     # 债务收入比
            50000,   # 储蓄金额
            0,       # 逾期次数
            5.0,     # 银行关系年限
            80000/35,# 收入年龄比
            50000/80000, # 储蓄收入比
            80000/8, # 平均年收入
            (0 + 0.3*10)/2, # 风险指数
            1,       # 性别编码
            2,       # 教育水平编码
            1,       # 婚姻状况编码
            1        # 房产情况编码
        ]
        
        predicted_credit, probabilities = self.predict_customer_credit(example_customer)
        
        return {
            'data': self.data,
            'models': self.models,
            'results': self.results,
            'feature_importance': feature_importance,
            'best_model': best_model
        }

def main():
    """主函数"""
    # 创建分析实例
    analysis = BankCreditAnalysis()
    
    # 运行完整分析
    results = analysis.run_complete_analysis()
    
    print("\n" + "="*50)
    print("银行客户信用评分分析系统使用说明")
    print("="*50)
    print("1. 数据已保存在 analysis.data 中")
    print("2. 训练好的模型保存在 analysis.models 中")
    print("3. 可以使用 analysis.predict_customer_credit() 预测新客户")
    print("4. 所有评估结果保存在 analysis.results 中")
    
    return analysis, results

if __name__ == "__main__":
    # 运行分析
    analyzer, analysis_results = main()
    
    # 保存数据到CSV
    print("\n保存数据到文件...")
    analyzer.data.to_csv('bank_customer_data.csv', index=False, encoding='utf-8-sig')
    print("数据已保存到 bank_customer_data.csv")
