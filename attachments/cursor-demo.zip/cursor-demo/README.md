# AI智能体个人主页

一个现代化、响应式的AI智能体个人主页，展示AI智能体的能力、技能和应用场景。

## 功能特色

### 🎨 设计特色
- **现代化设计**：采用渐变色彩和玻璃形态设计
- **响应式布局**：完美适配桌面、平板和移动设备
- **流畅动画**：丰富的CSS动画和JavaScript交互效果
- **AI主题**：专门为AI智能体设计的视觉元素

### 🚀 核心功能
- **智能导航**：平滑滚动和当前页面高亮
- **技能展示**：动态进度条展示各项AI技能
- **项目案例**：展示AI智能体的应用场景
- **互动聊天**：演示AI对话功能
- **动效丰富**：脉冲动画、粒子效果、视差滚动

### 📱 响应式特性
- 移动端汉堡菜单
- 自适应布局
- 触摸友好的交互
- 优化的移动端体验

## 文件结构

```
cursor-demo/
├── index.html          # 主页面结构
├── style.css           # 样式文件
├── script.js           # JavaScript交互功能
├── README.md           # 项目说明
├── note.md            # 其他笔记
└── test.py            # Python测试文件
```

## 主要组件

### 1. 导航栏 (Navigation)
- 固定顶部导航
- 滚动时背景变化
- 当前页面高亮显示

### 2. 主页横幅 (Hero Section)
- AI智能体介绍
- 动态统计数据
- 脉冲动画效果
- 渐变背景

### 3. 关于我 (About Section)
- AI智能体简介
- 核心特性展示
- 神经网络动画

### 4. 技能展示 (Skills Section)
- 6个核心技能模块
- 动态进度条
- 悬浮效果

### 5. 应用场景 (Projects Section)
- 4个主要应用场景
- 卡片式布局
- 标签系统

### 6. 联系方式 (Contact Section)
- 交互方式介绍
- 实时聊天演示
- 消息动画

### 7. 页脚 (Footer)
- 快速链接
- 服务信息
- 版权声明

## 技术特性

### CSS特性
- CSS3动画和过渡
- Flexbox和Grid布局
- 自定义CSS变量
- 响应式设计
- 玻璃形态效果

### JavaScript功能
- 交集观察器API
- 平滑滚动
- 动态进度条
- 打字机效果
- 聊天演示
- 移动端菜单

### 浏览器兼容性
- 现代浏览器支持
- CSS Grid和Flexbox
- ES6+语法
- IntersectionObserver API

## 使用方法

1. **直接打开**
   ```bash
   # 在浏览器中打开 index.html
   open index.html
   ```

2. **本地服务器**
   ```bash
   # 使用Python启动本地服务器
   python -m http.server 8000
   # 然后访问 http://localhost:8000
   ```

3. **Live Server**
   - 使用VS Code的Live Server插件
   - 右键点击index.html选择"Open with Live Server"

## 自定义配置

### 修改主题颜色
在`style.css`文件的`:root`部分修改CSS变量：

```css
:root {
    --primary-color: #2563eb;    /* 主色调 */
    --secondary-color: #1e40af;  /* 辅助色 */
    --accent-color: #3b82f6;     /* 强调色 */
}
```

### 修改内容
- **个人信息**：编辑`index.html`中的文本内容
- **技能数据**：修改进度条的`data-progress`属性
- **项目信息**：更新项目卡片的内容和标签

### 添加新功能
在`script.js`文件中可以添加新的交互功能：
- 更多动画效果
- 数据可视化
- API集成
- 主题切换

## 性能优化

- 使用了节流和防抖函数
- 懒加载图片支持
- CSS动画硬件加速
- 最小化重排和重绘

## 浏览器支持

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 部署建议

### GitHub Pages
1. 创建GitHub仓库
2. 上传文件到仓库
3. 在Settings中启用GitHub Pages

### Netlify
1. 连接GitHub仓库
2. 自动部署

### Vercel
1. 导入项目
2. 一键部署

## 维护和更新

- 定期更新技能数据
- 添加新的项目案例
- 优化性能和用户体验
- 保持内容的时效性

## 注意事项

1. 确保网络连接以加载外部字体和图标
2. 现代浏览器获得最佳体验
3. 移动端测试各项功能
4. 定期备份自定义内容

---

这个AI智能体主页展示了现代Web开发的最佳实践，结合了美观的设计和丰富的交互功能，完美展示了AI智能体的专业形象和技术能力。
