import os
os.system('swift sft --model xxx --dataset xxx')

