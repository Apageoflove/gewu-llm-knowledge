swift web-ui --lang zh
# or en
swift web-ui --lang en