CUDA_VISIBLE_DEVICES=0 \
swift export \
    --adapters output/v1-20250518-092615/checkpoint-6 \
    --push_to_hub true \
    --hub_model_id 'utoban/Qwen2-1.5B-3' \
    --hub_token 'cdd02b54-c2be-422b-bb85-0c464d2275ad' \
    --use_hf false