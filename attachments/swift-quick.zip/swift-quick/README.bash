基础环境：ubuntu22.04-cuda12.4.0-py311-torch2.6.0-1.26.0-LLM
pip install ms-swift -U

# deepspeed zero2/zero3
pip install deepspeed -U

pip install datasets==2.18.0

pip install transformers -U

chmod 777 *

#报错RuntimeError: CUDA error: invalid device ordinal
修改fsdp_offload.json ："num_processes": 1

zip -r -o checkpoint-6-merged.zip checkpoint-6-merged -x "*.safetensors" "*.pt" "*.bin" "vocab.json" "tokenizer.json" "merges.txt"
zip -r -o images.zip images

#监控显卡
nvidia-smi
nvidia-smi -l
watch -n 1 nvidia-smi
nvidia-smi topo -m

pip install nvitop
nvitop -m auto
nvitop -m compact
nvitop -m full