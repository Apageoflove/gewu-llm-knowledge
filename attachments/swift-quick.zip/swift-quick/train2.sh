#界面推理
swift app --model 'Qwen/Qwen2-1.5B' --studio_title My-Awesome-Space --stream true

#界面推理(微调后的模型)
swift app --model 'Qwen/Qwen2-1.5B' --adapters output/v3-20250516-172331/checkpoint-6 --stream true