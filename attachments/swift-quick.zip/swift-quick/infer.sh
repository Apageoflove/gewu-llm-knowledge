# 使用交互式命令行进行推理
CUDA_VISIBLE_DEVICES=0 \
swift infer \
    --adapters output/v1-20250518-092615/checkpoint-6 \
    --stream true \
    --temperature 0 \
    --max_new_tokens 2048