
#微调命令
llamafactory-cli train examples/train_lora/llama3_lora_sft.yaml
#推理命令
llamafactory-cli chat examples/inference/llama3_lora_sft.yaml
#合并命令
llamafactory-cli export examples/merge_lora/llama3_lora_sft.yaml

#配置推理服务端口，可以支持批量推理
API_PORT=8000 CUDA_VISIBLE_DEVICES=0 llamafactory-cli api examples/inference/llama3_lora_sft.yaml

#通过vllm进行推理
python scripts/vllm_infer.py --model_name_or_path /mnt/workspace/LLaMA-Factory/output/llama3_lora_sft --dataset alpaca_zh_demo