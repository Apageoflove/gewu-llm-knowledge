# 导入操作系统相关的功能模块，用于设置环境变量等操作
import os

# 设置使用的GPU设备号为0，例如在有多个GPU的机器上，这行代码指定只使用第一个GPU
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# 从swift.llm模块导入多个类和函数，这些是用于大语言模型推理的核心组件
# PtEngine: PyTorch推理引擎，用于执行模型推理
# RequestConfig: 配置推理请求的参数，如最大生成token数、温度等
# safe_snapshot_download: 安全下载模型检查点的函数
# get_model_tokenizer: 获取模型和分词器的函数
# get_template: 获取对话模板的函数
# InferRequest: 定义推理请求的类
from swift.llm import (
    PtEngine, RequestConfig, safe_snapshot_download, get_model_tokenizer, get_template, InferRequest
)
# 导入Swift类，用于加载和管理微调后的模型
from swift.tuners import Swift

# 请调整下面几行参数，根据实际需求修改
# 指定基础模型，这里使用的是通义千问的Qwen2-1.5B模型
model = 'Qwen/Qwen2-1.5B'
# 加载LoRA微调后的检查点，safe_snapshot_download会安全地下载或加载本地的检查点文件
# 例如，这里加载的是output目录下特定版本和时间的检查点
lora_checkpoint = safe_snapshot_download('output/v8-20250517-101314/checkpoint-6')  # 修改成你的checkpoint_dir路径
# 设置对话模板类型，None表示使用模型默认的模板类型
# 不同模型可能有不同的对话格式，如ChatML、Alpaca等
template_type = None  # None: 使用对应模型默认的template_type
# 设置系统提示词，定义AI助手的角色和行为
# 例如这里设置为"你是一个有帮助的助手"，会影响模型的回复风格
default_system = "You are a helpful assistant."  # None: 使用对应模型默认的default_system

# 加载模型和对话模板
# 获取预训练模型和对应的分词器
model, tokenizer = get_model_tokenizer(model)
# 使用Swift加载模型并应用LoRA微调参数
# 例如，将Qwen2-1.5B与我们的LoRA参数结合，得到一个定制化的模型
model = Swift.from_pretrained(model, lora_checkpoint)
# 如果没有指定template_type，则使用模型元数据中的默认模板
template_type = template_type or model.model_meta.template
# 根据模板类型、分词器和系统提示词创建对话模板
# 模板负责格式化用户输入和模型输出，确保符合模型训练时的格式
template = get_template(template_type, tokenizer, default_system=default_system)
# 创建PyTorch推理引擎，将模型和模板组合起来，设置最大批处理大小为2
# 批处理可以同时处理多个请求，提高推理效率
engine = PtEngine.from_model_template(model, template, max_batch_size=2)
# 创建请求配置，设置最大生成token数为512，温度为0
# 温度为0表示总是选择概率最高的token，使输出更确定性
request_config = RequestConfig(max_tokens=512, temperature=0)

# 这里使用了2个infer_request来展示批量推理功能
# 创建推理请求列表，每个请求包含一组对话消息
infer_requests = [
    # 第一个请求：简单的单轮对话，用户问"你是谁？"
    InferRequest(messages=[{'role': 'user', 'content': 'who are you?'}]),
    # 第二个请求：多轮对话，包含用户提问、助手回复和用户的后续提问
    # 这个例子模拟了用户先问"浙江的省会在哪？"，然后又问"这里有什么好吃的"
    InferRequest(messages=[{'role': 'user', 'content': '浙江的省会在哪？'},
                           {'role': 'assistant', 'content': '浙江的省会在哪？'},
                           {'role': 'user', 'content': '这里有什么好吃的'}, ]),
]
# 执行推理，获取响应列表
# engine.infer会处理所有请求并返回对应的响应
resp_list = engine.infer(infer_requests, request_config)
# 获取第一个请求的用户输入内容，用于后续打印
query0 = infer_requests[0].messages[0]['content']
# 打印第一个请求的模型回复
# resp_list[0]是第一个请求的响应，choices[0]是第一个生成选项，message.content是生成的文本内容
print(f'response0: {resp_list[0].choices[0].message.content}')
# 打印第二个请求的模型回复
print(f'response1: {resp_list[1].choices[0].message.content}')
