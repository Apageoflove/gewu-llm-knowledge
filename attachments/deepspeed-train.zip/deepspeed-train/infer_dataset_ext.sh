CUDA_VISIBLE_DEVICES=0 \
swift infer \
    --adapters output/v1-20250515-102306/checkpoint-1 \
    --infer_backend pt \
    --temperature 0 \
    --max_new_tokens 2048 \
    --val_dataset 'AI-ModelScope/alpaca-gpt4-data-zh#10 \
    --max_batch_size 1