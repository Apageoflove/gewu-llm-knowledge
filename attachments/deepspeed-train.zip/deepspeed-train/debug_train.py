from swift.llm import sft_main, TrainArguments  # 从swift.llm模块导入sft_main函数和TrainArguments类，用于大语言模型的微调训练

result = sft_main(TrainArguments(  # 调用sft_main函数进行模型训练，并传入TrainArguments参数配置，将训练结果保存到result变量
    model='Qwen/Qwen2-1.5B',  # 指定要训练的基础模型，这里使用的是通义千问的Qwen2-1.5B模型，相当于选择了训练的"原材料"
    train_type='lora',  # 使用LoRA训练方法，这是一种参数高效微调技术，只训练少量参数，节省显存和时间，就像只修改房子的装饰而不改变结构
    dataset=['swift/self-cognition#100'],  # 指定训练数据集，使用swift/self-cognition数据集的第10个版本，数据集就像是教材，用来教模型新知识
    torch_dtype='bfloat16'  # 设置模型参数的数据类型为bfloat16，这种格式可以在保持精度的同时减少内存占用，类似于用压缩格式存储图片
))
print(result)  # 打印训练结果，可以查看训练过程中的各项指标和最终效果
