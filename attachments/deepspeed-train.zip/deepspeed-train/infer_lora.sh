CUDA_VISIBLE_DEVICES=0 \
swift infer \
    --adapters output/v8-20250517-101314/checkpoint-6 \
    --infer_backend pt \
    --stream true \
    --temperature 0 \
    --max_new_tokens 2048