# c:\\users\用户名\.cache\huggingface\ ，修改环境变量 setx HF_HOME "D:\software\huggingface"

#创建python环境
conda create --name qlora-env  python=3.9
conda activate qlora-env

pip install transformers accelerate peft
pip install datasets bitsandbytes einops wandb

pip install trl==0.12.2

pip install transformers peft datasets evaluate accelerate torch bitsandbytes