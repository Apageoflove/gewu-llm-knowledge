# 安装必要的库
# pip install -q -U trl transformers accelerate git+https://github.com/huggingface/peft.git
# pip install -q datasets bitsandbytes einops wandb

# 导入数据集加载工具
from datasets import load_dataset

# 原始数据集注释：Human和Assistant对话格式
# dataset_name = "timdettmers/openassistant-guanaco" ###Human ,.,,,,,, ###Assistant

# 选择法语小说数据集
dataset_name = 'PericlesSavio/novel17_test'  # 法语小说
# 加载数据集的训练部分，只选择前2条数据
dataset = load_dataset(dataset_name, split="train").select(range(2))

# 导入必要的PyTorch和Transformers库
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, AutoTokenizer

# 指定预训练模型名称
model_name = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"

# 配置量化参数，用于减少模型内存占用
# 使用4位量化可以显著减少内存需求，同时保持模型性能
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,  # 启用4位量化
    bnb_4bit_quant_type="nf4",  # 使用nf4量化类型，对语言模型更友好
    bnb_4bit_compute_dtype=torch.float16,  # 计算时使用float16精度
)

# 加载预训练的因果语言模型，应用量化配置
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    quantization_config=bnb_config,
    trust_remote_code=True  # 允许执行模型仓库中的代码
)
# 禁用模型缓存以节省内存，但可能会降低推理速度
model.config.use_cache = False

# 加载与模型匹配的分词器
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
# 设置填充标记为结束标记，确保一致性
tokenizer.pad_token = tokenizer.eos_token

# 导入PEFT库中的LoRA相关功能，用于参数高效微调
from peft import LoraConfig, get_peft_model

# 设置LoRA参数
lora_alpha = 16  # 缩放参数，控制LoRA更新的强度
lora_dropout = 0.1  # dropout率，防止过拟合
lora_r = 64  # LoRA矩阵的秩，越高越有表现力但参数更多

# 创建LoRA配置
peft_config = LoraConfig(
    lora_alpha=lora_alpha,
    lora_dropout=lora_dropout,
    r=lora_r,
    bias="none",  # 不对偏置项进行微调
    task_type="CAUSAL_LM"  # 指定任务类型为因果语言建模
)

# 导入训练参数配置类
from transformers import TrainingArguments

# 设置训练参数
output_dir = "./results"  # 输出目录，保存模型和日志
per_device_train_batch_size = 4  # 每个设备的训练批次大小
gradient_accumulation_steps = 4  # 梯度累积步数，相当于增大批次大小
optim = "paged_adamw_32bit"  # 优化器类型，使用内存优化的AdamW
save_steps = 1  # 每100步保存一次模型
logging_steps = 1  # 每10步记录一次日志
learning_rate = 2e-4  # 学习率
max_grad_norm = 0.3  # 梯度裁剪阈值，防止梯度爆炸
max_steps = 2  # 最大训练步数
warmup_ratio = 0.03  # 预热比例，逐渐增加学习率
lr_scheduler_type = "constant"  # 学习率调度器类型，保持恒定学习率

# 创建训练参数对象
training_arguments = TrainingArguments(
    output_dir=output_dir,
    per_device_train_batch_size=per_device_train_batch_size,
    gradient_accumulation_steps=gradient_accumulation_steps,
    optim=optim,
    save_steps=save_steps,
    logging_steps=logging_steps,
    learning_rate=learning_rate,
    fp16=True,  # 使用半精度训练加速
    max_grad_norm=max_grad_norm,
    max_steps=max_steps,
    warmup_ratio=warmup_ratio,
    group_by_length=True,  # 按长度分组，提高训练效率
    lr_scheduler_type=lr_scheduler_type,
    report_to="none",  # 禁用 wandb 报告
)

# 导入监督微调训练器
from trl import SFTTrainer

# 设置最大序列长度
max_seq_length = 512

# 创建SFT训练器
trainer = SFTTrainer(
    model=model,  # 要训练的模型
    train_dataset=dataset,  # 训练数据集
    peft_config=peft_config,  # 参数高效微调配置
    dataset_text_field="text",  # 数据集中文本字段的名称
    max_seq_length=max_seq_length,  # 最大序列长度
    tokenizer=tokenizer,  # 分词器
    args=training_arguments,  # 训练参数
)

# 将所有归一化层转换为float32精度，提高训练稳定性
for name, module in trainer.model.named_modules():
    if "norm" in name:
        module = module.to(torch.float32)

# 开始训练过程
trainer.train()

# 保存模型，处理分布式训练情况
model_to_save = trainer.model.module if hasattr(trainer.model, 'module') else trainer.model  # 处理分布式/并行训练
model_to_save.save_pretrained("outputs")  # 将模型保存到outputs目录

# 从保存的目录加载LoRA配置
lora_config = LoraConfig.from_pretrained('outputs')
# 将LoRA配置应用到模型
model = get_peft_model(model, lora_config)

# 测试生成文本，提示为"用巴洛克风格写篇关于冰与火的文本一"
text = "Écrire un texte dans un style baroque sur la glace et le feu ### Assistant: Si j'en luis éton"
device = "cuda:0"  # 使用第一个GPU设备

# 将输入文本转换为模型输入格式并移至GPU
inputs = tokenizer(text, return_tensors="pt").to(device)
# 生成最多50个新token的文本
outputs = model.generate(**inputs, max_new_tokens=50)
# 解码输出并打印结果
print(tokenizer.decode(outputs[0], skip_special_tokens=True))

# 将模型上传到Hugging Face Hub的注释代码（当前已注释掉）
#model.push_to_hub("llama2-qlora-finetunined-french")
