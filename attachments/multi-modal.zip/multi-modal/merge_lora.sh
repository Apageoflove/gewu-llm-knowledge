swift export \
    --adapters output/v7-20250520-075913/checkpoint-9 \
    --merge_lora true
