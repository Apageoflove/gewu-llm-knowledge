基础环境：ubuntu22.04-cuda12.4.0-py311-torch2.6.0-1.26.0-LLM
pip install ms-swift -U

pip install datasets==2.18.0

pip install transformers -U

chmod 777 *

zip -r -o v3-20250516-182814.zip v3-20250516-182814 -x "*.safetensors" "*.pt" "*.bin"

#监控显卡
nvidia-smi
nvidia-smi -l
watch -n 1 nvidia-smi
nvidia-smi topo -m

pip install nvitop
nvitop -m auto
nvitop -m compact
nvitop -m full