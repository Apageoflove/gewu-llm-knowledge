swift export \
    --adapters output/Qwen2.5-1.5B-Instruct/v0-20250518-122729/checkpoint-18 \
    --merge_lora true