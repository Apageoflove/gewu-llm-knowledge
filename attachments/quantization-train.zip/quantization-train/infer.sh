CUDA_VISIBLE_DEVICES=0 \
swift infer \
    --adapters output/Qwen2.5-1.5B-Instruct/v0-20250518-122729/checkpoint-18 \
    --infer_backend pt \
    --stream true \
    --temperature 0 \
    --max_new_tokens 2048