# mcp_server.py
from mcp.server.fastmcp import FastMCP

# 创建一个 MCP 服务器
mcp = FastMCP("mcp-server")


# 添加一个加法工具
@mcp.tool()
def add(a: int, b: int) -> int:
    """添加两个数字"""
    return a + b

# 新增一个格式化数据工具
@mcp.tool()
def get_format_data(data: str) -> int:
    """获取格式化数据"""
    return data


@mcp.resource("mcp:server_info")
def get_server_info() -> str:
    """获取服务器信息"""
    return "MCP server 版本号：1.0.0"

# 添加一个动态问候资源
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """获取个性化问候"""
    return f"Hello, {name}!"