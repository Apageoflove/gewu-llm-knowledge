#如果想使用MCP Inspector ，就引入这个包
#from mcp.server.fastmcp import FastMCP
import uuid

#如果想独立启动fastmcp server，就引入这个包
from fastmcp import FastMCP

mcp = FastMCP("sse-mcp-server")


#帮我写一mcp生成uuid的工具
@mcp.tool()
def generate_uuid() -> str:
    """生成uuid
    """
    return str(uuid.uuid4())

@mcp.tool()
def format_date(date_str: str, input_format: str = "%Y-%m-%d", output_format: str = "%Y年%m月%d日") -> str:
    """
    日期格式化工具

    参数:
    date_str: 输入的日期字符串
    input_format: 输入日期的格式，默认为"%Y-%m-%d"
    output_format: 输出日期的格式，默认为"%Y年%m月%d日"

    返回:
    格式化后的日期字符串
    """
    from datetime import datetime
    dt = datetime.strptime(date_str, input_format)
    return dt.strftime(output_format)



@mcp.tool()
def say_hello(name: str) -> str:
    return 'hello，' + name

@mcp.tool()
def add(a: float, b: float) -> float:
    """加法运算

    参数:
    a: 第一个数字
    b: 第二个数字

    返回:
    两数之和
    """
    return a + b


@mcp.tool()
def subtract(a: float, b: float) -> float:
    """减法运算

    参数:
    a: 第一个数字
    b: 第二个数字

    返回:
    两数之差 (a - b)
    """
    return a - b


@mcp.tool()
def multiply(a: float, b: float) -> float:
    """乘法运算

    参数:
    a: 第一个数字
    b: 第二个数字

    返回:
    两数之积
    """
    return a * b


@mcp.tool()
def divide(a: float, b: float) -> float:
    """除法运算

    参数:
    a: 被除数
    b: 除数

    返回:
    两数之商 (a / b)

    异常:
    ValueError: 当除数为零时
    """
    if b == 0:
        raise ValueError("除数不能为零")
    return a / b


if __name__ == "__main__":
    mcp.run(transport='sse', host="127.0.0.1", port=3001)
